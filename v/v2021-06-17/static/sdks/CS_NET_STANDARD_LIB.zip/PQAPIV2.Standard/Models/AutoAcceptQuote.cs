// <copyright file="AutoAcceptQuote.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// AutoAcceptQuote.
    /// </summary>
    public class AutoAcceptQuote
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AutoAcceptQuote"/> class.
        /// </summary>
        public AutoAcceptQuote()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoAcceptQuote"/> class.
        /// </summary>
        /// <param name="autoAcceptQuoteProp">autoAcceptQuote.</param>
        public AutoAcceptQuote(
            bool? autoAcceptQuoteProp = null)
        {
            this.AutoAcceptQuoteProp = autoAcceptQuoteProp;
        }

        /// <summary>
        /// Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.
        /// </summary>
        [JsonProperty("autoAcceptQuote", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AutoAcceptQuoteProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AutoAcceptQuote : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AutoAcceptQuote other &&
                ((this.AutoAcceptQuoteProp == null && other.AutoAcceptQuoteProp == null) || (this.AutoAcceptQuoteProp?.Equals(other.AutoAcceptQuoteProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1798811244;

            if (this.AutoAcceptQuoteProp != null)
            {
               hashCode += this.AutoAcceptQuoteProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AutoAcceptQuoteProp = {(this.AutoAcceptQuoteProp == null ? "null" : this.AutoAcceptQuoteProp.ToString())}");
        }
    }
}