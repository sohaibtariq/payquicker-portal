// <copyright file="CountryNationalityInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// CountryNationalityInformation.
    /// </summary>
    public class CountryNationalityInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CountryNationalityInformation"/> class.
        /// </summary>
        public CountryNationalityInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CountryNationalityInformation"/> class.
        /// </summary>
        /// <param name="countryOfBirth">countryOfBirth.</param>
        /// <param name="countryOfNationality">countryOfNationality.</param>
        public CountryNationalityInformation(
            Models.CountryTypesEnum? countryOfBirth = null,
            Models.CountryTypesEnum? countryOfNationality = null)
        {
            this.CountryOfBirth = countryOfBirth;
            this.CountryOfNationality = countryOfNationality;
        }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("countryOfBirth", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? CountryOfBirth { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("countryOfNationality", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? CountryOfNationality { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CountryNationalityInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CountryNationalityInformation other &&
                ((this.CountryOfBirth == null && other.CountryOfBirth == null) || (this.CountryOfBirth?.Equals(other.CountryOfBirth) == true)) &&
                ((this.CountryOfNationality == null && other.CountryOfNationality == null) || (this.CountryOfNationality?.Equals(other.CountryOfNationality) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1199803012;

            if (this.CountryOfBirth != null)
            {
               hashCode += this.CountryOfBirth.GetHashCode();
            }

            if (this.CountryOfNationality != null)
            {
               hashCode += this.CountryOfNationality.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CountryOfBirth = {(this.CountryOfBirth == null ? "null" : this.CountryOfBirth.ToString())}");
            toStringOutput.Add($"this.CountryOfNationality = {(this.CountryOfNationality == null ? "null" : this.CountryOfNationality.ToString())}");
        }
    }
}