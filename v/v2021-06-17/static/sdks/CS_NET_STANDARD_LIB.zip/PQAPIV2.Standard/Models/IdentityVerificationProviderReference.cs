// <copyright file="IdentityVerificationProviderReference.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// IdentityVerificationProviderReference.
    /// </summary>
    public class IdentityVerificationProviderReference
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityVerificationProviderReference"/> class.
        /// </summary>
        public IdentityVerificationProviderReference()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityVerificationProviderReference"/> class.
        /// </summary>
        /// <param name="idvProviderReference">idvProviderReference.</param>
        public IdentityVerificationProviderReference(
            string idvProviderReference = null)
        {
            this.IdvProviderReference = idvProviderReference;
        }

        /// <summary>
        /// IDV provider unique ID for the IDV check performed
        /// </summary>
        [JsonProperty("idvProviderReference", NullValueHandling = NullValueHandling.Ignore)]
        public string IdvProviderReference { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"IdentityVerificationProviderReference : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is IdentityVerificationProviderReference other &&
                ((this.IdvProviderReference == null && other.IdvProviderReference == null) || (this.IdvProviderReference?.Equals(other.IdvProviderReference) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1782903912;

            if (this.IdvProviderReference != null)
            {
               hashCode += this.IdvProviderReference.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IdvProviderReference = {(this.IdvProviderReference == null ? "null" : this.IdvProviderReference == string.Empty ? "" : this.IdvProviderReference)}");
        }
    }
}