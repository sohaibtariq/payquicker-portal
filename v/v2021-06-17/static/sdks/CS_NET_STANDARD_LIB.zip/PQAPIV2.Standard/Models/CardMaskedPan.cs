// <copyright file="CardMaskedPan.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// CardMaskedPan.
    /// </summary>
    public class CardMaskedPan
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CardMaskedPan"/> class.
        /// </summary>
        public CardMaskedPan()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardMaskedPan"/> class.
        /// </summary>
        /// <param name="cardNumber">cardNumber.</param>
        public CardMaskedPan(
            string cardNumber = null)
        {
            this.CardNumber = cardNumber;
        }

        /// <summary>
        /// Masked card number with only the first 6 and last 4 digits visible
        /// </summary>
        [JsonProperty("cardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CardNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CardMaskedPan : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CardMaskedPan other &&
                ((this.CardNumber == null && other.CardNumber == null) || (this.CardNumber?.Equals(other.CardNumber) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 388837931;

            if (this.CardNumber != null)
            {
               hashCode += this.CardNumber.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CardNumber = {(this.CardNumber == null ? "null" : this.CardNumber == string.Empty ? "" : this.CardNumber)}");
        }
    }
}