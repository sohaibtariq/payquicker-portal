// <copyright file="LanguageTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// LanguageTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum LanguageTypesEnum
    {
        /// <summary>
        /// EnUS.
        /// </summary>
        [EnumMember(Value = "en-US")]
        EnUS,

        /// <summary>
        /// EnGB.
        /// </summary>
        [EnumMember(Value = "en-GB")]
        EnGB,

        /// <summary>
        /// FrCA.
        /// </summary>
        [EnumMember(Value = "fr-CA")]
        FrCA,

        /// <summary>
        /// FrFR.
        /// </summary>
        [EnumMember(Value = "fr-FR")]
        FrFR,

        /// <summary>
        /// EsMX.
        /// </summary>
        [EnumMember(Value = "es-MX")]
        EsMX,

        /// <summary>
        /// EsES.
        /// </summary>
        [EnumMember(Value = "es-ES")]
        EsES,

        /// <summary>
        /// PtBR.
        /// </summary>
        [EnumMember(Value = "pt-BR")]
        PtBR,

        /// <summary>
        /// PtPT.
        /// </summary>
        [EnumMember(Value = "pt-PT")]
        PtPT,

        /// <summary>
        /// DeDE.
        /// </summary>
        [EnumMember(Value = "de-DE")]
        DeDE,

        /// <summary>
        /// ItIT.
        /// </summary>
        [EnumMember(Value = "it-IT")]
        ItIT,

        /// <summary>
        /// JaJP.
        /// </summary>
        [EnumMember(Value = "ja-JP")]
        JaJP,

        /// <summary>
        /// ZhCN.
        /// </summary>
        [EnumMember(Value = "zh-CN")]
        ZhCN,

        /// <summary>
        /// ZhTW.
        /// </summary>
        [EnumMember(Value = "zh-TW")]
        ZhTW,
    }
}