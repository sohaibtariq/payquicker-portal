// <copyright file="OccupationTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// OccupationTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum OccupationTypesEnum
    {
        /// <summary>
        /// INDEPENDENTBUSINESSOWNER.
        /// </summary>
        [EnumMember(Value = "INDEPENDENT_BUSINESS_OWNER")]
        INDEPENDENTBUSINESSOWNER,

        /// <summary>
        /// SCIENCE.
        /// </summary>
        [EnumMember(Value = "SCIENCE")]
        SCIENCE,

        /// <summary>
        /// TECHNOLOGY.
        /// </summary>
        [EnumMember(Value = "TECHNOLOGY")]
        TECHNOLOGY,

        /// <summary>
        /// ENGINEERING.
        /// </summary>
        [EnumMember(Value = "ENGINEERING")]
        ENGINEERING,

        /// <summary>
        /// MATH.
        /// </summary>
        [EnumMember(Value = "MATH")]
        MATH,

        /// <summary>
        /// HEALTHCARE.
        /// </summary>
        [EnumMember(Value = "HEALTHCARE")]
        HEALTHCARE,

        /// <summary>
        /// SOCIALSERVICES.
        /// </summary>
        [EnumMember(Value = "SOCIAL_SERVICES")]
        SOCIALSERVICES,

        /// <summary>
        /// MEDIA.
        /// </summary>
        [EnumMember(Value = "MEDIA")]
        MEDIA,

        /// <summary>
        /// FINANCE.
        /// </summary>
        [EnumMember(Value = "FINANCE")]
        FINANCE,

        /// <summary>
        /// GOVERNMENT.
        /// </summary>
        [EnumMember(Value = "GOVERNMENT")]
        GOVERNMENT,

        /// <summary>
        /// MANUFACTURING.
        /// </summary>
        [EnumMember(Value = "MANUFACTURING")]
        MANUFACTURING,

        /// <summary>
        /// LAW.
        /// </summary>
        [EnumMember(Value = "LAW")]
        LAW,

        /// <summary>
        /// HOSPITALITYANDTOURISM.
        /// </summary>
        [EnumMember(Value = "HOSPITALITY_AND_TOURISM")]
        HOSPITALITYANDTOURISM,

        /// <summary>
        /// ARTS.
        /// </summary>
        [EnumMember(Value = "ARTS")]
        ARTS,

        /// <summary>
        /// DESIGN.
        /// </summary>
        [EnumMember(Value = "DESIGN")]
        DESIGN,

        /// <summary>
        /// OFFICEANDADMINSUPPORT.
        /// </summary>
        [EnumMember(Value = "OFFICE_AND_ADMIN_SUPPORT")]
        OFFICEANDADMINSUPPORT,

        /// <summary>
        /// EDUCATION.
        /// </summary>
        [EnumMember(Value = "EDUCATION")]
        EDUCATION,
    }
}