// <copyright file="TokenTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// TokenTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TokenTypesEnum
    {
        /// <summary>
        /// BANKACCOUNT.
        /// </summary>
        [EnumMember(Value = "BANK_ACCOUNT")]
        BANKACCOUNT,

        /// <summary>
        /// TRANSFER.
        /// </summary>
        [EnumMember(Value = "TRANSFER")]
        TRANSFER,

        /// <summary>
        /// PAYMENT.
        /// </summary>
        [EnumMember(Value = "PAYMENT")]
        PAYMENT,

        /// <summary>
        /// SPENDBACK.
        /// </summary>
        [EnumMember(Value = "SPEND_BACK")]
        SPENDBACK,

        /// <summary>
        /// PREPAIDCARD.
        /// </summary>
        [EnumMember(Value = "PREPAID_CARD")]
        PREPAIDCARD,

        /// <summary>
        /// USER.
        /// </summary>
        [EnumMember(Value = "USER")]
        USER,

        /// <summary>
        /// DOCUMENT.
        /// </summary>
        [EnumMember(Value = "DOCUMENT")]
        DOCUMENT,

        /// <summary>
        /// ACCOUNT.
        /// </summary>
        [EnumMember(Value = "ACCOUNT")]
        ACCOUNT,
    }
}