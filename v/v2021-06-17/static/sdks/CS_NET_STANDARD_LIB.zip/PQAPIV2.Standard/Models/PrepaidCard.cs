// <copyright file="PrepaidCard.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PrepaidCard.
    /// </summary>
    public class PrepaidCard
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCard"/> class.
        /// </summary>
        public PrepaidCard()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCard"/> class.
        /// </summary>
        /// <param name="country">country.</param>
        /// <param name="token">token.</param>
        /// <param name="status">status.</param>
        /// <param name="createdOn">createdOn.</param>
        /// <param name="currency">currency.</param>
        /// <param name="cardPersonalization">cardPersonalization.</param>
        /// <param name="cardPackage">cardPackage.</param>
        /// <param name="cardNetwork">cardNetwork.</param>
        /// <param name="expires">expires.</param>
        /// <param name="cardNumber">cardNumber.</param>
        /// <param name="cvv">cvv.</param>
        public PrepaidCard(
            Models.CountryTypesEnum country,
            string token = null,
            Models.StatusEnum? status = null,
            DateTime? createdOn = null,
            Models.CurrencyTypesEnum? currency = null,
            Models.PrepaidCardPersonalizationTypesEnum? cardPersonalization = null,
            string cardPackage = null,
            Models.CardNetworkTypesEnum? cardNetwork = null,
            DateTime? expires = null,
            string cardNumber = null,
            string cvv = null)
        {
            this.Token = token;
            this.Status = status;
            this.CreatedOn = createdOn;
            this.Country = country;
            this.Currency = currency;
            this.CardPersonalization = cardPersonalization;
            this.CardPackage = cardPackage;
            this.CardNetwork = cardNetwork;
            this.Expires = expires;
            this.CardNumber = cardNumber;
            this.Cvv = cvv;
        }

        /// <summary>
        /// Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// Current status of the prepaid card
        /// </summary>
        [JsonProperty("status", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.StatusEnum? Status { get; set; }

        /// <summary>
        /// Time at which the object was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("createdOn", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("country", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CountryTypesEnum Country { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("currency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? Currency { get; set; }

        /// <summary>
        /// Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer)
        /// </summary>
        [JsonProperty("cardPersonalization", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.PrepaidCardPersonalizationTypesEnum? CardPersonalization { get; set; }

        /// <summary>
        /// Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>
        /// </summary>
        [JsonProperty("cardPackage", NullValueHandling = NullValueHandling.Ignore)]
        public string CardPackage { get; set; }

        /// <summary>
        /// Major credit card network types
        /// </summary>
        [JsonProperty("cardNetwork", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CardNetworkTypesEnum? CardNetwork { get; set; }

        /// <summary>
        /// Quote expiration, ISO-8601 format, UTC by default unless overridden.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("expires", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? Expires { get; set; }

        /// <summary>
        /// Masked card number with only the first 6 and last 4 digits visible
        /// </summary>
        [JsonProperty("cardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CardNumber { get; set; }

        /// <summary>
        /// Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards)
        /// </summary>
        [JsonProperty("cvv", NullValueHandling = NullValueHandling.Ignore)]
        public string Cvv { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrepaidCard : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrepaidCard other &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.CreatedOn == null && other.CreatedOn == null) || (this.CreatedOn?.Equals(other.CreatedOn) == true)) &&
                this.Country.Equals(other.Country) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.CardPersonalization == null && other.CardPersonalization == null) || (this.CardPersonalization?.Equals(other.CardPersonalization) == true)) &&
                ((this.CardPackage == null && other.CardPackage == null) || (this.CardPackage?.Equals(other.CardPackage) == true)) &&
                ((this.CardNetwork == null && other.CardNetwork == null) || (this.CardNetwork?.Equals(other.CardNetwork) == true)) &&
                ((this.Expires == null && other.Expires == null) || (this.Expires?.Equals(other.Expires) == true)) &&
                ((this.CardNumber == null && other.CardNumber == null) || (this.CardNumber?.Equals(other.CardNumber) == true)) &&
                ((this.Cvv == null && other.Cvv == null) || (this.Cvv?.Equals(other.Cvv) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1960120039;

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            if (this.Status != null)
            {
               hashCode += this.Status.GetHashCode();
            }

            if (this.CreatedOn != null)
            {
               hashCode += this.CreatedOn.GetHashCode();
            }

            hashCode += this.Country.GetHashCode();

            if (this.Currency != null)
            {
               hashCode += this.Currency.GetHashCode();
            }

            if (this.CardPersonalization != null)
            {
               hashCode += this.CardPersonalization.GetHashCode();
            }

            if (this.CardPackage != null)
            {
               hashCode += this.CardPackage.GetHashCode();
            }

            if (this.CardNetwork != null)
            {
               hashCode += this.CardNetwork.GetHashCode();
            }

            if (this.Expires != null)
            {
               hashCode += this.Expires.GetHashCode();
            }

            if (this.CardNumber != null)
            {
               hashCode += this.CardNumber.GetHashCode();
            }

            if (this.Cvv != null)
            {
               hashCode += this.Cvv.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status.ToString())}");
            toStringOutput.Add($"this.CreatedOn = {(this.CreatedOn == null ? "null" : this.CreatedOn.ToString())}");
            toStringOutput.Add($"this.Country = {this.Country}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency.ToString())}");
            toStringOutput.Add($"this.CardPersonalization = {(this.CardPersonalization == null ? "null" : this.CardPersonalization.ToString())}");
            toStringOutput.Add($"this.CardPackage = {(this.CardPackage == null ? "null" : this.CardPackage == string.Empty ? "" : this.CardPackage)}");
            toStringOutput.Add($"this.CardNetwork = {(this.CardNetwork == null ? "null" : this.CardNetwork.ToString())}");
            toStringOutput.Add($"this.Expires = {(this.Expires == null ? "null" : this.Expires.ToString())}");
            toStringOutput.Add($"this.CardNumber = {(this.CardNumber == null ? "null" : this.CardNumber == string.Empty ? "" : this.CardNumber)}");
            toStringOutput.Add($"this.Cvv = {(this.Cvv == null ? "null" : this.Cvv == string.Empty ? "" : this.Cvv)}");
        }
    }
}