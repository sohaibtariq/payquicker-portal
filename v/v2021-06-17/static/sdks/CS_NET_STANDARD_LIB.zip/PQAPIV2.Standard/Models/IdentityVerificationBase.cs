// <copyright file="IdentityVerificationBase.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// IdentityVerificationBase.
    /// </summary>
    public class IdentityVerificationBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityVerificationBase"/> class.
        /// </summary>
        public IdentityVerificationBase()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityVerificationBase"/> class.
        /// </summary>
        /// <param name="idvProviderReference">idvProviderReference.</param>
        /// <param name="idvResult">idvResult.</param>
        /// <param name="idvSubResult">idvSubResult.</param>
        /// <param name="idvProvider">idvProvider.</param>
        /// <param name="createdOn">createdOn.</param>
        /// <param name="raw">raw.</param>
        /// <param name="idvCheckType">idvCheckType.</param>
        /// <param name="idvDispostion">idvDispostion.</param>
        /// <param name="token">token.</param>
        public IdentityVerificationBase(
            string idvProviderReference = null,
            Models.IdentityVerificationResultTypesEnum? idvResult = null,
            Models.IdentityVerificationResultSubTypesEnum? idvSubResult = null,
            Models.IdentityVerificationProviderTypesEnum? idvProvider = null,
            DateTime? createdOn = null,
            string raw = null,
            Models.IdentityVerificationCheckTypesEnum? idvCheckType = null,
            Models.IdentityVerificationDispositionTypesEnum? idvDispostion = null,
            string token = null)
        {
            this.IdvProviderReference = idvProviderReference;
            this.IdvResult = idvResult;
            this.IdvSubResult = idvSubResult;
            this.IdvProvider = idvProvider;
            this.CreatedOn = createdOn;
            this.Raw = raw;
            this.IdvCheckType = idvCheckType;
            this.IdvDispostion = idvDispostion;
            this.Token = token;
        }

        /// <summary>
        /// IDV provider unique ID for the IDV check performed
        /// </summary>
        [JsonProperty("idvProviderReference", NullValueHandling = NullValueHandling.Ignore)]
        public string IdvProviderReference { get; set; }

        /// <summary>
        /// In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.
        /// </summary>
        [JsonProperty("idvResult", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.IdentityVerificationResultTypesEnum? IdvResult { get; set; }

        /// <summary>
        /// If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.
        /// </summary>
        [JsonProperty("idvSubResult", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.IdentityVerificationResultSubTypesEnum? IdvSubResult { get; set; }

        /// <summary>
        /// Provider types of verification that can be used for performing identity checks
        /// </summary>
        [JsonProperty("idvProvider", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.IdentityVerificationProviderTypesEnum? IdvProvider { get; set; }

        /// <summary>
        /// Time at which the object was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("createdOn", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only
        /// </summary>
        [JsonProperty("raw", NullValueHandling = NullValueHandling.Ignore)]
        public string Raw { get; set; }

        /// <summary>
        /// Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.)
        /// </summary>
        [JsonProperty("idvCheckType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.IdentityVerificationCheckTypesEnum? IdvCheckType { get; set; }

        /// <summary>
        /// In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.
        /// </summary>
        [JsonProperty("idvDispostion", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.IdentityVerificationDispositionTypesEnum? IdvDispostion { get; set; }

        /// <summary>
        /// Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"IdentityVerificationBase : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is IdentityVerificationBase other &&
                ((this.IdvProviderReference == null && other.IdvProviderReference == null) || (this.IdvProviderReference?.Equals(other.IdvProviderReference) == true)) &&
                ((this.IdvResult == null && other.IdvResult == null) || (this.IdvResult?.Equals(other.IdvResult) == true)) &&
                ((this.IdvSubResult == null && other.IdvSubResult == null) || (this.IdvSubResult?.Equals(other.IdvSubResult) == true)) &&
                ((this.IdvProvider == null && other.IdvProvider == null) || (this.IdvProvider?.Equals(other.IdvProvider) == true)) &&
                ((this.CreatedOn == null && other.CreatedOn == null) || (this.CreatedOn?.Equals(other.CreatedOn) == true)) &&
                ((this.Raw == null && other.Raw == null) || (this.Raw?.Equals(other.Raw) == true)) &&
                ((this.IdvCheckType == null && other.IdvCheckType == null) || (this.IdvCheckType?.Equals(other.IdvCheckType) == true)) &&
                ((this.IdvDispostion == null && other.IdvDispostion == null) || (this.IdvDispostion?.Equals(other.IdvDispostion) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 893385124;

            if (this.IdvProviderReference != null)
            {
               hashCode += this.IdvProviderReference.GetHashCode();
            }

            if (this.IdvResult != null)
            {
               hashCode += this.IdvResult.GetHashCode();
            }

            if (this.IdvSubResult != null)
            {
               hashCode += this.IdvSubResult.GetHashCode();
            }

            if (this.IdvProvider != null)
            {
               hashCode += this.IdvProvider.GetHashCode();
            }

            if (this.CreatedOn != null)
            {
               hashCode += this.CreatedOn.GetHashCode();
            }

            if (this.Raw != null)
            {
               hashCode += this.Raw.GetHashCode();
            }

            if (this.IdvCheckType != null)
            {
               hashCode += this.IdvCheckType.GetHashCode();
            }

            if (this.IdvDispostion != null)
            {
               hashCode += this.IdvDispostion.GetHashCode();
            }

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IdvProviderReference = {(this.IdvProviderReference == null ? "null" : this.IdvProviderReference == string.Empty ? "" : this.IdvProviderReference)}");
            toStringOutput.Add($"this.IdvResult = {(this.IdvResult == null ? "null" : this.IdvResult.ToString())}");
            toStringOutput.Add($"this.IdvSubResult = {(this.IdvSubResult == null ? "null" : this.IdvSubResult.ToString())}");
            toStringOutput.Add($"this.IdvProvider = {(this.IdvProvider == null ? "null" : this.IdvProvider.ToString())}");
            toStringOutput.Add($"this.CreatedOn = {(this.CreatedOn == null ? "null" : this.CreatedOn.ToString())}");
            toStringOutput.Add($"this.Raw = {(this.Raw == null ? "null" : this.Raw == string.Empty ? "" : this.Raw)}");
            toStringOutput.Add($"this.IdvCheckType = {(this.IdvCheckType == null ? "null" : this.IdvCheckType.ToString())}");
            toStringOutput.Add($"this.IdvDispostion = {(this.IdvDispostion == null ? "null" : this.IdvDispostion.ToString())}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
        }
    }
}