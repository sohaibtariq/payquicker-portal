// <copyright file="ValidatorTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// ValidatorTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ValidatorTypesEnum
    {
        /// <summary>
        /// REGEX.
        /// </summary>
        [EnumMember(Value = "REGEX")]
        REGEX,

        /// <summary>
        /// LENGTH.
        /// </summary>
        [EnumMember(Value = "LENGTH")]
        LENGTH,
    }
}