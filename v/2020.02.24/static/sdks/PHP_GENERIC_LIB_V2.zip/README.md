# Getting Started with PQ API v2

## Getting Started

### Introduction

desc older version

### Building

The generated code has dependencies over external libraries like UniRest. These dependencies are defined in the `composer.json` file that comes with the SDK. To resolve these dependencies, we use the Composer package manager which requires PHP greater than or equal to 7.2 installed in your system. Visit [https://getcomposer.org/download/](https://getcomposer.org/download/) to download the installer file for Composer and run it in your system. Open command prompt and type `composer --version`. This should display the current version of the Composer installed if the installation was successful.

* Using command line, navigate to the directory containing the generated files (including `composer.json`) for the SDK.
* Run the command `composer install`. This should install all the required dependencies and create the `vendor` directory in your project directory.

![Building SDK - Step 1](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=installDependencies)

#### Configuring CURL Certificate Path in php.ini

:information_source: **Note** This is for Windows users only.

CURL used to include a list of accepted CAs, but no longer bundles ANY CA certs. So by default it will reject all SSL certificates as unverifiable. You will have to get your CA's cert and point curl at it. The steps are as follows:

1. Download the certificate bundle (.pem file) from [https://curl.haxx.se/docs/caextract.html](https://curl.haxx.se/docs/caextract.html) on to your system.
2. Add curl.cainfo = "PATH_TO/cacert.pem" to your php.ini file located in your php installation. “PATH_TO” must be an absolute path containing the .pem file.

```
[curl]; A default value for the CURLOPT_CAINFO option. This is required to be an
; absolute path.
curl.cainfo = PATH_TO/cacert.pem
```

### Installation

The following section explains how to use the PQAPIV2Lib library in a new project.

#### 1. Open Project in an IDE

Open an IDE for PHP like PhpStorm. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

![Open project in PHPStorm - Step 1](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=openIDE)

Click on `Open` in PhpStorm to browse to your generated SDK directory and then click `OK`.

![Open project in PHPStorm - Step 2](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=openProject0)

#### 2. Add a new Test Project

Create a new directory by right clicking on the solution name as shown below:

![Add a new project in PHPStorm - Step 1](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=createDirectory)

Name the directory as "test".

![Add a new project in PHPStorm - Step 2](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=nameDirectory)

Add a PHP file to this project.

![Add a new project in PHPStorm - Step 3](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=createFile)

Name it "testSDK".

![Add a new project in PHPStorm - Step 4](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=nameFile)

Depending on your project setup, you might need to include composer's autoloader in your PHP code to enable auto loading of classes.

```php
require_once "vendor/autoload.php";
```

It is important that the path inside require_once correctly points to the file `autoload.php` inside the vendor directory created during dependency installations.

![Add a new project in PHPStorm - Step 5](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=projectFiles)

After this you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and use the Controller methods is given in the subsequent sections.

#### 3. Run the Test Project

To run your project you must set the Interpreter for your project. Interpreter is the PHP engine installed on your computer.

Open `Settings` from `File` menu.

![Run Test Project - Step 1](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=openSettings)

Select `PHP` from within `Languages & Frameworks`.

![Run Test Project - Step 2](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=setInterpreter0)

Browse for Interpreters near the `Interpreter` option and choose your interpreter.

![Run Test Project - Step 3](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=setInterpreter1)

Once the interpreter is selected, click `OK`.

![Run Test Project - Step 4](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=setInterpreter2)

To run your project, right click on your PHP file inside your Test project and click on `Run`.

![Run Test Project - Step 5](https://apidocs.io/illustration/php?workspaceFolder=PQAPIV2&step=runProject)

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `timeout` | `int` | Timeout for API calls |

The API client can be initialized as follows:

```php
$client = new PQAPIV2Lib\PQAPIV2Client([
]);
```

### Test the SDK

Unit tests in this SDK can be run using PHPUnit.

1. First install the dependencies using composer including the `require-dev` dependencies.
2. Run `vendor\bin\phpunit --verbose` from commandline to execute tests. If you have installed PHPUnit globally, run tests using `phpunit --verbose` instead.

You can change the PHPUnit test configuration in the `phpunit.xml` file.

## Client Class Documentation

### PQ API v2 Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| getPaymentsController() | Gets PaymentsController |
| getTransfersController() | Gets TransfersController |
| getSpendBackController() | Gets SpendBackController |
| getPrepaidCardsController() | Gets PrepaidCardsController |
| getPaperChecksController() | Gets PaperChecksController |
| getBankAccountsController() | Gets BankAccountsController |
| getBalancesController() | Gets BalancesController |
| getReceiptsController() | Gets ReceiptsController |
| getUsersController() | Gets UsersController |
| getDocumentsController() | Gets DocumentsController |
| getWebhooksController() | Gets WebhooksController |
| getProgramController() | Gets ProgramController |

## API Reference

### List of APIs

* [Payments](#payments)
* [Transfers](#transfers)
* [Spend Back](#spend-back)
* [Prepaid Cards](#prepaid-cards)
* [Paper Checks](#paper-checks)
* [Bank Accounts](#bank-accounts)
* [Balances](#balances)
* [Receipts](#receipts)
* [Users](#users)
* [Documents](#documents)
* [Webhooks](#webhooks)
* [Program](#program)

### Payments

#### Overview

Payment-related operations

##### Get singleton instance

The singleton instance of the `PaymentsController` class can be accessed from the API Client.

```
$paymentsController = $client->getPaymentsController();
```

#### Get-Payments-Pmnt Token

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getPaymentsPmntToken(
    string $pmntToken,
    string $xMyPayQuickerVersion,
    ?string $filter = null,
    ?string $language = null
): PaymentResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```php
$pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
$xMyPayQuickerVersion = '2020.02.24';
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$language = Models\LanguageTypesEnum::ENUS;

$result = $paymentsController->getPaymentsPmntToken($pmntToken, $xMyPayQuickerVersion, $filter, $language);
```

#### Post-Payments-Pmnt Token

Accept an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```php
function postPaymentsPmntToken(
    string $pmntToken,
    string $xMyPayQuickerVersion,
    ?array $body = null
): PaymentResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `?array` | Body, Optional | - |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```php
$pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
$xMyPayQuickerVersion = '2020.02.24';

$result = $paymentsController->postPaymentsPmntToken($pmntToken, $xMyPayQuickerVersion);
```

#### Delete-Payments-Pmnt Token

Cancel an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```php
function deletePaymentsPmntToken(string $pmntToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
$xMyPayQuickerVersion = '2020.02.24';

$paymentsController->deletePaymentsPmntToken($pmntToken, $xMyPayQuickerVersion);
```

#### Put-Payments-Pmnt Token-Retract

Perform a payment retraction for the full payment amount.

:information_source: **Note** This endpoint does not require authentication.

```php
function putPaymentsPmntTokenRetract(string $pmntToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
$xMyPayQuickerVersion = '2020.02.24';

$paymentsController->putPaymentsPmntTokenRetract($pmntToken, $xMyPayQuickerVersion);
```

#### Patch-Payments-Pmnt Token-Retract

Perform a payment retraction for a partial payment amount.

:information_source: **Note** This endpoint does not require authentication.

```php
function patchPaymentsPmntTokenRetract(string $pmntToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
$xMyPayQuickerVersion = '2020.02.24';

$paymentsController->patchPaymentsPmntTokenRetract($pmntToken, $xMyPayQuickerVersion);
```

#### Get-Payments

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getPayments(
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): PaymentsCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaymentsCollectionResponse`](#payments-collection-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $paymentsController->getPayments($xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Payments

Create a payment quote.

:information_source: **Note** This endpoint does not require authentication.

```php
function postPayments(string $xMyPayQuickerVersion, ?PaymentRequest $body = null): PaymentResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?PaymentRequest`](#payment-request) | Body, Optional | - |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$body_amount = 78.98;
$body_currency = Models\CurrencyTypesEnum::HKD;
$body = new Models\PaymentRequest(
    $body_amount,
    $body_currency
);

$result = $paymentsController->postPayments($xMyPayQuickerVersion, $body);
```

### Transfers

#### Overview

Transfer-related operations

##### Get singleton instance

The singleton instance of the `TransfersController` class can be accessed from the API Client.

```
$transfersController = $client->getTransfersController();
```

#### Get-Transfers-Xfer Token

Retrieve details of a specific transfer represented by a transfer token.

:information_source: **Note** This endpoint does not require authentication.

```php
function getTransfersXferToken(
    string $xferToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): TransferResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```php
$xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $transfersController->getTransfersXferToken($xferToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Transfers-Xfer Token

Accept a transfer quote

:information_source: **Note** This endpoint does not require authentication.

```php
function postTransfersXferToken(string $xferToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
$xMyPayQuickerVersion = '2020.02.24';

$transfersController->postTransfersXferToken($xferToken, $xMyPayQuickerVersion);
```

#### Delete-Transfers-Xfer Token

Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote.

:information_source: **Note** This endpoint does not require authentication.

```php
function deleteTransfersXferToken(string $xferToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
$xMyPayQuickerVersion = '2020.02.24';

$transfersController->deleteTransfersXferToken($xferToken, $xMyPayQuickerVersion);
```

#### Get-Transfers

Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getTransfers(
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): TransferCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`TransferCollectionResponse`](#transfer-collection-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $transfersController->getTransfers($xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Transfers

Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>

:information_source: **Note** This endpoint does not require authentication.

```php
function postTransfers(string $xMyPayQuickerVersion, TransferRequest $body): TransferResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`TransferRequest`](#transfer-request) | Body, Required | - |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$body = new Models\TransferRequest;

$result = $transfersController->postTransfers($xMyPayQuickerVersion, $body);
```

##### Example Response *(as JSON)*

```json
{
  "sourceToken": "user-114773fd-85c1-4977-8ce5-24af71f744e9",
  "destinationToken": "dest-63947e68-5393-4d00-955d-e0020017924b",
  "notes": "string",
  "memo": "string",
  "destinationAmount": -1.79,
  "destinationCurrency": "USD",
  "clientTransferId": "DKKde3Meeiiw34",
  "token": "xfer-0c0f2727-6521-47c9-b1fa-f132306d456a",
  "sourceAmount": -1.79,
  "sourceCurrency": "USD",
  "status": "QUOTED",
  "fx": {
    "destinationAmount": -1.79,
    "destinationCurrency": "USD",
    "sourceAmount": -1.79,
    "sourceCurrency": "USD",
    "rate": 0.85
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://url.to.com/xfer-0c0f2727-6521-47c9-b1fa-f132306d456a"
    }
  ]
}
```

### Spend Back

#### Overview

Spendback-related operations

##### Get singleton instance

The singleton instance of the `SpendBackController` class can be accessed from the API Client.

```
$spendBackController = $client->getSpendBackController();
```

#### Get-Spendback-Spnd Token

Retrieve a single spendback quote using the spendback token.

:information_source: **Note** This endpoint does not require authentication.

```php
function getSpendbackSpndToken(
    string $spndToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```php
$spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$spendBackController->getSpendbackSpndToken($spndToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Spendback-Spnd Token

Accept an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```php
function postSpendbackSpndToken(string $spndToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
$xMyPayQuickerVersion = '2020.02.24';

$spendBackController->postSpendbackSpndToken($spndToken, $xMyPayQuickerVersion);
```

#### Delete-Spendback-Spnd Token

Cancel an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```php
function deleteSpendbackSpndToken(string $spndToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
$xMyPayQuickerVersion = '2020.02.24';

$spendBackController->deleteSpendbackSpndToken($spndToken, $xMyPayQuickerVersion);
```

#### Put-Spendback-Spnd Token-Refund

Perform a spendback refund for the full amount.

:information_source: **Note** This endpoint does not require authentication.

```php
function putSpendbackSpndTokenRefund(string $spndToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
$xMyPayQuickerVersion = '2020.02.24';

$spendBackController->putSpendbackSpndTokenRefund($spndToken, $xMyPayQuickerVersion);
```

#### Patch-Spendback-Spnd Token-Refund

Perform a spendback refund for a partial amount.

:information_source: **Note** This endpoint does not require authentication.

```php
function patchSpendbackSpndTokenRefund(string $spndToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
$xMyPayQuickerVersion = '2020.02.24';

$spendBackController->patchSpendbackSpndTokenRefund($spndToken, $xMyPayQuickerVersion);
```

#### Get-Spendback

Retrieve a list of all spendbacks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getSpendback(
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$spendBackController->getSpendback($xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Spendback

Create a spendback quote. <i>*Spendbacks can be automatically accepted by setting the `autoAcceptQuote` flag. If not automatically accepted, a POST is required to the spendback endpoint using the token returned in the response. Quotes can be accepted, cancelled, or allowed to expire.</i>

:information_source: **Note** This endpoint does not require authentication.

```php
function postSpendback(string $xMyPayQuickerVersion, ?array $body = null): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `?array` | Body, Optional | - |

##### Response Type

`void`

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';

$spendBackController->postSpendback($xMyPayQuickerVersion);
```

### Prepaid Cards

#### Overview

Prepaid Card-related operations

##### Get singleton instance

The singleton instance of the `PrepaidCardsController` class can be accessed from the API Client.

```
$prepaidCardsController = $client->getPrepaidCardsController();
```

#### Post-Users-User Token-Prepaidcards-Dest Token

Replace an existing Prepaid Card specifying the replacement reason and the card package for the replacement card.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenPrepaidcardsDestToken(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    ?array $body = null
): PrepaidCardResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `?array` | Body, Optional | - |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';

$result = $prepaidCardsController->postUsersUserTokenPrepaidcardsDestToken($userToken, $destToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaid-Cards-Dest Token

Retrieve Prepaid Card details by destination token.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPrepaidCardsDestToken(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion
): PrepaidCardResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';

$result = $prepaidCardsController->getUsersUserTokenPrepaidCardsDestToken($userToken, $destToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Patch-Users-User Token-Prepaidcards-Dest Token

Partial Prepaid Card update typically used when modifying card status. <i>*Does not require the entire object be passed in the request</i>

:information_source: **Note** This endpoint does not require authentication.

```php
function patchUsersUserTokenPrepaidcardsDestToken(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    ?PrepaidCardStatus $body = null
): PrepaidCardResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?PrepaidCardStatus`](#prepaid-card-status) | Body, Optional | - |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';

$result = $prepaidCardsController->patchUsersUserTokenPrepaidcardsDestToken($userToken, $destToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "LOCKED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Pin

Retrieve one part of a two-part token required to reveal or set a client side PIN. <i>*Not all programs support a reveal or set PIN operation.</i>

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPrepaidcardsDestTokenPin(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion
): PrepaidCardPinToken
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`PrepaidCardPinToken`](#prepaid-card-pin-token)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';

$result = $prepaidCardsController->getUsersUserTokenPrepaidcardsDestTokenPin($userToken, $destToken, $xMyPayQuickerVersion);
```

#### Put-Users-User Token-Prepaidcards-Dest Token-Pin

Allows the setting of a PIN if supported by program.

:information_source: **Note** This endpoint does not require authentication.

```php
function putUsersUserTokenPrepaidcardsDestTokenPin(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    string $token,
    string $cardPin
): UsersPrepaidCardsPinResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cardPin` | `string` | Query, Required | Prepaid card PIN for ATM and Debit usage |

##### Response Type

[`UsersPrepaidCardsPinResponse`](#users-prepaid-cards-pin-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';
$token = 'token6';
$cardPin = 'cardPin4';

$result = $prepaidCardsController->putUsersUserTokenPrepaidcardsDestTokenPin($userToken, $destToken, $xMyPayQuickerVersion, $token, $cardPin);
```

#### Post-Users-User Token-Prepaid-Cards-Dest Token-Pin

Reveals the PIN for a card where PIN reveal functionality is supported in the program and hosted by PayQuicker.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenPrepaidCardsDestTokenPin(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    string $token,
    string $cvc2,
    ?array $body = null
): PrepaidCardPin
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cvc2` | `string` | Query, Required | Card Verification Value (CVV) located on the back of your credit card or debit card is a 3-digit number on VISA® and MasterCard® branded credit cards, and debit cards. |
| `body` | `?array` | Body, Optional | - |

##### Response Type

[`PrepaidCardPin`](#prepaid-card-pin)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';
$token = 'token6';
$cvc2 = 'cvc20';

$result = $prepaidCardsController->postUsersUserTokenPrepaidCardsDestTokenPin($userToken, $destToken, $xMyPayQuickerVersion, $token, $cvc2);
```

#### Get-Users-User Token-Prepaidcards

Retrieve a list of all pre-paid cards by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPrepaidcards(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): PrepaidCardCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PrepaidCardCollectionResponse`](#prepaid-card-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $prepaidCardsController->getUsersUserTokenPrepaidcards($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
      "status": "QUEUED",
      "createdOn": "2020-02-21T22:00:00Z",
      "country": "US",
      "currency": "USD",
      "cardPersonalization": "PERSONALIZED",
      "cardPackage": "blue_consumer_10k",
      "cardNetwork": "VISA",
      "expires": "2023-02-21T00:00:00Z",
      "cardNumber": "1234 56** **** 1234",
      "cvv": "123",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards"
    }
  ]
}
```

#### Post-Users-User Token-Prepaidcards

Order a pre-paid card for the user by specifying a cardPackage. <i>*A package defines the type of card, currency, artwork utilized, and often the method of delivery.</i>

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenPrepaidcards(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?PrepaidCardBase $body = null
): PrepaidCardRequestResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?PrepaidCardBase`](#prepaid-card-base) | Body, Optional | - |

##### Response Type

[`PrepaidCardRequestResponse`](#prepaid-card-request-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';

$result = $prepaidCardsController->postUsersUserTokenPrepaidcards($userToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Generate a token used to reveal prepaid card information in the form of image data (base64) or JSON.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPrepaidCardsDestTokenPci(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    string $format,
    ?string $side = null
): PrepaidCardDataTokenResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | - |
| `destToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`string (Format)`](#format) | Query, Required | Desired format for the prepaid card data. |
| `side` | [`?string (Side)`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`PrepaidCardDataTokenResponse`](#prepaid-card-data-token-response)

##### Example Usage

```php
$userToken = 'user-token6';
$destToken = 'dest-token2';
$xMyPayQuickerVersion = '2020.02.24';
$format = Models\FormatEnum::ENUM_TEXTIMAGE;

$result = $prepaidCardsController->getUsersUserTokenPrepaidCardsDestTokenPci($userToken, $destToken, $xMyPayQuickerVersion, $format);
```

#### Post-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Return prepaid card data in the form of image data, text, or both.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenPrepaidCardsDestTokenPci(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    string $format,
    string $token,
    ?string $side = null
): PrepaidCardDataResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | - |
| `destToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`string (Format)`](#format) | Query, Required | Desired format for the prepaid card data. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `side` | [`?string (Side)`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`PrepaidCardDataResponse`](#prepaid-card-data-response)

##### Example Usage

```php
$userToken = 'user-token6';
$destToken = 'dest-token2';
$xMyPayQuickerVersion = '2020.02.24';
$format = Models\FormatEnum::ENUM_TEXTIMAGE;
$token = 'token6';

$result = $prepaidCardsController->postUsersUserTokenPrepaidCardsDestTokenPci($userToken, $destToken, $xMyPayQuickerVersion, $format, $token);
```

### Paper Checks

#### Overview

Paper check-related operations

##### Get singleton instance

The singleton instance of the `PaperChecksController` class can be accessed from the API Client.

```
$paperChecksController = $client->getPaperChecksController();
```

#### Get-Users-User Token-Paper-Checks

Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPaperChecks(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): PaperCheckCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaperCheckCollectionResponse`](#paper-check-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $paperChecksController->getUsersUserTokenPaperChecks($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Users-User Token-Paperchecks

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenPaperchecks(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?PaperCheckBase $body = null
): PaperCheckResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?PaperCheckBase`](#paper-check-base) | Body, Optional | - |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$body_amount = 78.98;
$body_currency = Models\CurrencyTypesEnum::HKD;
$body = new Models\PaperCheckBase(
    $body_amount,
    $body_currency
);

$result = $paperChecksController->postUsersUserTokenPaperchecks($userToken, $xMyPayQuickerVersion, $body);
```

#### Get-Users-User Token-Paperchecks-Dest Token

Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPaperchecksDestToken(
    string $userToken,
    string $xferToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): PaperCheckResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $paperChecksController->getUsersUserTokenPaperchecksDestToken($userToken, $xferToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Put-Users-User Token-Paperchecks-Dest Token

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```php
function putUsersUserTokenPaperchecksDestToken(
    string $userToken,
    string $xferToken,
    string $xMyPayQuickerVersion,
    ?array $body = null
): PaperCheckResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `?array` | Body, Optional | - |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
$xMyPayQuickerVersion = '2020.02.24';

$result = $paperChecksController->putUsersUserTokenPaperchecksDestToken($userToken, $xferToken, $xMyPayQuickerVersion);
```

#### Delete-Users-User Token-Paper-Checks-Dest Token

Delete a paper check by destination token.

:information_source: **Note** This endpoint does not require authentication.

```php
function deleteUsersUserTokenPaperChecksDestToken(
    string $userToken,
    string $xferToken,
    string $xMyPayQuickerVersion
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
$xMyPayQuickerVersion = '2020.02.24';

$paperChecksController->deleteUsersUserTokenPaperChecksDestToken($userToken, $xferToken, $xMyPayQuickerVersion);
```

### Bank Accounts

#### Overview

Bank account-related operations

##### Get singleton instance

The singleton instance of the `BankAccountsController` class can be accessed from the API Client.

```
$bankAccountsController = $client->getBankAccountsController();
```

#### Get-Users-User Token-Bankaccounts

Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenBankaccounts(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): BankAccountCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountCollectionResponse`](#bank-account-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $bankAccountsController->getUsersUserTokenBankaccounts($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-7d8b1c83-01bb-40fb-87d7-26bd4c303f01",
      "status": "DELETED",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "333333333"
        },
        {
          "key": "BANK_BBAN",
          "value": "4444444444"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "My account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    },
    {
      "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
      "status": "ACTIVE",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "012346789"
        },
        {
          "key": "BANK_BBAN",
          "value": "987654321"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "Personal checking account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Post-Users-User Token-Bankaccounts

Create a quote for a bank account using a user token.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenBankaccounts(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?BankAccountFields $body = null
): BankAccountResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';

$result = $bankAccountsController->postUsersUserTokenBankaccounts($userToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Get-Users-User Token-Bankaccounts-Dest Token

Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenBankaccountsDestToken(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): BankAccountResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $bankAccountsController->getUsersUserTokenBankaccountsDestToken($userToken, $destToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Put-Users-User Token-Bankaccounts-Dest Token

Update a bank account.

:information_source: **Note** This endpoint does not require authentication.

```php
function putUsersUserTokenBankaccountsDestToken(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    ?BankAccountFields $body = null
): BankAccountResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';

$result = $bankAccountsController->putUsersUserTokenBankaccountsDestToken($userToken, $destToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Delete-Users-User Token-Bankaccounts-Dest Token

Delete (cloak) a user bank account.

:information_source: **Note** This endpoint does not require authentication.

```php
function deleteUsersUserTokenBankaccountsDestToken(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';

$bankAccountsController->deleteUsersUserTokenBankaccountsDestToken($userToken, $destToken, $xMyPayQuickerVersion);
```

#### Get-Users-User Token-Bankaccounts-Requirements

Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenBankaccountsRequirements(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): BankAccountRequirementCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountRequirementCollectionResponse`](#bank-account-requirement-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $bankAccountsController->getUsersUserTokenBankaccountsRequirements($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "bankCountry": "IT",
      "bankCurrency": "EUR",
      "requirements": [
        {
          "requirement": "BANK_IBAN",
          "format": {
            "example": "IT43K0310412701000000820420",
            "legend": [
              {
                "key": "IT43K0310412701000000820420",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example IBAN"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio IBAN"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "IBAN"
            },
            {
              "language": "it-IT",
              "translation": "IBAN"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^IT\\\\d{2}[A-Z]\\\\d{10}[0-9A-Z]{12}$"
            }
          ]
        },
        {
          "requirement": "BANK_SWIFT_BIC",
          "format": {
            "example": "01234567890",
            "legend": [
              {
                "key": "01234567890",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example Swift/BIC"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio Swift/BIC"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "Swift/BIC"
            },
            {
              "language": "it-IT",
              "translation": "Swift/BIC"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^[a-z0-9A-Z]{8,11}$"
            }
          ]
        }
      ],
      "quote": {
        "formattedAmount": "$4.32 USD (USD, en-US), 0,00 € EUR (EUR, fr-FR)",
        "amount": 4.32,
        "currency": "USD"
      },
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

### Balances

#### Overview

Balance-related operations

##### Get singleton instance

The singleton instance of the `BalancesController` class can be accessed from the API Client.

```
$balancesController = $client->getBalancesController();
```

#### Get-Users-User Token-Balances

Retrieve a list of user balances that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenBalances(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): BalanceCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $balancesController->getUsersUserTokenBalances($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$4.32 USD",
      "amount": 4.32,
      "currency": "USD",
      "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/balances"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Balances

Retrieve a list of balances by destination token that supports filtering, sorting, and pagination through existing mechanisms. <i>*If the user belongs to a Flex-based program, balances against the user resource will return the wallet balance only. If it is a pre-paid card program (i.e., Meta USD), this balance and its associated pre-paid card balance will be the same.</i>

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPrepaidcardsDestTokenBalances(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): BalanceCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $balancesController->getUsersUserTokenPrepaidcardsDestTokenBalances($userToken, $destToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "formattedAmount": "$4.32",
  "amount": 4.32,
  "currency": "USD",
  "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
    }
  ]
}
```

#### Get-Accounts-Acct Token-Balances

Retrieve a single account balance.

:information_source: **Note** This endpoint does not require authentication.

```php
function getAccountsAcctTokenBalances(
    string $acctToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): BalanceCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```php
$acctToken = 'acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $balancesController->getAccountsAcctTokenBalances($acctToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$5.00",
      "amount": 5,
      "currency": "USD",
      "token": "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4"
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4/balances"
    }
  ]
}
```

### Receipts

#### Overview

Receipt-related operations

##### Get singleton instance

The singleton instance of the `ReceiptsController` class can be accessed from the API Client.

```
$receiptsController = $client->getReceiptsController();
```

#### Get-Accounts-Receipts

Retrieve a list of all account(s) receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getAccountsReceipts(
    string $acctToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): array
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`array`

##### Example Usage

```php
$acctToken = 'acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $receiptsController->getAccountsReceipts($acctToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response

```
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "acct-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Receipts

Retrieve a list all prepaid-card receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenPrepaidcardsReceipts(
    string $userToken,
    string $destToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): ReceiptCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $receiptsController->getUsersUserTokenPrepaidcardsReceipts($userToken, $destToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.05,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/prepaid-cards/dest-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-Receipts

Retrieve a list all user receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersReceipts(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): ReceiptCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $receiptsController->getUsersReceipts($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

### Users

#### Overview

User-related operations

##### Get singleton instance

The singleton instance of the `UsersController` class can be accessed from the API Client.

```
$usersController = $client->getUsersController();
```

#### Put-Users-User Token

Update a user object (change email, address change, etc.) using a user token.

:information_source: **Note** This endpoint does not require authentication.

```php
function putUsersUserToken(string $userToken, string $xMyPayQuickerVersion, ?UserBase $body = null): UserResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?UserBase`](#user-base) | Body, Optional | - |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';

$result = $usersController->putUsersUserToken($userToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token

Retrieve a single user record by user token.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserToken(string $userToken, string $xMyPayQuickerVersion): UserResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';

$result = $usersController->getUsersUserToken($userToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users

Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsers(
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): UserCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`UserCollectionResponse`](#user-collection-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$result = $usersController->getUsers($xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "firstName": "Jane",
      "lastName": "Smith",
      "dateOfBirth": "1977-12-14",
      "phoneNumber": "760-350-0324",
      "phoneNumberCountry": "US",
      "mobileNumber": "213-446-5755",
      "mobileNumberCountry": "US",
      "addressLine1": "290 Carriage Court",
      "city": "Los Angeles",
      "region": "CA",
      "country": "US",
      "postalCode": "90017",
      "addressType": "RESIDENTIAL",
      "email": "jsmith@payquicker.com",
      "gender": "FEMALE",
      "userType": "INDIVIDUAL",
      "programUserId": "d97ce0519b2d",
      "language": "en-US",
      "countryOfBirth": "US",
      "countryOfNationality": "US",
      "token": "usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357",
      "status": "PRE_ACTIVATED",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users"
    }
  ]
}
```

#### Post-Users

Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsers(string $xMyPayQuickerVersion, UserBase $body): UserResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase`](#user-base) | Body, Required | Body details of the request |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';
$body_phoneNumber = '760-350-0324';
$body_mobileNumber = '213-446-5755';
$body_phoneNumberCountry = Models\CountryTypesEnum::US;
$body_mobileNumberCountry = Models\CountryTypesEnum::US;
$body = new Models\UserBase(
    $body_phoneNumber,
    $body_mobileNumber,
    $body_phoneNumberCountry,
    $body_mobileNumberCountry
);
$body->setFirstName('Jane');
$body->setLastName('Smith');
$body->setDateOfBirth(DateTimeHelper::fromSimpleDate('1977-12-14'));
$body->setAddressLine1('290 Carriage Court');
$body->setCity('Los Angeles');
$body->setRegion('CA');
$body->setCountry(Models\CountryTypesEnum::US);
$body->setPostalCode('90017');
$body->setAddressType(Models\AddressTypesEnum::RESIDENTIAL);
$body->setEmail('jsmith@payquicker.com');
$body->setGender(Models\GenderTypesEnum::FEMALE);
$body->setUserType(Models\UserTypesEnum::INDIVIDUAL);
$body->setProgramUserId('d97ce0519b2d');
$body->setLanguage(Models\LanguageTypesEnum::ENUS);
$body->setCountryOfBirth(Models\CountryTypesEnum::US);
$body->setCountryOfNationality(Models\CountryTypesEnum::US);

$result = $usersController->postUsers($xMyPayQuickerVersion, $body);
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks

Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenIdvChecks(
    string $userToken,
    string $xMyPayQuickerVersion
): IdentityVerificationCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`IdentityVerificationCollectionResponse`](#identity-verification-collection-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';

$result = $usersController->getUsersUserTokenIdvChecks($userToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
      "idvResult": "PASS",
      "idvSubResult": "HARD",
      "idvProvider": "IDOLOGY",
      "createdOn": "2020-02-21T22:00:00Z",
      "raw": "<RAW IDV processor output, for informational /debugging purposes only>",
      "idvCheckType": "NON_DOCUMENTARY",
      "idvDisposition": "FINAL",
      "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks-Idvc Token

Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenIdvChecksIdvcToken(
    string $userToken,
    string $idvcToken,
    string $xMyPayQuickerVersion
): IdentityVerificationResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `idvcToken` | `string` | Template, Required | Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`IdentityVerificationResponse`](#identity-verification-response)

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$idvcToken = 'idvc-7e7567e0-c2db-485d-896d-45901a10baa9';
$xMyPayQuickerVersion = '2020.02.24';

$result = $usersController->getUsersUserTokenIdvChecksIdvcToken($userToken, $idvcToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
  "idvResult": "PASS",
  "idvSubResult": "HARD",
  "idvProvider": "IDOLOGY",
  "createdOn": "2020-02-21T22:00:00Z",
  "raw": "<RAW IDV processor output, for informational/debugging purposes only>",
  "idvCheckType": "NON_DOCUMENTARY",
  "idvDispostion": "FINAL",
  "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
    }
  ]
}
```

#### Get-Users-User Token-Events

Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenEvents(string $userToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';

$usersController->getUsersUserTokenEvents($userToken);
```

#### Get-Users-User Token-Events-Event Token

Retrieve a single user event

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenEventsEventToken(string $userToken, string $evntToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `evntToken` | `string` | Template, Required | Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$evntToken = 'evnt-28491de2-5b22-4e30-028a-45901a10baa9';

$usersController->getUsersUserTokenEventsEventToken($userToken, $evntToken);
```

#### Post-Users-User Token-Agreements-Agmt Token

Accept a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenAgreementsAgmtToken(string $userToken, string $agmtToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `agmtToken` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$agmtToken = 'agmt-45901a10-5b22-4e30-028a-45901a10baa9';

$usersController->postUsersUserTokenAgreementsAgmtToken($userToken, $agmtToken);
```

#### Get-Users-User Token-Agreements

Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenAgreements(string $userToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';

$usersController->getUsersUserTokenAgreements($userToken);
```

### Documents

#### Overview

Document-related operations

##### Get singleton instance

The singleton instance of the `DocumentsController` class can be accessed from the API Client.

```
$documentsController = $client->getDocumentsController();
```

#### Get-Users-User Token-Documents

Retrieve a list of user documents that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenDocuments(
    string $userToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$documentsController->getUsersUserTokenDocuments($userToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Post-Users-User Token-Documents

Create a quote for a user document.

:information_source: **Note** This endpoint does not require authentication.

```php
function postUsersUserTokenDocuments(string $userToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$xMyPayQuickerVersion = '2020.02.24';

$documentsController->postUsersUserTokenDocuments($userToken, $xMyPayQuickerVersion);
```

#### Get-Users-User Token-Documents-Docu Token

Retrieve an individual user document by its document token.

:information_source: **Note** This endpoint does not require authentication.

```php
function getUsersUserTokenDocumentsDocuToken(
    string $userToken,
    string $docuToken,
    string $xMyPayQuickerVersion,
    ?int $page = null,
    ?int $pageSize = 20,
    ?string $filter = null,
    ?string $sort = null,
    ?string $language = null
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `?int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `?int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `?string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `?string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`?string (LanguageTypes)`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$docuToken = 'docu-6260c132-5cb1-4e30-8b08-9ce559893acb';
$xMyPayQuickerVersion = '2020.02.24';
$pageSize = 20;
$filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
$sort = '-name';
$language = Models\LanguageTypesEnum::ENUS;

$documentsController->getUsersUserTokenDocumentsDocuToken($userToken, $docuToken, $xMyPayQuickerVersion, null, $pageSize, $filter, $sort, $language);
```

#### Put-Users-User Token-Documents-Docu Token

Replace the user document at the given document token.

:information_source: **Note** This endpoint does not require authentication.

```php
function putUsersUserTokenDocumentsDocuToken(
    string $userToken,
    string $docuToken,
    string $xMyPayQuickerVersion
): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
$docuToken = 'docu-6260c132-5cb1-4e30-8b08-9ce559893acb';
$xMyPayQuickerVersion = '2020.02.24';

$documentsController->putUsersUserTokenDocumentsDocuToken($userToken, $docuToken, $xMyPayQuickerVersion);
```

### Webhooks

#### Overview

Webhook-related operations

##### Get singleton instance

The singleton instance of the `WebhooksController` class can be accessed from the API Client.

```
$webhooksController = $client->getWebhooksController();
```

#### Get-Webhook

Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getWebhook(string $xMyPayQuickerVersion): WebhookCollectionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`WebhookCollectionResponse`](#webhook-collection-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';

$result = $webhooksController->getWebhook($xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "payload": [
    {
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ],
      "url": "https://www.example.com/webhooks",
      "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
      "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
      "created": "2020-01-01",
      "lastUpdated": "2020-02-01"
    }
  ]
}
```

#### Post-Webhooks

Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API.

:information_source: **Note** This endpoint does not require authentication.

```php
function postWebhooks(
    string $xMyPayQuickerVersion,
    ?WebhookSubscription $body = null
): WebhookSubscriptionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`?WebhookSubscription`](#webhook-subscription) | Body, Optional | - |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```php
$xMyPayQuickerVersion = '2020.02.24';

$result = $webhooksController->postWebhooks($xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01"
}
```

#### Get-Webhooks-Webh-Token

Retrieve a single webhook subscription using the webhook token.

:information_source: **Note** This endpoint does not require authentication.

```php
function getWebhooksWebhToken(string $webhToken, string $xMyPayQuickerVersion): WebhookSubscriptionResponse
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```php
$webhToken = 'webh-token0';
$xMyPayQuickerVersion = '2020.02.24';

$result = $webhooksController->getWebhooksWebhToken($webhToken, $xMyPayQuickerVersion);
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01",
  "lastUpdated": "2020-02-01"
}
```

#### Delete-Webhooks-Webh-Token

Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code.

:information_source: **Note** This endpoint does not require authentication.

```php
function deleteWebhooksWebhToken(string $webhToken, string $xMyPayQuickerVersion): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```php
$webhToken = 'webh-token0';
$xMyPayQuickerVersion = '2020.02.24';

$webhooksController->deleteWebhooksWebhToken($webhToken, $xMyPayQuickerVersion);
```

### Program

#### Overview

##### Get singleton instance

The singleton instance of the `ProgramController` class can be accessed from the API Client.

```
$programController = $client->getProgramController();
```

#### Get-Programs

Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getPrograms(): void
```

##### Response Type

`void`

##### Example Usage

```php
$programController->getPrograms();
```

#### Get-Programs-Prog Token

Retrieve a single program configuration

:information_source: **Note** This endpoint does not require authentication.

```php
function getProgramsProgToken(string $progToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |

##### Response Type

`void`

##### Example Usage

```php
$progToken = 'prog-4525ab9c-5b22-4e30-028a-45901a10aa0c';

$programController->getProgramsProgToken($progToken);
```

#### Get-Programs-Prog Token-Agreements

Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```php
function getProgramsProgTokenAgreements(string $progToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | - |

##### Response Type

`void`

##### Example Usage

```php
$progToken = 'prog-token4';

$programController->getProgramsProgTokenAgreements($progToken);
```

#### Get-Programs-Prog Token-Agreements-Agmt Token

Retrieve a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```php
function getProgramsProgTokenAgreementsAgmtToken(string $progToken, string $agmtToken): void
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |
| `agmtToken` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`void`

##### Example Usage

```php
$progToken = 'prog-4525ab9c-5b22-4e30-028a-45901a10aa0c';
$agmtToken = 'agmt-45901a10-5b22-4e30-028a-45901a10baa9';

$programController->getProgramsProgTokenAgreementsAgmtToken($progToken, $agmtToken);
```

## Model Reference

### Structures

* [Source Monetary Required](#source-monetary-required)
* [Haetos Self Ref](#haetos-self-ref)
* [Haetos Params](#haetos-params)
* [Haetos Relationship](#haetos-relationship)
* [Transfer-Request](#transfer-request)
* [Transfer](#transfer)
* [Expiration](#expiration)
* [Transfer-Response](#transfer-response)
* [Not Before or After](#not-before-or-after)
* [Address](#address)
* [Business Address](#business-address)
* [Monetary Formatted](#monetary-formatted)
* [Transfer Base](#transfer-base)
* [Payment Base](#payment-base)
* [Transfer Base Ext](#transfer-base-ext)
* [Destination Monetary Required](#destination-monetary-required)
* [Monetary Required](#monetary-required)
* [Balance](#balance)
* [Fx Object](#fx-object)
* [User Base](#user-base)
* [User](#user)
* [User-Response](#user-response)
* [Receipt Base](#receipt-base)
* [Receipt Collection-Response](#receipt-collection-response)
* [Balance Collection-Response](#balance-collection-response)
* [User Collection-Response](#user-collection-response)
* [Payment-Request](#payment-request)
* [Payment](#payment)
* [Payments Collection-Response](#payments-collection-response)
* [Payment-Response](#payment-response)
* [Transfer Collection-Response](#transfer-collection-response)
* [User Name](#user-name)
* [Dob](#dob)
* [Business Information](#business-information)
* [User Kyc Information](#user-kyc-information)
* [Phone Numbers](#phone-numbers)
* [Email Address](#email-address)
* [User Employer Id](#user-employer-id)
* [Gender](#gender)
* [Language](#language)
* [User Type](#user-type)
* [Program User Id](#program-user-id)
* [Source Destination Token](#source-destination-token)
* [Token](#token)
* [Client Transfer Id](#client-transfer-id)
* [Notes](#notes)
* [Memo](#memo)
* [Created On](#created-on)
* [Transfer Status](#transfer-status)
* [User Status](#user-status)
* [Payment Purpose](#payment-purpose)
* [Source Token](#source-token)
* [Destination Token](#destination-token)
* [Client Payment Id](#client-payment-id)
* [Auto Accept Quote](#auto-accept-quote)
* [Rate](#rate)
* [Fx](#fx)
* [Paper Check Base](#paper-check-base)
* [Transfer Type](#transfer-type)
* [Bank Account Ownership](#bank-account-ownership)
* [Shipping Method](#shipping-method)
* [Paper Check](#paper-check)
* [Paper Check-Response](#paper-check-response)
* [Paper Check Collection-Response](#paper-check-collection-response)
* [Bank Account Fields](#bank-account-fields)
* [Bank Account Type](#bank-account-type)
* [Bank Account](#bank-account)
* [Bank Account Status](#bank-account-status)
* [Bank Account-Response](#bank-account-response)
* [Bank Account Collection-Response](#bank-account-collection-response)
* [Prepaid Card Package](#prepaid-card-package)
* [Prepaid Card Base](#prepaid-card-base)
* [Prepaid Card Status](#prepaid-card-status)
* [Token Type](#token-type)
* [Prepaid Card Base Ext](#prepaid-card-base-ext)
* [Card Network](#card-network)
* [Card Personalization Type](#card-personalization-type)
* [Prepaid Card](#prepaid-card)
* [Currency](#currency)
* [Country](#country)
* [Prepaid Card-Request Response](#prepaid-card-request-response)
* [Prepaid Card-Response](#prepaid-card-response)
* [Prepaid Card Collection-Response](#prepaid-card-collection-response)
* [Card Masked Pan](#card-masked-pan)
* [Prepaid Card Replacement Reason](#prepaid-card-replacement-reason)
* [Prepaid Card Replacement Base](#prepaid-card-replacement-base)
* [Prepaid Card Pin Token](#prepaid-card-pin-token)
* [Prepaid Card Pin](#prepaid-card-pin)
* [Cvv](#cvv)
* [Identity Verification Provider Type](#identity-verification-provider-type)
* [Identity Verification Result Type](#identity-verification-result-type)
* [Identity Verification Sub Result Type](#identity-verification-sub-result-type)
* [Identity Verification Disposition Type](#identity-verification-disposition-type)
* [Identity Verification Check Type](#identity-verification-check-type)
* [Identity Verification Base](#identity-verification-base)
* [Identity Verification Provider Reference](#identity-verification-provider-reference)
* [Identity Verification Provider Raw Output](#identity-verification-provider-raw-output)
* [Identity Verification-Response](#identity-verification-response)
* [Identity Verification Collection-Response](#identity-verification-collection-response)
* [Key Value Pair String String](#key-value-pair-string-string)
* [Key Value Pair Bank Field Types String](#key-value-pair-bank-field-types-string)
* [Key Value Pair Bank Currency Currency Types](#key-value-pair-bank-currency-currency-types)
* [Key Value Bank Country Country Types](#key-value-bank-country-country-types)
* [Bank Account Required Fields](#bank-account-required-fields)
* [Bank Account Requirement Format](#bank-account-requirement-format)
* [Bank Account Requirement Format Legend](#bank-account-requirement-format-legend)
* [Key Value Pair Language Type String](#key-value-pair-language-type-string)
* [Bank Account Requirement Validator](#bank-account-requirement-validator)
* [Bank Account Requirement](#bank-account-requirement)
* [Bank Account Requirement-Response](#bank-account-requirement-response)
* [Bank Account Requirement Collection-Response](#bank-account-requirement-collection-response)
* [Occupation](#occupation)
* [Tax Resident Status](#tax-resident-status)
* [Webhook-Subscription](#webhook-subscription)
* [Webhook-Subscription-Response](#webhook-subscription-response)
* [Webhook Collection-Response](#webhook-collection-response)
* [Prepaid Card Data-Response](#prepaid-card-data-response)
* [Prepaid Card Data Token](#prepaid-card-data-token)
* [Prepaid Card Data Token-Response](#prepaid-card-data-token-response)
* [Business Type](#business-type)
* [Country Nationality Information](#country-nationality-information)
* [Users Prepaid Cards Pin Response](#users-prepaid-cards-pin-response)

#### Source Monetary Required

Required details of the monetary source.

##### Class Name

`SourceMonetaryRequired`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceAmount` | `?float` | Optional | Amount of the transfer in the specified currency. | getSourceAmount(): ?float | setSourceAmount(?float sourceAmount): void |
| `sourceCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getSourceCurrency(): ?string | setSourceCurrency(?string sourceCurrency): void |

##### Example (as JSON)

```json
{
  "sourceAmount": null,
  "sourceCurrency": null
}
```

#### Haetos Self Ref

Indicates the external link with the full URL of the same page on which the link appears.

##### Class Name

`HaetosSelfRef`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "links": null
}
```

#### Haetos Params

Hypermedia as the Engine of Application State (HAETOS) parameters used in a query.

##### Class Name

`HaetosParams`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `params` | [`HaetosRelationship`](#haetos-relationship) | Required | Indicates the HATEOS relationship between the target and current resources. | getParams(): HaetosRelationship | setParams(HaetosRelationship params): void |
| `href` | `string` | Required | URL for resource described by the relationship. | getHref(): string | setHref(string href): void |

##### Example (as JSON)

```json
{
  "params": {
    "rel": "self"
  },
  "href": null
}
```

#### Haetos Relationship

Indicates the HATEOS relationship between the target and current resources.

##### Class Name

`HaetosRelationship`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `rel` | `string` | Required | Indicates the relationship between the target and current resources.<br>**Default**: `'self'`<br>*Default: `'self'`* | getRel(): string | setRel(string rel): void |

##### Example (as JSON)

```json
{
  "rel": "self"
}
```

#### Transfer-Request

Request for the transfer

##### Class Name

`TransferRequest`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `clientTransferId` | `?string` | Optional | Unique value provided by the client for the transfer. | getClientTransferId(): ?string | setClientTransferId(?string clientTransferId): void |
| `destinationAmount` | `?float` | Optional | Amount transferred to the destination | getDestinationAmount(): ?float | setDestinationAmount(?float destinationAmount): void |
| `destinationCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getDestinationCurrency(): ?string | setDestinationCurrency(?string destinationCurrency): void |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "clientTransferId": null,
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Transfer

Description of the transfer request

##### Class Name

`Transfer`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `destinationAmount` | `?float` | Optional | Amount transferred to the destination | getDestinationAmount(): ?float | setDestinationAmount(?float destinationAmount): void |
| `destinationCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getDestinationCurrency(): ?string | setDestinationCurrency(?string destinationCurrency): void |
| `clientTransferId` | `?string` | Optional | Unique value provided by the client for the transfer. | getClientTransferId(): ?string | setClientTransferId(?string clientTransferId): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `sourceAmount` | `?float` | Optional | Amount of the transfer in the specified currency. | getSourceAmount(): ?float | setSourceAmount(?float sourceAmount): void |
| `sourceCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getSourceCurrency(): ?string | setSourceCurrency(?string sourceCurrency): void |
| `status` | [`?string (TransferStatusTypes)`](#transfer-status-types) | Optional | Current status of a transfer | getStatus(): ?string | setStatus(?string status): void |
| `fx` | [`?FxObject`](#fx-object) | Optional | Currency conversion object details | getFx(): ?FxObject | setFx(?FxObject fx): void |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null
}
```

#### Expiration

Date and time the object will expire

##### Class Name

`Expiration`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `expires` | `?\DateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | getExpires(): ?\DateTime | setExpires(?\DateTime expires): void |

##### Example (as JSON)

```json
{
  "expires": null
}
```

#### Transfer-Response

##### Class Name

`TransferResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `destinationAmount` | `?float` | Optional | Amount transferred to the destination | getDestinationAmount(): ?float | setDestinationAmount(?float destinationAmount): void |
| `destinationCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getDestinationCurrency(): ?string | setDestinationCurrency(?string destinationCurrency): void |
| `clientTransferId` | `?string` | Optional | Unique value provided by the client for the transfer. | getClientTransferId(): ?string | setClientTransferId(?string clientTransferId): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `sourceAmount` | `?float` | Optional | Amount of the transfer in the specified currency. | getSourceAmount(): ?float | setSourceAmount(?float sourceAmount): void |
| `sourceCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getSourceCurrency(): ?string | setSourceCurrency(?string sourceCurrency): void |
| `status` | [`?string (TransferStatusTypes)`](#transfer-status-types) | Optional | Current status of a transfer | getStatus(): ?string | setStatus(?string status): void |
| `fx` | [`?FxObject`](#fx-object) | Optional | Currency conversion object details | getFx(): ?FxObject | setFx(?FxObject fx): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null,
  "links": null
}
```

#### Not Before or After

##### Class Name

`NotBeforeOrAfter`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notBefore` | `?\DateTime` | Optional | Transfer is scheduled and will not process before this time. | getNotBefore(): ?\DateTime | setNotBefore(?\DateTime notBefore): void |
| `notAfter` | `?\DateTime` | Optional | Transfer expires if not completed prior to this time. | getNotAfter(): ?\DateTime | setNotAfter(?\DateTime notAfter): void |

##### Example (as JSON)

```json
{
  "notBefore": null,
  "notAfter": null
}
```

#### Address

Classifies the mailing address

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |

##### Example (as JSON)

```json
{
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null
}
```

#### Business Address

Address of the business location

##### Class Name

`BusinessAddress`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `businessAddressLine1` | `?string` | Optional | First line of the business address that specifies street number, street name, and building name | getBusinessAddressLine1(): ?string | setBusinessAddressLine1(?string businessAddressLine1): void |
| `businessAddressLine2` | `?string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getBusinessAddressLine2(): ?string | setBusinessAddressLine2(?string businessAddressLine2): void |
| `businessAddressLine3` | `?string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | getBusinessAddressLine3(): ?string | setBusinessAddressLine3(?string businessAddressLine3): void |
| `businessAddressLine4` | `?string` | Optional | fourth line of the business address street address | getBusinessAddressLine4(): ?string | setBusinessAddressLine4(?string businessAddressLine4): void |
| `businessAddressLine5` | `?string` | Optional | Fifth line of the business address street address | getBusinessAddressLine5(): ?string | setBusinessAddressLine5(?string businessAddressLine5): void |
| `businessCity` | `?string` | Optional | City the business is registered | getBusinessCity(): ?string | setBusinessCity(?string businessCity): void |
| `businessRegion` | `?string` | Optional | State, province, or region the business is registered | getBusinessRegion(): ?string | setBusinessRegion(?string businessRegion): void |
| `businessCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessCountry(): ?string | setBusinessCountry(?string businessCountry): void |
| `businessPostalCode` | `?string` | Optional | Postal code for the business address | getBusinessPostalCode(): ?string | setBusinessPostalCode(?string businessPostalCode): void |
| `businessPremiseNumber` | `?string` | Optional | House number for the business address | getBusinessPremiseNumber(): ?string | setBusinessPremiseNumber(?string businessPremiseNumber): void |

##### Example (as JSON)

```json
{
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null
}
```

#### Monetary Formatted

Object representing monies, including currency, decimal, and formatted amounts

##### Class Name

`MonetaryFormatted`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `formattedAmount` | `?string` | Optional | Formatted monetary amount | getFormattedAmount(): ?string | setFormattedAmount(?string formattedAmount): void |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base

Base class for the transfer

##### Class Name

`TransferBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null
}
```

#### Payment Base

Base class for the payment

##### Class Name

`PaymentBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `purpose` | [`?string (PaymentPurposeTypes)`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | getPurpose(): ?string | setPurpose(?string purpose): void |
| `clientPaymentId` | `?string` | Optional | Unique value provided by the client for the payment. | getClientPaymentId(): ?string | setClientPaymentId(?string clientPaymentId): void |
| `autoAcceptQuote` | `?bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | getAutoAcceptQuote(): ?bool | setAutoAcceptQuote(?bool autoAcceptQuote): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base Ext

Base extension for the transfer

##### Class Name

`TransferBaseExt`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `destinationAmount` | `?float` | Optional | Amount transferred to the destination | getDestinationAmount(): ?float | setDestinationAmount(?float destinationAmount): void |
| `destinationCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getDestinationCurrency(): ?string | setDestinationCurrency(?string destinationCurrency): void |
| `clientTransferId` | `?string` | Optional | Unique value provided by the client for the transfer. | getClientTransferId(): ?string | setClientTransferId(?string clientTransferId): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null
}
```

#### Destination Monetary Required

Monetary instruments required for the destination

##### Class Name

`DestinationMonetaryRequired`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `destinationAmount` | `?float` | Optional | Amount transferred to the destination | getDestinationAmount(): ?float | setDestinationAmount(?float destinationAmount): void |
| `destinationCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getDestinationCurrency(): ?string | setDestinationCurrency(?string destinationCurrency): void |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Monetary Required

Monetary requirements for the transfer

##### Class Name

`MonetaryRequired`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Balance

Account monetary balance

##### Class Name

`Balance`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `formattedAmount` | `?string` | Optional | Formatted monetary amount | getFormattedAmount(): ?string | setFormattedAmount(?string formattedAmount): void |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Fx Object

Currency conversion object details

##### Class Name

`FxObject`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `destinationAmount` | `?float` | Optional | Amount transferred to the destination | getDestinationAmount(): ?float | setDestinationAmount(?float destinationAmount): void |
| `destinationCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getDestinationCurrency(): ?string | setDestinationCurrency(?string destinationCurrency): void |
| `sourceAmount` | `?float` | Optional | Amount of the transfer in the specified currency. | getSourceAmount(): ?float | setSourceAmount(?float sourceAmount): void |
| `sourceCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getSourceCurrency(): ?string | setSourceCurrency(?string sourceCurrency): void |
| `rate` | `?float` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` | getRate(): ?float | setRate(?float rate): void |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "rate": null
}
```

#### User Base

Object for the established group of users

##### Class Name

`UserBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | getLastName(): ?string | setLastName(?string lastName): void |
| `dateOfBirth` | `?\DateTime` | Optional | User's date of birth | getDateOfBirth(): ?\DateTime | setDateOfBirth(?\DateTime dateOfBirth): void |
| `businessName` | `?string` | Optional | Legal name for the business | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `businessOperatingName` | `?string` | Optional | Name under which the business operates | getBusinessOperatingName(): ?string | setBusinessOperatingName(?string businessOperatingName): void |
| `businessRegistrationId` | `?string` | Optional | Registration number or ID assigned by a government body | getBusinessRegistrationId(): ?string | setBusinessRegistrationId(?string businessRegistrationId): void |
| `businessRegistrationRegion` | `?string` | Optional | State, province, or territory where the business is registered | getBusinessRegistrationRegion(): ?string | setBusinessRegistrationRegion(?string businessRegistrationRegion): void |
| `businessRegistrationCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessRegistrationCountry(): ?string | setBusinessRegistrationCountry(?string businessRegistrationCountry): void |
| `businessContactRole` | [`?string (BusinessContactRole)`](#business-contact-role) | Optional | Role of the user within the business | getBusinessContactRole(): ?string | setBusinessContactRole(?string businessContactRole): void |
| `businessAddressLine1` | `?string` | Optional | First line of the business address that specifies street number, street name, and building name | getBusinessAddressLine1(): ?string | setBusinessAddressLine1(?string businessAddressLine1): void |
| `businessAddressLine2` | `?string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getBusinessAddressLine2(): ?string | setBusinessAddressLine2(?string businessAddressLine2): void |
| `businessAddressLine3` | `?string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | getBusinessAddressLine3(): ?string | setBusinessAddressLine3(?string businessAddressLine3): void |
| `businessAddressLine4` | `?string` | Optional | fourth line of the business address street address | getBusinessAddressLine4(): ?string | setBusinessAddressLine4(?string businessAddressLine4): void |
| `businessAddressLine5` | `?string` | Optional | Fifth line of the business address street address | getBusinessAddressLine5(): ?string | setBusinessAddressLine5(?string businessAddressLine5): void |
| `businessCity` | `?string` | Optional | City the business is registered | getBusinessCity(): ?string | setBusinessCity(?string businessCity): void |
| `businessRegion` | `?string` | Optional | State, province, or region the business is registered | getBusinessRegion(): ?string | setBusinessRegion(?string businessRegion): void |
| `businessCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessCountry(): ?string | setBusinessCountry(?string businessCountry): void |
| `businessPostalCode` | `?string` | Optional | Postal code for the business address | getBusinessPostalCode(): ?string | setBusinessPostalCode(?string businessPostalCode): void |
| `businessPremiseNumber` | `?string` | Optional | House number for the business address | getBusinessPremiseNumber(): ?string | setBusinessPremiseNumber(?string businessPremiseNumber): void |
| `businessType` | [`?string (BusinessTypes)`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | getBusinessType(): ?string | setBusinessType(?string businessType): void |
| `driverLicenseId` | `?string` | Optional | User's driver's license number | getDriverLicenseId(): ?string | setDriverLicenseId(?string driverLicenseId): void |
| `passportId` | `?string` | Optional | User's passport number | getPassportId(): ?string | setPassportId(?string passportId): void |
| `governmentIdType` | [`?string (GovernmentIdType)`](#government-id-type) | Optional | User's government ID type | getGovernmentIdType(): ?string | setGovernmentIdType(?string governmentIdType): void |
| `governmentId` | `?string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | getGovernmentId(): ?string | setGovernmentId(?string governmentId): void |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | getPhoneNumber(): string | setPhoneNumber(string phoneNumber): void |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `phoneNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getPhoneNumberCountry(): string | setPhoneNumberCountry(string phoneNumberCountry): void |
| `mobileNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getMobileNumberCountry(): string | setMobileNumberCountry(string mobileNumberCountry): void |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |
| `email` | `?string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | getEmail(): ?string | setEmail(?string email): void |
| `employerId` | `?string` | Optional | User's employer identifier | getEmployerId(): ?string | setEmployerId(?string employerId): void |
| `gender` | [`?string (GenderTypes)`](#gender-types) | Optional | Gender as a user identifies | getGender(): ?string | setGender(?string gender): void |
| `userType` | [`?string (UserTypes)`](#user-types) | Optional | Account holder's profile type | getUserType(): ?string | setUserType(?string userType): void |
| `programUserId` | `?string` | Optional | Program identifier for the user | getProgramUserId(): ?string | setProgramUserId(?string programUserId): void |
| `language` | [`?string (LanguageTypes)`](#language-types) | Optional | Language type in IETF's BCP 47 format | getLanguage(): ?string | setLanguage(?string language): void |
| `countryOfBirth` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfBirth(): ?string | setCountryOfBirth(?string countryOfBirth): void |
| `countryOfNationality` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfNationality(): ?string | setCountryOfNationality(?string countryOfNationality): void |
| `occupation` | [`?string (OccupationTypes)`](#occupation-types) | Optional | Type of occupation for the user | getOccupation(): ?string | setOccupation(?string occupation): void |
| `taxResidentStatus` | [`?string (TaxResidentStatusTypes)`](#tax-resident-status-types) | Optional | Tax resident status type of a country | getTaxResidentStatus(): ?string | setTaxResidentStatus(?string taxResidentStatus): void |
| `currency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getCurrency(): ?string | setCurrency(?string currency): void |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null
}
```

#### User

Object for user

##### Class Name

`User`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | getLastName(): ?string | setLastName(?string lastName): void |
| `dateOfBirth` | `?\DateTime` | Optional | User's date of birth | getDateOfBirth(): ?\DateTime | setDateOfBirth(?\DateTime dateOfBirth): void |
| `businessName` | `?string` | Optional | Legal name for the business | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `businessOperatingName` | `?string` | Optional | Name under which the business operates | getBusinessOperatingName(): ?string | setBusinessOperatingName(?string businessOperatingName): void |
| `businessRegistrationId` | `?string` | Optional | Registration number or ID assigned by a government body | getBusinessRegistrationId(): ?string | setBusinessRegistrationId(?string businessRegistrationId): void |
| `businessRegistrationRegion` | `?string` | Optional | State, province, or territory where the business is registered | getBusinessRegistrationRegion(): ?string | setBusinessRegistrationRegion(?string businessRegistrationRegion): void |
| `businessRegistrationCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessRegistrationCountry(): ?string | setBusinessRegistrationCountry(?string businessRegistrationCountry): void |
| `businessContactRole` | [`?string (BusinessContactRole)`](#business-contact-role) | Optional | Role of the user within the business | getBusinessContactRole(): ?string | setBusinessContactRole(?string businessContactRole): void |
| `businessAddressLine1` | `?string` | Optional | First line of the business address that specifies street number, street name, and building name | getBusinessAddressLine1(): ?string | setBusinessAddressLine1(?string businessAddressLine1): void |
| `businessAddressLine2` | `?string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getBusinessAddressLine2(): ?string | setBusinessAddressLine2(?string businessAddressLine2): void |
| `businessAddressLine3` | `?string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | getBusinessAddressLine3(): ?string | setBusinessAddressLine3(?string businessAddressLine3): void |
| `businessAddressLine4` | `?string` | Optional | fourth line of the business address street address | getBusinessAddressLine4(): ?string | setBusinessAddressLine4(?string businessAddressLine4): void |
| `businessAddressLine5` | `?string` | Optional | Fifth line of the business address street address | getBusinessAddressLine5(): ?string | setBusinessAddressLine5(?string businessAddressLine5): void |
| `businessCity` | `?string` | Optional | City the business is registered | getBusinessCity(): ?string | setBusinessCity(?string businessCity): void |
| `businessRegion` | `?string` | Optional | State, province, or region the business is registered | getBusinessRegion(): ?string | setBusinessRegion(?string businessRegion): void |
| `businessCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessCountry(): ?string | setBusinessCountry(?string businessCountry): void |
| `businessPostalCode` | `?string` | Optional | Postal code for the business address | getBusinessPostalCode(): ?string | setBusinessPostalCode(?string businessPostalCode): void |
| `businessPremiseNumber` | `?string` | Optional | House number for the business address | getBusinessPremiseNumber(): ?string | setBusinessPremiseNumber(?string businessPremiseNumber): void |
| `businessType` | [`?string (BusinessTypes)`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | getBusinessType(): ?string | setBusinessType(?string businessType): void |
| `driverLicenseId` | `?string` | Optional | User's driver's license number | getDriverLicenseId(): ?string | setDriverLicenseId(?string driverLicenseId): void |
| `passportId` | `?string` | Optional | User's passport number | getPassportId(): ?string | setPassportId(?string passportId): void |
| `governmentIdType` | [`?string (GovernmentIdType)`](#government-id-type) | Optional | User's government ID type | getGovernmentIdType(): ?string | setGovernmentIdType(?string governmentIdType): void |
| `governmentId` | `?string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | getGovernmentId(): ?string | setGovernmentId(?string governmentId): void |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | getPhoneNumber(): string | setPhoneNumber(string phoneNumber): void |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `phoneNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getPhoneNumberCountry(): string | setPhoneNumberCountry(string phoneNumberCountry): void |
| `mobileNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getMobileNumberCountry(): string | setMobileNumberCountry(string mobileNumberCountry): void |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |
| `email` | `?string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | getEmail(): ?string | setEmail(?string email): void |
| `employerId` | `?string` | Optional | User's employer identifier | getEmployerId(): ?string | setEmployerId(?string employerId): void |
| `gender` | [`?string (GenderTypes)`](#gender-types) | Optional | Gender as a user identifies | getGender(): ?string | setGender(?string gender): void |
| `userType` | [`?string (UserTypes)`](#user-types) | Optional | Account holder's profile type | getUserType(): ?string | setUserType(?string userType): void |
| `programUserId` | `?string` | Optional | Program identifier for the user | getProgramUserId(): ?string | setProgramUserId(?string programUserId): void |
| `language` | [`?string (LanguageTypes)`](#language-types) | Optional | Language type in IETF's BCP 47 format | getLanguage(): ?string | setLanguage(?string language): void |
| `countryOfBirth` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfBirth(): ?string | setCountryOfBirth(?string countryOfBirth): void |
| `countryOfNationality` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfNationality(): ?string | setCountryOfNationality(?string countryOfNationality): void |
| `occupation` | [`?string (OccupationTypes)`](#occupation-types) | Optional | Type of occupation for the user | getOccupation(): ?string | setOccupation(?string occupation): void |
| `taxResidentStatus` | [`?string (TaxResidentStatusTypes)`](#tax-resident-status-types) | Optional | Tax resident status type of a country | getTaxResidentStatus(): ?string | setTaxResidentStatus(?string taxResidentStatus): void |
| `currency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getCurrency(): ?string | setCurrency(?string currency): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (UserStatusTypes)`](#user-status-types) | Optional | Current status of the user | getStatus(): ?string | setStatus(?string status): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null
}
```

#### User-Response

Response from a user request

##### Class Name

`UserResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | getLastName(): ?string | setLastName(?string lastName): void |
| `dateOfBirth` | `?\DateTime` | Optional | User's date of birth | getDateOfBirth(): ?\DateTime | setDateOfBirth(?\DateTime dateOfBirth): void |
| `businessName` | `?string` | Optional | Legal name for the business | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `businessOperatingName` | `?string` | Optional | Name under which the business operates | getBusinessOperatingName(): ?string | setBusinessOperatingName(?string businessOperatingName): void |
| `businessRegistrationId` | `?string` | Optional | Registration number or ID assigned by a government body | getBusinessRegistrationId(): ?string | setBusinessRegistrationId(?string businessRegistrationId): void |
| `businessRegistrationRegion` | `?string` | Optional | State, province, or territory where the business is registered | getBusinessRegistrationRegion(): ?string | setBusinessRegistrationRegion(?string businessRegistrationRegion): void |
| `businessRegistrationCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessRegistrationCountry(): ?string | setBusinessRegistrationCountry(?string businessRegistrationCountry): void |
| `businessContactRole` | [`?string (BusinessContactRole)`](#business-contact-role) | Optional | Role of the user within the business | getBusinessContactRole(): ?string | setBusinessContactRole(?string businessContactRole): void |
| `businessAddressLine1` | `?string` | Optional | First line of the business address that specifies street number, street name, and building name | getBusinessAddressLine1(): ?string | setBusinessAddressLine1(?string businessAddressLine1): void |
| `businessAddressLine2` | `?string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getBusinessAddressLine2(): ?string | setBusinessAddressLine2(?string businessAddressLine2): void |
| `businessAddressLine3` | `?string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | getBusinessAddressLine3(): ?string | setBusinessAddressLine3(?string businessAddressLine3): void |
| `businessAddressLine4` | `?string` | Optional | fourth line of the business address street address | getBusinessAddressLine4(): ?string | setBusinessAddressLine4(?string businessAddressLine4): void |
| `businessAddressLine5` | `?string` | Optional | Fifth line of the business address street address | getBusinessAddressLine5(): ?string | setBusinessAddressLine5(?string businessAddressLine5): void |
| `businessCity` | `?string` | Optional | City the business is registered | getBusinessCity(): ?string | setBusinessCity(?string businessCity): void |
| `businessRegion` | `?string` | Optional | State, province, or region the business is registered | getBusinessRegion(): ?string | setBusinessRegion(?string businessRegion): void |
| `businessCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessCountry(): ?string | setBusinessCountry(?string businessCountry): void |
| `businessPostalCode` | `?string` | Optional | Postal code for the business address | getBusinessPostalCode(): ?string | setBusinessPostalCode(?string businessPostalCode): void |
| `businessPremiseNumber` | `?string` | Optional | House number for the business address | getBusinessPremiseNumber(): ?string | setBusinessPremiseNumber(?string businessPremiseNumber): void |
| `businessType` | [`?string (BusinessTypes)`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | getBusinessType(): ?string | setBusinessType(?string businessType): void |
| `driverLicenseId` | `?string` | Optional | User's driver's license number | getDriverLicenseId(): ?string | setDriverLicenseId(?string driverLicenseId): void |
| `passportId` | `?string` | Optional | User's passport number | getPassportId(): ?string | setPassportId(?string passportId): void |
| `governmentIdType` | [`?string (GovernmentIdType)`](#government-id-type) | Optional | User's government ID type | getGovernmentIdType(): ?string | setGovernmentIdType(?string governmentIdType): void |
| `governmentId` | `?string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | getGovernmentId(): ?string | setGovernmentId(?string governmentId): void |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | getPhoneNumber(): string | setPhoneNumber(string phoneNumber): void |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `phoneNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getPhoneNumberCountry(): string | setPhoneNumberCountry(string phoneNumberCountry): void |
| `mobileNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getMobileNumberCountry(): string | setMobileNumberCountry(string mobileNumberCountry): void |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |
| `email` | `?string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | getEmail(): ?string | setEmail(?string email): void |
| `employerId` | `?string` | Optional | User's employer identifier | getEmployerId(): ?string | setEmployerId(?string employerId): void |
| `gender` | [`?string (GenderTypes)`](#gender-types) | Optional | Gender as a user identifies | getGender(): ?string | setGender(?string gender): void |
| `userType` | [`?string (UserTypes)`](#user-types) | Optional | Account holder's profile type | getUserType(): ?string | setUserType(?string userType): void |
| `programUserId` | `?string` | Optional | Program identifier for the user | getProgramUserId(): ?string | setProgramUserId(?string programUserId): void |
| `language` | [`?string (LanguageTypes)`](#language-types) | Optional | Language type in IETF's BCP 47 format | getLanguage(): ?string | setLanguage(?string language): void |
| `countryOfBirth` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfBirth(): ?string | setCountryOfBirth(?string countryOfBirth): void |
| `countryOfNationality` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfNationality(): ?string | setCountryOfNationality(?string countryOfNationality): void |
| `occupation` | [`?string (OccupationTypes)`](#occupation-types) | Optional | Type of occupation for the user | getOccupation(): ?string | setOccupation(?string occupation): void |
| `taxResidentStatus` | [`?string (TaxResidentStatusTypes)`](#tax-resident-status-types) | Optional | Tax resident status type of a country | getTaxResidentStatus(): ?string | setTaxResidentStatus(?string taxResidentStatus): void |
| `currency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getCurrency(): ?string | setCurrency(?string currency): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (UserStatusTypes)`](#user-status-types) | Optional | Current status of the user | getStatus(): ?string | setStatus(?string status): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null,
  "links": null
}
```

#### Receipt Base

Base for the receipt

##### Class Name

`ReceiptBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `formattedAmount` | `?string` | Optional | Formatted monetary amount | getFormattedAmount(): ?string | setFormattedAmount(?string formattedAmount): void |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (TransferStatusTypes)`](#transfer-status-types) | Optional | Current status of a transfer | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Receipt Collection-Response

Response from a Receipt Collection request

##### Class Name

`ReceiptCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(ReceiptBase[])`](#receipt-base) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Balance Collection-Response

Response from a Balance Collection request

##### Class Name

`BalanceCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(Balance[])`](#balance) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Collection-Response

Response from a User Collection request

##### Class Name

`UserCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(UserResponse[])`](#user-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Request

Payment request

##### Class Name

`PaymentRequest`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `purpose` | [`?string (PaymentPurposeTypes)`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | getPurpose(): ?string | setPurpose(?string purpose): void |
| `clientPaymentId` | `?string` | Optional | Unique value provided by the client for the payment. | getClientPaymentId(): ?string | setClientPaymentId(?string clientPaymentId): void |
| `autoAcceptQuote` | `?bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | getAutoAcceptQuote(): ?bool | setAutoAcceptQuote(?bool autoAcceptQuote): void |
| `notBefore` | `?\DateTime` | Optional | Transfer is scheduled and will not process before this time. | getNotBefore(): ?\DateTime | setNotBefore(?\DateTime notBefore): void |
| `notAfter` | `?\DateTime` | Optional | Transfer expires if not completed prior to this time. | getNotAfter(): ?\DateTime | setNotAfter(?\DateTime notAfter): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payment

Response from a Transfer request

##### Class Name

`Payment`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `purpose` | [`?string (PaymentPurposeTypes)`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | getPurpose(): ?string | setPurpose(?string purpose): void |
| `clientPaymentId` | `?string` | Optional | Unique value provided by the client for the payment. | getClientPaymentId(): ?string | setClientPaymentId(?string clientPaymentId): void |
| `autoAcceptQuote` | `?bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | getAutoAcceptQuote(): ?bool | setAutoAcceptQuote(?bool autoAcceptQuote): void |
| `expires` | `?\DateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | getExpires(): ?\DateTime | setExpires(?\DateTime expires): void |
| `notBefore` | `?\DateTime` | Optional | Transfer is scheduled and will not process before this time. | getNotBefore(): ?\DateTime | setNotBefore(?\DateTime notBefore): void |
| `notAfter` | `?\DateTime` | Optional | Transfer expires if not completed prior to this time. | getNotAfter(): ?\DateTime | setNotAfter(?\DateTime notAfter): void |
| `status` | [`?string (TransferStatusTypes)`](#transfer-status-types) | Optional | Current status of a transfer | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payments Collection-Response

Response from a Payment collection request

##### Class Name

`PaymentsCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(PaymentResponse[])`](#payment-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Response

Response from a Payment request

##### Class Name

`PaymentResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |
| `purpose` | [`?string (PaymentPurposeTypes)`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | getPurpose(): ?string | setPurpose(?string purpose): void |
| `clientPaymentId` | `?string` | Optional | Unique value provided by the client for the payment. | getClientPaymentId(): ?string | setClientPaymentId(?string clientPaymentId): void |
| `autoAcceptQuote` | `?bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | getAutoAcceptQuote(): ?bool | setAutoAcceptQuote(?bool autoAcceptQuote): void |
| `expires` | `?\DateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | getExpires(): ?\DateTime | setExpires(?\DateTime expires): void |
| `notBefore` | `?\DateTime` | Optional | Transfer is scheduled and will not process before this time. | getNotBefore(): ?\DateTime | setNotBefore(?\DateTime notBefore): void |
| `notAfter` | `?\DateTime` | Optional | Transfer expires if not completed prior to this time. | getNotAfter(): ?\DateTime | setNotAfter(?\DateTime notAfter): void |
| `status` | [`?string (TransferStatusTypes)`](#transfer-status-types) | Optional | Current status of a transfer | getStatus(): ?string | setStatus(?string status): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Collection-Response

Response from a Transfer request

##### Class Name

`TransferCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(TransferResponse[])`](#transfer-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Name

##### Class Name

`UserName`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | getLastName(): ?string | setLastName(?string lastName): void |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

#### Dob

##### Class Name

`Dob`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dateOfBirth` | `?\DateTime` | Optional | User's date of birth | getDateOfBirth(): ?\DateTime | setDateOfBirth(?\DateTime dateOfBirth): void |

##### Example (as JSON)

```json
{
  "dateOfBirth": null
}
```

#### Business Information

Physical address of the business and other information, such as <i>Operating Name</i>, <i>Registration ID</i>, etc.

##### Class Name

`BusinessInformation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `businessName` | `?string` | Optional | Legal name for the business | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `businessOperatingName` | `?string` | Optional | Name under which the business operates | getBusinessOperatingName(): ?string | setBusinessOperatingName(?string businessOperatingName): void |
| `businessRegistrationId` | `?string` | Optional | Registration number or ID assigned by a government body | getBusinessRegistrationId(): ?string | setBusinessRegistrationId(?string businessRegistrationId): void |
| `businessRegistrationRegion` | `?string` | Optional | State, province, or territory where the business is registered | getBusinessRegistrationRegion(): ?string | setBusinessRegistrationRegion(?string businessRegistrationRegion): void |
| `businessRegistrationCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessRegistrationCountry(): ?string | setBusinessRegistrationCountry(?string businessRegistrationCountry): void |
| `businessContactRole` | [`?string (BusinessContactRole)`](#business-contact-role) | Optional | Role of the user within the business | getBusinessContactRole(): ?string | setBusinessContactRole(?string businessContactRole): void |
| `businessAddressLine1` | `?string` | Optional | First line of the business address that specifies street number, street name, and building name | getBusinessAddressLine1(): ?string | setBusinessAddressLine1(?string businessAddressLine1): void |
| `businessAddressLine2` | `?string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getBusinessAddressLine2(): ?string | setBusinessAddressLine2(?string businessAddressLine2): void |
| `businessAddressLine3` | `?string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | getBusinessAddressLine3(): ?string | setBusinessAddressLine3(?string businessAddressLine3): void |
| `businessAddressLine4` | `?string` | Optional | fourth line of the business address street address | getBusinessAddressLine4(): ?string | setBusinessAddressLine4(?string businessAddressLine4): void |
| `businessAddressLine5` | `?string` | Optional | Fifth line of the business address street address | getBusinessAddressLine5(): ?string | setBusinessAddressLine5(?string businessAddressLine5): void |
| `businessCity` | `?string` | Optional | City the business is registered | getBusinessCity(): ?string | setBusinessCity(?string businessCity): void |
| `businessRegion` | `?string` | Optional | State, province, or region the business is registered | getBusinessRegion(): ?string | setBusinessRegion(?string businessRegion): void |
| `businessCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBusinessCountry(): ?string | setBusinessCountry(?string businessCountry): void |
| `businessPostalCode` | `?string` | Optional | Postal code for the business address | getBusinessPostalCode(): ?string | setBusinessPostalCode(?string businessPostalCode): void |
| `businessPremiseNumber` | `?string` | Optional | House number for the business address | getBusinessPremiseNumber(): ?string | setBusinessPremiseNumber(?string businessPremiseNumber): void |
| `businessType` | [`?string (BusinessTypes)`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | getBusinessType(): ?string | setBusinessType(?string businessType): void |

##### Example (as JSON)

```json
{
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null
}
```

#### User Kyc Information

##### Class Name

`UserKycInformation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `driverLicenseId` | `?string` | Optional | User's driver's license number | getDriverLicenseId(): ?string | setDriverLicenseId(?string driverLicenseId): void |
| `passportId` | `?string` | Optional | User's passport number | getPassportId(): ?string | setPassportId(?string passportId): void |
| `governmentIdType` | [`?string (GovernmentIdType)`](#government-id-type) | Optional | User's government ID type | getGovernmentIdType(): ?string | setGovernmentIdType(?string governmentIdType): void |
| `governmentId` | `?string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | getGovernmentId(): ?string | setGovernmentId(?string governmentId): void |

##### Example (as JSON)

```json
{
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null
}
```

#### Phone Numbers

##### Class Name

`PhoneNumbers`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | getPhoneNumber(): string | setPhoneNumber(string phoneNumber): void |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `phoneNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getPhoneNumberCountry(): string | setPhoneNumberCountry(string phoneNumberCountry): void |
| `mobileNumberCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getMobileNumberCountry(): string | setMobileNumberCountry(string mobileNumberCountry): void |

##### Example (as JSON)

```json
{
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC"
}
```

#### Email Address

Contact email address for the user account

##### Class Name

`EmailAddress`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `email` | `?string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | getEmail(): ?string | setEmail(?string email): void |

##### Example (as JSON)

```json
{
  "email": null
}
```

#### User Employer Id

User's employer identifier, generally used for tax purposes.

##### Class Name

`UserEmployerId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `employerId` | `?string` | Optional | User's employer identifier | getEmployerId(): ?string | setEmployerId(?string employerId): void |

##### Example (as JSON)

```json
{
  "employerId": null
}
```

#### Gender

Gender as the user identifies

##### Class Name

`Gender`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `gender` | [`?string (GenderTypes)`](#gender-types) | Optional | Gender as a user identifies | getGender(): ?string | setGender(?string gender): void |

##### Example (as JSON)

```json
{
  "gender": null
}
```

#### Language

Preferred language for the user's account. <i>Defaults to English</i>

##### Class Name

`Language`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `language` | [`?string (LanguageTypes)`](#language-types) | Optional | Language type in IETF's BCP 47 format | getLanguage(): ?string | setLanguage(?string language): void |

##### Example (as JSON)

```json
{
  "language": null
}
```

#### User Type

User's profile type

##### Class Name

`UserType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `userType` | [`?string (UserTypes)`](#user-types) | Optional | Account holder's profile type | getUserType(): ?string | setUserType(?string userType): void |

##### Example (as JSON)

```json
{
  "userType": null
}
```

#### Program User Id

Program identifier for the user

##### Class Name

`ProgramUserId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `programUserId` | `?string` | Optional | Program identifier for the user | getProgramUserId(): ?string | setProgramUserId(?string programUserId): void |

##### Example (as JSON)

```json
{
  "programUserId": null
}
```

#### Source Destination Token

Unique identifier representing the source of the funds.

##### Class Name

`SourceDestinationToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null
}
```

#### Token

Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.

##### Class Name

`Token`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Client Transfer Id

Unique value provided by the client for the transfer, utilized for reference and deduplication.

##### Class Name

`ClientTransferId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientTransferId` | `?string` | Optional | Unique value provided by the client for the transfer. | getClientTransferId(): ?string | setClientTransferId(?string clientTransferId): void |

##### Example (as JSON)

```json
{
  "clientTransferId": null
}
```

#### Notes

Optional comments visible to the user

##### Class Name

`Notes`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notes` | `?string` | Optional | Optional comments visible to the user. | getNotes(): ?string | setNotes(?string notes): void |

##### Example (as JSON)

```json
{
  "notes": null
}
```

#### Memo

Optional internal memo not visible to the user.

##### Class Name

`Memo`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `memo` | `?string` | Optional | Optional internal memo not visible to the user. | getMemo(): ?string | setMemo(?string memo): void |

##### Example (as JSON)

```json
{
  "memo": null
}
```

#### Created On

Time at which the object was created.

##### Class Name

`CreatedOn`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |

##### Example (as JSON)

```json
{
  "createdOn": null
}
```

#### Transfer Status

Current status of the transfer.

##### Class Name

`TransferStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`?string (TransferStatusTypes)`](#transfer-status-types) | Optional | Current status of a transfer | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### User Status

Current status of the user.

##### Class Name

`UserStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`?string (UserStatusTypes)`](#user-status-types) | Optional | Current status of the user | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Payment Purpose

Purpose for the payment being made.

##### Class Name

`PaymentPurpose`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `purpose` | [`?string (PaymentPurposeTypes)`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | getPurpose(): ?string | setPurpose(?string purpose): void |

##### Example (as JSON)

```json
{
  "purpose": null
}
```

#### Source Token

Unique identifier representing the source of funds.

##### Class Name

`SourceToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceToken` | `?string` | Optional | Unique identifier representing the source of funds. | getSourceToken(): ?string | setSourceToken(?string sourceToken): void |

##### Example (as JSON)

```json
{
  "sourceToken": null
}
```

#### Destination Token

Unique identifier representing the destination of funds.

##### Class Name

`DestinationToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `destinationToken` | `?string` | Optional | Unique identifier representing the destination of funds. | getDestinationToken(): ?string | setDestinationToken(?string destinationToken): void |

##### Example (as JSON)

```json
{
  "destinationToken": null
}
```

#### Client Payment Id

Unique value provided by the client for the payment, utilized for reference and de-duplication.

##### Class Name

`ClientPaymentId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientPaymentId` | `?string` | Optional | Unique value provided by the client for the payment. | getClientPaymentId(): ?string | setClientPaymentId(?string clientPaymentId): void |

##### Example (as JSON)

```json
{
  "clientPaymentId": null
}
```

#### Auto Accept Quote

Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.

##### Class Name

`AutoAcceptQuote`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `autoAcceptQuote` | `?bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | getAutoAcceptQuote(): ?bool | setAutoAcceptQuote(?bool autoAcceptQuote): void |

##### Example (as JSON)

```json
{
  "autoAcceptQuote": null
}
```

#### Rate

Exchange rate

##### Class Name

`Rate`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `rate` | `?float` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` | getRate(): ?float | setRate(?float rate): void |

##### Example (as JSON)

```json
{
  "rate": null
}
```

#### Fx

The details of the country's foreign exchange currency.

##### Class Name

`Fx`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fx` | [`?FxObject`](#fx-object) | Optional | Currency conversion object details | getFx(): ?FxObject | setFx(?FxObject fx): void |

##### Example (as JSON)

```json
{
  "fx": null
}
```

#### Paper Check Base

##### Class Name

`PaperCheckBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string (TransferTypes)`](#transfer-types) | Optional | Transfer type | getType(): ?string | setType(?string type): void |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |
| `shippingMethod` | [`?string (ShippingMethodTypes)`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | getShippingMethod(): ?string | setShippingMethod(?string shippingMethod): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Type

Type of transfer method

##### Class Name

`TransferType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string (TransferTypes)`](#transfer-types) | Optional | Transfer type | getType(): ?string | setType(?string type): void |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account Ownership

Account ownership type

##### Class Name

`BankAccountOwnership`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null
}
```

#### Shipping Method

Shipping method desired

##### Class Name

`ShippingMethod`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shippingMethod` | [`?string (ShippingMethodTypes)`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | getShippingMethod(): ?string | setShippingMethod(?string shippingMethod): void |

##### Example (as JSON)

```json
{
  "shippingMethod": null
}
```

#### Paper Check

Details of the paper check

##### Class Name

`PaperCheck`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `type` | [`?string (TransferTypes)`](#transfer-types) | Optional | Transfer type | getType(): ?string | setType(?string type): void |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |
| `shippingMethod` | [`?string (ShippingMethodTypes)`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | getShippingMethod(): ?string | setShippingMethod(?string shippingMethod): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check-Response

Response to a paper check request

##### Class Name

`PaperCheckResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `type` | [`?string (TransferTypes)`](#transfer-types) | Optional | Transfer type | getType(): ?string | setType(?string type): void |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. | getAmount(): float | setAmount(float amount): void |
| `currency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getCurrency(): string | setCurrency(string currency): void |
| `addressLine1` | `?string` | Optional | First line of the address that specifies street number, street name, and building name | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `addressLine3` | `?string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | getAddressLine3(): ?string | setAddressLine3(?string addressLine3): void |
| `addressLine4` | `?string` | Optional | Fourth line of the address, if any | getAddressLine4(): ?string | setAddressLine4(?string addressLine4): void |
| `addressLine5` | `?string` | Optional | Fifth line of the address, if any | getAddressLine5(): ?string | setAddressLine5(?string addressLine5): void |
| `city` | `?string` | Optional | City or town of the business address | getCity(): ?string | setCity(?string city): void |
| `region` | `?string` | Optional | State, province, or territory of the business address | getRegion(): ?string | setRegion(?string region): void |
| `country` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `premiseNumber` | `?string` | Optional | House or building number of the business address | getPremiseNumber(): ?string | setPremiseNumber(?string premiseNumber): void |
| `addressType` | [`?string (AddressTypes)`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | getAddressType(): ?string | setAddressType(?string addressType): void |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |
| `shippingMethod` | [`?string (ShippingMethodTypes)`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | getShippingMethod(): ?string | setShippingMethod(?string shippingMethod): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check Collection-Response

Response to a paper check collection request

##### Class Name

`PaperCheckCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(PaperCheck[])`](#paper-check) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Bank Account Fields

Classifies account field objects

##### Class Name

`BankAccountFields`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |
| `type` | [`?string (BankAccountTypes)`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | getType(): ?string | setType(?string type): void |
| `fields` | [`?(KeyValuePairBankFieldTypesString[])`](#key-value-pair-bank-field-types-string) | Optional | - | getFields(): ?array | setFields(?array fields): void |
| `bankCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getBankCurrency(): ?string | setBankCurrency(?string bankCurrency): void |
| `bankCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBankCountry(): ?string | setBankCountry(?string bankCountry): void |
| `description` | `?string` | Optional | User-supplied description of the bank account for reference | getDescription(): ?string | setDescription(?string description): void |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Type

Type of bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string (BankAccountTypes)`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | getType(): ?string | setType(?string type): void |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account

Unique identifier for the bank account

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (BankAccountStatusTypes)`](#bank-account-status-types) | Optional | Current verification status type of the bank account | getStatus(): ?string | setStatus(?string status): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |
| `type` | [`?string (BankAccountTypes)`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | getType(): ?string | setType(?string type): void |
| `fields` | [`?(KeyValuePairBankFieldTypesString[])`](#key-value-pair-bank-field-types-string) | Optional | - | getFields(): ?array | setFields(?array fields): void |
| `bankCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getBankCurrency(): ?string | setBankCurrency(?string bankCurrency): void |
| `bankCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBankCountry(): ?string | setBankCountry(?string bankCountry): void |
| `description` | `?string` | Optional | User-supplied description of the bank account for reference | getDescription(): ?string | setDescription(?string description): void |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Status

Verification status of the bank account (<i>Verified</i>, <i>Disabled</i>)

##### Class Name

`BankAccountStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`?string (BankAccountStatusTypes)`](#bank-account-status-types) | Optional | Current verification status type of the bank account | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Bank Account-Response

Response to the bank account request

##### Class Name

`BankAccountResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (BankAccountStatusTypes)`](#bank-account-status-types) | Optional | Current verification status type of the bank account | getStatus(): ?string | setStatus(?string status): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `bankAccountOwnershipType` | [`?string (BankAccountOwnershipTypes)`](#bank-account-ownership-types) | Optional | Account ownership types | getBankAccountOwnershipType(): ?string | setBankAccountOwnershipType(?string bankAccountOwnershipType): void |
| `type` | [`?string (BankAccountTypes)`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | getType(): ?string | setType(?string type): void |
| `fields` | [`?(KeyValuePairBankFieldTypesString[])`](#key-value-pair-bank-field-types-string) | Optional | - | getFields(): ?array | setFields(?array fields): void |
| `bankCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getBankCurrency(): ?string | setBankCurrency(?string bankCurrency): void |
| `bankCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getBankCountry(): ?string | setBankCountry(?string bankCountry): void |
| `description` | `?string` | Optional | User-supplied description of the bank account for reference | getDescription(): ?string | setDescription(?string description): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null,
  "links": null
}
```

#### Bank Account Collection-Response

Collection response to the bank account request

##### Class Name

`BankAccountCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(BankAccountResponse[])`](#bank-account-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Prepaid Card Package

Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>, including artwork, packaging, and delivery method

##### Class Name

`PrepaidCardPackage`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardPackage` | `?string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | getCardPackage(): ?string | setCardPackage(?string cardPackage): void |

##### Example (as JSON)

```json
{
  "cardPackage": null
}
```

#### Prepaid Card Base

Base class applied to the prepaid card

##### Class Name

`PrepaidCardBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardPackage` | `?string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | getCardPackage(): ?string | setCardPackage(?string cardPackage): void |
| `programToken` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` | getProgramToken(): string | setProgramToken(string programToken): void |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2"
}
```

#### Prepaid Card Status

Current status of the prepaid card

##### Class Name

`PrepaidCardStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`?string (Status)`](#status) | Optional | Current status of the prepaid card | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Token Type

##### Class Name

`TokenType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tokenType` | [`?string (TokenTypes)`](#token-types) | Optional | Types of resources represented by a token | getTokenType(): ?string | setTokenType(?string tokenType): void |

##### Example (as JSON)

```json
{
  "tokenType": null
}
```

#### Prepaid Card Base Ext

Base extension for the prepaid card

##### Class Name

`PrepaidCardBaseExt`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (Status)`](#status) | Optional | Current status of the prepaid card | getStatus(): ?string | setStatus(?string status): void |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null
}
```

#### Card Network

Major credit card network

##### Class Name

`CardNetwork`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardNetwork` | [`?string (CardNetworkTypes)`](#card-network-types) | Optional | Major credit card network types | getCardNetwork(): ?string | setCardNetwork(?string cardNetwork): void |

##### Example (as JSON)

```json
{
  "cardNetwork": null
}
```

#### Card Personalization Type

Type of personalization for the prepaid card

##### Class Name

`CardPersonalizationType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardPersonalization` | [`?string (PrepaidCardPersonalizationTypes)`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) | getCardPersonalization(): ?string | setCardPersonalization(?string cardPersonalization): void |

##### Example (as JSON)

```json
{
  "cardPersonalization": null
}
```

#### Prepaid Card

##### Class Name

`PrepaidCard`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (Status)`](#status) | Optional | Current status of the prepaid card | getStatus(): ?string | setStatus(?string status): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `country` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getCountry(): string | setCountry(string country): void |
| `currency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getCurrency(): ?string | setCurrency(?string currency): void |
| `cardPersonalization` | [`?string (PrepaidCardPersonalizationTypes)`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) | getCardPersonalization(): ?string | setCardPersonalization(?string cardPersonalization): void |
| `cardPackage` | `?string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | getCardPackage(): ?string | setCardPackage(?string cardPackage): void |
| `cardNetwork` | [`?string (CardNetworkTypes)`](#card-network-types) | Optional | Major credit card network types | getCardNetwork(): ?string | setCardNetwork(?string cardNetwork): void |
| `expires` | `?\DateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | getExpires(): ?\DateTime | setExpires(?\DateTime expires): void |
| `cardNumber` | `?string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` | getCardNumber(): ?string | setCardNumber(?string cardNumber): void |
| `cvv` | `?string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) | getCvv(): ?string | setCvv(?string cvv): void |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null
}
```

#### Currency

Currency code used for the object

##### Class Name

`Currency`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `currency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getCurrency(): ?string | setCurrency(?string currency): void |

##### Example (as JSON)

```json
{
  "currency": null
}
```

#### Country

Two-digit country code for the object

##### Class Name

`Country`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `country` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getCountry(): string | setCountry(string country): void |

##### Example (as JSON)

```json
{
  "country": "FO"
}
```

#### Prepaid Card-Request Response

##### Class Name

`PrepaidCardRequestResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (Status)`](#status) | Optional | Current status of the prepaid card | getStatus(): ?string | setStatus(?string status): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "links": null
}
```

#### Prepaid Card-Response

##### Class Name

`PrepaidCardResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `status` | [`?string (Status)`](#status) | Optional | Current status of the prepaid card | getStatus(): ?string | setStatus(?string status): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `country` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getCountry(): string | setCountry(string country): void |
| `currency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getCurrency(): ?string | setCurrency(?string currency): void |
| `cardPersonalization` | [`?string (PrepaidCardPersonalizationTypes)`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) | getCardPersonalization(): ?string | setCardPersonalization(?string cardPersonalization): void |
| `cardPackage` | `?string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | getCardPackage(): ?string | setCardPackage(?string cardPackage): void |
| `cardNetwork` | [`?string (CardNetworkTypes)`](#card-network-types) | Optional | Major credit card network types | getCardNetwork(): ?string | setCardNetwork(?string cardNetwork): void |
| `expires` | `?\DateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | getExpires(): ?\DateTime | setExpires(?\DateTime expires): void |
| `cardNumber` | `?string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` | getCardNumber(): ?string | setCardNumber(?string cardNumber): void |
| `cvv` | `?string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) | getCvv(): ?string | setCvv(?string cvv): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null,
  "links": null
}
```

#### Prepaid Card Collection-Response

##### Class Name

`PrepaidCardCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(PrepaidCardResponse[])`](#prepaid-card-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Card Masked Pan

Card number using PAN truncation

##### Class Name

`CardMaskedPan`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardNumber` | `?string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` | getCardNumber(): ?string | setCardNumber(?string cardNumber): void |

##### Example (as JSON)

```json
{
  "cardNumber": null
}
```

#### Prepaid Card Replacement Reason

##### Class Name

`PrepaidCardReplacementReason`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardReplacementReason` | [`?string (PrepaidCardReplacementReasonTypes)`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. | getCardReplacementReason(): ?string | setCardReplacementReason(?string cardReplacementReason): void |

##### Example (as JSON)

```json
{
  "cardReplacementReason": null
}
```

#### Prepaid Card Replacement Base

##### Class Name

`PrepaidCardReplacementBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardPackage` | `?string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | getCardPackage(): ?string | setCardPackage(?string cardPackage): void |
| `programToken` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` | getProgramToken(): string | setProgramToken(string programToken): void |
| `cardReplacementReason` | [`?string (PrepaidCardReplacementReasonTypes)`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. | getCardReplacementReason(): ?string | setCardReplacementReason(?string cardReplacementReason): void |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2",
  "cardReplacementReason": null
}
```

#### Prepaid Card Pin Token

##### Class Name

`PrepaidCardPinToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardPinToken` | `?string` | Optional | Token used as part of a two-leg card PIN reveal request sent directly from the client that generally involves a second piece of data, such as the CVV code on the back of the card. | getCardPinToken(): ?string | setCardPinToken(?string cardPinToken): void |
| `url` | `?string` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params | getUrl(): ?string | setUrl(?string url): void |

##### Example (as JSON)

```json
{
  "cardPinToken": null,
  "url": null
}
```

#### Prepaid Card Pin

##### Class Name

`PrepaidCardPin`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardPin` | `?string` | Optional | Card PIN for ATM and Debit usage | getCardPin(): ?string | setCardPin(?string cardPin): void |

##### Example (as JSON)

```json
{
  "cardPin": null
}
```

#### Cvv

Three- or four-digit Card Verification Value (CVV) number displayed on the back of a credit or debit card

##### Class Name

`Cvv`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cvv` | `?string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) | getCvv(): ?string | setCvv(?string cvv): void |

##### Example (as JSON)

```json
{
  "cvv": null
}
```

#### Identity Verification Provider Type

Provider type of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvProvider` | [`?string (IdentityVerificationProviderTypes)`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks | getIdvProvider(): ?string | setIdvProvider(?string idvProvider): void |

##### Example (as JSON)

```json
{
  "idvProvider": null
}
```

#### Identity Verification Result Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvResult` | [`?string (IdentityVerificationResultTypes)`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | getIdvResult(): ?string | setIdvResult(?string idvResult): void |

##### Example (as JSON)

```json
{
  "idvResult": null
}
```

#### Identity Verification Sub Result Type

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationSubResultType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvSubResult` | [`?string (IdentityVerificationResultSubTypes)`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. | getIdvSubResult(): ?string | setIdvSubResult(?string idvSubResult): void |

##### Example (as JSON)

```json
{
  "idvSubResult": null
}
```

#### Identity Verification Disposition Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvDispostion` | [`?string (IdentityVerificationDispositionTypes)`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | getIdvDispostion(): ?string | setIdvDispostion(?string idvDispostion): void |

##### Example (as JSON)

```json
{
  "idvDispostion": null
}
```

#### Identity Verification Check Type

Type of verification used for performing an identity check

##### Class Name

`IdentityVerificationCheckType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvCheckType` | [`?string (IdentityVerificationCheckTypes)`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) | getIdvCheckType(): ?string | setIdvCheckType(?string idvCheckType): void |

##### Example (as JSON)

```json
{
  "idvCheckType": null
}
```

#### Identity Verification Base

##### Class Name

`IdentityVerificationBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvProviderReference` | `?string` | Optional | IDV provider unique ID for the IDV check performed | getIdvProviderReference(): ?string | setIdvProviderReference(?string idvProviderReference): void |
| `idvResult` | [`?string (IdentityVerificationResultTypes)`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | getIdvResult(): ?string | setIdvResult(?string idvResult): void |
| `idvSubResult` | [`?string (IdentityVerificationResultSubTypes)`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. | getIdvSubResult(): ?string | setIdvSubResult(?string idvSubResult): void |
| `idvProvider` | [`?string (IdentityVerificationProviderTypes)`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks | getIdvProvider(): ?string | setIdvProvider(?string idvProvider): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `raw` | `?string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only | getRaw(): ?string | setRaw(?string raw): void |
| `idvCheckType` | [`?string (IdentityVerificationCheckTypes)`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) | getIdvCheckType(): ?string | setIdvCheckType(?string idvCheckType): void |
| `idvDispostion` | [`?string (IdentityVerificationDispositionTypes)`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | getIdvDispostion(): ?string | setIdvDispostion(?string idvDispostion): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null
}
```

#### Identity Verification Provider Reference

Provider reference used for performing identity checks for the provider

##### Class Name

`IdentityVerificationProviderReference`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvProviderReference` | `?string` | Optional | IDV provider unique ID for the IDV check performed | getIdvProviderReference(): ?string | setIdvProviderReference(?string idvProviderReference): void |

##### Example (as JSON)

```json
{
  "idvProviderReference": null
}
```

#### Identity Verification Provider Raw Output

Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only

##### Class Name

`IdentityVerificationProviderRawOutput`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `raw` | `?string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only | getRaw(): ?string | setRaw(?string raw): void |

##### Example (as JSON)

```json
{
  "raw": null
}
```

#### Identity Verification-Response

##### Class Name

`IdentityVerificationResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idvProviderReference` | `?string` | Optional | IDV provider unique ID for the IDV check performed | getIdvProviderReference(): ?string | setIdvProviderReference(?string idvProviderReference): void |
| `idvResult` | [`?string (IdentityVerificationResultTypes)`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | getIdvResult(): ?string | setIdvResult(?string idvResult): void |
| `idvSubResult` | [`?string (IdentityVerificationResultSubTypes)`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. | getIdvSubResult(): ?string | setIdvSubResult(?string idvSubResult): void |
| `idvProvider` | [`?string (IdentityVerificationProviderTypes)`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks | getIdvProvider(): ?string | setIdvProvider(?string idvProvider): void |
| `createdOn` | `?\DateTime` | Optional | Time at which the object was created. | getCreatedOn(): ?\DateTime | setCreatedOn(?\DateTime createdOn): void |
| `raw` | `?string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only | getRaw(): ?string | setRaw(?string raw): void |
| `idvCheckType` | [`?string (IdentityVerificationCheckTypes)`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) | getIdvCheckType(): ?string | setIdvCheckType(?string idvCheckType): void |
| `idvDispostion` | [`?string (IdentityVerificationDispositionTypes)`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | getIdvDispostion(): ?string | setIdvDispostion(?string idvDispostion): void |
| `token` | `?string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | getToken(): ?string | setToken(?string token): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null,
  "links": null
}
```

#### Identity Verification Collection-Response

##### Class Name

`IdentityVerificationCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(IdentityVerificationResponse[])`](#identity-verification-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Key Value Pair String String

##### Class Name

`KeyValuePairStringString`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | - | getKey(): ?string | setKey(?string key): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Pair Bank Field Types String

1...N required fields as determined by call to get requirements

##### Class Name

`KeyValuePairBankFieldTypesString`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | [`string (BankAccountFieldTypes)`](#bank-account-field-types) | Required | Classifies account field types | getKey(): string | setKey(string key): void |
| `value` | `string` | Required | - | getValue(): string | setValue(string value): void |

##### Example (as JSON)

```json
{
  "key": "BANK_NON_SWIFT_BIC",
  "value": "value2"
}
```

#### Key Value Pair Bank Currency Currency Types

##### Class Name

`KeyValuePairBankCurrencyCurrencyTypes`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | **Default**: `'BANK_CURRENCY'`<br>*Default: `'BANK_CURRENCY'`* | getKey(): ?string | setKey(?string key): void |
| `value` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getValue(): ?string | setValue(?string value): void |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Bank Country Country Types

##### Class Name

`KeyValueBankCountryCountryTypes`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | **Default**: `'BANK_COUNTRY'`<br>*Default: `'BANK_COUNTRY'`* | getKey(): ?string | setKey(?string key): void |
| `value` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getValue(): ?string | setValue(?string value): void |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Bank Account Required Fields

Classifies the required account field objects

##### Class Name

`BankAccountRequiredFields`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `format` | [`?BankAccountRequirementFormat`](#bank-account-requirement-format) | Optional | Classifies the format of the required information for a bank account | getFormat(): ?BankAccountRequirementFormat | setFormat(?BankAccountRequirementFormat format): void |
| `requirement` | [`?string (BankAccountFieldTypes)`](#bank-account-field-types) | Optional | Classifies account field types | getRequirement(): ?string | setRequirement(?string requirement): void |
| `description` | [`?(KeyValuePairLanguageTypeString[])`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes | getDescription(): ?array | setDescription(?array description): void |
| `validators` | [`?(BankAccountRequirementValidator[])`](#bank-account-requirement-validator) | Optional | - | getValidators(): ?array | setValidators(?array validators): void |

##### Example (as JSON)

```json
{
  "format": null,
  "requirement": null,
  "description": null,
  "validators": null
}
```

#### Bank Account Requirement Format

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormat`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `example` | `?string` | Optional | Example of a requirement generated from the validator(s) | getExample(): ?string | setExample(?string example): void |
| `legend` | [`?(BankAccountRequirementFormatLegend[])`](#bank-account-requirement-format-legend) | Optional | - | getLegend(): ?array | setLegend(?array legend): void |

##### Example (as JSON)

```json
{
  "example": null,
  "legend": null
}
```

#### Bank Account Requirement Format Legend

Classifies the legend format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormatLegend`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | - | getKey(): ?string | setKey(?string key): void |
| `descriptions` | [`?(KeyValuePairLanguageTypeString[])`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes | getDescriptions(): ?array | setDescriptions(?array descriptions): void |

##### Example (as JSON)

```json
{
  "key": null,
  "descriptions": null
}
```

#### Key Value Pair Language Type String

Localized requirement description for display purposes

##### Class Name

`KeyValuePairLanguageTypeString`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `language` | [`?string (LanguageTypes)`](#language-types) | Optional | Language type in IETF's BCP 47 format | getLanguage(): ?string | setLanguage(?string language): void |
| `translation` | `?string` | Optional | Translated string in the specified language | getTranslation(): ?string | setTranslation(?string translation): void |

##### Example (as JSON)

```json
{
  "language": null,
  "translation": null
}
```

#### Bank Account Requirement Validator

Specifies the validator type for the required bank account information

##### Class Name

`BankAccountRequirementValidator`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `validatorType` | [`?string (ValidatorTypes)`](#validator-types) | Optional | - | getValidatorType(): ?string | setValidatorType(?string validatorType): void |
| `expression` | `string` | Required | Validation regular expression | getExpression(): string | setExpression(string expression): void |

##### Example (as JSON)

```json
{
  "validatorType": null,
  "expression": "expression2"
}
```

#### Bank Account Requirement

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirement`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bankCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getBankCountry(): string | setBankCountry(string bankCountry): void |
| `bankCurrency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getBankCurrency(): string | setBankCurrency(string bankCurrency): void |
| `sourceCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getSourceCountry(): ?string | setSourceCountry(?string sourceCountry): void |
| `sourceCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getSourceCurrency(): ?string | setSourceCurrency(?string sourceCurrency): void |
| `requirements` | [`?(BankAccountRequiredFields[])`](#bank-account-required-fields) | Optional | - | getRequirements(): ?array | setRequirements(?array requirements): void |
| `quote` | [`?MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts | getQuote(): ?MonetaryFormatted | setQuote(?MonetaryFormatted quote): void |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null
}
```

#### Bank Account Requirement-Response

##### Class Name

`BankAccountRequirementResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bankCountry` | [`string (CountryTypes)`](#country-types) | Required | Two-digit country code types | getBankCountry(): string | setBankCountry(string bankCountry): void |
| `bankCurrency` | [`string (CurrencyTypes)`](#currency-types) | Required | Currency code type for the object | getBankCurrency(): string | setBankCurrency(string bankCurrency): void |
| `sourceCountry` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getSourceCountry(): ?string | setSourceCountry(?string sourceCountry): void |
| `sourceCurrency` | [`?string (CurrencyTypes)`](#currency-types) | Optional | Currency code type for the object | getSourceCurrency(): ?string | setSourceCurrency(?string sourceCurrency): void |
| `requirements` | [`?(BankAccountRequiredFields[])`](#bank-account-required-fields) | Optional | - | getRequirements(): ?array | setRequirements(?array requirements): void |
| `quote` | [`?MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts | getQuote(): ?MonetaryFormatted | setQuote(?MonetaryFormatted quote): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null,
  "links": null
}
```

#### Bank Account Requirement Collection-Response

##### Class Name

`BankAccountRequirementCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payload` | [`?(BankAccountRequirementResponse[])`](#bank-account-requirement-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Occupation

##### Class Name

`Occupation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `occupation` | [`?string (OccupationTypes)`](#occupation-types) | Optional | Type of occupation for the user | getOccupation(): ?string | setOccupation(?string occupation): void |

##### Example (as JSON)

```json
{
  "occupation": null
}
```

#### Tax Resident Status

##### Class Name

`TaxResidentStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `taxResidentStatus` | [`?string (TaxResidentStatusTypes)`](#tax-resident-status-types) | Optional | Tax resident status type of a country | getTaxResidentStatus(): ?string | setTaxResidentStatus(?string taxResidentStatus): void |

##### Example (as JSON)

```json
{
  "taxResidentStatus": null
}
```

#### Webhook-Subscription

Webhook subscription object

##### Class Name

`WebhookSubscription`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `url` | `?string` | Optional | - | getUrl(): ?string | setUrl(?string url): void |
| `mNamespace` | [`?string (MNamespace)`](#namespace) | Optional | Namespace used to identify and refer to the object | getMNamespace(): ?string | setMNamespace(?string mNamespace): void |

##### Example (as JSON)

```json
{
  "url": null,
  "namespace": null
}
```

#### Webhook-Subscription-Response

Webhook Subscription response

##### Class Name

`WebhookSubscriptionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |
| `url` | `?string` | Optional | - | getUrl(): ?string | setUrl(?string url): void |
| `mNamespace` | [`?string (MNamespace)`](#namespace) | Optional | Namespace used to identify and refer to the object | getMNamespace(): ?string | setMNamespace(?string mNamespace): void |
| `token` | `?string` | Optional | Token for the webhook subscription | getToken(): ?string | setToken(?string token): void |
| `created` | `?string` | Optional | Time stamp for the date the webhook subscription was created | getCreated(): ?string | setCreated(?string created): void |
| `lastUpdated` | `?string` | Optional | Time stamp for the date the webhook subscription was updated | getLastUpdated(): ?string | setLastUpdated(?string lastUpdated): void |

##### Example (as JSON)

```json
{
  "links": null,
  "url": null,
  "namespace": null,
  "token": null,
  "created": null,
  "lastUpdated": null
}
```

#### Webhook Collection-Response

Webhook Subscription collection response

##### Class Name

`WebhookCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `links` | [`?(HaetosParams[])`](#haetos-params) | Optional | - | getLinks(): ?array | setLinks(?array links): void |
| `payload` | [`?(WebhookSubscriptionResponse[])`](#webhook-subscription-response) | Optional | - | getPayload(): ?array | setPayload(?array payload): void |

##### Example (as JSON)

```json
{
  "links": null,
  "payload": null
}
```

#### Prepaid Card Data-Response

Response to the prepaid card data request

##### Class Name

`PrepaidCardDataResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cardImage` | `?string` | Optional | - | getCardImage(): ?string | setCardImage(?string cardImage): void |
| `cardNumber` | `?float` | Optional | - | getCardNumber(): ?float | setCardNumber(?float cardNumber): void |
| `cvvNumber` | `?string` | Optional | - | getCvvNumber(): ?string | setCvvNumber(?string cvvNumber): void |
| `expiration` | `?string` | Optional | - | getExpiration(): ?string | setExpiration(?string expiration): void |
| `nameOnCard` | `?string` | Optional | - | getNameOnCard(): ?string | setNameOnCard(?string nameOnCard): void |
| `side` | `?string` | Optional | - | getSide(): ?string | setSide(?string side): void |
| `token` | `?string` | Optional | - | getToken(): ?string | setToken(?string token): void |

##### Example (as JSON)

```json
{
  "cardImage": null,
  "cardNumber": null,
  "cvvNumber": null,
  "expiration": null,
  "nameOnCard": null,
  "side": null,
  "token": null
}
```

#### Prepaid Card Data Token

Token assigned to the prepaid card

##### Class Name

`PrepaidCardDataToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `string` | Required | **Constraints**: *Minimum Length*: `1` | getToken(): string | setToken(string token): void |
| `url` | `?string` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params | getUrl(): ?string | setUrl(?string url): void |

##### Example (as JSON)

```json
{
  "token": "token6",
  "url": null
}
```

#### Prepaid Card Data Token-Response

##### Class Name

`PrepaidCardDataTokenResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | [`?PrepaidCardDataToken`](#prepaid-card-data-token) | Optional | Token assigned to the prepaid card | getToken(): ?PrepaidCardDataToken | setToken(?PrepaidCardDataToken token): void |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Business Type

##### Class Name

`BusinessType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `businessType` | [`?string (BusinessTypes)`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | getBusinessType(): ?string | setBusinessType(?string businessType): void |

##### Example (as JSON)

```json
{
  "businessType": null
}
```

#### Country Nationality Information

##### Class Name

`CountryNationalityInformation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `countryOfBirth` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfBirth(): ?string | setCountryOfBirth(?string countryOfBirth): void |
| `countryOfNationality` | [`?string (CountryTypes)`](#country-types) | Optional | Two-digit country code types | getCountryOfNationality(): ?string | setCountryOfNationality(?string countryOfNationality): void |

##### Example (as JSON)

```json
{
  "countryOfBirth": null,
  "countryOfNationality": null
}
```

#### Users Prepaid Cards Pin Response

##### Class Name

`UsersPrepaidCardsPinResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `result` | `?bool` | Optional | - | getResult(): ?bool | setResult(?bool result): void |

##### Example (as JSON)

```json
{
  "result": null
}
```

### Enumerations

* [Transfer Status Types](#transfer-status-types)
* [Payment Purpose Types](#payment-purpose-types)
* [Address Types](#address-types)
* [User Types](#user-types)
* [User Status Types](#user-status-types)
* [Language Types](#language-types)
* [Gender Types](#gender-types)
* [Business Types](#business-types)
* [Transfer Types](#transfer-types)
* [Shipping Method Types](#shipping-method-types)
* [Bank Account Ownership Types](#bank-account-ownership-types)
* [Bank Account Types](#bank-account-types)
* [Bank Account Status Types](#bank-account-status-types)
* [Token Types](#token-types)
* [Card Network Types](#card-network-types)
* [Prepaid Card Personalization Types](#prepaid-card-personalization-types)
* [Currency Types](#currency-types)
* [Country Types](#country-types)
* [Prepaid Card Replacement Reason Types](#prepaid-card-replacement-reason-types)
* [Identity Verification Provider Types](#identity-verification-provider-types)
* [Identity Verification Result Types](#identity-verification-result-types)
* [Identity Verification Result Sub Types](#identity-verification-result-sub-types)
* [Identity Verification Disposition Types](#identity-verification-disposition-types)
* [Identity Verification Check Types](#identity-verification-check-types)
* [Bank Account Field Types](#bank-account-field-types)
* [Validator Types](#validator-types)
* [Occupation Types](#occupation-types)
* [Tax Resident Status Types](#tax-resident-status-types)
* [Namespace](#namespace)
* [Business Contact Role](#business-contact-role)
* [Format](#format)
* [Government Id Type](#government-id-type)
* [Side](#side)
* [Status](#status)

#### Transfer Status Types

Current status of a transfer

##### Class Name

`TransferStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `QUOTED` |
| `PENDING` |
| `SCHEDULED` |
| `COMPLETED` |
| `CANCELLED` |
| `RETURNED` |
| `FAILED` |
| `EXPIRED` |
| `VERIFICATION_HOLD` |

#### Payment Purpose Types

Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services)

##### Class Name

`PaymentPurposeTypesEnum`

##### Fields

| Name |
|  --- |
| `OTHER` |
| `TAXABLE` |
| `INCOME` |
| `BONUS` |
| `EXPENSE` |
| `NON_TAXABLE` |

#### Address Types

Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)

##### Class Name

`AddressTypesEnum`

##### Fields

| Name |
|  --- |
| `RESIDENTIAL` |
| `BUSINESS` |
| `MAILING` |

#### User Types

Account holder's profile type

##### Class Name

`UserTypesEnum`

##### Fields

| Name |
|  --- |
| `INDIVIDUAL` |
| `BUSINESS` |

#### User Status Types

Current status of the user

##### Class Name

`UserStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `ACTIVATED` |
| `PRE_ACTIVATED` |
| `PENDING_EMAIL_VERIFICATION` |
| `PENDING_KYC` |

#### Language Types

Language type in IETF's BCP 47 format

##### Class Name

`LanguageTypesEnum`

##### Fields

| Name |
|  --- |
| `ENUS` |
| `ENGB` |
| `FRCA` |
| `FRFR` |
| `ESMX` |
| `ESES` |
| `PTBR` |
| `PTPT` |
| `DEDE` |
| `ITIT` |
| `JAJP` |
| `ZHCN` |
| `ZHTW` |

#### Gender Types

Gender as a user identifies

##### Class Name

`GenderTypesEnum`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |
| `NOT_SPECIFIED` |

#### Business Types

Type of business (<i>Corporation</i> or <i>Partnership</i>)

##### Class Name

`BusinessTypesEnum`

##### Fields

| Name |
|  --- |
| `CORPORATION` |
| `PARTNERSHIP_DBA` |

#### Transfer Types

Transfer type

##### Class Name

`TransferTypesEnum`

##### Fields

| Name |
|  --- |
| `PAPER_CHECK` |
| `BANK_TRANSFER` |
| `PAYMENT` |
| `SPEND_BACK` |

#### Shipping Method Types

Shipping method type for a pre-paid card or paper check

##### Class Name

`ShippingMethodTypesEnum`

##### Fields

| Name |
|  --- |
| `STANDARD` |
| `EXPEDITED` |

#### Bank Account Ownership Types

Account ownership types

##### Class Name

`BankAccountOwnershipTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

#### Bank Account Types

Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountTypesEnum`

##### Fields

| Name |
|  --- |
| `CHECKING` |
| `SAVINGS` |
| `MONEY_MARKET` |

#### Bank Account Status Types

Current verification status type of the bank account

##### Class Name

`BankAccountStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `DELETED` |
| `ACTIVE` |
| `PENDING_VERIFICATION` |

#### Token Types

Types of resources represented by a token

##### Class Name

`TokenTypesEnum`

##### Fields

| Name |
|  --- |
| `BANK_ACCOUNT` |
| `TRANSFER` |
| `PAYMENT` |
| `SPEND_BACK` |
| `PREPAID_CARD` |
| `USER` |
| `DOCUMENT` |
| `ACCOUNT` |

#### Card Network Types

Major credit card network types

##### Class Name

`CardNetworkTypesEnum`

##### Fields

| Name |
|  --- |
| `VISA` |
| `MASTER_CARD` |

#### Prepaid Card Personalization Types

Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer)

##### Class Name

`PrepaidCardPersonalizationTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONALIZED` |
| `NON_PERSONALIZED` |

#### Currency Types

Currency code type for the object

##### Class Name

`CurrencyTypesEnum`

##### Fields

| Name |
|  --- |
| `USD` |
| `CAD` |
| `MXN` |
| `AUD` |
| `HKD` |
| `NZD` |
| `EUR` |
| `GBP` |

#### Country Types

Two-digit country code types

##### Class Name

`CountryTypesEnum`

##### Fields

| Name |
|  --- |
| `AD` |
| `AE` |
| `AF` |
| `AG` |
| `AI` |
| `AL` |
| `AM` |
| `AN` |
| `AO` |
| `AQ` |
| `AR` |
| `AS_` |
| `AT` |
| `AU` |
| `AW` |
| `AX` |
| `AZ` |
| `BA` |
| `BB` |
| `BD` |
| `BE` |
| `BF` |
| `BG` |
| `BH` |
| `BI` |
| `BJ` |
| `BL` |
| `BM` |
| `BN` |
| `BO` |
| `BQ` |
| `BR` |
| `BS` |
| `BT` |
| `BV` |
| `BW` |
| `BY` |
| `BZ` |
| `CA` |
| `CC` |
| `CD` |
| `CF` |
| `CG` |
| `CH` |
| `CI` |
| `CK` |
| `CL` |
| `CM` |
| `CN` |
| `CO` |
| `CR` |
| `CU` |
| `CV` |
| `CW` |
| `CX` |
| `CY` |
| `CZ` |
| `DE` |
| `DJ` |
| `DK` |
| `DM` |
| `DO_` |
| `DZ` |
| `EC` |
| `EE` |
| `EG` |
| `EH` |
| `ER` |
| `ES` |
| `ET` |
| `FI` |
| `FJ` |
| `FK` |
| `FM` |
| `FO` |
| `FR` |
| `GA` |
| `GB` |
| `GD` |
| `GE` |
| `GF` |
| `GG` |
| `GH` |
| `GI` |
| `GL` |
| `GM` |
| `GN` |
| `GP` |
| `GQ` |
| `GR` |
| `GS` |
| `GT` |
| `GU` |
| `GW` |
| `GY` |
| `HK` |
| `HM` |
| `HN` |
| `HR` |
| `HT` |
| `HU` |
| `ID` |
| `IE` |
| `IL` |
| `IM` |
| `IN` |
| `IO` |
| `IQ` |
| `IR` |
| `IS` |
| `IT` |
| `JE` |
| `JM` |
| `JO` |
| `JP` |
| `KE` |
| `KG` |
| `KH` |
| `KI` |
| `KM` |
| `KN` |
| `KP` |
| `KR` |
| `KW` |
| `KY` |
| `KZ` |
| `LA` |
| `LB` |
| `LC` |
| `LI` |
| `LK` |
| `LR` |
| `LS` |
| `LT` |
| `LU` |
| `LV` |
| `LY` |
| `MA` |
| `MC` |
| `MD` |
| `ME` |
| `MF` |
| `MG` |
| `MH` |
| `MK` |
| `ML` |
| `MM` |
| `MN` |
| `MO` |
| `MP` |
| `MQ` |
| `MR` |
| `MS` |
| `MT` |
| `MU` |
| `MV` |
| `MW` |
| `MX` |
| `MY` |
| `MZ` |
| `NA` |
| `NC` |
| `NE` |
| `NF` |
| `NG` |
| `NI` |
| `NL` |
| `NO` |
| `NP` |
| `NR` |
| `NU` |
| `NZ` |
| `OM` |
| `PA` |
| `PE` |
| `PF` |
| `PG` |
| `PH` |
| `PK` |
| `PL` |
| `PM` |
| `PN` |
| `PR` |
| `PS` |
| `PT` |
| `PW` |
| `PY` |
| `QA` |
| `RE` |
| `RO` |
| `RS` |
| `RU` |
| `RW` |
| `SA` |
| `SB` |
| `SC` |
| `SD` |
| `SE` |
| `SG` |
| `SH` |
| `SI` |
| `SJ` |
| `SK` |
| `SL` |
| `SM` |
| `SN` |
| `SO` |
| `SR` |
| `SS` |
| `ST` |
| `SV` |
| `SX` |
| `SY` |
| `SZ` |
| `TC` |
| `TD` |
| `TF` |
| `TG` |
| `TH` |
| `TJ` |
| `TK` |
| `TL` |
| `TM` |
| `TN` |
| `TO` |
| `TR` |
| `TT` |
| `TV` |
| `TW` |
| `TZ` |
| `UA` |
| `UG` |
| `UM` |
| `US` |
| `UY` |
| `UZ` |
| `VA` |
| `VC` |
| `VE` |
| `VG` |
| `VI` |
| `VN` |
| `VU` |
| `WF` |
| `WS` |
| `YE` |
| `YT` |
| `ZA` |
| `ZM` |
| `ZW` |

#### Prepaid Card Replacement Reason Types

Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility.

##### Class Name

`PrepaidCardReplacementReasonTypesEnum`

##### Fields

| Name |
|  --- |
| `LOST` |
| `STOLEN` |
| `DAMAGED` |
| `COMPROMISED` |
| `EXPIRED` |

#### Identity Verification Provider Types

Provider types of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderTypesEnum`

##### Fields

| Name |
|  --- |
| `W2` |
| `IDOLOGY` |
| `BANK` |
| `EQUIFAX` |
| `OFAC` |
| `LEXUS_NEXUS` |

#### Identity Verification Result Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultTypesEnum`

##### Fields

| Name |
|  --- |
| `PASS` |
| `FAIL` |
| `SERVICE_OFFLINE` |
| `PROCESSING` |

#### Identity Verification Result Sub Types

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationResultSubTypesEnum`

##### Fields

| Name |
|  --- |
| `HARD` |
| `SOFT` |

#### Identity Verification Disposition Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionTypesEnum`

##### Fields

| Name |
|  --- |
| `TRANSIENT` |
| `FINAL_` |

#### Identity Verification Check Types

Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.)

##### Class Name

`IdentityVerificationCheckTypesEnum`

##### Fields

| Name |
|  --- |
| `DOCUMENTARY` |
| `NON_DOCUMENTARY` |
| `OFAC` |

#### Bank Account Field Types

Classifies account field types

##### Class Name

`BankAccountFieldTypesEnum`

##### Fields

| Name |
|  --- |
| `BANK_ACH_ABA` |
| `BANK_BBAN` |
| `BANK_BRANCH_CODE` |
| `BANK_BSB_CODE` |
| `BANK_CITY` |
| `BANK_CLABE` |
| `BANK_CODE` |
| `BANK_CURP` |
| `BANK_IBAN` |
| `BANK_NAME` |
| `BANK_NON_SWIFT_BIC` |
| `BANK_NUBAN` |
| `BANK_PHONE_NUMBER` |
| `BANK_POSTAL_CODE` |
| `BANK_REGION` |
| `BANK_RFC` |
| `BANK_SORT_CODE` |
| `BANK_STREET_ADDRESS` |
| `BANK_SWIFT_BIC` |
| `BANK_TRANSIT_CODE` |
| `BENEFICIARY_ACCOUNT_NUMBER` |
| `BENEFICIARY_PHONE_NUMBER` |
| `BENEFICIARY_TAX_ID` |
| `BENEFICIARY_NAME` |
| `BANK_BRANCH_NAME` |
| `BANK_PURPOSE_OF_PAYMENT_CODE` |
| `BANK_VALUE_ADD_TAX` |

#### Validator Types

##### Class Name

`ValidatorTypesEnum`

##### Fields

| Name |
|  --- |
| `REGEX` |
| `LENGTH` |

#### Occupation Types

Type of occupation for the user

##### Class Name

`OccupationTypesEnum`

##### Fields

| Name |
|  --- |
| `INDEPENDENT_BUSINESS_OWNER` |
| `SCIENCE` |
| `TECHNOLOGY` |
| `ENGINEERING` |
| `MATH` |
| `HEALTHCARE` |
| `SOCIAL_SERVICES` |
| `MEDIA` |
| `FINANCE` |
| `GOVERNMENT` |
| `MANUFACTURING` |
| `LAW` |
| `HOSPITALITY_AND_TOURISM` |
| `ARTS` |
| `DESIGN` |
| `OFFICE_AND_ADMIN_SUPPORT` |
| `EDUCATION` |

#### Tax Resident Status Types

Tax resident status type of a country

##### Class Name

`TaxResidentStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `YES` |
| `NO` |
| `PREFER_NOT_TO_ANSWER` |

#### Namespace

Namespace used to identify and refer to the object

##### Class Name

`MNamespaceEnum`

##### Fields

| Name |
|  --- |
| `ENUM_BANKACCOUNTSUPDATEDSTATUSAPPROVED` |
| `ENUM_PREPAIDCARDSCREATED` |
| `ENUM_TRANSFERSACCEPTED` |

#### Business Contact Role

Role of the user within the business

##### Class Name

`BusinessContactRoleEnum`

##### Fields

| Name |
|  --- |
| `OWNER` |
| `MANAGER` |
| `PARTNER` |
| `OTHER` |

#### Format

##### Class Name

`FormatEnum`

##### Fields

| Name |
|  --- |
| `TEXT` |
| `IMAGE` |
| `ENUM_TEXTIMAGE` |

#### Government Id Type

User's government ID type

##### Class Name

`GovernmentIdTypeEnum`

##### Fields

| Name |
|  --- |
| `PASSPORT` |
| `NATIONAL_ID_CARD` |
| `CURP` |

#### Side

##### Class Name

`SideEnum`

##### Fields

| Name |
|  --- |
| `FRONT` |
| `BACK` |

#### Status

Current status of the prepaid card

##### Class Name

`StatusEnum`

##### Fields

| Name |
|  --- |
| `QUEUED` |
| `LOST_STOLEN_DAMAGED` |
| `ACTIVATED` |
| `PENDING_ACTIVATION` |
| `SUSPENDED` |
| `COMPLIANCE_HOLD` |
| `KYC_HOLD` |
| `LOCKED` |

## Utility Classes Documentation

### FileWrapper

Thrown when there is a network error or HTTP response status code is not okay.

### Constructor Args

| Name | Type | Description |
|  --- | --- | --- |
| $realFilePath | string | The path of the file to wrap. |
| $mimeType | ?mimeType | The mime-type to be sent with the file. |
| $filename | ?string | The name to be used when sending the file. |

### Methods

| Name | Type | Description |
|  --- | --- | --- |
| getFilename() | ?string | Get name of the file to be used in the upload data. |
| getMimeType() | ?string | Get the mime-type to be sent with the file. |

## Common Code Documentation

### ApiException

Thrown when there is a network error or HTTP response status code is not okay.

#### Methods

| Name | Type | Description |
|  --- | --- | --- |
| getHttpRequest() | HttpRequest | Returns the HTTP request. |
| getHttpResponse() | ?HttpResponse | Returns the HTTP response. |
| hasResponse() | bool | Is the response available? |

### HttpRequest

Represents a single Http Request.

#### Methods

| Name | Type | Description |
|  --- | --- | --- |
| getHttpMethod() | string | The HTTP method of the request. |
| getQueryUrl() | string | The endpoint URL for the API request. |
| getHeaders() | array | Request headers. |
| getParameters() | array | Input parameters for the body. |

### HttpResponse

Http response received.

#### Methods

| Name | Type | Description |
|  --- | --- | --- |
| getStatusCode() | int | The status code of the response. |
| getHeaders() | array | Response headers. |
| getRawBody() | string | Raw body of the response. |

