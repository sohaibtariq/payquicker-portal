# Getting Started with PQ API v2

## Getting Started

### Introduction

desc older version

### Installation

The following section explains how to use the PQ API v2Lib library in a new project.

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `timeout` | `number` | Timeout for API calls.<br>*Default*: `0` |

The API client can be initialized as follows:

```ts
const client = new Client({
  timeout: 0,
})
```

## Client Class Documentation

### PQ API v2 Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| payments | Gets PaymentsController |
| transfers | Gets TransfersController |
| spendBack | Gets SpendBackController |
| prepaidCards | Gets PrepaidCardsController |
| paperChecks | Gets PaperChecksController |
| bankAccounts | Gets BankAccountsController |
| balances | Gets BalancesController |
| receipts | Gets ReceiptsController |
| users | Gets UsersController |
| documents | Gets DocumentsController |
| webhooks | Gets WebhooksController |
| program | Gets ProgramController |

## API Reference

### List of APIs

* [Payments](#payments)
* [Transfers](#transfers)
* [Spend Back](#spend-back)
* [Prepaid Cards](#prepaid-cards)
* [Paper Checks](#paper-checks)
* [Bank Accounts](#bank-accounts)
* [Balances](#balances)
* [Receipts](#receipts)
* [Users](#users)
* [Documents](#documents)
* [Webhooks](#webhooks)
* [Program](#program)

### Payments

#### Overview

Payment-related operations

#### Retrieve Payment

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrievePayment(
  pmntToken: string,
  xMyPayQuickerVersion: string,
  filter?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaymentResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```ts
const pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
const xMyPayQuickerVersion = '2020.02.24';
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await paymentsController.retrievePayment(pmntToken, xMyPayQuickerVersion, filter, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Accept Payment Quote

Accept an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```ts
async acceptPaymentQuote(
  pmntToken: string,
  xMyPayQuickerVersion: string,
  body?: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaymentResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `unknown \| undefined` | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```ts
const pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await paymentsController.acceptPaymentQuote(pmntToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Cancel Payment Quote

Cancel an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```ts
async cancelPaymentQuote(
  pmntToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await paymentsController.cancelPaymentQuote(pmntToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retract Payment Full

Perform a payment retraction for the full payment amount.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retractPaymentFull(
  pmntToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await paymentsController.retractPaymentFull(pmntToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retract Payment Partial

Perform a payment retraction for a partial payment amount.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retractPaymentPartial(
  pmntToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const pmntToken = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await paymentsController.retractPaymentPartial(pmntToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### List Payments

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listPayments(
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaymentsCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaymentsCollectionResponse`](#payments-collection-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await paymentsController.listPayments(xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Create Payment Quote

Create a payment quote.

:information_source: **Note** This endpoint does not require authentication.

```ts
async createPaymentQuote(
  xMyPayQuickerVersion: string,
  body?: PaymentRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaymentResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PaymentRequest \| undefined`](#payment-request) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const body: PaymentRequest = {
  amount: 78.98,
  currency: 'HKD',
};

try {
  const { result, ...httpResponse } = await paymentsController.createPaymentQuote(xMyPayQuickerVersion, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Transfers

#### Overview

Transfer-related operations

#### Retrieve Transfer

Retrieve details of a specific transfer represented by a transfer token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveTransfer(
  xferToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<TransferResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```ts
const xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await transfersController.retrieveTransfer(xferToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Accept Transfer Quote

Accept a transfer quote

:information_source: **Note** This endpoint does not require authentication.

```ts
async acceptTransferQuote(
  xferToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await transfersController.acceptTransferQuote(xferToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Cancel Transfer Quote

Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote.

:information_source: **Note** This endpoint does not require authentication.

```ts
async cancelTransferQuote(
  xferToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await transfersController.cancelTransferQuote(xferToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### List Transfers

Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listTransfers(
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<TransferCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`TransferCollectionResponse`](#transfer-collection-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await transfersController.listTransfers(xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Quote Transfer

Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>

:information_source: **Note** This endpoint does not require authentication.

```ts
async quoteTransfer(
  xMyPayQuickerVersion: string,
  body: TransferRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<TransferResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`TransferRequest`](#transfer-request) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const body: TransferRequest = {};

try {
  const { result, ...httpResponse } = await transfersController.quoteTransfer(xMyPayQuickerVersion, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "sourceToken": "user-114773fd-85c1-4977-8ce5-24af71f744e9",
  "destinationToken": "dest-63947e68-5393-4d00-955d-e0020017924b",
  "notes": "string",
  "memo": "string",
  "destinationAmount": -1.79,
  "destinationCurrency": "USD",
  "clientTransferId": "DKKde3Meeiiw34",
  "token": "xfer-0c0f2727-6521-47c9-b1fa-f132306d456a",
  "sourceAmount": -1.79,
  "sourceCurrency": "USD",
  "status": "QUOTED",
  "fx": {
    "destinationAmount": -1.79,
    "destinationCurrency": "USD",
    "sourceAmount": -1.79,
    "sourceCurrency": "USD",
    "rate": 0.85
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://url.to.com/xfer-0c0f2727-6521-47c9-b1fa-f132306d456a"
    }
  ]
}
```

### Spend Back

#### Overview

Spendback-related operations

#### Retrieve Spendback

Retrieve a single spendback quote using the spendback token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveSpendback(
  spndToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await spendBackController.retrieveSpendback(spndToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Accept Spendback Quote

Accept an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```ts
async acceptSpendbackQuote(
  spndToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await spendBackController.acceptSpendbackQuote(spndToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Cancel Spendback Quote

Cancel an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```ts
async cancelSpendbackQuote(
  spndToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await spendBackController.cancelSpendbackQuote(spndToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Refund Spendback Full

Perform a spendback refund for the full amount.

:information_source: **Note** This endpoint does not require authentication.

```ts
async refundSpendbackFull(
  spndToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await spendBackController.refundSpendbackFull(spndToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Refund Spendback Partial

Perform a spendback refund for a partial amount.

:information_source: **Note** This endpoint does not require authentication.

```ts
async refundSpendbackPartial(
  spndToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const spndToken = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await spendBackController.refundSpendbackPartial(spndToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### List Spend Backs

Retrieve a list of all spendbacks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listSpendBacks(
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await spendBackController.listSpendBacks(xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Quote Spendback

Create a spendback quote. <i>*Spendbacks can be automatically accepted by setting the `autoAcceptQuote` flag. If not automatically accepted, a POST is required to the spendback endpoint using the token returned in the response. Quotes can be accepted, cancelled, or allowed to expire.</i>

:information_source: **Note** This endpoint does not require authentication.

```ts
async quoteSpendback(
  xMyPayQuickerVersion: string,
  body?: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `unknown \| undefined` | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await spendBackController.quoteSpendback(xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Prepaid Cards

#### Overview

Prepaid Card-related operations

#### Replace Prepaid Card

Replace an existing Prepaid Card specifying the replacement reason and the card package for the replacement card.

:information_source: **Note** This endpoint does not require authentication.

```ts
async replacePrepaidCard(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  body?: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `unknown \| undefined` | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await prepaidCardsController.replacePrepaidCard(userToken, destToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Retrieve Prepaid Card

Retrieve Prepaid Card details by destination token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrievePrepaidCard(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await prepaidCardsController.retrievePrepaidCard(userToken, destToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Update Prepaid Card Partial

Partial Prepaid Card update typically used when modifying card status. <i>*Does not require the entire object be passed in the request</i>

:information_source: **Note** This endpoint does not require authentication.

```ts
async updatePrepaidCardPartial(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  body?: PrepaidCardStatus,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PrepaidCardStatus \| undefined`](#prepaid-card-status) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await prepaidCardsController.updatePrepaidCardPartial(userToken, destToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "LOCKED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Generate PIN Operation Token

Retrieve one part of a two-part token required to reveal or set a client side PIN. <i>*Not all programs support a reveal or set PIN operation.</i>

:information_source: **Note** This endpoint does not require authentication.

```ts
async generatePINOperationToken(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardPinToken>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardPinToken`](#prepaid-card-pin-token)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await prepaidCardsController.generatePINOperationToken(userToken, destToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Set PIN If Supported

Allows the setting of a PIN if supported by program.

:information_source: **Note** This endpoint does not require authentication.

```ts
async setPINIfSupported(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  token: string,
  cardPin: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UsersPrepaidCardsPinResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cardPin` | `string` | Query, Required | Prepaid card PIN for ATM and Debit usage |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`UsersPrepaidCardsPinResponse`](#users-prepaid-cards-pin-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
const token = 'token6';
const cardPin = 'cardPin4';
try {
  const { result, ...httpResponse } = await prepaidCardsController.setPINIfSupported(userToken, destToken, xMyPayQuickerVersion, token, cardPin);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Reveal PIN If Supported

Reveals the PIN for a card where PIN reveal functionality is supported in the program and hosted by PayQuicker.

:information_source: **Note** This endpoint does not require authentication.

```ts
async revealPINIfSupported(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  token: string,
  cvc2: string,
  body?: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardPin>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cvc2` | `string` | Query, Required | Card Verification Value (CVV) located on the back of your credit card or debit card is a 3-digit number on VISA® and MasterCard® branded credit cards, and debit cards. |
| `body` | `unknown \| undefined` | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardPin`](#prepaid-card-pin)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
const token = 'token6';
const cvc2 = 'cvc20';
try {
  const { result, ...httpResponse } = await prepaidCardsController.revealPINIfSupported(userToken, destToken, xMyPayQuickerVersion, token, cvc2);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### List Prepaid Cards

Retrieve a list of all pre-paid cards by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listPrepaidCards(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardCollectionResponse`](#prepaid-card-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await prepaidCardsController.listPrepaidCards(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
      "status": "QUEUED",
      "createdOn": "2020-02-21T22:00:00Z",
      "country": "US",
      "currency": "USD",
      "cardPersonalization": "PERSONALIZED",
      "cardPackage": "blue_consumer_10k",
      "cardNetwork": "VISA",
      "expires": "2023-02-21T00:00:00Z",
      "cardNumber": "1234 56** **** 1234",
      "cvv": "123",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards"
    }
  ]
}
```

#### Order Prepaid Card

Order a pre-paid card for the user by specifying a cardPackage. <i>*A package defines the type of card, currency, artwork utilized, and often the method of delivery.</i>

:information_source: **Note** This endpoint does not require authentication.

```ts
async orderPrepaidCard(
  userToken: string,
  xMyPayQuickerVersion: string,
  body?: PrepaidCardBase,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardRequestResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PrepaidCardBase \| undefined`](#prepaid-card-base) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardRequestResponse`](#prepaid-card-request-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await prepaidCardsController.orderPrepaidCard(userToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Generate Prepaid Card Data Token

Generate a token used to reveal prepaid card information in the form of image data (base64) or JSON.

:information_source: **Note** This endpoint does not require authentication.

```ts
async generatePrepaidCardDataToken(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  format: FormatEnum,
  side?: SideEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardDataTokenResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | - |
| `destToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `side` | [`SideEnum \| undefined`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardDataTokenResponse`](#prepaid-card-data-token-response)

##### Example Usage

```ts
const userToken = 'user-token6';
const destToken = 'dest-token2';
const xMyPayQuickerVersion = '2020.02.24';
const format = 'TEXT;IMAGE';
try {
  const { result, ...httpResponse } = await prepaidCardsController.generatePrepaidCardDataToken(userToken, destToken, xMyPayQuickerVersion, format);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Get Prepaid Card Data

Return prepaid card data in the form of image data, text, or both.

:information_source: **Note** This endpoint does not require authentication.

```ts
async getPrepaidCardData(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  format: FormatEnum,
  token: string,
  side?: SideEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PrepaidCardDataResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | - |
| `destToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `side` | [`SideEnum \| undefined`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PrepaidCardDataResponse`](#prepaid-card-data-response)

##### Example Usage

```ts
const userToken = 'user-token6';
const destToken = 'dest-token2';
const xMyPayQuickerVersion = '2020.02.24';
const format = 'TEXT;IMAGE';
const token = 'token6';
try {
  const { result, ...httpResponse } = await prepaidCardsController.getPrepaidCardData(userToken, destToken, xMyPayQuickerVersion, format, token);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Paper Checks

#### Overview

Paper check-related operations

#### List Paper Checks

Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listPaperChecks(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaperCheckCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaperCheckCollectionResponse`](#paper-check-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await paperChecksController.listPaperChecks(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Order Paper Check

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```ts
async orderPaperCheck(
  userToken: string,
  xMyPayQuickerVersion: string,
  body?: PaperCheckBase,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaperCheckResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PaperCheckBase \| undefined`](#paper-check-base) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const body: PaperCheckBase = {
  amount: 78.98,
  currency: 'HKD',
};

try {
  const { result, ...httpResponse } = await paperChecksController.orderPaperCheck(userToken, xMyPayQuickerVersion, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retrieve Paper Check

Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrievePaperCheck(
  userToken: string,
  xferToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaperCheckResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await paperChecksController.retrievePaperCheck(userToken, xferToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Update Paper Check

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```ts
async updatePaperCheck(
  userToken: string,
  xferToken: string,
  xMyPayQuickerVersion: string,
  body?: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PaperCheckResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `unknown \| undefined` | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await paperChecksController.updatePaperCheck(userToken, xferToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Cancel Paper Check

Delete a paper check by destination token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async cancelPaperCheck(
  userToken: string,
  xferToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xferToken = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await paperChecksController.cancelPaperCheck(userToken, xferToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Bank Accounts

#### Overview

Bank account-related operations

#### List Bank Accounts

Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listBankAccounts(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BankAccountCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BankAccountCollectionResponse`](#bank-account-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await bankAccountsController.listBankAccounts(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-7d8b1c83-01bb-40fb-87d7-26bd4c303f01",
      "status": "DELETED",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "333333333"
        },
        {
          "key": "BANK_BBAN",
          "value": "4444444444"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "My account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    },
    {
      "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
      "status": "ACTIVE",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "012346789"
        },
        {
          "key": "BANK_BBAN",
          "value": "987654321"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "Personal checking account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Create Bank Account

Create a quote for a bank account using a user token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async createBankAccount(
  userToken: string,
  xMyPayQuickerVersion: string,
  body?: BankAccountFields,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BankAccountResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`BankAccountFields \| undefined`](#bank-account-fields) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await bankAccountsController.createBankAccount(userToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Retrieve Bank Account

Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveBankAccount(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BankAccountResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await bankAccountsController.retrieveBankAccount(userToken, destToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Update Bank Account

Update a bank account.

:information_source: **Note** This endpoint does not require authentication.

```ts
async updateBankAccount(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  body?: BankAccountFields,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BankAccountResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`BankAccountFields \| undefined`](#bank-account-fields) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await bankAccountsController.updateBankAccount(userToken, destToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Delete Bank Account

Delete (cloak) a user bank account.

:information_source: **Note** This endpoint does not require authentication.

```ts
async deleteBankAccount(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await bankAccountsController.deleteBankAccount(userToken, destToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Get Bank Account Requirements

Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation.

:information_source: **Note** This endpoint does not require authentication.

```ts
async getBankAccountRequirements(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BankAccountRequirementCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BankAccountRequirementCollectionResponse`](#bank-account-requirement-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await bankAccountsController.getBankAccountRequirements(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "bankCountry": "IT",
      "bankCurrency": "EUR",
      "requirements": [
        {
          "requirement": "BANK_IBAN",
          "format": {
            "example": "IT43K0310412701000000820420",
            "legend": [
              {
                "key": "IT43K0310412701000000820420",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example IBAN"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio IBAN"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "IBAN"
            },
            {
              "language": "it-IT",
              "translation": "IBAN"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^IT\\\\d{2}[A-Z]\\\\d{10}[0-9A-Z]{12}$"
            }
          ]
        },
        {
          "requirement": "BANK_SWIFT_BIC",
          "format": {
            "example": "01234567890",
            "legend": [
              {
                "key": "01234567890",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example Swift/BIC"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio Swift/BIC"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "Swift/BIC"
            },
            {
              "language": "it-IT",
              "translation": "Swift/BIC"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^[a-z0-9A-Z]{8,11}$"
            }
          ]
        }
      ],
      "quote": {
        "formattedAmount": "$4.32 USD (USD, en-US), 0,00 € EUR (EUR, fr-FR)",
        "amount": 4.32,
        "currency": "USD"
      },
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

### Balances

#### Overview

Balance-related operations

#### List User Balances

Retrieve a list of user balances that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listUserBalances(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BalanceCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await balancesController.listUserBalances(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$4.32 USD",
      "amount": 4.32,
      "currency": "USD",
      "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/balances"
    }
  ]
}
```

#### List Prepaid Card Balance

Retrieve a list of balances by destination token that supports filtering, sorting, and pagination through existing mechanisms. <i>*If the user belongs to a Flex-based program, balances against the user resource will return the wallet balance only. If it is a pre-paid card program (i.e., Meta USD), this balance and its associated pre-paid card balance will be the same.</i>

:information_source: **Note** This endpoint does not require authentication.

```ts
async listPrepaidCardBalance(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BalanceCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await balancesController.listPrepaidCardBalance(userToken, destToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "formattedAmount": "$4.32",
  "amount": 4.32,
  "currency": "USD",
  "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
    }
  ]
}
```

#### List Account Balances

Retrieve a single account balance.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listAccountBalances(
  acctToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<BalanceCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```ts
const acctToken = 'acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await balancesController.listAccountBalances(acctToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$5.00",
      "amount": 5,
      "currency": "USD",
      "token": "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4"
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4/balances"
    }
  ]
}
```

### Receipts

#### Overview

Receipt-related operations

#### List Account Receipts

Retrieve a list of all account(s) receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listAccountReceipts(
  acctToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<unknown>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`unknown`

##### Example Usage

```ts
const acctToken = 'acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await receiptsController.listAccountReceipts(acctToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response

```
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "acct-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### List Prepaid Card Receipts

Retrieve a list all prepaid-card receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listPrepaidCardReceipts(
  userToken: string,
  destToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ReceiptCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const destToken = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await receiptsController.listPrepaidCardReceipts(userToken, destToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.05,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/prepaid-cards/dest-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### List User Receipts

Retrieve a list all user receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listUserReceipts(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ReceiptCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await receiptsController.listUserReceipts(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

### Users

#### Overview

User-related operations

#### Update User

Update a user object (change email, address change, etc.) using a user token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async updateUser(
  userToken: string,
  xMyPayQuickerVersion: string,
  body?: UserBase,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase \| undefined`](#user-base) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await usersController.updateUser(userToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Retrieve User

Retrieve a single user record by user token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveUser(
  userToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await usersController.retrieveUser(userToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### List Users

Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listUsers(
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`UserCollectionResponse`](#user-collection-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await usersController.listUsers(xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "firstName": "Jane",
      "lastName": "Smith",
      "dateOfBirth": "1977-12-14",
      "phoneNumber": "760-350-0324",
      "phoneNumberCountry": "US",
      "mobileNumber": "213-446-5755",
      "mobileNumberCountry": "US",
      "addressLine1": "290 Carriage Court",
      "city": "Los Angeles",
      "region": "CA",
      "country": "US",
      "postalCode": "90017",
      "addressType": "RESIDENTIAL",
      "email": "jsmith@payquicker.com",
      "gender": "FEMALE",
      "userType": "INDIVIDUAL",
      "programUserId": "d97ce0519b2d",
      "language": "en-US",
      "countryOfBirth": "US",
      "countryOfNationality": "US",
      "token": "usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357",
      "status": "PRE_ACTIVATED",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users"
    }
  ]
}
```

#### Create User

Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc.

:information_source: **Note** This endpoint does not require authentication.

```ts
async createUser(
  xMyPayQuickerVersion: string,
  body: UserBase,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase`](#user-base) | Body, Required | Body details of the request |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
const body: UserBase = {
  phoneNumber: '760-350-0324',
  mobileNumber: '213-446-5755',
  phoneNumberCountry: 'US',
  mobileNumberCountry: 'US',
};
body.firstName = 'Jane';
body.lastName = 'Smith';
body.dateOfBirth = '2016-03-13T12:52:32.123Z';
body.addressLine1 = '290 Carriage Court';
body.city = 'Los Angeles';
body.region = 'CA';
body.country = 'US';
body.postalCode = '90017';
body.addressType = 'RESIDENTIAL';
body.email = 'jsmith@payquicker.com';
body.gender = 'FEMALE';
body.userType = 'INDIVIDUAL';
body.programUserId = 'd97ce0519b2d';
body.language = 'en-US';
body.countryOfBirth = 'US';
body.countryOfNationality = 'US';

try {
  const { result, ...httpResponse } = await usersController.createUser(xMyPayQuickerVersion, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### List User IDV Checks

Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listUserIDVChecks(
  userToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<IdentityVerificationCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`IdentityVerificationCollectionResponse`](#identity-verification-collection-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await usersController.listUserIDVChecks(userToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
      "idvResult": "PASS",
      "idvSubResult": "HARD",
      "idvProvider": "IDOLOGY",
      "createdOn": "2020-02-21T22:00:00Z",
      "raw": "<RAW IDV processor output, for informational /debugging purposes only>",
      "idvCheckType": "NON_DOCUMENTARY",
      "idvDisposition": "FINAL",
      "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks"
    }
  ]
}
```

#### Retrieve User IDV Check

Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveUserIDVCheck(
  userToken: string,
  idvcToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<IdentityVerificationResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `idvcToken` | `string` | Template, Required | Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`IdentityVerificationResponse`](#identity-verification-response)

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const idvcToken = 'idvc-7e7567e0-c2db-485d-896d-45901a10baa9';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await usersController.retrieveUserIDVCheck(userToken, idvcToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
  "idvResult": "PASS",
  "idvSubResult": "HARD",
  "idvProvider": "IDOLOGY",
  "createdOn": "2020-02-21T22:00:00Z",
  "raw": "<RAW IDV processor output, for informational/debugging purposes only>",
  "idvCheckType": "NON_DOCUMENTARY",
  "idvDispostion": "FINAL",
  "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
    }
  ]
}
```

#### List User Events

Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listUserEvents(
  userToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
try {
  const { result, ...httpResponse } = await usersController.listUserEvents(userToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retrieve User Event

Retrieve a single user event

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveUserEvent(
  userToken: string,
  evntToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `evntToken` | `string` | Template, Required | Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const evntToken = 'evnt-28491de2-5b22-4e30-028a-45901a10baa9';
try {
  const { result, ...httpResponse } = await usersController.retrieveUserEvent(userToken, evntToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Accept Program Agreement

Accept a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```ts
async acceptProgramAgreement(
  userToken: string,
  agmtToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `agmtToken` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const agmtToken = 'agmt-45901a10-5b22-4e30-028a-45901a10baa9';
try {
  const { result, ...httpResponse } = await usersController.acceptProgramAgreement(userToken, agmtToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### List Accepted Program Agreements

Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listAcceptedProgramAgreements(
  userToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
try {
  const { result, ...httpResponse } = await usersController.listAcceptedProgramAgreements(userToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Documents

#### Overview

Document-related operations

#### List User Documents

Retrieve a list of user documents that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listUserDocuments(
  userToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await documentsController.listUserDocuments(userToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Create User Document

Create a quote for a user document.

:information_source: **Note** This endpoint does not require authentication.

```ts
async createUserDocument(
  userToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await documentsController.createUserDocument(userToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retrieve User Document

Retrieve an individual user document by its document token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveUserDocument(
  userToken: string,
  docuToken: string,
  xMyPayQuickerVersion: string,
  page?: number,
  pageSize?: number,
  filter?: string,
  sort?: string,
  language?: LanguageTypesEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `number \| undefined` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `number \| undefined` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string \| undefined` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string \| undefined` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Query, Optional | Filter results by language type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const docuToken = 'docu-6260c132-5cb1-4e30-8b08-9ce559893acb';
const xMyPayQuickerVersion = '2020.02.24';
const pageSize = 20;
const filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\'';
const sort = '-name';
const language = 'en-US';
try {
  const { result, ...httpResponse } = await documentsController.retrieveUserDocument(userToken, docuToken, xMyPayQuickerVersion, None, pageSize, filter, sort, language);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Replace User Document

Replace the user document at the given document token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async replaceUserDocument(
  userToken: string,
  docuToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const userToken = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a';
const docuToken = 'docu-6260c132-5cb1-4e30-8b08-9ce559893acb';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await documentsController.replaceUserDocument(userToken, docuToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Webhooks

#### Overview

Webhook-related operations

#### List Webhook Subscriptions

Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listWebhookSubscriptions(
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<WebhookCollectionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`WebhookCollectionResponse`](#webhook-collection-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await webhooksController.listWebhookSubscriptions(xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "payload": [
    {
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ],
      "url": "https://www.example.com/webhooks",
      "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
      "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
      "created": "2020-01-01",
      "lastUpdated": "2020-02-01"
    }
  ]
}
```

#### Create Webhook Subscription

Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API.

:information_source: **Note** This endpoint does not require authentication.

```ts
async createWebhookSubscription(
  xMyPayQuickerVersion: string,
  body?: WebhookSubscription,
  requestOptions?: RequestOptions
): Promise<ApiResponse<WebhookSubscriptionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`WebhookSubscription \| undefined`](#webhook-subscription) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```ts
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await webhooksController.createWebhookSubscription(xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01"
}
```

#### Retrieve Webhook Subscription

Retrieve a single webhook subscription using the webhook token.

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveWebhookSubscription(
  webhToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<WebhookSubscriptionResponse>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```ts
const webhToken = 'webh-token0';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await webhooksController.retrieveWebhookSubscription(webhToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01",
  "lastUpdated": "2020-02-01"
}
```

#### Delete Webhook Subscription

Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code.

:information_source: **Note** This endpoint does not require authentication.

```ts
async deleteWebhookSubscription(
  webhToken: string,
  xMyPayQuickerVersion: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const webhToken = 'webh-token0';
const xMyPayQuickerVersion = '2020.02.24';
try {
  const { result, ...httpResponse } = await webhooksController.deleteWebhookSubscription(webhToken, xMyPayQuickerVersion);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

### Program

#### List Programs

Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listPrograms(
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
try {
  const { result, ...httpResponse } = await programController.listPrograms();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retrieve Program

Retrieve a single program configuration

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveProgram(
  progToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const progToken = 'prog-4525ab9c-5b22-4e30-028a-45901a10aa0c';
try {
  const { result, ...httpResponse } = await programController.retrieveProgram(progToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### List Program Agreements

Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listProgramAgreements(
  progToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const progToken = 'prog-token4';
try {
  const { result, ...httpResponse } = await programController.listProgramAgreements(progToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

#### Retrieve Program Agreement

Retrieve a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```ts
async retrieveProgramAgreement(
  progToken: string,
  agmtToken: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |
| `agmtToken` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

##### Response Type

`void`

##### Example Usage

```ts
const progToken = 'prog-4525ab9c-5b22-4e30-028a-45901a10aa0c';
const agmtToken = 'agmt-45901a10-5b22-4e30-028a-45901a10baa9';
try {
  const { result, ...httpResponse } = await programController.retrieveProgramAgreement(progToken, agmtToken);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Model Reference

### Structures

* [Source Monetary Required](#source-monetary-required)
* [Haetos Self Ref](#haetos-self-ref)
* [Haetos Params](#haetos-params)
* [Haetos Relationship](#haetos-relationship)
* [Transfer-Request](#transfer-request)
* [Transfer](#transfer)
* [Expiration](#expiration)
* [Transfer-Response](#transfer-response)
* [Not Before or After](#not-before-or-after)
* [Address](#address)
* [Business Address](#business-address)
* [Monetary Formatted](#monetary-formatted)
* [Transfer Base](#transfer-base)
* [Payment Base](#payment-base)
* [Transfer Base Ext](#transfer-base-ext)
* [Destination Monetary Required](#destination-monetary-required)
* [Monetary Required](#monetary-required)
* [Balance](#balance)
* [Fx Object](#fx-object)
* [User Base](#user-base)
* [User](#user)
* [User-Response](#user-response)
* [Receipt Base](#receipt-base)
* [Receipt Collection-Response](#receipt-collection-response)
* [Balance Collection-Response](#balance-collection-response)
* [User Collection-Response](#user-collection-response)
* [Payment-Request](#payment-request)
* [Payment](#payment)
* [Payments Collection-Response](#payments-collection-response)
* [Payment-Response](#payment-response)
* [Transfer Collection-Response](#transfer-collection-response)
* [User Name](#user-name)
* [Dob](#dob)
* [Business Information](#business-information)
* [User Kyc Information](#user-kyc-information)
* [Phone Numbers](#phone-numbers)
* [Email Address](#email-address)
* [User Employer Id](#user-employer-id)
* [Gender](#gender)
* [Language](#language)
* [User Type](#user-type)
* [Program User Id](#program-user-id)
* [Source Destination Token](#source-destination-token)
* [Token](#token)
* [Client Transfer Id](#client-transfer-id)
* [Notes](#notes)
* [Memo](#memo)
* [Created On](#created-on)
* [Transfer Status](#transfer-status)
* [User Status](#user-status)
* [Payment Purpose](#payment-purpose)
* [Source Token](#source-token)
* [Destination Token](#destination-token)
* [Client Payment Id](#client-payment-id)
* [Auto Accept Quote](#auto-accept-quote)
* [Rate](#rate)
* [Fx](#fx)
* [Paper Check Base](#paper-check-base)
* [Transfer Type](#transfer-type)
* [Bank Account Ownership](#bank-account-ownership)
* [Shipping Method](#shipping-method)
* [Paper Check](#paper-check)
* [Paper Check-Response](#paper-check-response)
* [Paper Check Collection-Response](#paper-check-collection-response)
* [Bank Account Fields](#bank-account-fields)
* [Bank Account Type](#bank-account-type)
* [Bank Account](#bank-account)
* [Bank Account Status](#bank-account-status)
* [Bank Account-Response](#bank-account-response)
* [Bank Account Collection-Response](#bank-account-collection-response)
* [Prepaid Card Package](#prepaid-card-package)
* [Prepaid Card Base](#prepaid-card-base)
* [Prepaid Card Status](#prepaid-card-status)
* [Token Type](#token-type)
* [Prepaid Card Base Ext](#prepaid-card-base-ext)
* [Card Network](#card-network)
* [Card Personalization Type](#card-personalization-type)
* [Prepaid Card](#prepaid-card)
* [Currency](#currency)
* [Country](#country)
* [Prepaid Card-Request Response](#prepaid-card-request-response)
* [Prepaid Card-Response](#prepaid-card-response)
* [Prepaid Card Collection-Response](#prepaid-card-collection-response)
* [Card Masked Pan](#card-masked-pan)
* [Prepaid Card Replacement Reason](#prepaid-card-replacement-reason)
* [Prepaid Card Replacement Base](#prepaid-card-replacement-base)
* [Prepaid Card Pin Token](#prepaid-card-pin-token)
* [Prepaid Card Pin](#prepaid-card-pin)
* [Cvv](#cvv)
* [Identity Verification Provider Type](#identity-verification-provider-type)
* [Identity Verification Result Type](#identity-verification-result-type)
* [Identity Verification Sub Result Type](#identity-verification-sub-result-type)
* [Identity Verification Disposition Type](#identity-verification-disposition-type)
* [Identity Verification Check Type](#identity-verification-check-type)
* [Identity Verification Base](#identity-verification-base)
* [Identity Verification Provider Reference](#identity-verification-provider-reference)
* [Identity Verification Provider Raw Output](#identity-verification-provider-raw-output)
* [Identity Verification-Response](#identity-verification-response)
* [Identity Verification Collection-Response](#identity-verification-collection-response)
* [Key Value Pair String String](#key-value-pair-string-string)
* [Key Value Pair Bank Field Types String](#key-value-pair-bank-field-types-string)
* [Key Value Pair Bank Currency Currency Types](#key-value-pair-bank-currency-currency-types)
* [Key Value Bank Country Country Types](#key-value-bank-country-country-types)
* [Bank Account Required Fields](#bank-account-required-fields)
* [Bank Account Requirement Format](#bank-account-requirement-format)
* [Bank Account Requirement Format Legend](#bank-account-requirement-format-legend)
* [Key Value Pair Language Type String](#key-value-pair-language-type-string)
* [Bank Account Requirement Validator](#bank-account-requirement-validator)
* [Bank Account Requirement](#bank-account-requirement)
* [Bank Account Requirement-Response](#bank-account-requirement-response)
* [Bank Account Requirement Collection-Response](#bank-account-requirement-collection-response)
* [Occupation](#occupation)
* [Tax Resident Status](#tax-resident-status)
* [Webhook-Subscription](#webhook-subscription)
* [Webhook-Subscription-Response](#webhook-subscription-response)
* [Webhook Collection-Response](#webhook-collection-response)
* [Prepaid Card Data-Response](#prepaid-card-data-response)
* [Prepaid Card Data Token](#prepaid-card-data-token)
* [Prepaid Card Data Token-Response](#prepaid-card-data-token-response)
* [Business Type](#business-type)
* [Country Nationality Information](#country-nationality-information)
* [Users Prepaid Cards Pin Response](#users-prepaid-cards-pin-response)

#### Source Monetary Required

Required details of the monetary source.

##### Class Name

`SourceMonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceAmount` | `number \| undefined` | Optional | Amount of the transfer in the specified currency. |
| `sourceCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "sourceAmount": null,
  "sourceCurrency": null
}
```

#### Haetos Self Ref

Indicates the external link with the full URL of the same page on which the link appears.

##### Class Name

`HaetosSelfRef`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "links": null
}
```

#### Haetos Params

Hypermedia as the Engine of Application State (HAETOS) parameters used in a query.

##### Class Name

`HaetosParams`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`HaetosRelationship`](#haetos-relationship) | Required | Indicates the HATEOS relationship between the target and current resources. |
| `href` | `string` | Required | URL for resource described by the relationship. |

##### Example (as JSON)

```json
{
  "params": {
    "rel": "self"
  },
  "href": null
}
```

#### Haetos Relationship

Indicates the HATEOS relationship between the target and current resources.

##### Class Name

`HaetosRelationship`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rel` | `string` | Required | Indicates the relationship between the target and current resources.<br>**Default**: `'self'`<br>*Default: `'self'`* |

##### Example (as JSON)

```json
{
  "rel": "self"
}
```

#### Transfer-Request

Request for the transfer

##### Class Name

`TransferRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `clientTransferId` | `string \| undefined` | Optional | Unique value provided by the client for the transfer. |
| `destinationAmount` | `number \| undefined` | Optional | Amount transferred to the destination |
| `destinationCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "clientTransferId": null,
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Transfer

Description of the transfer request

##### Class Name

`Transfer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `destinationAmount` | `number \| undefined` | Optional | Amount transferred to the destination |
| `destinationCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `clientTransferId` | `string \| undefined` | Optional | Unique value provided by the client for the transfer. |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `sourceAmount` | `number \| undefined` | Optional | Amount of the transfer in the specified currency. |
| `sourceCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `status` | [`TransferStatusTypesEnum \| undefined`](#transfer-status-types) | Optional | Current status of a transfer |
| `fx` | [`FxObject \| undefined`](#fx-object) | Optional | Currency conversion object details |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null
}
```

#### Expiration

Date and time the object will expire

##### Class Name

`Expiration`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `expires` | `string \| undefined` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |

##### Example (as JSON)

```json
{
  "expires": null
}
```

#### Transfer-Response

##### Class Name

`TransferResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `destinationAmount` | `number \| undefined` | Optional | Amount transferred to the destination |
| `destinationCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `clientTransferId` | `string \| undefined` | Optional | Unique value provided by the client for the transfer. |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `sourceAmount` | `number \| undefined` | Optional | Amount of the transfer in the specified currency. |
| `sourceCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `status` | [`TransferStatusTypesEnum \| undefined`](#transfer-status-types) | Optional | Current status of a transfer |
| `fx` | [`FxObject \| undefined`](#fx-object) | Optional | Currency conversion object details |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null,
  "links": null
}
```

#### Not Before or After

##### Class Name

`NotBeforeOrAfter`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notBefore` | `string \| undefined` | Optional | Transfer is scheduled and will not process before this time. |
| `notAfter` | `string \| undefined` | Optional | Transfer expires if not completed prior to this time. |

##### Example (as JSON)

```json
{
  "notBefore": null,
  "notAfter": null
}
```

#### Address

Classifies the mailing address

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |

##### Example (as JSON)

```json
{
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null
}
```

#### Business Address

Address of the business location

##### Class Name

`BusinessAddress`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `businessAddressLine1` | `string \| undefined` | Optional | First line of the business address that specifies street number, street name, and building name |
| `businessAddressLine2` | `string \| undefined` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `businessAddressLine3` | `string \| undefined` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `businessAddressLine4` | `string \| undefined` | Optional | fourth line of the business address street address |
| `businessAddressLine5` | `string \| undefined` | Optional | Fifth line of the business address street address |
| `businessCity` | `string \| undefined` | Optional | City the business is registered |
| `businessRegion` | `string \| undefined` | Optional | State, province, or region the business is registered |
| `businessCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessPostalCode` | `string \| undefined` | Optional | Postal code for the business address |
| `businessPremiseNumber` | `string \| undefined` | Optional | House number for the business address |

##### Example (as JSON)

```json
{
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null
}
```

#### Monetary Formatted

Object representing monies, including currency, decimal, and formatted amounts

##### Class Name

`MonetaryFormatted`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formattedAmount` | `string \| undefined` | Optional | Formatted monetary amount |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base

Base class for the transfer

##### Class Name

`TransferBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null
}
```

#### Payment Base

Base class for the payment

##### Class Name

`PaymentBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum \| undefined`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `clientPaymentId` | `string \| undefined` | Optional | Unique value provided by the client for the payment. |
| `autoAcceptQuote` | `boolean \| undefined` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base Ext

Base extension for the transfer

##### Class Name

`TransferBaseExt`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `destinationAmount` | `number \| undefined` | Optional | Amount transferred to the destination |
| `destinationCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `clientTransferId` | `string \| undefined` | Optional | Unique value provided by the client for the transfer. |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null
}
```

#### Destination Monetary Required

Monetary instruments required for the destination

##### Class Name

`DestinationMonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destinationAmount` | `number \| undefined` | Optional | Amount transferred to the destination |
| `destinationCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Monetary Required

Monetary requirements for the transfer

##### Class Name

`MonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Balance

Account monetary balance

##### Class Name

`Balance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formattedAmount` | `string \| undefined` | Optional | Formatted monetary amount |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Fx Object

Currency conversion object details

##### Class Name

`FxObject`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destinationAmount` | `number \| undefined` | Optional | Amount transferred to the destination |
| `destinationCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `sourceAmount` | `number \| undefined` | Optional | Amount of the transfer in the specified currency. |
| `sourceCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `rate` | `number \| undefined` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "rate": null
}
```

#### User Base

Object for the established group of users

##### Class Name

`UserBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `string \| undefined` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `lastName` | `string \| undefined` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `dateOfBirth` | `string \| undefined` | Optional | User's date of birth |
| `businessName` | `string \| undefined` | Optional | Legal name for the business |
| `businessOperatingName` | `string \| undefined` | Optional | Name under which the business operates |
| `businessRegistrationId` | `string \| undefined` | Optional | Registration number or ID assigned by a government body |
| `businessRegistrationRegion` | `string \| undefined` | Optional | State, province, or territory where the business is registered |
| `businessRegistrationCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessContactRole` | [`BusinessContactRoleEnum \| undefined`](#business-contact-role) | Optional | Role of the user within the business |
| `businessAddressLine1` | `string \| undefined` | Optional | First line of the business address that specifies street number, street name, and building name |
| `businessAddressLine2` | `string \| undefined` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `businessAddressLine3` | `string \| undefined` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `businessAddressLine4` | `string \| undefined` | Optional | fourth line of the business address street address |
| `businessAddressLine5` | `string \| undefined` | Optional | Fifth line of the business address street address |
| `businessCity` | `string \| undefined` | Optional | City the business is registered |
| `businessRegion` | `string \| undefined` | Optional | State, province, or region the business is registered |
| `businessCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessPostalCode` | `string \| undefined` | Optional | Postal code for the business address |
| `businessPremiseNumber` | `string \| undefined` | Optional | House number for the business address |
| `businessType` | [`BusinessTypesEnum \| undefined`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `driverLicenseId` | `string \| undefined` | Optional | User's driver's license number |
| `passportId` | `string \| undefined` | Optional | User's passport number |
| `governmentIdType` | [`GovernmentIdTypeEnum \| undefined`](#government-id-type) | Optional | User's government ID type |
| `governmentId` | `string \| undefined` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `email` | `string \| undefined` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `employerId` | `string \| undefined` | Optional | User's employer identifier |
| `gender` | [`GenderTypesEnum \| undefined`](#gender-types) | Optional | Gender as a user identifies |
| `userType` | [`UserTypesEnum \| undefined`](#user-types) | Optional | Account holder's profile type |
| `programUserId` | `string \| undefined` | Optional | Program identifier for the user |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `countryOfBirth` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `countryOfNationality` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `occupation` | [`OccupationTypesEnum \| undefined`](#occupation-types) | Optional | Type of occupation for the user |
| `taxResidentStatus` | [`TaxResidentStatusTypesEnum \| undefined`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `currency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null
}
```

#### User

Object for user

##### Class Name

`User`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `string \| undefined` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `lastName` | `string \| undefined` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `dateOfBirth` | `string \| undefined` | Optional | User's date of birth |
| `businessName` | `string \| undefined` | Optional | Legal name for the business |
| `businessOperatingName` | `string \| undefined` | Optional | Name under which the business operates |
| `businessRegistrationId` | `string \| undefined` | Optional | Registration number or ID assigned by a government body |
| `businessRegistrationRegion` | `string \| undefined` | Optional | State, province, or territory where the business is registered |
| `businessRegistrationCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessContactRole` | [`BusinessContactRoleEnum \| undefined`](#business-contact-role) | Optional | Role of the user within the business |
| `businessAddressLine1` | `string \| undefined` | Optional | First line of the business address that specifies street number, street name, and building name |
| `businessAddressLine2` | `string \| undefined` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `businessAddressLine3` | `string \| undefined` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `businessAddressLine4` | `string \| undefined` | Optional | fourth line of the business address street address |
| `businessAddressLine5` | `string \| undefined` | Optional | Fifth line of the business address street address |
| `businessCity` | `string \| undefined` | Optional | City the business is registered |
| `businessRegion` | `string \| undefined` | Optional | State, province, or region the business is registered |
| `businessCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessPostalCode` | `string \| undefined` | Optional | Postal code for the business address |
| `businessPremiseNumber` | `string \| undefined` | Optional | House number for the business address |
| `businessType` | [`BusinessTypesEnum \| undefined`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `driverLicenseId` | `string \| undefined` | Optional | User's driver's license number |
| `passportId` | `string \| undefined` | Optional | User's passport number |
| `governmentIdType` | [`GovernmentIdTypeEnum \| undefined`](#government-id-type) | Optional | User's government ID type |
| `governmentId` | `string \| undefined` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `email` | `string \| undefined` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `employerId` | `string \| undefined` | Optional | User's employer identifier |
| `gender` | [`GenderTypesEnum \| undefined`](#gender-types) | Optional | Gender as a user identifies |
| `userType` | [`UserTypesEnum \| undefined`](#user-types) | Optional | Account holder's profile type |
| `programUserId` | `string \| undefined` | Optional | Program identifier for the user |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `countryOfBirth` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `countryOfNationality` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `occupation` | [`OccupationTypesEnum \| undefined`](#occupation-types) | Optional | Type of occupation for the user |
| `taxResidentStatus` | [`TaxResidentStatusTypesEnum \| undefined`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `currency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`UserStatusTypesEnum \| undefined`](#user-status-types) | Optional | Current status of the user |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null
}
```

#### User-Response

Response from a user request

##### Class Name

`UserResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `string \| undefined` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `lastName` | `string \| undefined` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `dateOfBirth` | `string \| undefined` | Optional | User's date of birth |
| `businessName` | `string \| undefined` | Optional | Legal name for the business |
| `businessOperatingName` | `string \| undefined` | Optional | Name under which the business operates |
| `businessRegistrationId` | `string \| undefined` | Optional | Registration number or ID assigned by a government body |
| `businessRegistrationRegion` | `string \| undefined` | Optional | State, province, or territory where the business is registered |
| `businessRegistrationCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessContactRole` | [`BusinessContactRoleEnum \| undefined`](#business-contact-role) | Optional | Role of the user within the business |
| `businessAddressLine1` | `string \| undefined` | Optional | First line of the business address that specifies street number, street name, and building name |
| `businessAddressLine2` | `string \| undefined` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `businessAddressLine3` | `string \| undefined` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `businessAddressLine4` | `string \| undefined` | Optional | fourth line of the business address street address |
| `businessAddressLine5` | `string \| undefined` | Optional | Fifth line of the business address street address |
| `businessCity` | `string \| undefined` | Optional | City the business is registered |
| `businessRegion` | `string \| undefined` | Optional | State, province, or region the business is registered |
| `businessCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessPostalCode` | `string \| undefined` | Optional | Postal code for the business address |
| `businessPremiseNumber` | `string \| undefined` | Optional | House number for the business address |
| `businessType` | [`BusinessTypesEnum \| undefined`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `driverLicenseId` | `string \| undefined` | Optional | User's driver's license number |
| `passportId` | `string \| undefined` | Optional | User's passport number |
| `governmentIdType` | [`GovernmentIdTypeEnum \| undefined`](#government-id-type) | Optional | User's government ID type |
| `governmentId` | `string \| undefined` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `email` | `string \| undefined` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `employerId` | `string \| undefined` | Optional | User's employer identifier |
| `gender` | [`GenderTypesEnum \| undefined`](#gender-types) | Optional | Gender as a user identifies |
| `userType` | [`UserTypesEnum \| undefined`](#user-types) | Optional | Account holder's profile type |
| `programUserId` | `string \| undefined` | Optional | Program identifier for the user |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `countryOfBirth` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `countryOfNationality` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `occupation` | [`OccupationTypesEnum \| undefined`](#occupation-types) | Optional | Type of occupation for the user |
| `taxResidentStatus` | [`TaxResidentStatusTypesEnum \| undefined`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `currency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`UserStatusTypesEnum \| undefined`](#user-status-types) | Optional | Current status of the user |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null,
  "links": null
}
```

#### Receipt Base

Base for the receipt

##### Class Name

`ReceiptBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formattedAmount` | `string \| undefined` | Optional | Formatted monetary amount |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`TransferStatusTypesEnum \| undefined`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Receipt Collection-Response

Response from a Receipt Collection request

##### Class Name

`ReceiptCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`ReceiptBase[] \| undefined`](#receipt-base) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Balance Collection-Response

Response from a Balance Collection request

##### Class Name

`BalanceCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`Balance[] \| undefined`](#balance) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Collection-Response

Response from a User Collection request

##### Class Name

`UserCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`UserResponse[] \| undefined`](#user-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Request

Payment request

##### Class Name

`PaymentRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum \| undefined`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `clientPaymentId` | `string \| undefined` | Optional | Unique value provided by the client for the payment. |
| `autoAcceptQuote` | `boolean \| undefined` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `notBefore` | `string \| undefined` | Optional | Transfer is scheduled and will not process before this time. |
| `notAfter` | `string \| undefined` | Optional | Transfer expires if not completed prior to this time. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payment

Response from a Transfer request

##### Class Name

`Payment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum \| undefined`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `clientPaymentId` | `string \| undefined` | Optional | Unique value provided by the client for the payment. |
| `autoAcceptQuote` | `boolean \| undefined` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `expires` | `string \| undefined` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `notBefore` | `string \| undefined` | Optional | Transfer is scheduled and will not process before this time. |
| `notAfter` | `string \| undefined` | Optional | Transfer expires if not completed prior to this time. |
| `status` | [`TransferStatusTypesEnum \| undefined`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payments Collection-Response

Response from a Payment collection request

##### Class Name

`PaymentsCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`PaymentResponse[] \| undefined`](#payment-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Response

Response from a Payment request

##### Class Name

`PaymentResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum \| undefined`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `clientPaymentId` | `string \| undefined` | Optional | Unique value provided by the client for the payment. |
| `autoAcceptQuote` | `boolean \| undefined` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `expires` | `string \| undefined` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `notBefore` | `string \| undefined` | Optional | Transfer is scheduled and will not process before this time. |
| `notAfter` | `string \| undefined` | Optional | Transfer expires if not completed prior to this time. |
| `status` | [`TransferStatusTypesEnum \| undefined`](#transfer-status-types) | Optional | Current status of a transfer |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Collection-Response

Response from a Transfer request

##### Class Name

`TransferCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`TransferResponse[] \| undefined`](#transfer-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Name

##### Class Name

`UserName`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `string \| undefined` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `lastName` | `string \| undefined` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

#### Dob

##### Class Name

`Dob`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dateOfBirth` | `string \| undefined` | Optional | User's date of birth |

##### Example (as JSON)

```json
{
  "dateOfBirth": null
}
```

#### Business Information

Physical address of the business and other information, such as <i>Operating Name</i>, <i>Registration ID</i>, etc.

##### Class Name

`BusinessInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `businessName` | `string \| undefined` | Optional | Legal name for the business |
| `businessOperatingName` | `string \| undefined` | Optional | Name under which the business operates |
| `businessRegistrationId` | `string \| undefined` | Optional | Registration number or ID assigned by a government body |
| `businessRegistrationRegion` | `string \| undefined` | Optional | State, province, or territory where the business is registered |
| `businessRegistrationCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessContactRole` | [`BusinessContactRoleEnum \| undefined`](#business-contact-role) | Optional | Role of the user within the business |
| `businessAddressLine1` | `string \| undefined` | Optional | First line of the business address that specifies street number, street name, and building name |
| `businessAddressLine2` | `string \| undefined` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `businessAddressLine3` | `string \| undefined` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `businessAddressLine4` | `string \| undefined` | Optional | fourth line of the business address street address |
| `businessAddressLine5` | `string \| undefined` | Optional | Fifth line of the business address street address |
| `businessCity` | `string \| undefined` | Optional | City the business is registered |
| `businessRegion` | `string \| undefined` | Optional | State, province, or region the business is registered |
| `businessCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `businessPostalCode` | `string \| undefined` | Optional | Postal code for the business address |
| `businessPremiseNumber` | `string \| undefined` | Optional | House number for the business address |
| `businessType` | [`BusinessTypesEnum \| undefined`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |

##### Example (as JSON)

```json
{
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null
}
```

#### User Kyc Information

##### Class Name

`UserKycInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `driverLicenseId` | `string \| undefined` | Optional | User's driver's license number |
| `passportId` | `string \| undefined` | Optional | User's passport number |
| `governmentIdType` | [`GovernmentIdTypeEnum \| undefined`](#government-id-type) | Optional | User's government ID type |
| `governmentId` | `string \| undefined` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |

##### Example (as JSON)

```json
{
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null
}
```

#### Phone Numbers

##### Class Name

`PhoneNumbers`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `phoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |

##### Example (as JSON)

```json
{
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC"
}
```

#### Email Address

Contact email address for the user account

##### Class Name

`EmailAddress`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `string \| undefined` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |

##### Example (as JSON)

```json
{
  "email": null
}
```

#### User Employer Id

User's employer identifier, generally used for tax purposes.

##### Class Name

`UserEmployerId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `employerId` | `string \| undefined` | Optional | User's employer identifier |

##### Example (as JSON)

```json
{
  "employerId": null
}
```

#### Gender

Gender as the user identifies

##### Class Name

`Gender`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gender` | [`GenderTypesEnum \| undefined`](#gender-types) | Optional | Gender as a user identifies |

##### Example (as JSON)

```json
{
  "gender": null
}
```

#### Language

Preferred language for the user's account. <i>Defaults to English</i>

##### Class Name

`Language`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Optional | Language type in IETF's BCP 47 format |

##### Example (as JSON)

```json
{
  "language": null
}
```

#### User Type

User's profile type

##### Class Name

`UserType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userType` | [`UserTypesEnum \| undefined`](#user-types) | Optional | Account holder's profile type |

##### Example (as JSON)

```json
{
  "userType": null
}
```

#### Program User Id

Program identifier for the user

##### Class Name

`ProgramUserId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `programUserId` | `string \| undefined` | Optional | Program identifier for the user |

##### Example (as JSON)

```json
{
  "programUserId": null
}
```

#### Source Destination Token

Unique identifier representing the source of the funds.

##### Class Name

`SourceDestinationToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null
}
```

#### Token

Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.

##### Class Name

`Token`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Client Transfer Id

Unique value provided by the client for the transfer, utilized for reference and deduplication.

##### Class Name

`ClientTransferId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clientTransferId` | `string \| undefined` | Optional | Unique value provided by the client for the transfer. |

##### Example (as JSON)

```json
{
  "clientTransferId": null
}
```

#### Notes

Optional comments visible to the user

##### Class Name

`Notes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notes` | `string \| undefined` | Optional | Optional comments visible to the user. |

##### Example (as JSON)

```json
{
  "notes": null
}
```

#### Memo

Optional internal memo not visible to the user.

##### Class Name

`Memo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `memo` | `string \| undefined` | Optional | Optional internal memo not visible to the user. |

##### Example (as JSON)

```json
{
  "memo": null
}
```

#### Created On

Time at which the object was created.

##### Class Name

`CreatedOn`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |

##### Example (as JSON)

```json
{
  "createdOn": null
}
```

#### Transfer Status

Current status of the transfer.

##### Class Name

`TransferStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`TransferStatusTypesEnum \| undefined`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### User Status

Current status of the user.

##### Class Name

`UserStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`UserStatusTypesEnum \| undefined`](#user-status-types) | Optional | Current status of the user |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Payment Purpose

Purpose for the payment being made.

##### Class Name

`PaymentPurpose`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `purpose` | [`PaymentPurposeTypesEnum \| undefined`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |

##### Example (as JSON)

```json
{
  "purpose": null
}
```

#### Source Token

Unique identifier representing the source of funds.

##### Class Name

`SourceToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sourceToken` | `string \| undefined` | Optional | Unique identifier representing the source of funds. |

##### Example (as JSON)

```json
{
  "sourceToken": null
}
```

#### Destination Token

Unique identifier representing the destination of funds.

##### Class Name

`DestinationToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destinationToken` | `string \| undefined` | Optional | Unique identifier representing the destination of funds. |

##### Example (as JSON)

```json
{
  "destinationToken": null
}
```

#### Client Payment Id

Unique value provided by the client for the payment, utilized for reference and de-duplication.

##### Class Name

`ClientPaymentId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clientPaymentId` | `string \| undefined` | Optional | Unique value provided by the client for the payment. |

##### Example (as JSON)

```json
{
  "clientPaymentId": null
}
```

#### Auto Accept Quote

Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.

##### Class Name

`AutoAcceptQuote`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `autoAcceptQuote` | `boolean \| undefined` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |

##### Example (as JSON)

```json
{
  "autoAcceptQuote": null
}
```

#### Rate

Exchange rate

##### Class Name

`Rate`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate` | `number \| undefined` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` |

##### Example (as JSON)

```json
{
  "rate": null
}
```

#### Fx

The details of the country's foreign exchange currency.

##### Class Name

`Fx`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fx` | [`FxObject \| undefined`](#fx-object) | Optional | Currency conversion object details |

##### Example (as JSON)

```json
{
  "fx": null
}
```

#### Paper Check Base

##### Class Name

`PaperCheckBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`TransferTypesEnum \| undefined`](#transfer-types) | Optional | Transfer type |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |
| `shippingMethod` | [`ShippingMethodTypesEnum \| undefined`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Type

Type of transfer method

##### Class Name

`TransferType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`TransferTypesEnum \| undefined`](#transfer-types) | Optional | Transfer type |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account Ownership

Account ownership type

##### Class Name

`BankAccountOwnership`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null
}
```

#### Shipping Method

Shipping method desired

##### Class Name

`ShippingMethod`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shippingMethod` | [`ShippingMethodTypesEnum \| undefined`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "shippingMethod": null
}
```

#### Paper Check

Details of the paper check

##### Class Name

`PaperCheck`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `type` | [`TransferTypesEnum \| undefined`](#transfer-types) | Optional | Transfer type |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |
| `shippingMethod` | [`ShippingMethodTypesEnum \| undefined`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check-Response

Response to a paper check request

##### Class Name

`PaperCheckResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `type` | [`TransferTypesEnum \| undefined`](#transfer-types) | Optional | Transfer type |
| `amount` | `number` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `addressLine1` | `string \| undefined` | Optional | First line of the address that specifies street number, street name, and building name |
| `addressLine2` | `string \| undefined` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `addressLine3` | `string \| undefined` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `addressLine4` | `string \| undefined` | Optional | Fourth line of the address, if any |
| `addressLine5` | `string \| undefined` | Optional | Fifth line of the address, if any |
| `city` | `string \| undefined` | Optional | City or town of the business address |
| `region` | `string \| undefined` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `postalCode` | `string \| undefined` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premiseNumber` | `string \| undefined` | Optional | House or building number of the business address |
| `addressType` | [`AddressTypesEnum \| undefined`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |
| `shippingMethod` | [`ShippingMethodTypesEnum \| undefined`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check Collection-Response

Response to a paper check collection request

##### Class Name

`PaperCheckCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`PaperCheck[] \| undefined`](#paper-check) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Bank Account Fields

Classifies account field objects

##### Class Name

`BankAccountFields`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |
| `type` | [`BankAccountTypesEnum \| undefined`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `fields` | [`KeyValuePairBankFieldTypesString[] \| undefined`](#key-value-pair-bank-field-types-string) | Optional | - |
| `bankCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `bankCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `description` | `string \| undefined` | Optional | User-supplied description of the bank account for reference |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Type

Type of bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`BankAccountTypesEnum \| undefined`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account

Unique identifier for the bank account

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`BankAccountStatusTypesEnum \| undefined`](#bank-account-status-types) | Optional | Current verification status type of the bank account |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |
| `type` | [`BankAccountTypesEnum \| undefined`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `fields` | [`KeyValuePairBankFieldTypesString[] \| undefined`](#key-value-pair-bank-field-types-string) | Optional | - |
| `bankCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `bankCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `description` | `string \| undefined` | Optional | User-supplied description of the bank account for reference |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Status

Verification status of the bank account (<i>Verified</i>, <i>Disabled</i>)

##### Class Name

`BankAccountStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`BankAccountStatusTypesEnum \| undefined`](#bank-account-status-types) | Optional | Current verification status type of the bank account |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Bank Account-Response

Response to the bank account request

##### Class Name

`BankAccountResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`BankAccountStatusTypesEnum \| undefined`](#bank-account-status-types) | Optional | Current verification status type of the bank account |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `bankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum \| undefined`](#bank-account-ownership-types) | Optional | Account ownership types |
| `type` | [`BankAccountTypesEnum \| undefined`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `fields` | [`KeyValuePairBankFieldTypesString[] \| undefined`](#key-value-pair-bank-field-types-string) | Optional | - |
| `bankCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `bankCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `description` | `string \| undefined` | Optional | User-supplied description of the bank account for reference |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null,
  "links": null
}
```

#### Bank Account Collection-Response

Collection response to the bank account request

##### Class Name

`BankAccountCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`BankAccountResponse[] \| undefined`](#bank-account-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Prepaid Card Package

Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>, including artwork, packaging, and delivery method

##### Class Name

`PrepaidCardPackage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardPackage` | `string \| undefined` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |

##### Example (as JSON)

```json
{
  "cardPackage": null
}
```

#### Prepaid Card Base

Base class applied to the prepaid card

##### Class Name

`PrepaidCardBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardPackage` | `string \| undefined` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `programToken` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2"
}
```

#### Prepaid Card Status

Current status of the prepaid card

##### Class Name

`PrepaidCardStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`StatusEnum \| undefined`](#status) | Optional | Current status of the prepaid card |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Token Type

##### Class Name

`TokenType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tokenType` | [`TokenTypesEnum \| undefined`](#token-types) | Optional | Types of resources represented by a token |

##### Example (as JSON)

```json
{
  "tokenType": null
}
```

#### Prepaid Card Base Ext

Base extension for the prepaid card

##### Class Name

`PrepaidCardBaseExt`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum \| undefined`](#status) | Optional | Current status of the prepaid card |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null
}
```

#### Card Network

Major credit card network

##### Class Name

`CardNetwork`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardNetwork` | [`CardNetworkTypesEnum \| undefined`](#card-network-types) | Optional | Major credit card network types |

##### Example (as JSON)

```json
{
  "cardNetwork": null
}
```

#### Card Personalization Type

Type of personalization for the prepaid card

##### Class Name

`CardPersonalizationType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardPersonalization` | [`PrepaidCardPersonalizationTypesEnum \| undefined`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |

##### Example (as JSON)

```json
{
  "cardPersonalization": null
}
```

#### Prepaid Card

##### Class Name

`PrepaidCard`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum \| undefined`](#status) | Optional | Current status of the prepaid card |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `currency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `cardPersonalization` | [`PrepaidCardPersonalizationTypesEnum \| undefined`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |
| `cardPackage` | `string \| undefined` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `cardNetwork` | [`CardNetworkTypesEnum \| undefined`](#card-network-types) | Optional | Major credit card network types |
| `expires` | `string \| undefined` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `cardNumber` | `string \| undefined` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |
| `cvv` | `string \| undefined` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null
}
```

#### Currency

Currency code used for the object

##### Class Name

`Currency`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "currency": null
}
```

#### Country

Two-digit country code for the object

##### Class Name

`Country`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |

##### Example (as JSON)

```json
{
  "country": "FO"
}
```

#### Prepaid Card-Request Response

##### Class Name

`PrepaidCardRequestResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum \| undefined`](#status) | Optional | Current status of the prepaid card |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "links": null
}
```

#### Prepaid Card-Response

##### Class Name

`PrepaidCardResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum \| undefined`](#status) | Optional | Current status of the prepaid card |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `currency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `cardPersonalization` | [`PrepaidCardPersonalizationTypesEnum \| undefined`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |
| `cardPackage` | `string \| undefined` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `cardNetwork` | [`CardNetworkTypesEnum \| undefined`](#card-network-types) | Optional | Major credit card network types |
| `expires` | `string \| undefined` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `cardNumber` | `string \| undefined` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |
| `cvv` | `string \| undefined` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null,
  "links": null
}
```

#### Prepaid Card Collection-Response

##### Class Name

`PrepaidCardCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`PrepaidCardResponse[] \| undefined`](#prepaid-card-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Card Masked Pan

Card number using PAN truncation

##### Class Name

`CardMaskedPan`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardNumber` | `string \| undefined` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |

##### Example (as JSON)

```json
{
  "cardNumber": null
}
```

#### Prepaid Card Replacement Reason

##### Class Name

`PrepaidCardReplacementReason`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardReplacementReason` | [`PrepaidCardReplacementReasonTypesEnum \| undefined`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. |

##### Example (as JSON)

```json
{
  "cardReplacementReason": null
}
```

#### Prepaid Card Replacement Base

##### Class Name

`PrepaidCardReplacementBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardPackage` | `string \| undefined` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `programToken` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` |
| `cardReplacementReason` | [`PrepaidCardReplacementReasonTypesEnum \| undefined`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2",
  "cardReplacementReason": null
}
```

#### Prepaid Card Pin Token

##### Class Name

`PrepaidCardPinToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardPinToken` | `string \| undefined` | Optional | Token used as part of a two-leg card PIN reveal request sent directly from the client that generally involves a second piece of data, such as the CVV code on the back of the card. |
| `url` | `string \| undefined` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params |

##### Example (as JSON)

```json
{
  "cardPinToken": null,
  "url": null
}
```

#### Prepaid Card Pin

##### Class Name

`PrepaidCardPin`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardPin` | `string \| undefined` | Optional | Card PIN for ATM and Debit usage |

##### Example (as JSON)

```json
{
  "cardPin": null
}
```

#### Cvv

Three- or four-digit Card Verification Value (CVV) number displayed on the back of a credit or debit card

##### Class Name

`Cvv`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cvv` | `string \| undefined` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |

##### Example (as JSON)

```json
{
  "cvv": null
}
```

#### Identity Verification Provider Type

Provider type of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvProvider` | [`IdentityVerificationProviderTypesEnum \| undefined`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |

##### Example (as JSON)

```json
{
  "idvProvider": null
}
```

#### Identity Verification Result Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvResult` | [`IdentityVerificationResultTypesEnum \| undefined`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |

##### Example (as JSON)

```json
{
  "idvResult": null
}
```

#### Identity Verification Sub Result Type

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationSubResultType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvSubResult` | [`IdentityVerificationResultSubTypesEnum \| undefined`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |

##### Example (as JSON)

```json
{
  "idvSubResult": null
}
```

#### Identity Verification Disposition Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvDispostion` | [`IdentityVerificationDispositionTypesEnum \| undefined`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |

##### Example (as JSON)

```json
{
  "idvDispostion": null
}
```

#### Identity Verification Check Type

Type of verification used for performing an identity check

##### Class Name

`IdentityVerificationCheckType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvCheckType` | [`IdentityVerificationCheckTypesEnum \| undefined`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |

##### Example (as JSON)

```json
{
  "idvCheckType": null
}
```

#### Identity Verification Base

##### Class Name

`IdentityVerificationBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvProviderReference` | `string \| undefined` | Optional | IDV provider unique ID for the IDV check performed |
| `idvResult` | [`IdentityVerificationResultTypesEnum \| undefined`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `idvSubResult` | [`IdentityVerificationResultSubTypesEnum \| undefined`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |
| `idvProvider` | [`IdentityVerificationProviderTypesEnum \| undefined`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `raw` | `string \| undefined` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |
| `idvCheckType` | [`IdentityVerificationCheckTypesEnum \| undefined`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |
| `idvDispostion` | [`IdentityVerificationDispositionTypesEnum \| undefined`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null
}
```

#### Identity Verification Provider Reference

Provider reference used for performing identity checks for the provider

##### Class Name

`IdentityVerificationProviderReference`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvProviderReference` | `string \| undefined` | Optional | IDV provider unique ID for the IDV check performed |

##### Example (as JSON)

```json
{
  "idvProviderReference": null
}
```

#### Identity Verification Provider Raw Output

Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only

##### Class Name

`IdentityVerificationProviderRawOutput`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `raw` | `string \| undefined` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |

##### Example (as JSON)

```json
{
  "raw": null
}
```

#### Identity Verification-Response

##### Class Name

`IdentityVerificationResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idvProviderReference` | `string \| undefined` | Optional | IDV provider unique ID for the IDV check performed |
| `idvResult` | [`IdentityVerificationResultTypesEnum \| undefined`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `idvSubResult` | [`IdentityVerificationResultSubTypesEnum \| undefined`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |
| `idvProvider` | [`IdentityVerificationProviderTypesEnum \| undefined`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |
| `createdOn` | `string \| undefined` | Optional | Time at which the object was created. |
| `raw` | `string \| undefined` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |
| `idvCheckType` | [`IdentityVerificationCheckTypesEnum \| undefined`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |
| `idvDispostion` | [`IdentityVerificationDispositionTypesEnum \| undefined`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `token` | `string \| undefined` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null,
  "links": null
}
```

#### Identity Verification Collection-Response

##### Class Name

`IdentityVerificationCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`IdentityVerificationResponse[] \| undefined`](#identity-verification-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Key Value Pair String String

##### Class Name

`KeyValuePairStringString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | - |
| `value` | `string \| undefined` | Optional | - |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Pair Bank Field Types String

1...N required fields as determined by call to get requirements

##### Class Name

`KeyValuePairBankFieldTypesString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | [`BankAccountFieldTypesEnum`](#bank-account-field-types) | Required | Classifies account field types |
| `value` | `string` | Required | - |

##### Example (as JSON)

```json
{
  "key": "BANK_NON_SWIFT_BIC",
  "value": "value2"
}
```

#### Key Value Pair Bank Currency Currency Types

##### Class Name

`KeyValuePairBankCurrencyCurrencyTypes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | **Default**: `'BANK_CURRENCY'`<br>*Default: `'BANK_CURRENCY'`* |
| `value` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Bank Country Country Types

##### Class Name

`KeyValueBankCountryCountryTypes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | **Default**: `'BANK_COUNTRY'`<br>*Default: `'BANK_COUNTRY'`* |
| `value` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Bank Account Required Fields

Classifies the required account field objects

##### Class Name

`BankAccountRequiredFields`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `format` | [`BankAccountRequirementFormat \| undefined`](#bank-account-requirement-format) | Optional | Classifies the format of the required information for a bank account |
| `requirement` | [`BankAccountFieldTypesEnum \| undefined`](#bank-account-field-types) | Optional | Classifies account field types |
| `description` | [`KeyValuePairLanguageTypeString[] \| undefined`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes |
| `validators` | [`BankAccountRequirementValidator[] \| undefined`](#bank-account-requirement-validator) | Optional | - |

##### Example (as JSON)

```json
{
  "format": null,
  "requirement": null,
  "description": null,
  "validators": null
}
```

#### Bank Account Requirement Format

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `example` | `string \| undefined` | Optional | Example of a requirement generated from the validator(s) |
| `legend` | [`BankAccountRequirementFormatLegend[] \| undefined`](#bank-account-requirement-format-legend) | Optional | - |

##### Example (as JSON)

```json
{
  "example": null,
  "legend": null
}
```

#### Bank Account Requirement Format Legend

Classifies the legend format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormatLegend`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | - |
| `descriptions` | [`KeyValuePairLanguageTypeString[] \| undefined`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes |

##### Example (as JSON)

```json
{
  "key": null,
  "descriptions": null
}
```

#### Key Value Pair Language Type String

Localized requirement description for display purposes

##### Class Name

`KeyValuePairLanguageTypeString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `language` | [`LanguageTypesEnum \| undefined`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `translation` | `string \| undefined` | Optional | Translated string in the specified language |

##### Example (as JSON)

```json
{
  "language": null,
  "translation": null
}
```

#### Bank Account Requirement Validator

Specifies the validator type for the required bank account information

##### Class Name

`BankAccountRequirementValidator`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `validatorType` | [`ValidatorTypesEnum \| undefined`](#validator-types) | Optional | - |
| `expression` | `string` | Required | Validation regular expression |

##### Example (as JSON)

```json
{
  "validatorType": null,
  "expression": "expression2"
}
```

#### Bank Account Requirement

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirement`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bankCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `bankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `sourceCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `requirements` | [`BankAccountRequiredFields[] \| undefined`](#bank-account-required-fields) | Optional | - |
| `quote` | [`MonetaryFormatted \| undefined`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null
}
```

#### Bank Account Requirement-Response

##### Class Name

`BankAccountRequirementResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bankCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `bankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `sourceCountry` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `sourceCurrency` | [`CurrencyTypesEnum \| undefined`](#currency-types) | Optional | Currency code type for the object |
| `requirements` | [`BankAccountRequiredFields[] \| undefined`](#bank-account-required-fields) | Optional | - |
| `quote` | [`MonetaryFormatted \| undefined`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null,
  "links": null
}
```

#### Bank Account Requirement Collection-Response

##### Class Name

`BankAccountRequirementCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`BankAccountRequirementResponse[] \| undefined`](#bank-account-requirement-response) | Optional | - |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Occupation

##### Class Name

`Occupation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `occupation` | [`OccupationTypesEnum \| undefined`](#occupation-types) | Optional | Type of occupation for the user |

##### Example (as JSON)

```json
{
  "occupation": null
}
```

#### Tax Resident Status

##### Class Name

`TaxResidentStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `taxResidentStatus` | [`TaxResidentStatusTypesEnum \| undefined`](#tax-resident-status-types) | Optional | Tax resident status type of a country |

##### Example (as JSON)

```json
{
  "taxResidentStatus": null
}
```

#### Webhook-Subscription

Webhook subscription object

##### Class Name

`WebhookSubscription`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `string \| undefined` | Optional | - |
| `namespace` | [`NamespaceEnum \| undefined`](#namespace) | Optional | Namespace used to identify and refer to the object |

##### Example (as JSON)

```json
{
  "url": null,
  "namespace": null
}
```

#### Webhook-Subscription-Response

Webhook Subscription response

##### Class Name

`WebhookSubscriptionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |
| `url` | `string \| undefined` | Optional | - |
| `namespace` | [`NamespaceEnum \| undefined`](#namespace) | Optional | Namespace used to identify and refer to the object |
| `token` | `string \| undefined` | Optional | Token for the webhook subscription |
| `created` | `string \| undefined` | Optional | Time stamp for the date the webhook subscription was created |
| `lastUpdated` | `string \| undefined` | Optional | Time stamp for the date the webhook subscription was updated |

##### Example (as JSON)

```json
{
  "links": null,
  "url": null,
  "namespace": null,
  "token": null,
  "created": null,
  "lastUpdated": null
}
```

#### Webhook Collection-Response

Webhook Subscription collection response

##### Class Name

`WebhookCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`HaetosParams[] \| undefined`](#haetos-params) | Optional | - |
| `payload` | [`WebhookSubscriptionResponse[] \| undefined`](#webhook-subscription-response) | Optional | - |

##### Example (as JSON)

```json
{
  "links": null,
  "payload": null
}
```

#### Prepaid Card Data-Response

Response to the prepaid card data request

##### Class Name

`PrepaidCardDataResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cardImage` | `string \| undefined` | Optional | - |
| `cardNumber` | `number \| undefined` | Optional | - |
| `cvvNumber` | `string \| undefined` | Optional | - |
| `expiration` | `string \| undefined` | Optional | - |
| `nameOnCard` | `string \| undefined` | Optional | - |
| `side` | `string \| undefined` | Optional | - |
| `token` | `string \| undefined` | Optional | - |

##### Example (as JSON)

```json
{
  "cardImage": null,
  "cardNumber": null,
  "cvvNumber": null,
  "expiration": null,
  "nameOnCard": null,
  "side": null,
  "token": null
}
```

#### Prepaid Card Data Token

Token assigned to the prepaid card

##### Class Name

`PrepaidCardDataToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Required | **Constraints**: *Minimum Length*: `1` |
| `url` | `string \| undefined` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params |

##### Example (as JSON)

```json
{
  "token": "token6",
  "url": null
}
```

#### Prepaid Card Data Token-Response

##### Class Name

`PrepaidCardDataTokenResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | [`PrepaidCardDataToken \| undefined`](#prepaid-card-data-token) | Optional | Token assigned to the prepaid card |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Business Type

##### Class Name

`BusinessType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `businessType` | [`BusinessTypesEnum \| undefined`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |

##### Example (as JSON)

```json
{
  "businessType": null
}
```

#### Country Nationality Information

##### Class Name

`CountryNationalityInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `countryOfBirth` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |
| `countryOfNationality` | [`CountryTypesEnum \| undefined`](#country-types) | Optional | Two-digit country code types |

##### Example (as JSON)

```json
{
  "countryOfBirth": null,
  "countryOfNationality": null
}
```

#### Users Prepaid Cards Pin Response

##### Class Name

`UsersPrepaidCardsPinResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | `boolean \| undefined` | Optional | - |

##### Example (as JSON)

```json
{
  "result": null
}
```

### Enumerations

* [Transfer Status Types](#transfer-status-types)
* [Payment Purpose Types](#payment-purpose-types)
* [Address Types](#address-types)
* [User Types](#user-types)
* [User Status Types](#user-status-types)
* [Language Types](#language-types)
* [Gender Types](#gender-types)
* [Business Types](#business-types)
* [Transfer Types](#transfer-types)
* [Shipping Method Types](#shipping-method-types)
* [Bank Account Ownership Types](#bank-account-ownership-types)
* [Bank Account Types](#bank-account-types)
* [Bank Account Status Types](#bank-account-status-types)
* [Token Types](#token-types)
* [Card Network Types](#card-network-types)
* [Prepaid Card Personalization Types](#prepaid-card-personalization-types)
* [Currency Types](#currency-types)
* [Country Types](#country-types)
* [Prepaid Card Replacement Reason Types](#prepaid-card-replacement-reason-types)
* [Identity Verification Provider Types](#identity-verification-provider-types)
* [Identity Verification Result Types](#identity-verification-result-types)
* [Identity Verification Result Sub Types](#identity-verification-result-sub-types)
* [Identity Verification Disposition Types](#identity-verification-disposition-types)
* [Identity Verification Check Types](#identity-verification-check-types)
* [Bank Account Field Types](#bank-account-field-types)
* [Validator Types](#validator-types)
* [Occupation Types](#occupation-types)
* [Tax Resident Status Types](#tax-resident-status-types)
* [Namespace](#namespace)
* [Business Contact Role](#business-contact-role)
* [Format](#format)
* [Government Id Type](#government-id-type)
* [Side](#side)
* [Status](#status)

#### Transfer Status Types

Current status of a transfer

##### Class Name

`TransferStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `qUOTED` |
| `pENDING` |
| `sCHEDULED` |
| `cOMPLETED` |
| `cANCELLED` |
| `rETURNED` |
| `fAILED` |
| `eXPIRED` |
| `vERIFICATIONHOLD` |

#### Payment Purpose Types

Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services)

##### Class Name

`PaymentPurposeTypesEnum`

##### Fields

| Name |
|  --- |
| `oTHER` |
| `tAXABLE` |
| `iNCOME` |
| `bONUS` |
| `eXPENSE` |
| `nONTAXABLE` |

#### Address Types

Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)

##### Class Name

`AddressTypesEnum`

##### Fields

| Name |
|  --- |
| `rESIDENTIAL` |
| `bUSINESS` |
| `mAILING` |

#### User Types

Account holder's profile type

##### Class Name

`UserTypesEnum`

##### Fields

| Name |
|  --- |
| `iNDIVIDUAL` |
| `bUSINESS` |

#### User Status Types

Current status of the user

##### Class Name

`UserStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `aCTIVATED` |
| `pREACTIVATED` |
| `pENDINGEMAILVERIFICATION` |
| `pENDINGKYC` |

#### Language Types

Language type in IETF's BCP 47 format

##### Class Name

`LanguageTypesEnum`

##### Fields

| Name |
|  --- |
| `enUS` |
| `enGB` |
| `frCA` |
| `frFR` |
| `esMX` |
| `esES` |
| `ptBR` |
| `ptPT` |
| `deDE` |
| `itIT` |
| `jaJP` |
| `zhCN` |
| `zhTW` |

#### Gender Types

Gender as a user identifies

##### Class Name

`GenderTypesEnum`

##### Fields

| Name |
|  --- |
| `mALE` |
| `fEMALE` |
| `nOTSPECIFIED` |

#### Business Types

Type of business (<i>Corporation</i> or <i>Partnership</i>)

##### Class Name

`BusinessTypesEnum`

##### Fields

| Name |
|  --- |
| `cORPORATION` |
| `pARTNERSHIPDBA` |

#### Transfer Types

Transfer type

##### Class Name

`TransferTypesEnum`

##### Fields

| Name |
|  --- |
| `pAPERCHECK` |
| `bANKTRANSFER` |
| `pAYMENT` |
| `sPENDBACK` |

#### Shipping Method Types

Shipping method type for a pre-paid card or paper check

##### Class Name

`ShippingMethodTypesEnum`

##### Fields

| Name |
|  --- |
| `sTANDARD` |
| `eXPEDITED` |

#### Bank Account Ownership Types

Account ownership types

##### Class Name

`BankAccountOwnershipTypesEnum`

##### Fields

| Name |
|  --- |
| `pERSONAL` |
| `bUSINESS` |

#### Bank Account Types

Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountTypesEnum`

##### Fields

| Name |
|  --- |
| `cHECKING` |
| `sAVINGS` |
| `mONEYMARKET` |

#### Bank Account Status Types

Current verification status type of the bank account

##### Class Name

`BankAccountStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `dELETED` |
| `aCTIVE` |
| `pENDINGVERIFICATION` |

#### Token Types

Types of resources represented by a token

##### Class Name

`TokenTypesEnum`

##### Fields

| Name |
|  --- |
| `bANKACCOUNT` |
| `tRANSFER` |
| `pAYMENT` |
| `sPENDBACK` |
| `pREPAIDCARD` |
| `uSER` |
| `dOCUMENT` |
| `aCCOUNT` |

#### Card Network Types

Major credit card network types

##### Class Name

`CardNetworkTypesEnum`

##### Fields

| Name |
|  --- |
| `vISA` |
| `mASTERCARD` |

#### Prepaid Card Personalization Types

Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer)

##### Class Name

`PrepaidCardPersonalizationTypesEnum`

##### Fields

| Name |
|  --- |
| `pERSONALIZED` |
| `nONPERSONALIZED` |

#### Currency Types

Currency code type for the object

##### Class Name

`CurrencyTypesEnum`

##### Fields

| Name |
|  --- |
| `uSD` |
| `cAD` |
| `mXN` |
| `aUD` |
| `hKD` |
| `nZD` |
| `eUR` |
| `gBP` |

#### Country Types

Two-digit country code types

##### Class Name

`CountryTypesEnum`

##### Fields

| Name |
|  --- |
| `aD` |
| `aE` |
| `aF` |
| `aG` |
| `aI` |
| `aL` |
| `aM` |
| `aN` |
| `aO` |
| `aQ` |
| `aR` |
| `aS` |
| `aT` |
| `aU` |
| `aW` |
| `aX` |
| `aZ` |
| `bA` |
| `bB` |
| `bD` |
| `bE` |
| `bF` |
| `bG` |
| `bH` |
| `bI` |
| `bJ` |
| `bL` |
| `bM` |
| `bN` |
| `bO` |
| `bQ` |
| `bR` |
| `bS` |
| `bT` |
| `bV` |
| `bW` |
| `bY` |
| `bZ` |
| `cA` |
| `cC` |
| `cD` |
| `cF` |
| `cG` |
| `cH` |
| `cI` |
| `cK` |
| `cL` |
| `cM` |
| `cN` |
| `cO` |
| `cR` |
| `cU` |
| `cV` |
| `cW` |
| `cX` |
| `cY` |
| `cZ` |
| `dE` |
| `dJ` |
| `dK` |
| `dM` |
| `dO` |
| `dZ` |
| `eC` |
| `eE` |
| `eG` |
| `eH` |
| `eR` |
| `eS` |
| `eT` |
| `fI` |
| `fJ` |
| `fK` |
| `fM` |
| `fO` |
| `fR` |
| `gA` |
| `gB` |
| `gD` |
| `gE` |
| `gF` |
| `gG` |
| `gH` |
| `gI` |
| `gL` |
| `gM` |
| `gN` |
| `gP` |
| `gQ` |
| `gR` |
| `gS` |
| `gT` |
| `gU` |
| `gW` |
| `gY` |
| `hK` |
| `hM` |
| `hN` |
| `hR` |
| `hT` |
| `hU` |
| `iD` |
| `iE` |
| `iL` |
| `iM` |
| `iN` |
| `iO` |
| `iQ` |
| `iR` |
| `iS` |
| `iT` |
| `jE` |
| `jM` |
| `jO` |
| `jP` |
| `kE` |
| `kG` |
| `kH` |
| `kI` |
| `kM` |
| `kN` |
| `kP` |
| `kR` |
| `kW` |
| `kY` |
| `kZ` |
| `lA` |
| `lB` |
| `lC` |
| `lI` |
| `lK` |
| `lR` |
| `lS` |
| `lT` |
| `lU` |
| `lV` |
| `lY` |
| `mA` |
| `mC` |
| `mD` |
| `mE` |
| `mF` |
| `mG` |
| `mH` |
| `mK` |
| `mL` |
| `mM` |
| `mN` |
| `mO` |
| `mP` |
| `mQ` |
| `mR` |
| `mS` |
| `mT` |
| `mU` |
| `mV` |
| `mW` |
| `mX` |
| `mY` |
| `mZ` |
| `nA` |
| `nC` |
| `nE` |
| `nF` |
| `nG` |
| `nI` |
| `nL` |
| `nO` |
| `nP` |
| `nR` |
| `nU` |
| `nZ` |
| `oM` |
| `pA` |
| `pE` |
| `pF` |
| `pG` |
| `pH` |
| `pK` |
| `pL` |
| `pM` |
| `pN` |
| `pR` |
| `pS` |
| `pT` |
| `pW` |
| `pY` |
| `qA` |
| `rE` |
| `rO` |
| `rS` |
| `rU` |
| `rW` |
| `sA` |
| `sB` |
| `sC` |
| `sD` |
| `sE` |
| `sG` |
| `sH` |
| `sI` |
| `sJ` |
| `sK` |
| `sL` |
| `sM` |
| `sN` |
| `sO` |
| `sR` |
| `sS` |
| `sT` |
| `sV` |
| `sX` |
| `sY` |
| `sZ` |
| `tC` |
| `tD` |
| `tF` |
| `tG` |
| `tH` |
| `tJ` |
| `tK` |
| `tL` |
| `tM` |
| `tN` |
| `tO` |
| `tR` |
| `tT` |
| `tV` |
| `tW` |
| `tZ` |
| `uA` |
| `uG` |
| `uM` |
| `uS` |
| `uY` |
| `uZ` |
| `vA` |
| `vC` |
| `vE` |
| `vG` |
| `vI` |
| `vN` |
| `vU` |
| `wF` |
| `wS` |
| `yE` |
| `yT` |
| `zA` |
| `zM` |
| `zW` |

#### Prepaid Card Replacement Reason Types

Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility.

##### Class Name

`PrepaidCardReplacementReasonTypesEnum`

##### Fields

| Name |
|  --- |
| `lOST` |
| `sTOLEN` |
| `dAMAGED` |
| `cOMPROMISED` |
| `eXPIRED` |

#### Identity Verification Provider Types

Provider types of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderTypesEnum`

##### Fields

| Name |
|  --- |
| `w2` |
| `iDOLOGY` |
| `bANK` |
| `eQUIFAX` |
| `oFAC` |
| `lEXUSNEXUS` |

#### Identity Verification Result Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultTypesEnum`

##### Fields

| Name |
|  --- |
| `pASS` |
| `fAIL` |
| `sERVICEOFFLINE` |
| `pROCESSING` |

#### Identity Verification Result Sub Types

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationResultSubTypesEnum`

##### Fields

| Name |
|  --- |
| `hARD` |
| `sOFT` |

#### Identity Verification Disposition Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionTypesEnum`

##### Fields

| Name |
|  --- |
| `tRANSIENT` |
| `fINAL` |

#### Identity Verification Check Types

Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.)

##### Class Name

`IdentityVerificationCheckTypesEnum`

##### Fields

| Name |
|  --- |
| `dOCUMENTARY` |
| `nONDOCUMENTARY` |
| `oFAC` |

#### Bank Account Field Types

Classifies account field types

##### Class Name

`BankAccountFieldTypesEnum`

##### Fields

| Name |
|  --- |
| `bANKACHABA` |
| `bANKBBAN` |
| `bANKBRANCHCODE` |
| `bANKBSBCODE` |
| `bANKCITY` |
| `bANKCLABE` |
| `bANKCODE` |
| `bANKCURP` |
| `bANKIBAN` |
| `bANKNAME` |
| `bANKNONSWIFTBIC` |
| `bANKNUBAN` |
| `bANKPHONENUMBER` |
| `bANKPOSTALCODE` |
| `bANKREGION` |
| `bANKRFC` |
| `bANKSORTCODE` |
| `bANKSTREETADDRESS` |
| `bANKSWIFTBIC` |
| `bANKTRANSITCODE` |
| `bENEFICIARYACCOUNTNUMBER` |
| `bENEFICIARYPHONENUMBER` |
| `bENEFICIARYTAXID` |
| `bENEFICIARYNAME` |
| `bANKBRANCHNAME` |
| `bANKPURPOSEOFPAYMENTCODE` |
| `bANKVALUEADDTAX` |

#### Validator Types

##### Class Name

`ValidatorTypesEnum`

##### Fields

| Name |
|  --- |
| `rEGEX` |
| `lENGTH` |

#### Occupation Types

Type of occupation for the user

##### Class Name

`OccupationTypesEnum`

##### Fields

| Name |
|  --- |
| `iNDEPENDENTBUSINESSOWNER` |
| `sCIENCE` |
| `tECHNOLOGY` |
| `eNGINEERING` |
| `mATH` |
| `hEALTHCARE` |
| `sOCIALSERVICES` |
| `mEDIA` |
| `fINANCE` |
| `gOVERNMENT` |
| `mANUFACTURING` |
| `lAW` |
| `hOSPITALITYANDTOURISM` |
| `aRTS` |
| `dESIGN` |
| `oFFICEANDADMINSUPPORT` |
| `eDUCATION` |

#### Tax Resident Status Types

Tax resident status type of a country

##### Class Name

`TaxResidentStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `yES` |
| `nO` |
| `pREFERNOTTOANSWER` |

#### Namespace

Namespace used to identify and refer to the object

##### Class Name

`NamespaceEnum`

##### Fields

| Name |
|  --- |
| `enumBANKACCOUNTSUPDATEDSTATUSAPPROVED` |
| `enumPREPAIDCARDSCREATED` |
| `enumTRANSFERSACCEPTED` |

#### Business Contact Role

Role of the user within the business

##### Class Name

`BusinessContactRoleEnum`

##### Fields

| Name |
|  --- |
| `oWNER` |
| `mANAGER` |
| `pARTNER` |
| `oTHER` |

#### Format

##### Class Name

`FormatEnum`

##### Fields

| Name |
|  --- |
| `tEXT` |
| `iMAGE` |
| `enumTEXTIMAGE` |

#### Government Id Type

User's government ID type

##### Class Name

`GovernmentIdTypeEnum`

##### Fields

| Name |
|  --- |
| `pASSPORT` |
| `nATIONALIDCARD` |
| `cURP` |

#### Side

##### Class Name

`SideEnum`

##### Fields

| Name |
|  --- |
| `fRONT` |
| `bACK` |

#### Status

Current status of the prepaid card

##### Class Name

`StatusEnum`

##### Fields

| Name |
|  --- |
| `qUEUED` |
| `lOSTSTOLENDAMAGED` |
| `aCTIVATED` |
| `pENDINGACTIVATION` |
| `sUSPENDED` |
| `cOMPLIANCEHOLD` |
| `kYCHOLD` |
| `lOCKED` |

## Common Code Documentation

### ApiResponse

An interface for the result of an API call.

#### Properties

| Name | Type | Description |
|  --- | --- | --- |
| request | HttpRequest | Original request that resulted in this response. |
| statusCode | number | Response status codee. |
| headers | Record<string, string> | Response headers. |
| result | T | Response data. |
| body | string \| Blob \| NodeJS.ReadableStream | Original body from the response. |

### ApiError

Thrown when the HTTP status code is not okay.

The ApiError extends the ApiResponse interface, so all ApiResponse properties are available.

#### Properties

| Name | Type | Description |
|  --- | --- | --- |
| request | HttpRequest | Original request that resulted in this response. |
| statusCode | number | Response status codee. |
| headers | Record<string, string> | Response headers. |
| result | T | Response data. |
| body | string \| Blob \| NodeJS.ReadableStream | Original body from the response. |

