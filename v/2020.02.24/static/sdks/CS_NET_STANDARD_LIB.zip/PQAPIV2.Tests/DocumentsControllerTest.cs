// <copyright file="DocumentsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// DocumentsControllerTest.
    /// </summary>
    [TestFixture]
    public class DocumentsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private DocumentsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.DocumentsController;
        }

        /// <summary>
        /// Retrieve a list of user documents that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenDocuments()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            try
            {
                await this.controller.GetUsersUserTokenDocumentsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Create a quote for a user document..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostUsersUserTokenDocuments()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.PostUsersUserTokenDocumentsAsync(userToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Retrieve an individual user document by its document token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenDocumentsDocuToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string docuToken = "docu-6260c132-5cb1-4e30-8b08-9ce559893acb";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            try
            {
                await this.controller.GetUsersUserTokenDocumentsDocuTokenAsync(userToken, docuToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Replace the user document at the given document token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPutUsersUserTokenDocumentsDocuToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string docuToken = "docu-6260c132-5cb1-4e30-8b08-9ce559893acb";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.PutUsersUserTokenDocumentsDocuTokenAsync(userToken, docuToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}