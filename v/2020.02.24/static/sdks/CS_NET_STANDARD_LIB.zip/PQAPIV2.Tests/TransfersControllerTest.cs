// <copyright file="TransfersControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// TransfersControllerTest.
    /// </summary>
    [TestFixture]
    public class TransfersControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private TransfersController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.TransfersController;
        }

        /// <summary>
        /// Retrieve details of a specific transfer represented by a transfer token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetTransfersXferToken()
        {
            // Parameters for the API call
            string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.TransferResponse result = null;
            try
            {
                result = await this.controller.GetTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Accept a transfer quote.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostTransfersXferToken()
        {
            // Parameters for the API call
            string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.PostTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteTransfersXferToken()
        {
            // Parameters for the API call
            string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.DeleteTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetTransfers()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.TransferCollectionResponse result = null;
            try
            {
                result = await this.controller.GetTransfersAsync(xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("X-TimeZone", "America/New_York");
            headers.Add("X-Paging-PageNo", null);
            headers.Add("X-Paging-PageCount", null);
            headers.Add("X-Paging-PageSize", null);
            headers.Add("X-Paging-TotalRecordCount", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }
    }
}