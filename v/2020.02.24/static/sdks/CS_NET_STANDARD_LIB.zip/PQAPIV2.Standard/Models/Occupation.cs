// <copyright file="Occupation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// Occupation.
    /// </summary>
    public class Occupation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Occupation"/> class.
        /// </summary>
        public Occupation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Occupation"/> class.
        /// </summary>
        /// <param name="occupationProp">occupation.</param>
        public Occupation(
            Models.OccupationTypesEnum? occupationProp = null)
        {
            this.OccupationProp = occupationProp;
        }

        /// <summary>
        /// Type of occupation for the user
        /// </summary>
        [JsonProperty("occupation", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.OccupationTypesEnum? OccupationProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Occupation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Occupation other &&
                ((this.OccupationProp == null && other.OccupationProp == null) || (this.OccupationProp?.Equals(other.OccupationProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 696710411;

            if (this.OccupationProp != null)
            {
               hashCode += this.OccupationProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OccupationProp = {(this.OccupationProp == null ? "null" : this.OccupationProp.ToString())}");
        }
    }
}