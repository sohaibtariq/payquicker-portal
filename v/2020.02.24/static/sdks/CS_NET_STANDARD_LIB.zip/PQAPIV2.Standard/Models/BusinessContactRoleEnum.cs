// <copyright file="BusinessContactRoleEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BusinessContactRoleEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BusinessContactRoleEnum
    {
        /// <summary>
        /// OWNER.
        /// </summary>
        [EnumMember(Value = "OWNER")]
        OWNER,

        /// <summary>
        /// MANAGER.
        /// </summary>
        [EnumMember(Value = "MANAGER")]
        MANAGER,

        /// <summary>
        /// PARTNER.
        /// </summary>
        [EnumMember(Value = "PARTNER")]
        PARTNER,

        /// <summary>
        /// OTHER.
        /// </summary>
        [EnumMember(Value = "OTHER")]
        OTHER,
    }
}