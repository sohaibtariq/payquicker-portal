// <copyright file="GovernmentIdTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// GovernmentIdTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum GovernmentIdTypeEnum
    {
        /// <summary>
        /// PASSPORT.
        /// </summary>
        [EnumMember(Value = "PASSPORT")]
        PASSPORT,

        /// <summary>
        /// NATIONALIDCARD.
        /// </summary>
        [EnumMember(Value = "NATIONAL_ID_CARD")]
        NATIONALIDCARD,

        /// <summary>
        /// CURP.
        /// </summary>
        [EnumMember(Value = "CURP")]
        CURP,
    }
}