// <copyright file="Fx.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// Fx.
    /// </summary>
    public class Fx
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Fx"/> class.
        /// </summary>
        public Fx()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Fx"/> class.
        /// </summary>
        /// <param name="fxProp">fx.</param>
        public Fx(
            Models.FxObject fxProp = null)
        {
            this.FxProp = fxProp;
        }

        /// <summary>
        /// Currency conversion object details
        /// </summary>
        [JsonProperty("fx", NullValueHandling = NullValueHandling.Ignore)]
        public Models.FxObject FxProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Fx : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Fx other &&
                ((this.FxProp == null && other.FxProp == null) || (this.FxProp?.Equals(other.FxProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -172649704;

            if (this.FxProp != null)
            {
               hashCode += this.FxProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FxProp = {(this.FxProp == null ? "null" : this.FxProp.ToString())}");
        }
    }
}