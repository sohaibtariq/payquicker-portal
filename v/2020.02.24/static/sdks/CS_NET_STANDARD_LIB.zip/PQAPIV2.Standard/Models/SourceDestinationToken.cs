// <copyright file="SourceDestinationToken.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// SourceDestinationToken.
    /// </summary>
    public class SourceDestinationToken
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SourceDestinationToken"/> class.
        /// </summary>
        public SourceDestinationToken()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SourceDestinationToken"/> class.
        /// </summary>
        /// <param name="sourceToken">sourceToken.</param>
        /// <param name="destinationToken">destinationToken.</param>
        public SourceDestinationToken(
            string sourceToken = null,
            string destinationToken = null)
        {
            this.SourceToken = sourceToken;
            this.DestinationToken = destinationToken;
        }

        /// <summary>
        /// Unique identifier representing the source of funds.
        /// </summary>
        [JsonProperty("sourceToken", NullValueHandling = NullValueHandling.Ignore)]
        public string SourceToken { get; set; }

        /// <summary>
        /// Unique identifier representing the destination of funds.
        /// </summary>
        [JsonProperty("destinationToken", NullValueHandling = NullValueHandling.Ignore)]
        public string DestinationToken { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SourceDestinationToken : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SourceDestinationToken other &&
                ((this.SourceToken == null && other.SourceToken == null) || (this.SourceToken?.Equals(other.SourceToken) == true)) &&
                ((this.DestinationToken == null && other.DestinationToken == null) || (this.DestinationToken?.Equals(other.DestinationToken) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 14147946;

            if (this.SourceToken != null)
            {
               hashCode += this.SourceToken.GetHashCode();
            }

            if (this.DestinationToken != null)
            {
               hashCode += this.DestinationToken.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SourceToken = {(this.SourceToken == null ? "null" : this.SourceToken == string.Empty ? "" : this.SourceToken)}");
            toStringOutput.Add($"this.DestinationToken = {(this.DestinationToken == null ? "null" : this.DestinationToken == string.Empty ? "" : this.DestinationToken)}");
        }
    }
}