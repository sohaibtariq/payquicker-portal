// <copyright file="KeyValuePairBankCurrencyCurrencyTypes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// KeyValuePairBankCurrencyCurrencyTypes.
    /// </summary>
    public class KeyValuePairBankCurrencyCurrencyTypes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValuePairBankCurrencyCurrencyTypes"/> class.
        /// </summary>
        public KeyValuePairBankCurrencyCurrencyTypes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValuePairBankCurrencyCurrencyTypes"/> class.
        /// </summary>
        /// <param name="key">key.</param>
        /// <param name="mValue">value.</param>
        public KeyValuePairBankCurrencyCurrencyTypes(
            string key = "BANK_CURRENCY",
            Models.CurrencyTypesEnum? mValue = null)
        {
            this.Key = key;
            this.MValue = mValue;
        }

        /// <summary>
        /// Gets or sets Key.
        /// </summary>
        [JsonProperty("key", NullValueHandling = NullValueHandling.Ignore)]
        public string Key { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("value", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? MValue { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"KeyValuePairBankCurrencyCurrencyTypes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is KeyValuePairBankCurrencyCurrencyTypes other &&
                ((this.Key == null && other.Key == null) || (this.Key?.Equals(other.Key) == true)) &&
                ((this.MValue == null && other.MValue == null) || (this.MValue?.Equals(other.MValue) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 386462047;

            if (this.Key != null)
            {
               hashCode += this.Key.GetHashCode();
            }

            if (this.MValue != null)
            {
               hashCode += this.MValue.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Key = {(this.Key == null ? "null" : this.Key == string.Empty ? "" : this.Key)}");
            toStringOutput.Add($"this.MValue = {(this.MValue == null ? "null" : this.MValue.ToString())}");
        }
    }
}