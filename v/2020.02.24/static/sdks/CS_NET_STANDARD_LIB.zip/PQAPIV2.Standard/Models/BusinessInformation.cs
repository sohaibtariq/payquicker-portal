// <copyright file="BusinessInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BusinessInformation.
    /// </summary>
    public class BusinessInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessInformation"/> class.
        /// </summary>
        public BusinessInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessInformation"/> class.
        /// </summary>
        /// <param name="businessName">businessName.</param>
        /// <param name="businessOperatingName">businessOperatingName.</param>
        /// <param name="businessRegistrationId">businessRegistrationId.</param>
        /// <param name="businessRegistrationRegion">businessRegistrationRegion.</param>
        /// <param name="businessRegistrationCountry">businessRegistrationCountry.</param>
        /// <param name="businessContactRole">businessContactRole.</param>
        /// <param name="businessAddressLine1">businessAddressLine1.</param>
        /// <param name="businessAddressLine2">businessAddressLine2.</param>
        /// <param name="businessAddressLine3">businessAddressLine3.</param>
        /// <param name="businessAddressLine4">businessAddressLine4.</param>
        /// <param name="businessAddressLine5">businessAddressLine5.</param>
        /// <param name="businessCity">businessCity.</param>
        /// <param name="businessRegion">businessRegion.</param>
        /// <param name="businessCountry">businessCountry.</param>
        /// <param name="businessPostalCode">businessPostalCode.</param>
        /// <param name="businessPremiseNumber">businessPremiseNumber.</param>
        /// <param name="businessType">businessType.</param>
        public BusinessInformation(
            string businessName = null,
            string businessOperatingName = null,
            string businessRegistrationId = null,
            string businessRegistrationRegion = null,
            Models.CountryTypesEnum? businessRegistrationCountry = null,
            Models.BusinessContactRoleEnum? businessContactRole = null,
            string businessAddressLine1 = null,
            string businessAddressLine2 = null,
            string businessAddressLine3 = null,
            string businessAddressLine4 = null,
            string businessAddressLine5 = null,
            string businessCity = null,
            string businessRegion = null,
            Models.CountryTypesEnum? businessCountry = null,
            string businessPostalCode = null,
            string businessPremiseNumber = null,
            Models.BusinessTypesEnum? businessType = null)
        {
            this.BusinessName = businessName;
            this.BusinessOperatingName = businessOperatingName;
            this.BusinessRegistrationId = businessRegistrationId;
            this.BusinessRegistrationRegion = businessRegistrationRegion;
            this.BusinessRegistrationCountry = businessRegistrationCountry;
            this.BusinessContactRole = businessContactRole;
            this.BusinessAddressLine1 = businessAddressLine1;
            this.BusinessAddressLine2 = businessAddressLine2;
            this.BusinessAddressLine3 = businessAddressLine3;
            this.BusinessAddressLine4 = businessAddressLine4;
            this.BusinessAddressLine5 = businessAddressLine5;
            this.BusinessCity = businessCity;
            this.BusinessRegion = businessRegion;
            this.BusinessCountry = businessCountry;
            this.BusinessPostalCode = businessPostalCode;
            this.BusinessPremiseNumber = businessPremiseNumber;
            this.BusinessType = businessType;
        }

        /// <summary>
        /// Legal name for the business
        /// </summary>
        [JsonProperty("businessName", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessName { get; set; }

        /// <summary>
        /// Name under which the business operates
        /// </summary>
        [JsonProperty("businessOperatingName", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessOperatingName { get; set; }

        /// <summary>
        /// Registration number or ID assigned by a government body
        /// </summary>
        [JsonProperty("businessRegistrationId", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessRegistrationId { get; set; }

        /// <summary>
        /// State, province, or territory where the business is registered
        /// </summary>
        [JsonProperty("businessRegistrationRegion", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessRegistrationRegion { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("businessRegistrationCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? BusinessRegistrationCountry { get; set; }

        /// <summary>
        /// Role of the user within the business
        /// </summary>
        [JsonProperty("businessContactRole", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BusinessContactRoleEnum? BusinessContactRole { get; set; }

        /// <summary>
        /// First line of the business address that specifies street number, street name, and building name
        /// </summary>
        [JsonProperty("businessAddressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine1 { get; set; }

        /// <summary>
        /// Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address)
        /// </summary>
        [JsonProperty("businessAddressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine2 { get; set; }

        /// <summary>
        /// Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3
        /// </summary>
        [JsonProperty("businessAddressLine3", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine3 { get; set; }

        /// <summary>
        /// fourth line of the business address street address
        /// </summary>
        [JsonProperty("businessAddressLine4", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine4 { get; set; }

        /// <summary>
        /// Fifth line of the business address street address
        /// </summary>
        [JsonProperty("businessAddressLine5", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine5 { get; set; }

        /// <summary>
        /// City the business is registered
        /// </summary>
        [JsonProperty("businessCity", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessCity { get; set; }

        /// <summary>
        /// State, province, or region the business is registered
        /// </summary>
        [JsonProperty("businessRegion", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessRegion { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("businessCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? BusinessCountry { get; set; }

        /// <summary>
        /// Postal code for the business address
        /// </summary>
        [JsonProperty("businessPostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessPostalCode { get; set; }

        /// <summary>
        /// House number for the business address
        /// </summary>
        [JsonProperty("businessPremiseNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessPremiseNumber { get; set; }

        /// <summary>
        /// Type of business (<i>Corporation</i> or <i>Partnership</i>)
        /// </summary>
        [JsonProperty("businessType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BusinessTypesEnum? BusinessType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BusinessInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BusinessInformation other &&
                ((this.BusinessName == null && other.BusinessName == null) || (this.BusinessName?.Equals(other.BusinessName) == true)) &&
                ((this.BusinessOperatingName == null && other.BusinessOperatingName == null) || (this.BusinessOperatingName?.Equals(other.BusinessOperatingName) == true)) &&
                ((this.BusinessRegistrationId == null && other.BusinessRegistrationId == null) || (this.BusinessRegistrationId?.Equals(other.BusinessRegistrationId) == true)) &&
                ((this.BusinessRegistrationRegion == null && other.BusinessRegistrationRegion == null) || (this.BusinessRegistrationRegion?.Equals(other.BusinessRegistrationRegion) == true)) &&
                ((this.BusinessRegistrationCountry == null && other.BusinessRegistrationCountry == null) || (this.BusinessRegistrationCountry?.Equals(other.BusinessRegistrationCountry) == true)) &&
                ((this.BusinessContactRole == null && other.BusinessContactRole == null) || (this.BusinessContactRole?.Equals(other.BusinessContactRole) == true)) &&
                ((this.BusinessAddressLine1 == null && other.BusinessAddressLine1 == null) || (this.BusinessAddressLine1?.Equals(other.BusinessAddressLine1) == true)) &&
                ((this.BusinessAddressLine2 == null && other.BusinessAddressLine2 == null) || (this.BusinessAddressLine2?.Equals(other.BusinessAddressLine2) == true)) &&
                ((this.BusinessAddressLine3 == null && other.BusinessAddressLine3 == null) || (this.BusinessAddressLine3?.Equals(other.BusinessAddressLine3) == true)) &&
                ((this.BusinessAddressLine4 == null && other.BusinessAddressLine4 == null) || (this.BusinessAddressLine4?.Equals(other.BusinessAddressLine4) == true)) &&
                ((this.BusinessAddressLine5 == null && other.BusinessAddressLine5 == null) || (this.BusinessAddressLine5?.Equals(other.BusinessAddressLine5) == true)) &&
                ((this.BusinessCity == null && other.BusinessCity == null) || (this.BusinessCity?.Equals(other.BusinessCity) == true)) &&
                ((this.BusinessRegion == null && other.BusinessRegion == null) || (this.BusinessRegion?.Equals(other.BusinessRegion) == true)) &&
                ((this.BusinessCountry == null && other.BusinessCountry == null) || (this.BusinessCountry?.Equals(other.BusinessCountry) == true)) &&
                ((this.BusinessPostalCode == null && other.BusinessPostalCode == null) || (this.BusinessPostalCode?.Equals(other.BusinessPostalCode) == true)) &&
                ((this.BusinessPremiseNumber == null && other.BusinessPremiseNumber == null) || (this.BusinessPremiseNumber?.Equals(other.BusinessPremiseNumber) == true)) &&
                ((this.BusinessType == null && other.BusinessType == null) || (this.BusinessType?.Equals(other.BusinessType) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 213968408;

            if (this.BusinessName != null)
            {
               hashCode += this.BusinessName.GetHashCode();
            }

            if (this.BusinessOperatingName != null)
            {
               hashCode += this.BusinessOperatingName.GetHashCode();
            }

            if (this.BusinessRegistrationId != null)
            {
               hashCode += this.BusinessRegistrationId.GetHashCode();
            }

            if (this.BusinessRegistrationRegion != null)
            {
               hashCode += this.BusinessRegistrationRegion.GetHashCode();
            }

            if (this.BusinessRegistrationCountry != null)
            {
               hashCode += this.BusinessRegistrationCountry.GetHashCode();
            }

            if (this.BusinessContactRole != null)
            {
               hashCode += this.BusinessContactRole.GetHashCode();
            }

            if (this.BusinessAddressLine1 != null)
            {
               hashCode += this.BusinessAddressLine1.GetHashCode();
            }

            if (this.BusinessAddressLine2 != null)
            {
               hashCode += this.BusinessAddressLine2.GetHashCode();
            }

            if (this.BusinessAddressLine3 != null)
            {
               hashCode += this.BusinessAddressLine3.GetHashCode();
            }

            if (this.BusinessAddressLine4 != null)
            {
               hashCode += this.BusinessAddressLine4.GetHashCode();
            }

            if (this.BusinessAddressLine5 != null)
            {
               hashCode += this.BusinessAddressLine5.GetHashCode();
            }

            if (this.BusinessCity != null)
            {
               hashCode += this.BusinessCity.GetHashCode();
            }

            if (this.BusinessRegion != null)
            {
               hashCode += this.BusinessRegion.GetHashCode();
            }

            if (this.BusinessCountry != null)
            {
               hashCode += this.BusinessCountry.GetHashCode();
            }

            if (this.BusinessPostalCode != null)
            {
               hashCode += this.BusinessPostalCode.GetHashCode();
            }

            if (this.BusinessPremiseNumber != null)
            {
               hashCode += this.BusinessPremiseNumber.GetHashCode();
            }

            if (this.BusinessType != null)
            {
               hashCode += this.BusinessType.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BusinessName = {(this.BusinessName == null ? "null" : this.BusinessName == string.Empty ? "" : this.BusinessName)}");
            toStringOutput.Add($"this.BusinessOperatingName = {(this.BusinessOperatingName == null ? "null" : this.BusinessOperatingName == string.Empty ? "" : this.BusinessOperatingName)}");
            toStringOutput.Add($"this.BusinessRegistrationId = {(this.BusinessRegistrationId == null ? "null" : this.BusinessRegistrationId == string.Empty ? "" : this.BusinessRegistrationId)}");
            toStringOutput.Add($"this.BusinessRegistrationRegion = {(this.BusinessRegistrationRegion == null ? "null" : this.BusinessRegistrationRegion == string.Empty ? "" : this.BusinessRegistrationRegion)}");
            toStringOutput.Add($"this.BusinessRegistrationCountry = {(this.BusinessRegistrationCountry == null ? "null" : this.BusinessRegistrationCountry.ToString())}");
            toStringOutput.Add($"this.BusinessContactRole = {(this.BusinessContactRole == null ? "null" : this.BusinessContactRole.ToString())}");
            toStringOutput.Add($"this.BusinessAddressLine1 = {(this.BusinessAddressLine1 == null ? "null" : this.BusinessAddressLine1 == string.Empty ? "" : this.BusinessAddressLine1)}");
            toStringOutput.Add($"this.BusinessAddressLine2 = {(this.BusinessAddressLine2 == null ? "null" : this.BusinessAddressLine2 == string.Empty ? "" : this.BusinessAddressLine2)}");
            toStringOutput.Add($"this.BusinessAddressLine3 = {(this.BusinessAddressLine3 == null ? "null" : this.BusinessAddressLine3 == string.Empty ? "" : this.BusinessAddressLine3)}");
            toStringOutput.Add($"this.BusinessAddressLine4 = {(this.BusinessAddressLine4 == null ? "null" : this.BusinessAddressLine4 == string.Empty ? "" : this.BusinessAddressLine4)}");
            toStringOutput.Add($"this.BusinessAddressLine5 = {(this.BusinessAddressLine5 == null ? "null" : this.BusinessAddressLine5 == string.Empty ? "" : this.BusinessAddressLine5)}");
            toStringOutput.Add($"this.BusinessCity = {(this.BusinessCity == null ? "null" : this.BusinessCity == string.Empty ? "" : this.BusinessCity)}");
            toStringOutput.Add($"this.BusinessRegion = {(this.BusinessRegion == null ? "null" : this.BusinessRegion == string.Empty ? "" : this.BusinessRegion)}");
            toStringOutput.Add($"this.BusinessCountry = {(this.BusinessCountry == null ? "null" : this.BusinessCountry.ToString())}");
            toStringOutput.Add($"this.BusinessPostalCode = {(this.BusinessPostalCode == null ? "null" : this.BusinessPostalCode == string.Empty ? "" : this.BusinessPostalCode)}");
            toStringOutput.Add($"this.BusinessPremiseNumber = {(this.BusinessPremiseNumber == null ? "null" : this.BusinessPremiseNumber == string.Empty ? "" : this.BusinessPremiseNumber)}");
            toStringOutput.Add($"this.BusinessType = {(this.BusinessType == null ? "null" : this.BusinessType.ToString())}");
        }
    }
}