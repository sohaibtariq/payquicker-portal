// <copyright file="WebhookCollectionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// WebhookCollectionResponse.
    /// </summary>
    public class WebhookCollectionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WebhookCollectionResponse"/> class.
        /// </summary>
        public WebhookCollectionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WebhookCollectionResponse"/> class.
        /// </summary>
        /// <param name="links">links.</param>
        /// <param name="payload">payload.</param>
        public WebhookCollectionResponse(
            List<Models.HaetosParams> links = null,
            List<Models.WebhookSubscriptionResponse> payload = null)
        {
            this.Links = links;
            this.Payload = payload;
        }

        /// <summary>
        /// Gets or sets Links.
        /// </summary>
        [JsonProperty("links", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.HaetosParams> Links { get; set; }

        /// <summary>
        /// Gets or sets Payload.
        /// </summary>
        [JsonProperty("payload", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.WebhookSubscriptionResponse> Payload { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"WebhookCollectionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is WebhookCollectionResponse other &&
                ((this.Links == null && other.Links == null) || (this.Links?.Equals(other.Links) == true)) &&
                ((this.Payload == null && other.Payload == null) || (this.Payload?.Equals(other.Payload) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1651519387;

            if (this.Links != null)
            {
               hashCode += this.Links.GetHashCode();
            }

            if (this.Payload != null)
            {
               hashCode += this.Payload.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Links = {(this.Links == null ? "null" : $"[{string.Join(", ", this.Links)} ]")}");
            toStringOutput.Add($"this.Payload = {(this.Payload == null ? "null" : $"[{string.Join(", ", this.Payload)} ]")}");
        }
    }
}