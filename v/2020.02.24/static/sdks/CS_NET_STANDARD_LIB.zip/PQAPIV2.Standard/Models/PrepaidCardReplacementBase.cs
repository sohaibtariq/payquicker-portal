// <copyright file="PrepaidCardReplacementBase.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PrepaidCardReplacementBase.
    /// </summary>
    public class PrepaidCardReplacementBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardReplacementBase"/> class.
        /// </summary>
        public PrepaidCardReplacementBase()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardReplacementBase"/> class.
        /// </summary>
        /// <param name="programToken">programToken.</param>
        /// <param name="cardPackage">cardPackage.</param>
        /// <param name="cardReplacementReason">cardReplacementReason.</param>
        public PrepaidCardReplacementBase(
            string programToken,
            string cardPackage = null,
            Models.PrepaidCardReplacementReasonTypesEnum? cardReplacementReason = null)
        {
            this.CardPackage = cardPackage;
            this.ProgramToken = programToken;
            this.CardReplacementReason = cardReplacementReason;
        }

        /// <summary>
        /// Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>
        /// </summary>
        [JsonProperty("cardPackage", NullValueHandling = NullValueHandling.Ignore)]
        public string CardPackage { get; set; }

        /// <summary>
        /// Token representing a program
        /// </summary>
        [JsonProperty("programToken")]
        public string ProgramToken { get; set; }

        /// <summary>
        /// Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility.
        /// </summary>
        [JsonProperty("cardReplacementReason", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.PrepaidCardReplacementReasonTypesEnum? CardReplacementReason { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrepaidCardReplacementBase : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrepaidCardReplacementBase other &&
                ((this.CardPackage == null && other.CardPackage == null) || (this.CardPackage?.Equals(other.CardPackage) == true)) &&
                ((this.ProgramToken == null && other.ProgramToken == null) || (this.ProgramToken?.Equals(other.ProgramToken) == true)) &&
                ((this.CardReplacementReason == null && other.CardReplacementReason == null) || (this.CardReplacementReason?.Equals(other.CardReplacementReason) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 85882951;

            if (this.CardPackage != null)
            {
               hashCode += this.CardPackage.GetHashCode();
            }

            if (this.ProgramToken != null)
            {
               hashCode += this.ProgramToken.GetHashCode();
            }

            if (this.CardReplacementReason != null)
            {
               hashCode += this.CardReplacementReason.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CardPackage = {(this.CardPackage == null ? "null" : this.CardPackage == string.Empty ? "" : this.CardPackage)}");
            toStringOutput.Add($"this.ProgramToken = {(this.ProgramToken == null ? "null" : this.ProgramToken == string.Empty ? "" : this.ProgramToken)}");
            toStringOutput.Add($"this.CardReplacementReason = {(this.CardReplacementReason == null ? "null" : this.CardReplacementReason.ToString())}");
        }
    }
}