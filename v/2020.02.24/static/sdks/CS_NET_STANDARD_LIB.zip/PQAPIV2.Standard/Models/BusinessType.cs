// <copyright file="BusinessType.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BusinessType.
    /// </summary>
    public class BusinessType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessType"/> class.
        /// </summary>
        public BusinessType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessType"/> class.
        /// </summary>
        /// <param name="businessTypeProp">businessType.</param>
        public BusinessType(
            Models.BusinessTypesEnum? businessTypeProp = null)
        {
            this.BusinessTypeProp = businessTypeProp;
        }

        /// <summary>
        /// Type of business (<i>Corporation</i> or <i>Partnership</i>)
        /// </summary>
        [JsonProperty("businessType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BusinessTypesEnum? BusinessTypeProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BusinessType : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BusinessType other &&
                ((this.BusinessTypeProp == null && other.BusinessTypeProp == null) || (this.BusinessTypeProp?.Equals(other.BusinessTypeProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1874828242;

            if (this.BusinessTypeProp != null)
            {
               hashCode += this.BusinessTypeProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BusinessTypeProp = {(this.BusinessTypeProp == null ? "null" : this.BusinessTypeProp.ToString())}");
        }
    }
}