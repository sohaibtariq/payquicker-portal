// <copyright file="BankAccountRequirementFormatLegend.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountRequirementFormatLegend.
    /// </summary>
    public class BankAccountRequirementFormatLegend
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirementFormatLegend"/> class.
        /// </summary>
        public BankAccountRequirementFormatLegend()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirementFormatLegend"/> class.
        /// </summary>
        /// <param name="key">key.</param>
        /// <param name="descriptions">descriptions.</param>
        public BankAccountRequirementFormatLegend(
            string key = null,
            List<Models.KeyValuePairLanguageTypeString> descriptions = null)
        {
            this.Key = key;
            this.Descriptions = descriptions;
        }

        /// <summary>
        /// Gets or sets Key.
        /// </summary>
        [JsonProperty("key", NullValueHandling = NullValueHandling.Ignore)]
        public string Key { get; set; }

        /// <summary>
        /// Localized requirement description for display purposes
        /// </summary>
        [JsonProperty("descriptions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.KeyValuePairLanguageTypeString> Descriptions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccountRequirementFormatLegend : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccountRequirementFormatLegend other &&
                ((this.Key == null && other.Key == null) || (this.Key?.Equals(other.Key) == true)) &&
                ((this.Descriptions == null && other.Descriptions == null) || (this.Descriptions?.Equals(other.Descriptions) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -308008007;

            if (this.Key != null)
            {
               hashCode += this.Key.GetHashCode();
            }

            if (this.Descriptions != null)
            {
               hashCode += this.Descriptions.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Key = {(this.Key == null ? "null" : this.Key == string.Empty ? "" : this.Key)}");
            toStringOutput.Add($"this.Descriptions = {(this.Descriptions == null ? "null" : $"[{string.Join(", ", this.Descriptions)} ]")}");
        }
    }
}