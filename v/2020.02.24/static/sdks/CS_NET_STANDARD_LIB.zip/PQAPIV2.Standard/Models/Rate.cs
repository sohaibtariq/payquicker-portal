// <copyright file="Rate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// Rate.
    /// </summary>
    public class Rate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Rate"/> class.
        /// </summary>
        public Rate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Rate"/> class.
        /// </summary>
        /// <param name="rateProp">rate.</param>
        public Rate(
            double? rateProp = null)
        {
            this.RateProp = rateProp;
        }

        /// <summary>
        /// Exchange rate
        /// </summary>
        [JsonProperty("rate", NullValueHandling = NullValueHandling.Ignore)]
        public double? RateProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Rate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Rate other &&
                ((this.RateProp == null && other.RateProp == null) || (this.RateProp?.Equals(other.RateProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1523668497;

            if (this.RateProp != null)
            {
               hashCode += this.RateProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RateProp = {(this.RateProp == null ? "null" : this.RateProp.ToString())}");
        }
    }
}