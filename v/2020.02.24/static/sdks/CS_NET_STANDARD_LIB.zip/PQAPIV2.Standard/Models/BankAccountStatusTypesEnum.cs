// <copyright file="BankAccountStatusTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountStatusTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BankAccountStatusTypesEnum
    {
        /// <summary>
        /// DELETED.
        /// </summary>
        [EnumMember(Value = "DELETED")]
        DELETED,

        /// <summary>
        /// ACTIVE.
        /// </summary>
        [EnumMember(Value = "ACTIVE")]
        ACTIVE,

        /// <summary>
        /// PENDINGVERIFICATION.
        /// </summary>
        [EnumMember(Value = "PENDING_VERIFICATION")]
        PENDINGVERIFICATION,
    }
}