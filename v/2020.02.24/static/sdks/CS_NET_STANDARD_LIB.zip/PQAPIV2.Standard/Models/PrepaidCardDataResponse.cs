// <copyright file="PrepaidCardDataResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PrepaidCardDataResponse.
    /// </summary>
    public class PrepaidCardDataResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardDataResponse"/> class.
        /// </summary>
        public PrepaidCardDataResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardDataResponse"/> class.
        /// </summary>
        /// <param name="cardImage">cardImage.</param>
        /// <param name="cardNumber">cardNumber.</param>
        /// <param name="cvvNumber">cvvNumber.</param>
        /// <param name="expiration">expiration.</param>
        /// <param name="nameOnCard">nameOnCard.</param>
        /// <param name="side">side.</param>
        /// <param name="token">token.</param>
        public PrepaidCardDataResponse(
            string cardImage = null,
            double? cardNumber = null,
            string cvvNumber = null,
            string expiration = null,
            string nameOnCard = null,
            string side = null,
            string token = null)
        {
            this.CardImage = cardImage;
            this.CardNumber = cardNumber;
            this.CvvNumber = cvvNumber;
            this.Expiration = expiration;
            this.NameOnCard = nameOnCard;
            this.Side = side;
            this.Token = token;
        }

        /// <summary>
        /// Gets or sets CardImage.
        /// </summary>
        [JsonProperty("cardImage", NullValueHandling = NullValueHandling.Ignore)]
        public string CardImage { get; set; }

        /// <summary>
        /// Gets or sets CardNumber.
        /// </summary>
        [JsonProperty("cardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public double? CardNumber { get; set; }

        /// <summary>
        /// Gets or sets CvvNumber.
        /// </summary>
        [JsonProperty("cvvNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CvvNumber { get; set; }

        /// <summary>
        /// Gets or sets Expiration.
        /// </summary>
        [JsonProperty("expiration", NullValueHandling = NullValueHandling.Ignore)]
        public string Expiration { get; set; }

        /// <summary>
        /// Gets or sets NameOnCard.
        /// </summary>
        [JsonProperty("nameOnCard", NullValueHandling = NullValueHandling.Ignore)]
        public string NameOnCard { get; set; }

        /// <summary>
        /// Gets or sets Side.
        /// </summary>
        [JsonProperty("side", NullValueHandling = NullValueHandling.Ignore)]
        public string Side { get; set; }

        /// <summary>
        /// Gets or sets Token.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrepaidCardDataResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrepaidCardDataResponse other &&
                ((this.CardImage == null && other.CardImage == null) || (this.CardImage?.Equals(other.CardImage) == true)) &&
                ((this.CardNumber == null && other.CardNumber == null) || (this.CardNumber?.Equals(other.CardNumber) == true)) &&
                ((this.CvvNumber == null && other.CvvNumber == null) || (this.CvvNumber?.Equals(other.CvvNumber) == true)) &&
                ((this.Expiration == null && other.Expiration == null) || (this.Expiration?.Equals(other.Expiration) == true)) &&
                ((this.NameOnCard == null && other.NameOnCard == null) || (this.NameOnCard?.Equals(other.NameOnCard) == true)) &&
                ((this.Side == null && other.Side == null) || (this.Side?.Equals(other.Side) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -730262418;

            if (this.CardImage != null)
            {
               hashCode += this.CardImage.GetHashCode();
            }

            if (this.CardNumber != null)
            {
               hashCode += this.CardNumber.GetHashCode();
            }

            if (this.CvvNumber != null)
            {
               hashCode += this.CvvNumber.GetHashCode();
            }

            if (this.Expiration != null)
            {
               hashCode += this.Expiration.GetHashCode();
            }

            if (this.NameOnCard != null)
            {
               hashCode += this.NameOnCard.GetHashCode();
            }

            if (this.Side != null)
            {
               hashCode += this.Side.GetHashCode();
            }

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CardImage = {(this.CardImage == null ? "null" : this.CardImage == string.Empty ? "" : this.CardImage)}");
            toStringOutput.Add($"this.CardNumber = {(this.CardNumber == null ? "null" : this.CardNumber.ToString())}");
            toStringOutput.Add($"this.CvvNumber = {(this.CvvNumber == null ? "null" : this.CvvNumber == string.Empty ? "" : this.CvvNumber)}");
            toStringOutput.Add($"this.Expiration = {(this.Expiration == null ? "null" : this.Expiration == string.Empty ? "" : this.Expiration)}");
            toStringOutput.Add($"this.NameOnCard = {(this.NameOnCard == null ? "null" : this.NameOnCard == string.Empty ? "" : this.NameOnCard)}");
            toStringOutput.Add($"this.Side = {(this.Side == null ? "null" : this.Side == string.Empty ? "" : this.Side)}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
        }
    }
}