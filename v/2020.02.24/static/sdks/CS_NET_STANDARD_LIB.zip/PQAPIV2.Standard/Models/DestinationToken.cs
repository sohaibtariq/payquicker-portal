// <copyright file="DestinationToken.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// DestinationToken.
    /// </summary>
    public class DestinationToken
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DestinationToken"/> class.
        /// </summary>
        public DestinationToken()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DestinationToken"/> class.
        /// </summary>
        /// <param name="destinationTokenProp">destinationToken.</param>
        public DestinationToken(
            string destinationTokenProp = null)
        {
            this.DestinationTokenProp = destinationTokenProp;
        }

        /// <summary>
        /// Unique identifier representing the destination of funds.
        /// </summary>
        [JsonProperty("destinationToken", NullValueHandling = NullValueHandling.Ignore)]
        public string DestinationTokenProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DestinationToken : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DestinationToken other &&
                ((this.DestinationTokenProp == null && other.DestinationTokenProp == null) || (this.DestinationTokenProp?.Equals(other.DestinationTokenProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1100743124;

            if (this.DestinationTokenProp != null)
            {
               hashCode += this.DestinationTokenProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DestinationTokenProp = {(this.DestinationTokenProp == null ? "null" : this.DestinationTokenProp == string.Empty ? "" : this.DestinationTokenProp)}");
        }
    }
}