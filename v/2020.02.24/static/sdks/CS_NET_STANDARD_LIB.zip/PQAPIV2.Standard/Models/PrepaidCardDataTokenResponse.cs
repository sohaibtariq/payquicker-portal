// <copyright file="PrepaidCardDataTokenResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PrepaidCardDataTokenResponse.
    /// </summary>
    public class PrepaidCardDataTokenResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardDataTokenResponse"/> class.
        /// </summary>
        public PrepaidCardDataTokenResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardDataTokenResponse"/> class.
        /// </summary>
        /// <param name="token">token.</param>
        public PrepaidCardDataTokenResponse(
            Models.PrepaidCardDataToken token = null)
        {
            this.Token = token;
        }

        /// <summary>
        /// Token assigned to the prepaid card
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PrepaidCardDataToken Token { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrepaidCardDataTokenResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrepaidCardDataTokenResponse other &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 197426015;

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token.ToString())}");
        }
    }
}