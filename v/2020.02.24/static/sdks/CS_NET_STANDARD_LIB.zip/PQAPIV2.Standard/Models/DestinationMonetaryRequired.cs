// <copyright file="DestinationMonetaryRequired.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// DestinationMonetaryRequired.
    /// </summary>
    public class DestinationMonetaryRequired
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DestinationMonetaryRequired"/> class.
        /// </summary>
        public DestinationMonetaryRequired()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DestinationMonetaryRequired"/> class.
        /// </summary>
        /// <param name="destinationAmount">destinationAmount.</param>
        /// <param name="destinationCurrency">destinationCurrency.</param>
        public DestinationMonetaryRequired(
            double? destinationAmount = null,
            Models.CurrencyTypesEnum? destinationCurrency = null)
        {
            this.DestinationAmount = destinationAmount;
            this.DestinationCurrency = destinationCurrency;
        }

        /// <summary>
        /// Amount transferred to the destination
        /// </summary>
        [JsonProperty("destinationAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DestinationAmount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("destinationCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? DestinationCurrency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DestinationMonetaryRequired : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DestinationMonetaryRequired other &&
                ((this.DestinationAmount == null && other.DestinationAmount == null) || (this.DestinationAmount?.Equals(other.DestinationAmount) == true)) &&
                ((this.DestinationCurrency == null && other.DestinationCurrency == null) || (this.DestinationCurrency?.Equals(other.DestinationCurrency) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1945985316;

            if (this.DestinationAmount != null)
            {
               hashCode += this.DestinationAmount.GetHashCode();
            }

            if (this.DestinationCurrency != null)
            {
               hashCode += this.DestinationCurrency.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DestinationAmount = {(this.DestinationAmount == null ? "null" : this.DestinationAmount.ToString())}");
            toStringOutput.Add($"this.DestinationCurrency = {(this.DestinationCurrency == null ? "null" : this.DestinationCurrency.ToString())}");
        }
    }
}