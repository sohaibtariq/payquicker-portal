// <copyright file="UserBase.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// UserBase.
    /// </summary>
    public class UserBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserBase"/> class.
        /// </summary>
        public UserBase()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserBase"/> class.
        /// </summary>
        /// <param name="phoneNumber">phoneNumber.</param>
        /// <param name="mobileNumber">mobileNumber.</param>
        /// <param name="phoneNumberCountry">phoneNumberCountry.</param>
        /// <param name="mobileNumberCountry">mobileNumberCountry.</param>
        /// <param name="firstName">firstName.</param>
        /// <param name="lastName">lastName.</param>
        /// <param name="dateOfBirth">dateOfBirth.</param>
        /// <param name="businessName">businessName.</param>
        /// <param name="businessOperatingName">businessOperatingName.</param>
        /// <param name="businessRegistrationId">businessRegistrationId.</param>
        /// <param name="businessRegistrationRegion">businessRegistrationRegion.</param>
        /// <param name="businessRegistrationCountry">businessRegistrationCountry.</param>
        /// <param name="businessContactRole">businessContactRole.</param>
        /// <param name="businessAddressLine1">businessAddressLine1.</param>
        /// <param name="businessAddressLine2">businessAddressLine2.</param>
        /// <param name="businessAddressLine3">businessAddressLine3.</param>
        /// <param name="businessAddressLine4">businessAddressLine4.</param>
        /// <param name="businessAddressLine5">businessAddressLine5.</param>
        /// <param name="businessCity">businessCity.</param>
        /// <param name="businessRegion">businessRegion.</param>
        /// <param name="businessCountry">businessCountry.</param>
        /// <param name="businessPostalCode">businessPostalCode.</param>
        /// <param name="businessPremiseNumber">businessPremiseNumber.</param>
        /// <param name="businessType">businessType.</param>
        /// <param name="driverLicenseId">driverLicenseId.</param>
        /// <param name="passportId">passportId.</param>
        /// <param name="governmentIdType">governmentIdType.</param>
        /// <param name="governmentId">governmentId.</param>
        /// <param name="addressLine1">addressLine1.</param>
        /// <param name="addressLine2">addressLine2.</param>
        /// <param name="addressLine3">addressLine3.</param>
        /// <param name="addressLine4">addressLine4.</param>
        /// <param name="addressLine5">addressLine5.</param>
        /// <param name="city">city.</param>
        /// <param name="region">region.</param>
        /// <param name="country">country.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="premiseNumber">premiseNumber.</param>
        /// <param name="addressType">addressType.</param>
        /// <param name="email">email.</param>
        /// <param name="employerId">employerId.</param>
        /// <param name="gender">gender.</param>
        /// <param name="userType">userType.</param>
        /// <param name="programUserId">programUserId.</param>
        /// <param name="language">language.</param>
        /// <param name="countryOfBirth">countryOfBirth.</param>
        /// <param name="countryOfNationality">countryOfNationality.</param>
        /// <param name="occupation">occupation.</param>
        /// <param name="taxResidentStatus">taxResidentStatus.</param>
        /// <param name="currency">currency.</param>
        public UserBase(
            string phoneNumber,
            string mobileNumber,
            Models.CountryTypesEnum phoneNumberCountry,
            Models.CountryTypesEnum mobileNumberCountry,
            string firstName = null,
            string lastName = null,
            DateTime? dateOfBirth = null,
            string businessName = null,
            string businessOperatingName = null,
            string businessRegistrationId = null,
            string businessRegistrationRegion = null,
            Models.CountryTypesEnum? businessRegistrationCountry = null,
            Models.BusinessContactRoleEnum? businessContactRole = null,
            string businessAddressLine1 = null,
            string businessAddressLine2 = null,
            string businessAddressLine3 = null,
            string businessAddressLine4 = null,
            string businessAddressLine5 = null,
            string businessCity = null,
            string businessRegion = null,
            Models.CountryTypesEnum? businessCountry = null,
            string businessPostalCode = null,
            string businessPremiseNumber = null,
            Models.BusinessTypesEnum? businessType = null,
            string driverLicenseId = null,
            string passportId = null,
            Models.GovernmentIdTypeEnum? governmentIdType = null,
            string governmentId = null,
            string addressLine1 = null,
            string addressLine2 = null,
            string addressLine3 = null,
            string addressLine4 = null,
            string addressLine5 = null,
            string city = null,
            string region = null,
            Models.CountryTypesEnum? country = null,
            string postalCode = null,
            string premiseNumber = null,
            Models.AddressTypesEnum? addressType = null,
            string email = null,
            string employerId = null,
            Models.GenderTypesEnum? gender = null,
            Models.UserTypesEnum? userType = null,
            string programUserId = null,
            Models.LanguageTypesEnum? language = null,
            Models.CountryTypesEnum? countryOfBirth = null,
            Models.CountryTypesEnum? countryOfNationality = null,
            Models.OccupationTypesEnum? occupation = null,
            Models.TaxResidentStatusTypesEnum? taxResidentStatus = null,
            Models.CurrencyTypesEnum? currency = null)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.DateOfBirth = dateOfBirth;
            this.BusinessName = businessName;
            this.BusinessOperatingName = businessOperatingName;
            this.BusinessRegistrationId = businessRegistrationId;
            this.BusinessRegistrationRegion = businessRegistrationRegion;
            this.BusinessRegistrationCountry = businessRegistrationCountry;
            this.BusinessContactRole = businessContactRole;
            this.BusinessAddressLine1 = businessAddressLine1;
            this.BusinessAddressLine2 = businessAddressLine2;
            this.BusinessAddressLine3 = businessAddressLine3;
            this.BusinessAddressLine4 = businessAddressLine4;
            this.BusinessAddressLine5 = businessAddressLine5;
            this.BusinessCity = businessCity;
            this.BusinessRegion = businessRegion;
            this.BusinessCountry = businessCountry;
            this.BusinessPostalCode = businessPostalCode;
            this.BusinessPremiseNumber = businessPremiseNumber;
            this.BusinessType = businessType;
            this.DriverLicenseId = driverLicenseId;
            this.PassportId = passportId;
            this.GovernmentIdType = governmentIdType;
            this.GovernmentId = governmentId;
            this.PhoneNumber = phoneNumber;
            this.MobileNumber = mobileNumber;
            this.PhoneNumberCountry = phoneNumberCountry;
            this.MobileNumberCountry = mobileNumberCountry;
            this.AddressLine1 = addressLine1;
            this.AddressLine2 = addressLine2;
            this.AddressLine3 = addressLine3;
            this.AddressLine4 = addressLine4;
            this.AddressLine5 = addressLine5;
            this.City = city;
            this.Region = region;
            this.Country = country;
            this.PostalCode = postalCode;
            this.PremiseNumber = premiseNumber;
            this.AddressType = addressType;
            this.Email = email;
            this.EmployerId = employerId;
            this.Gender = gender;
            this.UserType = userType;
            this.ProgramUserId = programUserId;
            this.Language = language;
            this.CountryOfBirth = countryOfBirth;
            this.CountryOfNationality = countryOfNationality;
            this.Occupation = occupation;
            this.TaxResidentStatus = taxResidentStatus;
            this.Currency = currency;
        }

        /// <summary>
        /// User's first name. <i>Required</i> if the user is registered as an individual.
        /// </summary>
        [JsonProperty("firstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>
        /// User's last name. <i>Required</i> if the user is registered as an individual.
        /// </summary>
        [JsonProperty("lastName", NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; }

        /// <summary>
        /// User's date of birth
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dateOfBirth", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateOfBirth { get; set; }

        /// <summary>
        /// Legal name for the business
        /// </summary>
        [JsonProperty("businessName", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessName { get; set; }

        /// <summary>
        /// Name under which the business operates
        /// </summary>
        [JsonProperty("businessOperatingName", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessOperatingName { get; set; }

        /// <summary>
        /// Registration number or ID assigned by a government body
        /// </summary>
        [JsonProperty("businessRegistrationId", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessRegistrationId { get; set; }

        /// <summary>
        /// State, province, or territory where the business is registered
        /// </summary>
        [JsonProperty("businessRegistrationRegion", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessRegistrationRegion { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("businessRegistrationCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? BusinessRegistrationCountry { get; set; }

        /// <summary>
        /// Role of the user within the business
        /// </summary>
        [JsonProperty("businessContactRole", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BusinessContactRoleEnum? BusinessContactRole { get; set; }

        /// <summary>
        /// First line of the business address that specifies street number, street name, and building name
        /// </summary>
        [JsonProperty("businessAddressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine1 { get; set; }

        /// <summary>
        /// Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address)
        /// </summary>
        [JsonProperty("businessAddressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine2 { get; set; }

        /// <summary>
        /// Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3
        /// </summary>
        [JsonProperty("businessAddressLine3", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine3 { get; set; }

        /// <summary>
        /// fourth line of the business address street address
        /// </summary>
        [JsonProperty("businessAddressLine4", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine4 { get; set; }

        /// <summary>
        /// Fifth line of the business address street address
        /// </summary>
        [JsonProperty("businessAddressLine5", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddressLine5 { get; set; }

        /// <summary>
        /// City the business is registered
        /// </summary>
        [JsonProperty("businessCity", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessCity { get; set; }

        /// <summary>
        /// State, province, or region the business is registered
        /// </summary>
        [JsonProperty("businessRegion", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessRegion { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("businessCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? BusinessCountry { get; set; }

        /// <summary>
        /// Postal code for the business address
        /// </summary>
        [JsonProperty("businessPostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessPostalCode { get; set; }

        /// <summary>
        /// House number for the business address
        /// </summary>
        [JsonProperty("businessPremiseNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessPremiseNumber { get; set; }

        /// <summary>
        /// Type of business (<i>Corporation</i> or <i>Partnership</i>)
        /// </summary>
        [JsonProperty("businessType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BusinessTypesEnum? BusinessType { get; set; }

        /// <summary>
        /// User's driver's license number
        /// </summary>
        [JsonProperty("driverLicenseId", NullValueHandling = NullValueHandling.Ignore)]
        public string DriverLicenseId { get; set; }

        /// <summary>
        /// User's passport number
        /// </summary>
        [JsonProperty("passportId", NullValueHandling = NullValueHandling.Ignore)]
        public string PassportId { get; set; }

        /// <summary>
        /// User's government ID type
        /// </summary>
        [JsonProperty("governmentIdType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.GovernmentIdTypeEnum? GovernmentIdType { get; set; }

        /// <summary>
        /// User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i>
        /// </summary>
        [JsonProperty("governmentId", NullValueHandling = NullValueHandling.Ignore)]
        public string GovernmentId { get; set; }

        /// <summary>
        /// The E.164 formatted primary phone number. This can be the same as the mobile number.
        /// </summary>
        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared.
        /// </summary>
        [JsonProperty("mobileNumber")]
        public string MobileNumber { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("phoneNumberCountry", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CountryTypesEnum PhoneNumberCountry { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("mobileNumberCountry", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CountryTypesEnum MobileNumberCountry { get; set; }

        /// <summary>
        /// First line of the address that specifies street number, street name, and building name
        /// </summary>
        [JsonProperty("addressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address)
        /// </summary>
        [JsonProperty("addressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Third line of the address that specifies the international or business addresses that do not fit on addressLine2
        /// </summary>
        [JsonProperty("addressLine3", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Fourth line of the address, if any
        /// </summary>
        [JsonProperty("addressLine4", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Fifth line of the address, if any
        /// </summary>
        [JsonProperty("addressLine5", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine5 { get; set; }

        /// <summary>
        /// City or town of the business address
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// State, province, or territory of the business address
        /// </summary>
        [JsonProperty("region", NullValueHandling = NullValueHandling.Ignore)]
        public string Region { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("country", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? Country { get; set; }

        /// <summary>
        /// Series of letters, digits, or both, included in a postal address for the purpose of sorting mail
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// House or building number of the business address
        /// </summary>
        [JsonProperty("premiseNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PremiseNumber { get; set; }

        /// <summary>
        /// Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)
        /// </summary>
        [JsonProperty("addressType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressTypesEnum? AddressType { get; set; }

        /// <summary>
        /// Email address for the user account
        /// </summary>
        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// User's employer identifier
        /// </summary>
        [JsonProperty("employerId", NullValueHandling = NullValueHandling.Ignore)]
        public string EmployerId { get; set; }

        /// <summary>
        /// Gender as a user identifies
        /// </summary>
        [JsonProperty("gender", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.GenderTypesEnum? Gender { get; set; }

        /// <summary>
        /// Account holder's profile type
        /// </summary>
        [JsonProperty("userType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.UserTypesEnum? UserType { get; set; }

        /// <summary>
        /// Program identifier for the user
        /// </summary>
        [JsonProperty("programUserId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProgramUserId { get; set; }

        /// <summary>
        /// Language type in IETF's BCP 47 format
        /// </summary>
        [JsonProperty("language", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.LanguageTypesEnum? Language { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("countryOfBirth", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? CountryOfBirth { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("countryOfNationality", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? CountryOfNationality { get; set; }

        /// <summary>
        /// Type of occupation for the user
        /// </summary>
        [JsonProperty("occupation", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.OccupationTypesEnum? Occupation { get; set; }

        /// <summary>
        /// Tax resident status type of a country
        /// </summary>
        [JsonProperty("taxResidentStatus", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TaxResidentStatusTypesEnum? TaxResidentStatus { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("currency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? Currency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UserBase : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UserBase other &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.DateOfBirth == null && other.DateOfBirth == null) || (this.DateOfBirth?.Equals(other.DateOfBirth) == true)) &&
                ((this.BusinessName == null && other.BusinessName == null) || (this.BusinessName?.Equals(other.BusinessName) == true)) &&
                ((this.BusinessOperatingName == null && other.BusinessOperatingName == null) || (this.BusinessOperatingName?.Equals(other.BusinessOperatingName) == true)) &&
                ((this.BusinessRegistrationId == null && other.BusinessRegistrationId == null) || (this.BusinessRegistrationId?.Equals(other.BusinessRegistrationId) == true)) &&
                ((this.BusinessRegistrationRegion == null && other.BusinessRegistrationRegion == null) || (this.BusinessRegistrationRegion?.Equals(other.BusinessRegistrationRegion) == true)) &&
                ((this.BusinessRegistrationCountry == null && other.BusinessRegistrationCountry == null) || (this.BusinessRegistrationCountry?.Equals(other.BusinessRegistrationCountry) == true)) &&
                ((this.BusinessContactRole == null && other.BusinessContactRole == null) || (this.BusinessContactRole?.Equals(other.BusinessContactRole) == true)) &&
                ((this.BusinessAddressLine1 == null && other.BusinessAddressLine1 == null) || (this.BusinessAddressLine1?.Equals(other.BusinessAddressLine1) == true)) &&
                ((this.BusinessAddressLine2 == null && other.BusinessAddressLine2 == null) || (this.BusinessAddressLine2?.Equals(other.BusinessAddressLine2) == true)) &&
                ((this.BusinessAddressLine3 == null && other.BusinessAddressLine3 == null) || (this.BusinessAddressLine3?.Equals(other.BusinessAddressLine3) == true)) &&
                ((this.BusinessAddressLine4 == null && other.BusinessAddressLine4 == null) || (this.BusinessAddressLine4?.Equals(other.BusinessAddressLine4) == true)) &&
                ((this.BusinessAddressLine5 == null && other.BusinessAddressLine5 == null) || (this.BusinessAddressLine5?.Equals(other.BusinessAddressLine5) == true)) &&
                ((this.BusinessCity == null && other.BusinessCity == null) || (this.BusinessCity?.Equals(other.BusinessCity) == true)) &&
                ((this.BusinessRegion == null && other.BusinessRegion == null) || (this.BusinessRegion?.Equals(other.BusinessRegion) == true)) &&
                ((this.BusinessCountry == null && other.BusinessCountry == null) || (this.BusinessCountry?.Equals(other.BusinessCountry) == true)) &&
                ((this.BusinessPostalCode == null && other.BusinessPostalCode == null) || (this.BusinessPostalCode?.Equals(other.BusinessPostalCode) == true)) &&
                ((this.BusinessPremiseNumber == null && other.BusinessPremiseNumber == null) || (this.BusinessPremiseNumber?.Equals(other.BusinessPremiseNumber) == true)) &&
                ((this.BusinessType == null && other.BusinessType == null) || (this.BusinessType?.Equals(other.BusinessType) == true)) &&
                ((this.DriverLicenseId == null && other.DriverLicenseId == null) || (this.DriverLicenseId?.Equals(other.DriverLicenseId) == true)) &&
                ((this.PassportId == null && other.PassportId == null) || (this.PassportId?.Equals(other.PassportId) == true)) &&
                ((this.GovernmentIdType == null && other.GovernmentIdType == null) || (this.GovernmentIdType?.Equals(other.GovernmentIdType) == true)) &&
                ((this.GovernmentId == null && other.GovernmentId == null) || (this.GovernmentId?.Equals(other.GovernmentId) == true)) &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true)) &&
                ((this.MobileNumber == null && other.MobileNumber == null) || (this.MobileNumber?.Equals(other.MobileNumber) == true)) &&
                this.PhoneNumberCountry.Equals(other.PhoneNumberCountry) &&
                this.MobileNumberCountry.Equals(other.MobileNumberCountry) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.AddressLine3 == null && other.AddressLine3 == null) || (this.AddressLine3?.Equals(other.AddressLine3) == true)) &&
                ((this.AddressLine4 == null && other.AddressLine4 == null) || (this.AddressLine4?.Equals(other.AddressLine4) == true)) &&
                ((this.AddressLine5 == null && other.AddressLine5 == null) || (this.AddressLine5?.Equals(other.AddressLine5) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.Region == null && other.Region == null) || (this.Region?.Equals(other.Region) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.PremiseNumber == null && other.PremiseNumber == null) || (this.PremiseNumber?.Equals(other.PremiseNumber) == true)) &&
                ((this.AddressType == null && other.AddressType == null) || (this.AddressType?.Equals(other.AddressType) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.EmployerId == null && other.EmployerId == null) || (this.EmployerId?.Equals(other.EmployerId) == true)) &&
                ((this.Gender == null && other.Gender == null) || (this.Gender?.Equals(other.Gender) == true)) &&
                ((this.UserType == null && other.UserType == null) || (this.UserType?.Equals(other.UserType) == true)) &&
                ((this.ProgramUserId == null && other.ProgramUserId == null) || (this.ProgramUserId?.Equals(other.ProgramUserId) == true)) &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.CountryOfBirth == null && other.CountryOfBirth == null) || (this.CountryOfBirth?.Equals(other.CountryOfBirth) == true)) &&
                ((this.CountryOfNationality == null && other.CountryOfNationality == null) || (this.CountryOfNationality?.Equals(other.CountryOfNationality) == true)) &&
                ((this.Occupation == null && other.Occupation == null) || (this.Occupation?.Equals(other.Occupation) == true)) &&
                ((this.TaxResidentStatus == null && other.TaxResidentStatus == null) || (this.TaxResidentStatus?.Equals(other.TaxResidentStatus) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 220261488;

            if (this.FirstName != null)
            {
               hashCode += this.FirstName.GetHashCode();
            }

            if (this.LastName != null)
            {
               hashCode += this.LastName.GetHashCode();
            }

            if (this.DateOfBirth != null)
            {
               hashCode += this.DateOfBirth.GetHashCode();
            }

            if (this.BusinessName != null)
            {
               hashCode += this.BusinessName.GetHashCode();
            }

            if (this.BusinessOperatingName != null)
            {
               hashCode += this.BusinessOperatingName.GetHashCode();
            }

            if (this.BusinessRegistrationId != null)
            {
               hashCode += this.BusinessRegistrationId.GetHashCode();
            }

            if (this.BusinessRegistrationRegion != null)
            {
               hashCode += this.BusinessRegistrationRegion.GetHashCode();
            }

            if (this.BusinessRegistrationCountry != null)
            {
               hashCode += this.BusinessRegistrationCountry.GetHashCode();
            }

            if (this.BusinessContactRole != null)
            {
               hashCode += this.BusinessContactRole.GetHashCode();
            }

            if (this.BusinessAddressLine1 != null)
            {
               hashCode += this.BusinessAddressLine1.GetHashCode();
            }

            if (this.BusinessAddressLine2 != null)
            {
               hashCode += this.BusinessAddressLine2.GetHashCode();
            }

            if (this.BusinessAddressLine3 != null)
            {
               hashCode += this.BusinessAddressLine3.GetHashCode();
            }

            if (this.BusinessAddressLine4 != null)
            {
               hashCode += this.BusinessAddressLine4.GetHashCode();
            }

            if (this.BusinessAddressLine5 != null)
            {
               hashCode += this.BusinessAddressLine5.GetHashCode();
            }

            if (this.BusinessCity != null)
            {
               hashCode += this.BusinessCity.GetHashCode();
            }

            if (this.BusinessRegion != null)
            {
               hashCode += this.BusinessRegion.GetHashCode();
            }

            if (this.BusinessCountry != null)
            {
               hashCode += this.BusinessCountry.GetHashCode();
            }

            if (this.BusinessPostalCode != null)
            {
               hashCode += this.BusinessPostalCode.GetHashCode();
            }

            if (this.BusinessPremiseNumber != null)
            {
               hashCode += this.BusinessPremiseNumber.GetHashCode();
            }

            if (this.BusinessType != null)
            {
               hashCode += this.BusinessType.GetHashCode();
            }

            if (this.DriverLicenseId != null)
            {
               hashCode += this.DriverLicenseId.GetHashCode();
            }

            if (this.PassportId != null)
            {
               hashCode += this.PassportId.GetHashCode();
            }

            if (this.GovernmentIdType != null)
            {
               hashCode += this.GovernmentIdType.GetHashCode();
            }

            if (this.GovernmentId != null)
            {
               hashCode += this.GovernmentId.GetHashCode();
            }

            if (this.PhoneNumber != null)
            {
               hashCode += this.PhoneNumber.GetHashCode();
            }

            if (this.MobileNumber != null)
            {
               hashCode += this.MobileNumber.GetHashCode();
            }

            hashCode += this.PhoneNumberCountry.GetHashCode();
            hashCode += this.MobileNumberCountry.GetHashCode();

            if (this.AddressLine1 != null)
            {
               hashCode += this.AddressLine1.GetHashCode();
            }

            if (this.AddressLine2 != null)
            {
               hashCode += this.AddressLine2.GetHashCode();
            }

            if (this.AddressLine3 != null)
            {
               hashCode += this.AddressLine3.GetHashCode();
            }

            if (this.AddressLine4 != null)
            {
               hashCode += this.AddressLine4.GetHashCode();
            }

            if (this.AddressLine5 != null)
            {
               hashCode += this.AddressLine5.GetHashCode();
            }

            if (this.City != null)
            {
               hashCode += this.City.GetHashCode();
            }

            if (this.Region != null)
            {
               hashCode += this.Region.GetHashCode();
            }

            if (this.Country != null)
            {
               hashCode += this.Country.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.PremiseNumber != null)
            {
               hashCode += this.PremiseNumber.GetHashCode();
            }

            if (this.AddressType != null)
            {
               hashCode += this.AddressType.GetHashCode();
            }

            if (this.Email != null)
            {
               hashCode += this.Email.GetHashCode();
            }

            if (this.EmployerId != null)
            {
               hashCode += this.EmployerId.GetHashCode();
            }

            if (this.Gender != null)
            {
               hashCode += this.Gender.GetHashCode();
            }

            if (this.UserType != null)
            {
               hashCode += this.UserType.GetHashCode();
            }

            if (this.ProgramUserId != null)
            {
               hashCode += this.ProgramUserId.GetHashCode();
            }

            if (this.Language != null)
            {
               hashCode += this.Language.GetHashCode();
            }

            if (this.CountryOfBirth != null)
            {
               hashCode += this.CountryOfBirth.GetHashCode();
            }

            if (this.CountryOfNationality != null)
            {
               hashCode += this.CountryOfNationality.GetHashCode();
            }

            if (this.Occupation != null)
            {
               hashCode += this.Occupation.GetHashCode();
            }

            if (this.TaxResidentStatus != null)
            {
               hashCode += this.TaxResidentStatus.GetHashCode();
            }

            if (this.Currency != null)
            {
               hashCode += this.Currency.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName == string.Empty ? "" : this.LastName)}");
            toStringOutput.Add($"this.DateOfBirth = {(this.DateOfBirth == null ? "null" : this.DateOfBirth.ToString())}");
            toStringOutput.Add($"this.BusinessName = {(this.BusinessName == null ? "null" : this.BusinessName == string.Empty ? "" : this.BusinessName)}");
            toStringOutput.Add($"this.BusinessOperatingName = {(this.BusinessOperatingName == null ? "null" : this.BusinessOperatingName == string.Empty ? "" : this.BusinessOperatingName)}");
            toStringOutput.Add($"this.BusinessRegistrationId = {(this.BusinessRegistrationId == null ? "null" : this.BusinessRegistrationId == string.Empty ? "" : this.BusinessRegistrationId)}");
            toStringOutput.Add($"this.BusinessRegistrationRegion = {(this.BusinessRegistrationRegion == null ? "null" : this.BusinessRegistrationRegion == string.Empty ? "" : this.BusinessRegistrationRegion)}");
            toStringOutput.Add($"this.BusinessRegistrationCountry = {(this.BusinessRegistrationCountry == null ? "null" : this.BusinessRegistrationCountry.ToString())}");
            toStringOutput.Add($"this.BusinessContactRole = {(this.BusinessContactRole == null ? "null" : this.BusinessContactRole.ToString())}");
            toStringOutput.Add($"this.BusinessAddressLine1 = {(this.BusinessAddressLine1 == null ? "null" : this.BusinessAddressLine1 == string.Empty ? "" : this.BusinessAddressLine1)}");
            toStringOutput.Add($"this.BusinessAddressLine2 = {(this.BusinessAddressLine2 == null ? "null" : this.BusinessAddressLine2 == string.Empty ? "" : this.BusinessAddressLine2)}");
            toStringOutput.Add($"this.BusinessAddressLine3 = {(this.BusinessAddressLine3 == null ? "null" : this.BusinessAddressLine3 == string.Empty ? "" : this.BusinessAddressLine3)}");
            toStringOutput.Add($"this.BusinessAddressLine4 = {(this.BusinessAddressLine4 == null ? "null" : this.BusinessAddressLine4 == string.Empty ? "" : this.BusinessAddressLine4)}");
            toStringOutput.Add($"this.BusinessAddressLine5 = {(this.BusinessAddressLine5 == null ? "null" : this.BusinessAddressLine5 == string.Empty ? "" : this.BusinessAddressLine5)}");
            toStringOutput.Add($"this.BusinessCity = {(this.BusinessCity == null ? "null" : this.BusinessCity == string.Empty ? "" : this.BusinessCity)}");
            toStringOutput.Add($"this.BusinessRegion = {(this.BusinessRegion == null ? "null" : this.BusinessRegion == string.Empty ? "" : this.BusinessRegion)}");
            toStringOutput.Add($"this.BusinessCountry = {(this.BusinessCountry == null ? "null" : this.BusinessCountry.ToString())}");
            toStringOutput.Add($"this.BusinessPostalCode = {(this.BusinessPostalCode == null ? "null" : this.BusinessPostalCode == string.Empty ? "" : this.BusinessPostalCode)}");
            toStringOutput.Add($"this.BusinessPremiseNumber = {(this.BusinessPremiseNumber == null ? "null" : this.BusinessPremiseNumber == string.Empty ? "" : this.BusinessPremiseNumber)}");
            toStringOutput.Add($"this.BusinessType = {(this.BusinessType == null ? "null" : this.BusinessType.ToString())}");
            toStringOutput.Add($"this.DriverLicenseId = {(this.DriverLicenseId == null ? "null" : this.DriverLicenseId == string.Empty ? "" : this.DriverLicenseId)}");
            toStringOutput.Add($"this.PassportId = {(this.PassportId == null ? "null" : this.PassportId == string.Empty ? "" : this.PassportId)}");
            toStringOutput.Add($"this.GovernmentIdType = {(this.GovernmentIdType == null ? "null" : this.GovernmentIdType.ToString())}");
            toStringOutput.Add($"this.GovernmentId = {(this.GovernmentId == null ? "null" : this.GovernmentId == string.Empty ? "" : this.GovernmentId)}");
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber == string.Empty ? "" : this.PhoneNumber)}");
            toStringOutput.Add($"this.MobileNumber = {(this.MobileNumber == null ? "null" : this.MobileNumber == string.Empty ? "" : this.MobileNumber)}");
            toStringOutput.Add($"this.PhoneNumberCountry = {this.PhoneNumberCountry}");
            toStringOutput.Add($"this.MobileNumberCountry = {this.MobileNumberCountry}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1 == string.Empty ? "" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2 == string.Empty ? "" : this.AddressLine2)}");
            toStringOutput.Add($"this.AddressLine3 = {(this.AddressLine3 == null ? "null" : this.AddressLine3 == string.Empty ? "" : this.AddressLine3)}");
            toStringOutput.Add($"this.AddressLine4 = {(this.AddressLine4 == null ? "null" : this.AddressLine4 == string.Empty ? "" : this.AddressLine4)}");
            toStringOutput.Add($"this.AddressLine5 = {(this.AddressLine5 == null ? "null" : this.AddressLine5 == string.Empty ? "" : this.AddressLine5)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.Region = {(this.Region == null ? "null" : this.Region == string.Empty ? "" : this.Region)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country.ToString())}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.PremiseNumber = {(this.PremiseNumber == null ? "null" : this.PremiseNumber == string.Empty ? "" : this.PremiseNumber)}");
            toStringOutput.Add($"this.AddressType = {(this.AddressType == null ? "null" : this.AddressType.ToString())}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.EmployerId = {(this.EmployerId == null ? "null" : this.EmployerId == string.Empty ? "" : this.EmployerId)}");
            toStringOutput.Add($"this.Gender = {(this.Gender == null ? "null" : this.Gender.ToString())}");
            toStringOutput.Add($"this.UserType = {(this.UserType == null ? "null" : this.UserType.ToString())}");
            toStringOutput.Add($"this.ProgramUserId = {(this.ProgramUserId == null ? "null" : this.ProgramUserId == string.Empty ? "" : this.ProgramUserId)}");
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language.ToString())}");
            toStringOutput.Add($"this.CountryOfBirth = {(this.CountryOfBirth == null ? "null" : this.CountryOfBirth.ToString())}");
            toStringOutput.Add($"this.CountryOfNationality = {(this.CountryOfNationality == null ? "null" : this.CountryOfNationality.ToString())}");
            toStringOutput.Add($"this.Occupation = {(this.Occupation == null ? "null" : this.Occupation.ToString())}");
            toStringOutput.Add($"this.TaxResidentStatus = {(this.TaxResidentStatus == null ? "null" : this.TaxResidentStatus.ToString())}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency.ToString())}");
        }
    }
}