// <copyright file="ShippingMethodTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// ShippingMethodTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ShippingMethodTypesEnum
    {
        /// <summary>
        /// STANDARD.
        /// </summary>
        [EnumMember(Value = "STANDARD")]
        STANDARD,

        /// <summary>
        /// EXPEDITED.
        /// </summary>
        [EnumMember(Value = "EXPEDITED")]
        EXPEDITED,
    }
}