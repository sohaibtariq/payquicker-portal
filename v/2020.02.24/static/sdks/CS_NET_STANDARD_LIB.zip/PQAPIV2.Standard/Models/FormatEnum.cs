// <copyright file="FormatEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// FormatEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FormatEnum
    {
        /// <summary>
        /// TEXT.
        /// </summary>
        [EnumMember(Value = "TEXT")]
        TEXT,

        /// <summary>
        /// IMAGE.
        /// </summary>
        [EnumMember(Value = "IMAGE")]
        IMAGE,

        /// <summary>
        /// EnumTEXTIMAGE.
        /// </summary>
        [EnumMember(Value = "TEXT;IMAGE")]
        EnumTEXTIMAGE,
    }
}