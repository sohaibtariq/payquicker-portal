// <copyright file="Expiration.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// Expiration.
    /// </summary>
    public class Expiration
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Expiration"/> class.
        /// </summary>
        public Expiration()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Expiration"/> class.
        /// </summary>
        /// <param name="expires">expires.</param>
        public Expiration(
            DateTime? expires = null)
        {
            this.Expires = expires;
        }

        /// <summary>
        /// Quote expiration, ISO-8601 format, UTC by default unless overridden.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("expires", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? Expires { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Expiration : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Expiration other &&
                ((this.Expires == null && other.Expires == null) || (this.Expires?.Equals(other.Expires) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1587515160;

            if (this.Expires != null)
            {
               hashCode += this.Expires.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Expires = {(this.Expires == null ? "null" : this.Expires.ToString())}");
        }
    }
}