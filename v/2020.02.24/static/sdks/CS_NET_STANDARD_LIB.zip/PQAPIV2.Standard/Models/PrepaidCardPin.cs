// <copyright file="PrepaidCardPin.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PrepaidCardPin.
    /// </summary>
    public class PrepaidCardPin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardPin"/> class.
        /// </summary>
        public PrepaidCardPin()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrepaidCardPin"/> class.
        /// </summary>
        /// <param name="cardPin">cardPin.</param>
        public PrepaidCardPin(
            string cardPin = null)
        {
            this.CardPin = cardPin;
        }

        /// <summary>
        /// Card PIN for ATM and Debit usage
        /// </summary>
        [JsonProperty("cardPin", NullValueHandling = NullValueHandling.Ignore)]
        public string CardPin { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrepaidCardPin : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrepaidCardPin other &&
                ((this.CardPin == null && other.CardPin == null) || (this.CardPin?.Equals(other.CardPin) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1646462833;

            if (this.CardPin != null)
            {
               hashCode += this.CardPin.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CardPin = {(this.CardPin == null ? "null" : this.CardPin == string.Empty ? "" : this.CardPin)}");
        }
    }
}