// <copyright file="BankAccountRequirement.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountRequirement.
    /// </summary>
    public class BankAccountRequirement
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirement"/> class.
        /// </summary>
        public BankAccountRequirement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirement"/> class.
        /// </summary>
        /// <param name="bankCountry">bankCountry.</param>
        /// <param name="bankCurrency">bankCurrency.</param>
        /// <param name="sourceCountry">sourceCountry.</param>
        /// <param name="sourceCurrency">sourceCurrency.</param>
        /// <param name="requirements">requirements.</param>
        /// <param name="quote">quote.</param>
        public BankAccountRequirement(
            Models.CountryTypesEnum bankCountry,
            Models.CurrencyTypesEnum bankCurrency,
            Models.CountryTypesEnum? sourceCountry = null,
            Models.CurrencyTypesEnum? sourceCurrency = null,
            List<Models.BankAccountRequiredFields> requirements = null,
            Models.MonetaryFormatted quote = null)
        {
            this.BankCountry = bankCountry;
            this.BankCurrency = bankCurrency;
            this.SourceCountry = sourceCountry;
            this.SourceCurrency = sourceCurrency;
            this.Requirements = requirements;
            this.Quote = quote;
        }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("bankCountry", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CountryTypesEnum BankCountry { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("bankCurrency", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CurrencyTypesEnum BankCurrency { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("sourceCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? SourceCountry { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("sourceCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? SourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Requirements.
        /// </summary>
        [JsonProperty("requirements", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.BankAccountRequiredFields> Requirements { get; set; }

        /// <summary>
        /// Object representing monies, including currency, decimal, and formatted amounts
        /// </summary>
        [JsonProperty("quote", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MonetaryFormatted Quote { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccountRequirement : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccountRequirement other &&
                this.BankCountry.Equals(other.BankCountry) &&
                this.BankCurrency.Equals(other.BankCurrency) &&
                ((this.SourceCountry == null && other.SourceCountry == null) || (this.SourceCountry?.Equals(other.SourceCountry) == true)) &&
                ((this.SourceCurrency == null && other.SourceCurrency == null) || (this.SourceCurrency?.Equals(other.SourceCurrency) == true)) &&
                ((this.Requirements == null && other.Requirements == null) || (this.Requirements?.Equals(other.Requirements) == true)) &&
                ((this.Quote == null && other.Quote == null) || (this.Quote?.Equals(other.Quote) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 610461655;
            hashCode += this.BankCountry.GetHashCode();
            hashCode += this.BankCurrency.GetHashCode();

            if (this.SourceCountry != null)
            {
               hashCode += this.SourceCountry.GetHashCode();
            }

            if (this.SourceCurrency != null)
            {
               hashCode += this.SourceCurrency.GetHashCode();
            }

            if (this.Requirements != null)
            {
               hashCode += this.Requirements.GetHashCode();
            }

            if (this.Quote != null)
            {
               hashCode += this.Quote.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BankCountry = {this.BankCountry}");
            toStringOutput.Add($"this.BankCurrency = {this.BankCurrency}");
            toStringOutput.Add($"this.SourceCountry = {(this.SourceCountry == null ? "null" : this.SourceCountry.ToString())}");
            toStringOutput.Add($"this.SourceCurrency = {(this.SourceCurrency == null ? "null" : this.SourceCurrency.ToString())}");
            toStringOutput.Add($"this.Requirements = {(this.Requirements == null ? "null" : $"[{string.Join(", ", this.Requirements)} ]")}");
            toStringOutput.Add($"this.Quote = {(this.Quote == null ? "null" : this.Quote.ToString())}");
        }
    }
}