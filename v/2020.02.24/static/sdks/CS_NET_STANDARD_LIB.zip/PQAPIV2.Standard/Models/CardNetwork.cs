// <copyright file="CardNetwork.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// CardNetwork.
    /// </summary>
    public class CardNetwork
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CardNetwork"/> class.
        /// </summary>
        public CardNetwork()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardNetwork"/> class.
        /// </summary>
        /// <param name="cardNetworkProp">cardNetwork.</param>
        public CardNetwork(
            Models.CardNetworkTypesEnum? cardNetworkProp = null)
        {
            this.CardNetworkProp = cardNetworkProp;
        }

        /// <summary>
        /// Major credit card network types
        /// </summary>
        [JsonProperty("cardNetwork", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CardNetworkTypesEnum? CardNetworkProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CardNetwork : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CardNetwork other &&
                ((this.CardNetworkProp == null && other.CardNetworkProp == null) || (this.CardNetworkProp?.Equals(other.CardNetworkProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -50584984;

            if (this.CardNetworkProp != null)
            {
               hashCode += this.CardNetworkProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CardNetworkProp = {(this.CardNetworkProp == null ? "null" : this.CardNetworkProp.ToString())}");
        }
    }
}