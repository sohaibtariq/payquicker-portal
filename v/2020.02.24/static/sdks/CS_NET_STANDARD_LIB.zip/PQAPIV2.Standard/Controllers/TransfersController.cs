// <copyright file="TransfersController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Request;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// TransfersController.
    /// </summary>
    public class TransfersController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransfersController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal TransfersController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Retrieve details of a specific transfer represented by a transfer token..
        /// </summary>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.TransferResponse response from the API call.</returns>
        public Models.TransferResponse RetrieveTransfer(
                string xferToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.TransferResponse> t = this.RetrieveTransferAsync(xferToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve details of a specific transfer represented by a transfer token..
        /// </summary>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransferResponse response from the API call.</returns>
        public async Task<Models.TransferResponse> RetrieveTransferAsync(
                string xferToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/transfers/{xfer-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "xfer-token", xferToken },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransferResponse>(response.Body);
        }

        /// <summary>
        /// Accept a transfer quote.
        /// </summary>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        public void AcceptTransferQuote(
                string xferToken,
                string xMyPayQuickerVersion)
        {
            Task t = this.AcceptTransferQuoteAsync(xferToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Accept a transfer quote.
        /// </summary>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AcceptTransferQuoteAsync(
                string xferToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/transfers/{xfer-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "xfer-token", xferToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Post(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote..
        /// </summary>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        public void CancelTransferQuote(
                string xferToken,
                string xMyPayQuickerVersion)
        {
            Task t = this.CancelTransferQuoteAsync(xferToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote..
        /// </summary>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CancelTransferQuoteAsync(
                string xferToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/transfers/{xfer-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "xfer-token", xferToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.TransferCollectionResponse response from the API call.</returns>
        public Models.TransferCollectionResponse ListTransfers(
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.TransferCollectionResponse> t = this.ListTransfersAsync(xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransferCollectionResponse response from the API call.</returns>
        public async Task<Models.TransferCollectionResponse> ListTransfersAsync(
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/transfers");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransferCollectionResponse>(response.Body);
        }

        /// <summary>
        /// Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>.
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransferResponse response from the API call.</returns>
        public Models.TransferResponse QuoteTransfer(
                string xMyPayQuickerVersion,
                Models.TransferRequest body)
        {
            Task<Models.TransferResponse> t = this.QuoteTransferAsync(xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>.
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransferResponse response from the API call.</returns>
        public async Task<Models.TransferResponse> QuoteTransferAsync(
                string xMyPayQuickerVersion,
                Models.TransferRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/transfers");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransferResponse>(response.Body);
        }
    }
}