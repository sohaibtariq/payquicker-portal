// <copyright file="UsersController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Request;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// UsersController.
    /// </summary>
    public class UsersController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UsersController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal UsersController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Update a user object (change email, address change, etc.) using a user token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.UserResponse response from the API call.</returns>
        public Models.UserResponse UpdateUser(
                string userToken,
                string xMyPayQuickerVersion,
                Models.UserBase body = null)
        {
            Task<Models.UserResponse> t = this.UpdateUserAsync(userToken, xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update a user object (change email, address change, etc.) using a user token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UserResponse response from the API call.</returns>
        public async Task<Models.UserResponse> UpdateUserAsync(
                string userToken,
                string xMyPayQuickerVersion,
                Models.UserBase body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.UserResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a single user record by user token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <returns>Returns the Models.UserResponse response from the API call.</returns>
        public Models.UserResponse RetrieveUser(
                string userToken,
                string xMyPayQuickerVersion)
        {
            Task<Models.UserResponse> t = this.RetrieveUserAsync(userToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a single user record by user token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UserResponse response from the API call.</returns>
        public async Task<Models.UserResponse> RetrieveUserAsync(
                string userToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.UserResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.UserCollectionResponse response from the API call.</returns>
        public Models.UserCollectionResponse ListUsers(
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.UserCollectionResponse> t = this.ListUsersAsync(xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UserCollectionResponse response from the API call.</returns>
        public async Task<Models.UserCollectionResponse> ListUsersAsync(
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.UserCollectionResponse>(response.Body);
        }

        /// <summary>
        /// Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Required parameter: Body details of the request.</param>
        /// <returns>Returns the Models.UserResponse response from the API call.</returns>
        public Models.UserResponse CreateUser(
                string xMyPayQuickerVersion,
                Models.UserBase body)
        {
            Task<Models.UserResponse> t = this.CreateUserAsync(xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Required parameter: Body details of the request.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UserResponse response from the API call.</returns>
        public async Task<Models.UserResponse> CreateUserAsync(
                string xMyPayQuickerVersion,
                Models.UserBase body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.UserResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <returns>Returns the Models.IdentityVerificationCollectionResponse response from the API call.</returns>
        public Models.IdentityVerificationCollectionResponse ListUserIDVChecks(
                string userToken,
                string xMyPayQuickerVersion)
        {
            Task<Models.IdentityVerificationCollectionResponse> t = this.ListUserIDVChecksAsync(userToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.IdentityVerificationCollectionResponse response from the API call.</returns>
        public async Task<Models.IdentityVerificationCollectionResponse> ListUserIDVChecksAsync(
                string userToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/idv-checks");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.IdentityVerificationCollectionResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="idvcToken">Required parameter: Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <returns>Returns the Models.IdentityVerificationResponse response from the API call.</returns>
        public Models.IdentityVerificationResponse RetrieveUserIDVCheck(
                string userToken,
                string idvcToken,
                string xMyPayQuickerVersion)
        {
            Task<Models.IdentityVerificationResponse> t = this.RetrieveUserIDVCheckAsync(userToken, idvcToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="idvcToken">Required parameter: Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.IdentityVerificationResponse response from the API call.</returns>
        public async Task<Models.IdentityVerificationResponse> RetrieveUserIDVCheckAsync(
                string userToken,
                string idvcToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/idv-checks/{idvc-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "idvc-token", idvcToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.IdentityVerificationResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        public void ListUserEvents(
                string userToken)
        {
            Task t = this.ListUserEventsAsync(userToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ListUserEventsAsync(
                string userToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/events");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve a single user event.
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="evntToken">Required parameter: Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>..</param>
        public void RetrieveUserEvent(
                string userToken,
                string evntToken)
        {
            Task t = this.RetrieveUserEventAsync(userToken, evntToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a single user event.
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="evntToken">Required parameter: Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task RetrieveUserEventAsync(
                string userToken,
                string evntToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/events/{evnt-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "evnt-token", evntToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Accept a single program agreement.
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="agmtToken">Required parameter: Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>..</param>
        public void AcceptProgramAgreement(
                string userToken,
                string agmtToken)
        {
            Task t = this.AcceptProgramAgreementAsync(userToken, agmtToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Accept a single program agreement.
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="agmtToken">Required parameter: Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AcceptProgramAgreementAsync(
                string userToken,
                string agmtToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/agreements/{agmt-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "agmt-token", agmtToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Post(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        public void ListAcceptedProgramAgreements(
                string userToken)
        {
            Task t = this.ListAcceptedProgramAgreementsAsync(userToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ListAcceptedProgramAgreementsAsync(
                string userToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/agreements");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}