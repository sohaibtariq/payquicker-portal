// <copyright file="ProgramController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Request;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// ProgramController.
    /// </summary>
    public class ProgramController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProgramController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal ProgramController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        public void GetPrograms()
        {
            Task t = this.GetProgramsAsync();
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetProgramsAsync(CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/programs");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve a single program configuration.
        /// </summary>
        /// <param name="progToken">Required parameter: Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>..</param>
        public void GetProgramsProgToken(
                string progToken)
        {
            Task t = this.GetProgramsProgTokenAsync(progToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a single program configuration.
        /// </summary>
        /// <param name="progToken">Required parameter: Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetProgramsProgTokenAsync(
                string progToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/programs/{prog-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "prog-token", progToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="progToken">Required parameter: Example: .</param>
        public void GetProgramsProgTokenAgreements(
                string progToken)
        {
            Task t = this.GetProgramsProgTokenAgreementsAsync(progToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="progToken">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetProgramsProgTokenAgreementsAsync(
                string progToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/programs/{prog-token}/agreements");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "prog-token", progToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve a single program agreement.
        /// </summary>
        /// <param name="progToken">Required parameter: Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>..</param>
        /// <param name="agmtToken">Required parameter: Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>..</param>
        public void GetProgramsProgTokenAgreementsAgmtToken(
                string progToken,
                string agmtToken)
        {
            Task t = this.GetProgramsProgTokenAgreementsAgmtTokenAsync(progToken, agmtToken);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Retrieve a single program agreement.
        /// </summary>
        /// <param name="progToken">Required parameter: Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>..</param>
        /// <param name="agmtToken">Required parameter: Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetProgramsProgTokenAgreementsAgmtTokenAsync(
                string progToken,
                string agmtToken,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/programs/{prog-token}/agreements/{agmt-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "prog-token", progToken },
                { "agmt-token", agmtToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}