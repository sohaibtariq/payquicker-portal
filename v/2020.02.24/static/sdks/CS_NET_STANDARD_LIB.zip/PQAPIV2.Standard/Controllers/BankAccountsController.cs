// <copyright file="BankAccountsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Request;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountsController.
    /// </summary>
    public class BankAccountsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal BankAccountsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.BankAccountCollectionResponse response from the API call.</returns>
        public Models.BankAccountCollectionResponse GetUsersUserTokenBankaccounts(
                string userToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.BankAccountCollectionResponse> t = this.GetUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BankAccountCollectionResponse response from the API call.</returns>
        public async Task<Models.BankAccountCollectionResponse> GetUsersUserTokenBankaccountsAsync(
                string userToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/bank-accounts");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.BankAccountCollectionResponse>(response.Body);
        }

        /// <summary>
        /// Create a quote for a bank account using a user token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.BankAccountResponse response from the API call.</returns>
        public Models.BankAccountResponse PostUsersUserTokenBankaccounts(
                string userToken,
                string xMyPayQuickerVersion,
                Models.BankAccountFields body = null)
        {
            Task<Models.BankAccountResponse> t = this.PostUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a quote for a bank account using a user token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BankAccountResponse response from the API call.</returns>
        public async Task<Models.BankAccountResponse> PostUsersUserTokenBankaccountsAsync(
                string userToken,
                string xMyPayQuickerVersion,
                Models.BankAccountFields body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/bank-accounts");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.BankAccountResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="destToken">Required parameter: Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.BankAccountResponse response from the API call.</returns>
        public Models.BankAccountResponse GetUsersUserTokenBankaccountsDestToken(
                string userToken,
                string destToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.BankAccountResponse> t = this.GetUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="destToken">Required parameter: Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BankAccountResponse response from the API call.</returns>
        public async Task<Models.BankAccountResponse> GetUsersUserTokenBankaccountsDestTokenAsync(
                string userToken,
                string destToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/bank-accounts/{dest-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "dest-token", destToken },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.BankAccountResponse>(response.Body);
        }

        /// <summary>
        /// Update a bank account..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="destToken">Required parameter: Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.BankAccountResponse response from the API call.</returns>
        public Models.BankAccountResponse PutUsersUserTokenBankaccountsDestToken(
                string userToken,
                string destToken,
                string xMyPayQuickerVersion,
                Models.BankAccountFields body = null)
        {
            Task<Models.BankAccountResponse> t = this.PutUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update a bank account..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="destToken">Required parameter: Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BankAccountResponse response from the API call.</returns>
        public async Task<Models.BankAccountResponse> PutUsersUserTokenBankaccountsDestTokenAsync(
                string userToken,
                string destToken,
                string xMyPayQuickerVersion,
                Models.BankAccountFields body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/bank-accounts/{dest-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "dest-token", destToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.BankAccountResponse>(response.Body);
        }

        /// <summary>
        /// Delete (cloak) a user bank account..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="destToken">Required parameter: Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        public void DeleteUsersUserTokenBankaccountsDestToken(
                string userToken,
                string destToken,
                string xMyPayQuickerVersion)
        {
            Task t = this.DeleteUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Delete (cloak) a user bank account..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="destToken">Required parameter: Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteUsersUserTokenBankaccountsDestTokenAsync(
                string userToken,
                string destToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/bank-accounts/{dest-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "dest-token", destToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.BankAccountRequirementCollectionResponse response from the API call.</returns>
        public Models.BankAccountRequirementCollectionResponse GetUsersUserTokenBankaccountsRequirements(
                string userToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.BankAccountRequirementCollectionResponse> t = this.GetUsersUserTokenBankaccountsRequirementsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BankAccountRequirementCollectionResponse response from the API call.</returns>
        public async Task<Models.BankAccountRequirementCollectionResponse> GetUsersUserTokenBankaccountsRequirementsAsync(
                string userToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/bank-accounts/requirements");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.BankAccountRequirementCollectionResponse>(response.Body);
        }
    }
}