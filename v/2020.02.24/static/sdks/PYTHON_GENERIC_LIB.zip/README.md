# Getting Started with PQ API v2

## Getting Started

### Introduction

desc older version

### Building

You must have Python `2 >=2.7.9` or Python `3 >=3.4` installed on your system to install and run this SDK. This SDK package depends on other Python packages like nose, jsonpickle etc. These dependencies are defined in the `requirements.txt` file that comes with the SDK.To resolve these dependencies, you can use the PIP Dependency manager. Install it by following steps at [https://pip.pypa.io/en/stable/installing/](https://pip.pypa.io/en/stable/installing/).

Python and PIP executables should be defined in your PATH. Open command prompt and type `pip --version`. This should display the version of the PIP Dependency Manager installed if your installation was successful and the paths are properly defined.

* Using command line, navigate to the directory containing the generated files (including `requirements.txt`) for the SDK.
* Run the command `pip install -r requirements.txt`. This should install all the required dependencies.

![Building SDK - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&step=installDependencies)

### Installation

The following section explains how to use the pqapiv2 library in a new project.

#### 1. Open Project in an IDE

Open up a Python IDE like PyCharm. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

![Open project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&step=pyCharm)

Click on `Open` in PyCharm to browse to your generated SDK directory and then click `OK`.

![Open project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&step=openProject0)

The project files will be displayed in the side bar as follows:

![Open project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&projectName=pqapiv2&step=openProject1)

#### 2. Add a new Test Project

Create a new directory by right clicking on the solution name as shown below:

![Add a new project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&projectName=pqapiv2&step=createDirectory)

Name the directory as "test".

![Add a new project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&step=nameDirectory)

Add a python file to this project.

![Add a new project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&projectName=pqapiv2&step=createFile)

Name it "testSDK".

![Add a new project in PyCharm - Step 4](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&projectName=pqapiv2&step=nameFile)

In your python file you will be required to import the generated python library using the following code lines

```python
from pqapiv2.pqapiv_2_client import Pqapiv2Client
```

![Add a new project in PyCharm - Step 5](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&projectName=pqapiv2&libraryName=pqapiv2.pqapiv_2_client&className=Pqapiv2Client&step=projectFiles)

After this you can write code to instantiate an API client object, get a controller object and  make API calls. Sample code is given in the subsequent sections.

#### 3. Run the Test Project

To run the file within your test project, right click on your Python file inside your Test project and click on `Run`

![Run Test Project - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Pqapiv2-Python&projectName=pqapiv2&libraryName=pqapiv2.pqapiv_2_client&className=Pqapiv2Client&step=runProject)

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| `retry_statuses` | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT', 'GET', 'PUT']** |

The API client can be initialized as follows:

```python
from pqapiv2.pqapiv_2_client import Pqapiv2Client
from pqapiv2.configuration import Environment

client = Pqapiv2Client(
    environment = ,)
```

### Test the SDK

You can test the generated SDK and the server with test cases. `unittest` is used as the testing framework and `nose` is used as the test runner. You can run the tests as follows:

Navigate to the root directory of the SDK and run the following commands

```
pip install -r test-requirements.txt
nosetests
```

## Client Class Documentation

### PQ API v2 Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| payments | Gets PaymentsController |
| transfers | Gets TransfersController |
| spend_back | Gets SpendBackController |
| prepaid_cards | Gets PrepaidCardsController |
| paper_checks | Gets PaperChecksController |
| bank_accounts | Gets BankAccountsController |
| balances | Gets BalancesController |
| receipts | Gets ReceiptsController |
| users | Gets UsersController |
| documents | Gets DocumentsController |
| webhooks | Gets WebhooksController |
| program | Gets ProgramController |

## API Reference

### List of APIs

* [Payments](#payments)
* [Transfers](#transfers)
* [Spend Back](#spend-back)
* [Prepaid Cards](#prepaid-cards)
* [Paper Checks](#paper-checks)
* [Bank Accounts](#bank-accounts)
* [Balances](#balances)
* [Receipts](#receipts)
* [Users](#users)
* [Documents](#documents)
* [Webhooks](#webhooks)
* [Program](#program)

### Payments

#### Overview

Payment-related operations

##### Get instance

An instance of the `PaymentsController` class can be accessed from the API Client.

```
payments_controller = client.payments
```

#### Get-Payments-Pmnt Token

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_payments_pmnt_token(self,
                           pmnt_token,
                           x_my_pay_quicker_version,
                           filter=None,
                           language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmnt_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```python
pmnt_token = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20'
x_my_pay_quicker_version = '2020.02.24'
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
language = LanguageTypesEnum.ENUS

result = payments_controller.get_payments_pmnt_token(pmnt_token, x_my_pay_quicker_version, filter, language)
```

#### Post-Payments-Pmnt Token

Accept an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_payments_pmnt_token(self,
                            pmnt_token,
                            x_my_pay_quicker_version,
                            body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmnt_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```python
pmnt_token = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20'
x_my_pay_quicker_version = '2020.02.24'

result = payments_controller.post_payments_pmnt_token(pmnt_token, x_my_pay_quicker_version)
```

#### Delete-Payments-Pmnt Token

Cancel an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_payments_pmnt_token(self,
                              pmnt_token,
                              x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmnt_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
pmnt_token = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20'
x_my_pay_quicker_version = '2020.02.24'

result = payments_controller.delete_payments_pmnt_token(pmnt_token, x_my_pay_quicker_version)
```

#### Put-Payments-Pmnt Token-Retract

Perform a payment retraction for the full payment amount.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_payments_pmnt_token_retract(self,
                                   pmnt_token,
                                   x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmnt_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
pmnt_token = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20'
x_my_pay_quicker_version = '2020.02.24'

result = payments_controller.put_payments_pmnt_token_retract(pmnt_token, x_my_pay_quicker_version)
```

#### Patch-Payments-Pmnt Token-Retract

Perform a payment retraction for a partial payment amount.

:information_source: **Note** This endpoint does not require authentication.

```python
def patch_payments_pmnt_token_retract(self,
                                     pmnt_token,
                                     x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmnt_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
pmnt_token = 'pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20'
x_my_pay_quicker_version = '2020.02.24'

result = payments_controller.patch_payments_pmnt_token_retract(pmnt_token, x_my_pay_quicker_version)
```

#### Get-Payments

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_payments(self,
                x_my_pay_quicker_version,
                page=None,
                page_size=20,
                filter=None,
                sort=None,
                language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaymentsCollectionResponse`](#payments-collection-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = payments_controller.get_payments(x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Payments

Create a payment quote.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_payments(self,
                 x_my_pay_quicker_version,
                 body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PaymentRequest`](#payment-request) | Body, Optional | - |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
body = PaymentRequest()
body.amount = 78.98
body.currency = CurrencyTypesEnum.HKD

result = payments_controller.post_payments(x_my_pay_quicker_version, body)
```

### Transfers

#### Overview

Transfer-related operations

##### Get instance

An instance of the `TransfersController` class can be accessed from the API Client.

```
transfers_controller = client.transfers
```

#### Get-Transfers-Xfer Token

Retrieve details of a specific transfer represented by a transfer token.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_transfers_xfer_token(self,
                            xfer_token,
                            x_my_pay_quicker_version,
                            page=None,
                            page_size=20,
                            filter=None,
                            sort=None,
                            language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xfer_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```python
xfer_token = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = transfers_controller.get_transfers_xfer_token(xfer_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Transfers-Xfer Token

Accept a transfer quote

:information_source: **Note** This endpoint does not require authentication.

```python
def post_transfers_xfer_token(self,
                             xfer_token,
                             x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xfer_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
xfer_token = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff'
x_my_pay_quicker_version = '2020.02.24'

result = transfers_controller.post_transfers_xfer_token(xfer_token, x_my_pay_quicker_version)
```

#### Delete-Transfers-Xfer Token

Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote.

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_transfers_xfer_token(self,
                               xfer_token,
                               x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xfer_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
xfer_token = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff'
x_my_pay_quicker_version = '2020.02.24'

result = transfers_controller.delete_transfers_xfer_token(xfer_token, x_my_pay_quicker_version)
```

#### Get-Transfers

Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_transfers(self,
                 x_my_pay_quicker_version,
                 page=None,
                 page_size=20,
                 filter=None,
                 sort=None,
                 language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`TransferCollectionResponse`](#transfer-collection-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = transfers_controller.get_transfers(x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Transfers

Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>

:information_source: **Note** This endpoint does not require authentication.

```python
def post_transfers(self,
                  x_my_pay_quicker_version,
                  body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`TransferRequest`](#transfer-request) | Body, Required | - |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
body = TransferRequest()

result = transfers_controller.post_transfers(x_my_pay_quicker_version, body)
```

##### Example Response *(as JSON)*

```json
{
  "sourceToken": "user-114773fd-85c1-4977-8ce5-24af71f744e9",
  "destinationToken": "dest-63947e68-5393-4d00-955d-e0020017924b",
  "notes": "string",
  "memo": "string",
  "destinationAmount": -1.79,
  "destinationCurrency": "USD",
  "clientTransferId": "DKKde3Meeiiw34",
  "token": "xfer-0c0f2727-6521-47c9-b1fa-f132306d456a",
  "sourceAmount": -1.79,
  "sourceCurrency": "USD",
  "status": "QUOTED",
  "fx": {
    "destinationAmount": -1.79,
    "destinationCurrency": "USD",
    "sourceAmount": -1.79,
    "sourceCurrency": "USD",
    "rate": 0.85
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://url.to.com/xfer-0c0f2727-6521-47c9-b1fa-f132306d456a"
    }
  ]
}
```

### Spend Back

#### Overview

Spendback-related operations

##### Get instance

An instance of the `SpendBackController` class can be accessed from the API Client.

```
spend_back_controller = client.spend_back
```

#### Get-Spendback-Spnd Token

Retrieve a single spendback quote using the spendback token.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_spendback_spnd_token(self,
                            spnd_token,
                            x_my_pay_quicker_version,
                            page=None,
                            page_size=20,
                            filter=None,
                            sort=None,
                            language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spnd_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```python
spnd_token = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = spend_back_controller.get_spendback_spnd_token(spnd_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Spendback-Spnd Token

Accept an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_spendback_spnd_token(self,
                             spnd_token,
                             x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spnd_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
spnd_token = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762'
x_my_pay_quicker_version = '2020.02.24'

result = spend_back_controller.post_spendback_spnd_token(spnd_token, x_my_pay_quicker_version)
```

#### Delete-Spendback-Spnd Token

Cancel an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_spendback_spnd_token(self,
                               spnd_token,
                               x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spnd_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
spnd_token = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762'
x_my_pay_quicker_version = '2020.02.24'

result = spend_back_controller.delete_spendback_spnd_token(spnd_token, x_my_pay_quicker_version)
```

#### Put-Spendback-Spnd Token-Refund

Perform a spendback refund for the full amount.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_spendback_spnd_token_refund(self,
                                   spnd_token,
                                   x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spnd_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
spnd_token = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762'
x_my_pay_quicker_version = '2020.02.24'

result = spend_back_controller.put_spendback_spnd_token_refund(spnd_token, x_my_pay_quicker_version)
```

#### Patch-Spendback-Spnd Token-Refund

Perform a spendback refund for a partial amount.

:information_source: **Note** This endpoint does not require authentication.

```python
def patch_spendback_spnd_token_refund(self,
                                     spnd_token,
                                     x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spnd_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
spnd_token = 'spnd-c39437e1-dc80-4293-8211-c14b5a32f762'
x_my_pay_quicker_version = '2020.02.24'

result = spend_back_controller.patch_spendback_spnd_token_refund(spnd_token, x_my_pay_quicker_version)
```

#### Get-Spendback

Retrieve a list of all spendbacks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_spendback(self,
                 x_my_pay_quicker_version,
                 page=None,
                 page_size=20,
                 filter=None,
                 sort=None,
                 language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = spend_back_controller.get_spendback(x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Spendback

Create a spendback quote. <i>*Spendbacks can be automatically accepted by setting the `autoAcceptQuote` flag. If not automatically accepted, a POST is required to the spendback endpoint using the token returned in the response. Quotes can be accepted, cancelled, or allowed to expire.</i>

:information_source: **Note** This endpoint does not require authentication.

```python
def post_spendback(self,
                  x_my_pay_quicker_version,
                  body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

`void`

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'

result = spend_back_controller.post_spendback(x_my_pay_quicker_version)
```

### Prepaid Cards

#### Overview

Prepaid Card-related operations

##### Get instance

An instance of the `PrepaidCardsController` class can be accessed from the API Client.

```
prepaid_cards_controller = client.prepaid_cards
```

#### Post-Users-User Token-Prepaidcards-Dest Token

Replace an existing Prepaid Card specifying the replacement reason and the card package for the replacement card.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_prepaidcards_dest_token(self,
                                                 user_token,
                                                 dest_token,
                                                 x_my_pay_quicker_version,
                                                 body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'

result = prepaid_cards_controller.post_users_user_token_prepaidcards_dest_token(user_token, dest_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaid-Cards-Dest Token

Retrieve Prepaid Card details by destination token.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_prepaid_cards_dest_token(self,
                                                 user_token,
                                                 dest_token,
                                                 x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'

result = prepaid_cards_controller.get_users_user_token_prepaid_cards_dest_token(user_token, dest_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Patch-Users-User Token-Prepaidcards-Dest Token

Partial Prepaid Card update typically used when modifying card status. <i>*Does not require the entire object be passed in the request</i>

:information_source: **Note** This endpoint does not require authentication.

```python
def patch_users_user_token_prepaidcards_dest_token(self,
                                                  user_token,
                                                  dest_token,
                                                  x_my_pay_quicker_version,
                                                  body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PrepaidCardStatus`](#prepaid-card-status) | Body, Optional | - |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'

result = prepaid_cards_controller.patch_users_user_token_prepaidcards_dest_token(user_token, dest_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "LOCKED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Pin

Retrieve one part of a two-part token required to reveal or set a client side PIN. <i>*Not all programs support a reveal or set PIN operation.</i>

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_prepaidcards_dest_token_pin(self,
                                                    user_token,
                                                    dest_token,
                                                    x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`PrepaidCardPinToken`](#prepaid-card-pin-token)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'

result = prepaid_cards_controller.get_users_user_token_prepaidcards_dest_token_pin(user_token, dest_token, x_my_pay_quicker_version)
```

#### Put-Users-User Token-Prepaidcards-Dest Token-Pin

Allows the setting of a PIN if supported by program.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_users_user_token_prepaidcards_dest_token_pin(self,
                                                    user_token,
                                                    dest_token,
                                                    x_my_pay_quicker_version,
                                                    token,
                                                    card_pin)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `card_pin` | `string` | Query, Required | Prepaid card PIN for ATM and Debit usage |

##### Response Type

[`UsersPrepaidCardsPinResponse`](#users-prepaid-cards-pin-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'
token = 'token6'
card_pin = 'cardPin4'

result = prepaid_cards_controller.put_users_user_token_prepaidcards_dest_token_pin(user_token, dest_token, x_my_pay_quicker_version, token, card_pin)
```

#### Post-Users-User Token-Prepaid-Cards-Dest Token-Pin

Reveals the PIN for a card where PIN reveal functionality is supported in the program and hosted by PayQuicker.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_prepaid_cards_dest_token_pin(self,
                                                      user_token,
                                                      dest_token,
                                                      x_my_pay_quicker_version,
                                                      token,
                                                      cvc_2,
                                                      body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cvc_2` | `string` | Query, Required | Card Verification Value (CVV) located on the back of your credit card or debit card is a 3-digit number on VISA® and MasterCard® branded credit cards, and debit cards. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`PrepaidCardPin`](#prepaid-card-pin)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'
token = 'token6'
cvc_2 = 'cvc20'

result = prepaid_cards_controller.post_users_user_token_prepaid_cards_dest_token_pin(user_token, dest_token, x_my_pay_quicker_version, token, cvc_2)
```

#### Get-Users-User Token-Prepaidcards

Retrieve a list of all pre-paid cards by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_prepaidcards(self,
                                     user_token,
                                     x_my_pay_quicker_version,
                                     page=None,
                                     page_size=20,
                                     filter=None,
                                     sort=None,
                                     language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PrepaidCardCollectionResponse`](#prepaid-card-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = prepaid_cards_controller.get_users_user_token_prepaidcards(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
      "status": "QUEUED",
      "createdOn": "2020-02-21T22:00:00Z",
      "country": "US",
      "currency": "USD",
      "cardPersonalization": "PERSONALIZED",
      "cardPackage": "blue_consumer_10k",
      "cardNetwork": "VISA",
      "expires": "2023-02-21T00:00:00Z",
      "cardNumber": "1234 56** **** 1234",
      "cvv": "123",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards"
    }
  ]
}
```

#### Post-Users-User Token-Prepaidcards

Order a pre-paid card for the user by specifying a cardPackage. <i>*A package defines the type of card, currency, artwork utilized, and often the method of delivery.</i>

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_prepaidcards(self,
                                      user_token,
                                      x_my_pay_quicker_version,
                                      body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PrepaidCardBase`](#prepaid-card-base) | Body, Optional | - |

##### Response Type

[`PrepaidCardRequestResponse`](#prepaid-card-request-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'

result = prepaid_cards_controller.post_users_user_token_prepaidcards(user_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Generate a token used to reveal prepaid card information in the form of image data (base64) or JSON.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_prepaid_cards_dest_token_pci(self,
                                                     user_token,
                                                     dest_token,
                                                     x_my_pay_quicker_version,
                                                     format,
                                                     side=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | - |
| `dest_token` | `string` | Template, Required | - |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `side` | [`SideEnum`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`PrepaidCardDataTokenResponse`](#prepaid-card-data-token-response)

##### Example Usage

```python
user_token = 'user-token6'
dest_token = 'dest-token2'
x_my_pay_quicker_version = '2020.02.24'
format = FormatEnum.ENUM_TEXTIMAGE

result = prepaid_cards_controller.get_users_user_token_prepaid_cards_dest_token_pci(user_token, dest_token, x_my_pay_quicker_version, format)
```

#### Post-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Return prepaid card data in the form of image data, text, or both.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_prepaid_cards_dest_token_pci(self,
                                                      user_token,
                                                      dest_token,
                                                      x_my_pay_quicker_version,
                                                      format,
                                                      token,
                                                      side=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | - |
| `dest_token` | `string` | Template, Required | - |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `side` | [`SideEnum`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`PrepaidCardDataResponse`](#prepaid-card-data-response)

##### Example Usage

```python
user_token = 'user-token6'
dest_token = 'dest-token2'
x_my_pay_quicker_version = '2020.02.24'
format = FormatEnum.ENUM_TEXTIMAGE
token = 'token6'

result = prepaid_cards_controller.post_users_user_token_prepaid_cards_dest_token_pci(user_token, dest_token, x_my_pay_quicker_version, format, token)
```

### Paper Checks

#### Overview

Paper check-related operations

##### Get instance

An instance of the `PaperChecksController` class can be accessed from the API Client.

```
paper_checks_controller = client.paper_checks
```

#### Get-Users-User Token-Paper-Checks

Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_paper_checks(self,
                                     user_token,
                                     x_my_pay_quicker_version,
                                     page=None,
                                     page_size=20,
                                     filter=None,
                                     sort=None,
                                     language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaperCheckCollectionResponse`](#paper-check-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = paper_checks_controller.get_users_user_token_paper_checks(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Users-User Token-Paperchecks

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_paperchecks(self,
                                     user_token,
                                     x_my_pay_quicker_version,
                                     body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PaperCheckBase`](#paper-check-base) | Body, Optional | - |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
body = PaperCheckBase()
body.amount = 78.98
body.currency = CurrencyTypesEnum.HKD

result = paper_checks_controller.post_users_user_token_paperchecks(user_token, x_my_pay_quicker_version, body)
```

#### Get-Users-User Token-Paperchecks-Dest Token

Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_paperchecks_dest_token(self,
                                               user_token,
                                               xfer_token,
                                               x_my_pay_quicker_version,
                                               page=None,
                                               page_size=20,
                                               filter=None,
                                               sort=None,
                                               language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xfer_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
xfer_token = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = paper_checks_controller.get_users_user_token_paperchecks_dest_token(user_token, xfer_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Put-Users-User Token-Paperchecks-Dest Token

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_users_user_token_paperchecks_dest_token(self,
                                               user_token,
                                               xfer_token,
                                               x_my_pay_quicker_version,
                                               body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xfer_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
xfer_token = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff'
x_my_pay_quicker_version = '2020.02.24'

result = paper_checks_controller.put_users_user_token_paperchecks_dest_token(user_token, xfer_token, x_my_pay_quicker_version)
```

#### Delete-Users-User Token-Paper-Checks-Dest Token

Delete a paper check by destination token.

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_users_user_token_paper_checks_dest_token(self,
                                                   user_token,
                                                   xfer_token,
                                                   x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xfer_token` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
xfer_token = 'xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff'
x_my_pay_quicker_version = '2020.02.24'

result = paper_checks_controller.delete_users_user_token_paper_checks_dest_token(user_token, xfer_token, x_my_pay_quicker_version)
```

### Bank Accounts

#### Overview

Bank account-related operations

##### Get instance

An instance of the `BankAccountsController` class can be accessed from the API Client.

```
bank_accounts_controller = client.bank_accounts
```

#### Get-Users-User Token-Bankaccounts

Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_bankaccounts(self,
                                     user_token,
                                     x_my_pay_quicker_version,
                                     page=None,
                                     page_size=20,
                                     filter=None,
                                     sort=None,
                                     language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountCollectionResponse`](#bank-account-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = bank_accounts_controller.get_users_user_token_bankaccounts(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-7d8b1c83-01bb-40fb-87d7-26bd4c303f01",
      "status": "DELETED",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "333333333"
        },
        {
          "key": "BANK_BBAN",
          "value": "4444444444"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "My account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    },
    {
      "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
      "status": "ACTIVE",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "012346789"
        },
        {
          "key": "BANK_BBAN",
          "value": "987654321"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "Personal checking account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Post-Users-User Token-Bankaccounts

Create a quote for a bank account using a user token.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_bankaccounts(self,
                                      user_token,
                                      x_my_pay_quicker_version,
                                      body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'

result = bank_accounts_controller.post_users_user_token_bankaccounts(user_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Get-Users-User Token-Bankaccounts-Dest Token

Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_bankaccounts_dest_token(self,
                                                user_token,
                                                dest_token,
                                                x_my_pay_quicker_version,
                                                page=None,
                                                page_size=20,
                                                filter=None,
                                                sort=None,
                                                language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = bank_accounts_controller.get_users_user_token_bankaccounts_dest_token(user_token, dest_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Put-Users-User Token-Bankaccounts-Dest Token

Update a bank account.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_users_user_token_bankaccounts_dest_token(self,
                                                user_token,
                                                dest_token,
                                                x_my_pay_quicker_version,
                                                body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'

result = bank_accounts_controller.put_users_user_token_bankaccounts_dest_token(user_token, dest_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Delete-Users-User Token-Bankaccounts-Dest Token

Delete (cloak) a user bank account.

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_users_user_token_bankaccounts_dest_token(self,
                                                   user_token,
                                                   dest_token,
                                                   x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'

result = bank_accounts_controller.delete_users_user_token_bankaccounts_dest_token(user_token, dest_token, x_my_pay_quicker_version)
```

#### Get-Users-User Token-Bankaccounts-Requirements

Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_bankaccounts_requirements(self,
                                                  user_token,
                                                  x_my_pay_quicker_version,
                                                  page=None,
                                                  page_size=20,
                                                  filter=None,
                                                  sort=None,
                                                  language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountRequirementCollectionResponse`](#bank-account-requirement-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = bank_accounts_controller.get_users_user_token_bankaccounts_requirements(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "bankCountry": "IT",
      "bankCurrency": "EUR",
      "requirements": [
        {
          "requirement": "BANK_IBAN",
          "format": {
            "example": "IT43K0310412701000000820420",
            "legend": [
              {
                "key": "IT43K0310412701000000820420",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example IBAN"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio IBAN"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "IBAN"
            },
            {
              "language": "it-IT",
              "translation": "IBAN"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^IT\\\\d{2}[A-Z]\\\\d{10}[0-9A-Z]{12}$"
            }
          ]
        },
        {
          "requirement": "BANK_SWIFT_BIC",
          "format": {
            "example": "01234567890",
            "legend": [
              {
                "key": "01234567890",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example Swift/BIC"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio Swift/BIC"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "Swift/BIC"
            },
            {
              "language": "it-IT",
              "translation": "Swift/BIC"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^[a-z0-9A-Z]{8,11}$"
            }
          ]
        }
      ],
      "quote": {
        "formattedAmount": "$4.32 USD (USD, en-US), 0,00 € EUR (EUR, fr-FR)",
        "amount": 4.32,
        "currency": "USD"
      },
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

### Balances

#### Overview

Balance-related operations

##### Get instance

An instance of the `BalancesController` class can be accessed from the API Client.

```
balances_controller = client.balances
```

#### Get-Users-User Token-Balances

Retrieve a list of user balances that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_balances(self,
                                 user_token,
                                 x_my_pay_quicker_version,
                                 page=None,
                                 page_size=20,
                                 filter=None,
                                 sort=None,
                                 language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = balances_controller.get_users_user_token_balances(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$4.32 USD",
      "amount": 4.32,
      "currency": "USD",
      "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/balances"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Balances

Retrieve a list of balances by destination token that supports filtering, sorting, and pagination through existing mechanisms. <i>*If the user belongs to a Flex-based program, balances against the user resource will return the wallet balance only. If it is a pre-paid card program (i.e., Meta USD), this balance and its associated pre-paid card balance will be the same.</i>

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_prepaidcards_dest_token_balances(self,
                                                         user_token,
                                                         dest_token,
                                                         x_my_pay_quicker_version,
                                                         page=None,
                                                         page_size=20,
                                                         filter=None,
                                                         sort=None,
                                                         language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = balances_controller.get_users_user_token_prepaidcards_dest_token_balances(user_token, dest_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "formattedAmount": "$4.32",
  "amount": 4.32,
  "currency": "USD",
  "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
    }
  ]
}
```

#### Get-Accounts-Acct Token-Balances

Retrieve a single account balance.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_accounts_acct_token_balances(self,
                                    acct_token,
                                    x_my_pay_quicker_version,
                                    page=None,
                                    page_size=20,
                                    filter=None,
                                    sort=None,
                                    language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acct_token` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```python
acct_token = 'acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = balances_controller.get_accounts_acct_token_balances(acct_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$5.00",
      "amount": 5,
      "currency": "USD",
      "token": "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4"
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4/balances"
    }
  ]
}
```

### Receipts

#### Overview

Receipt-related operations

##### Get instance

An instance of the `ReceiptsController` class can be accessed from the API Client.

```
receipts_controller = client.receipts
```

#### Get-Accounts-Receipts

Retrieve a list of all account(s) receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_accounts_receipts(self,
                         acct_token,
                         x_my_pay_quicker_version,
                         page=None,
                         page_size=20,
                         filter=None,
                         sort=None,
                         language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acct_token` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`object`

##### Example Usage

```python
acct_token = 'acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = receipts_controller.get_accounts_receipts(acct_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response

```
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "acct-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Receipts

Retrieve a list all prepaid-card receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_prepaidcards_receipts(self,
                                              user_token,
                                              dest_token,
                                              x_my_pay_quicker_version,
                                              page=None,
                                              page_size=20,
                                              filter=None,
                                              sort=None,
                                              language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `dest_token` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
dest_token = 'dest-4aed86e2-4929-45bf-814d-9030aef21e79'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = receipts_controller.get_users_user_token_prepaidcards_receipts(user_token, dest_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.05,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/prepaid-cards/dest-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-Receipts

Retrieve a list all user receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_receipts(self,
                      user_token,
                      x_my_pay_quicker_version,
                      page=None,
                      page_size=20,
                      filter=None,
                      sort=None,
                      language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = receipts_controller.get_users_receipts(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

### Users

#### Overview

User-related operations

##### Get instance

An instance of the `UsersController` class can be accessed from the API Client.

```
users_controller = client.users
```

#### Put-Users-User Token

Update a user object (change email, address change, etc.) using a user token.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_users_user_token(self,
                        user_token,
                        x_my_pay_quicker_version,
                        body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase`](#user-base) | Body, Optional | - |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'

result = users_controller.put_users_user_token(user_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token

Retrieve a single user record by user token.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token(self,
                        user_token,
                        x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'

result = users_controller.get_users_user_token(user_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users

Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users(self,
             x_my_pay_quicker_version,
             page=None,
             page_size=20,
             filter=None,
             sort=None,
             language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`UserCollectionResponse`](#user-collection-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = users_controller.get_users(x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "firstName": "Jane",
      "lastName": "Smith",
      "dateOfBirth": "1977-12-14",
      "phoneNumber": "760-350-0324",
      "phoneNumberCountry": "US",
      "mobileNumber": "213-446-5755",
      "mobileNumberCountry": "US",
      "addressLine1": "290 Carriage Court",
      "city": "Los Angeles",
      "region": "CA",
      "country": "US",
      "postalCode": "90017",
      "addressType": "RESIDENTIAL",
      "email": "jsmith@payquicker.com",
      "gender": "FEMALE",
      "userType": "INDIVIDUAL",
      "programUserId": "d97ce0519b2d",
      "language": "en-US",
      "countryOfBirth": "US",
      "countryOfNationality": "US",
      "token": "usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357",
      "status": "PRE_ACTIVATED",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users"
    }
  ]
}
```

#### Post-Users

Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users(self,
              x_my_pay_quicker_version,
              body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase`](#user-base) | Body, Required | Body details of the request |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'
body = UserBase()
body.first_name = 'Jane'
body.last_name = 'Smith'
body.date_of_birth = dateutil.parser.parse('1977-12-14').date()
body.phone_number = '760-350-0324'
body.mobile_number = '213-446-5755'
body.phone_number_country = CountryTypesEnum.US
body.mobile_number_country = CountryTypesEnum.US
body.address_line_1 = '290 Carriage Court'
body.city = 'Los Angeles'
body.region = 'CA'
body.country = CountryTypesEnum.US
body.postal_code = '90017'
body.address_type = AddressTypesEnum.RESIDENTIAL
body.email = 'jsmith@payquicker.com'
body.gender = GenderTypesEnum.FEMALE
body.user_type = UserTypesEnum.INDIVIDUAL
body.program_user_id = 'd97ce0519b2d'
body.language = LanguageTypesEnum.ENUS
body.country_of_birth = CountryTypesEnum.US
body.country_of_nationality = CountryTypesEnum.US

result = users_controller.post_users(x_my_pay_quicker_version, body)
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks

Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_idv_checks(self,
                                   user_token,
                                   x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`IdentityVerificationCollectionResponse`](#identity-verification-collection-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'

result = users_controller.get_users_user_token_idv_checks(user_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
      "idvResult": "PASS",
      "idvSubResult": "HARD",
      "idvProvider": "IDOLOGY",
      "createdOn": "2020-02-21T22:00:00Z",
      "raw": "<RAW IDV processor output, for informational /debugging purposes only>",
      "idvCheckType": "NON_DOCUMENTARY",
      "idvDisposition": "FINAL",
      "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks-Idvc Token

Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_idv_checks_idvc_token(self,
                                              user_token,
                                              idvc_token,
                                              x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `idvc_token` | `string` | Template, Required | Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`IdentityVerificationResponse`](#identity-verification-response)

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
idvc_token = 'idvc-7e7567e0-c2db-485d-896d-45901a10baa9'
x_my_pay_quicker_version = '2020.02.24'

result = users_controller.get_users_user_token_idv_checks_idvc_token(user_token, idvc_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
  "idvResult": "PASS",
  "idvSubResult": "HARD",
  "idvProvider": "IDOLOGY",
  "createdOn": "2020-02-21T22:00:00Z",
  "raw": "<RAW IDV processor output, for informational/debugging purposes only>",
  "idvCheckType": "NON_DOCUMENTARY",
  "idvDispostion": "FINAL",
  "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
    }
  ]
}
```

#### Get-Users-User Token-Events

Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_events(self,
                               user_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'

result = users_controller.get_users_user_token_events(user_token)
```

#### Get-Users-User Token-Events-Event Token

Retrieve a single user event

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_events_event_token(self,
                                           user_token,
                                           evnt_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `evnt_token` | `string` | Template, Required | Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
evnt_token = 'evnt-28491de2-5b22-4e30-028a-45901a10baa9'

result = users_controller.get_users_user_token_events_event_token(user_token, evnt_token)
```

#### Post-Users-User Token-Agreements-Agmt Token

Accept a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_agreements_agmt_token(self,
                                               user_token,
                                               agmt_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `agmt_token` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
agmt_token = 'agmt-45901a10-5b22-4e30-028a-45901a10baa9'

result = users_controller.post_users_user_token_agreements_agmt_token(user_token, agmt_token)
```

#### Get-Users-User Token-Agreements

Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_agreements(self,
                                   user_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'

result = users_controller.get_users_user_token_agreements(user_token)
```

### Documents

#### Overview

Document-related operations

##### Get instance

An instance of the `DocumentsController` class can be accessed from the API Client.

```
documents_controller = client.documents
```

#### Get-Users-User Token-Documents

Retrieve a list of user documents that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_documents(self,
                                  user_token,
                                  x_my_pay_quicker_version,
                                  page=None,
                                  page_size=20,
                                  filter=None,
                                  sort=None,
                                  language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = documents_controller.get_users_user_token_documents(user_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Post-Users-User Token-Documents

Create a quote for a user document.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_users_user_token_documents(self,
                                   user_token,
                                   x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
x_my_pay_quicker_version = '2020.02.24'

result = documents_controller.post_users_user_token_documents(user_token, x_my_pay_quicker_version)
```

#### Get-Users-User Token-Documents-Docu Token

Retrieve an individual user document by its document token.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_users_user_token_documents_docu_token(self,
                                             user_token,
                                             docu_token,
                                             x_my_pay_quicker_version,
                                             page=None,
                                             page_size=20,
                                             filter=None,
                                             sort=None,
                                             language=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docu_token` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `page_size` | `int` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
docu_token = 'docu-6260c132-5cb1-4e30-8b08-9ce559893acb'
x_my_pay_quicker_version = '2020.02.24'
page_size = 20
filter = '\'name\'*\'Fra\'||*\'Ger\',\'numericCode\'>\'5\''
sort = '-name'
language = LanguageTypesEnum.ENUS

result = documents_controller.get_users_user_token_documents_docu_token(user_token, docu_token, x_my_pay_quicker_version, None, page_size, filter, sort, language)
```

#### Put-Users-User Token-Documents-Docu Token

Replace the user document at the given document token.

:information_source: **Note** This endpoint does not require authentication.

```python
def put_users_user_token_documents_docu_token(self,
                                             user_token,
                                             docu_token,
                                             x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_token` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docu_token` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
user_token = 'user-f012bc86-4d42-415b-a8b2-be5e0b90e59a'
docu_token = 'docu-6260c132-5cb1-4e30-8b08-9ce559893acb'
x_my_pay_quicker_version = '2020.02.24'

result = documents_controller.put_users_user_token_documents_docu_token(user_token, docu_token, x_my_pay_quicker_version)
```

### Webhooks

#### Overview

Webhook-related operations

##### Get instance

An instance of the `WebhooksController` class can be accessed from the API Client.

```
webhooks_controller = client.webhooks
```

#### Get-Webhook

Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_webhook(self,
               x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`WebhookCollectionResponse`](#webhook-collection-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'

result = webhooks_controller.get_webhook(x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "payload": [
    {
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ],
      "url": "https://www.example.com/webhooks",
      "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
      "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
      "created": "2020-01-01",
      "lastUpdated": "2020-02-01"
    }
  ]
}
```

#### Post-Webhooks

Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API.

:information_source: **Note** This endpoint does not require authentication.

```python
def post_webhooks(self,
                 x_my_pay_quicker_version,
                 body=None)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`WebhookSubscription`](#webhook-subscription) | Body, Optional | - |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```python
x_my_pay_quicker_version = '2020.02.24'

result = webhooks_controller.post_webhooks(x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01"
}
```

#### Get-Webhooks-Webh-Token

Retrieve a single webhook subscription using the webhook token.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_webhooks_webh_token(self,
                           webh_token,
                           x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webh_token` | `string` | Template, Required | - |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```python
webh_token = 'webh-token0'
x_my_pay_quicker_version = '2020.02.24'

result = webhooks_controller.get_webhooks_webh_token(webh_token, x_my_pay_quicker_version)
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01",
  "lastUpdated": "2020-02-01"
}
```

#### Delete-Webhooks-Webh-Token

Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code.

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_webhooks_webh_token(self,
                              webh_token,
                              x_my_pay_quicker_version)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webh_token` | `string` | Template, Required | - |
| `x_my_pay_quicker_version` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```python
webh_token = 'webh-token0'
x_my_pay_quicker_version = '2020.02.24'

result = webhooks_controller.delete_webhooks_webh_token(webh_token, x_my_pay_quicker_version)
```

### Program

#### Overview

##### Get instance

An instance of the `ProgramController` class can be accessed from the API Client.

```
program_controller = client.program
```

#### Get-Programs

Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_programs(self)
```

##### Response Type

`void`

##### Example Usage

```python
result = program_controller.get_programs()
```

#### Get-Programs-Prog Token

Retrieve a single program configuration

:information_source: **Note** This endpoint does not require authentication.

```python
def get_programs_prog_token(self,
                           prog_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prog_token` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |

##### Response Type

`void`

##### Example Usage

```python
prog_token = 'prog-4525ab9c-5b22-4e30-028a-45901a10aa0c'

result = program_controller.get_programs_prog_token(prog_token)
```

#### Get-Programs-Prog Token-Agreements

Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_programs_prog_token_agreements(self,
                                      prog_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prog_token` | `string` | Template, Required | - |

##### Response Type

`void`

##### Example Usage

```python
prog_token = 'prog-token4'

result = program_controller.get_programs_prog_token_agreements(prog_token)
```

#### Get-Programs-Prog Token-Agreements-Agmt Token

Retrieve a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```python
def get_programs_prog_token_agreements_agmt_token(self,
                                                 prog_token,
                                                 agmt_token)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prog_token` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |
| `agmt_token` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`void`

##### Example Usage

```python
prog_token = 'prog-4525ab9c-5b22-4e30-028a-45901a10aa0c'
agmt_token = 'agmt-45901a10-5b22-4e30-028a-45901a10baa9'

result = program_controller.get_programs_prog_token_agreements_agmt_token(prog_token, agmt_token)
```

## Model Reference

### Structures

* [Source Monetary Required](#source-monetary-required)
* [Haetos Self Ref](#haetos-self-ref)
* [Haetos Params](#haetos-params)
* [Haetos Relationship](#haetos-relationship)
* [Transfer-Request](#transfer-request)
* [Transfer](#transfer)
* [Expiration](#expiration)
* [Transfer-Response](#transfer-response)
* [Not Before or After](#not-before-or-after)
* [Address](#address)
* [Business Address](#business-address)
* [Monetary Formatted](#monetary-formatted)
* [Transfer Base](#transfer-base)
* [Payment Base](#payment-base)
* [Transfer Base Ext](#transfer-base-ext)
* [Destination Monetary Required](#destination-monetary-required)
* [Monetary Required](#monetary-required)
* [Balance](#balance)
* [Fx Object](#fx-object)
* [User Base](#user-base)
* [User](#user)
* [User-Response](#user-response)
* [Receipt Base](#receipt-base)
* [Receipt Collection-Response](#receipt-collection-response)
* [Balance Collection-Response](#balance-collection-response)
* [User Collection-Response](#user-collection-response)
* [Payment-Request](#payment-request)
* [Payment](#payment)
* [Payments Collection-Response](#payments-collection-response)
* [Payment-Response](#payment-response)
* [Transfer Collection-Response](#transfer-collection-response)
* [User Name](#user-name)
* [Dob](#dob)
* [Business Information](#business-information)
* [User Kyc Information](#user-kyc-information)
* [Phone Numbers](#phone-numbers)
* [Email Address](#email-address)
* [User Employer Id](#user-employer-id)
* [Gender](#gender)
* [Language](#language)
* [User Type](#user-type)
* [Program User Id](#program-user-id)
* [Source Destination Token](#source-destination-token)
* [Token](#token)
* [Client Transfer Id](#client-transfer-id)
* [Notes](#notes)
* [Memo](#memo)
* [Created On](#created-on)
* [Transfer Status](#transfer-status)
* [User Status](#user-status)
* [Payment Purpose](#payment-purpose)
* [Source Token](#source-token)
* [Destination Token](#destination-token)
* [Client Payment Id](#client-payment-id)
* [Auto Accept Quote](#auto-accept-quote)
* [Rate](#rate)
* [Fx](#fx)
* [Paper Check Base](#paper-check-base)
* [Transfer Type](#transfer-type)
* [Bank Account Ownership](#bank-account-ownership)
* [Shipping Method](#shipping-method)
* [Paper Check](#paper-check)
* [Paper Check-Response](#paper-check-response)
* [Paper Check Collection-Response](#paper-check-collection-response)
* [Bank Account Fields](#bank-account-fields)
* [Bank Account Type](#bank-account-type)
* [Bank Account](#bank-account)
* [Bank Account Status](#bank-account-status)
* [Bank Account-Response](#bank-account-response)
* [Bank Account Collection-Response](#bank-account-collection-response)
* [Prepaid Card Package](#prepaid-card-package)
* [Prepaid Card Base](#prepaid-card-base)
* [Prepaid Card Status](#prepaid-card-status)
* [Token Type](#token-type)
* [Prepaid Card Base Ext](#prepaid-card-base-ext)
* [Card Network](#card-network)
* [Card Personalization Type](#card-personalization-type)
* [Prepaid Card](#prepaid-card)
* [Currency](#currency)
* [Country](#country)
* [Prepaid Card-Request Response](#prepaid-card-request-response)
* [Prepaid Card-Response](#prepaid-card-response)
* [Prepaid Card Collection-Response](#prepaid-card-collection-response)
* [Card Masked Pan](#card-masked-pan)
* [Prepaid Card Replacement Reason](#prepaid-card-replacement-reason)
* [Prepaid Card Replacement Base](#prepaid-card-replacement-base)
* [Prepaid Card Pin Token](#prepaid-card-pin-token)
* [Prepaid Card Pin](#prepaid-card-pin)
* [Cvv](#cvv)
* [Identity Verification Provider Type](#identity-verification-provider-type)
* [Identity Verification Result Type](#identity-verification-result-type)
* [Identity Verification Sub Result Type](#identity-verification-sub-result-type)
* [Identity Verification Disposition Type](#identity-verification-disposition-type)
* [Identity Verification Check Type](#identity-verification-check-type)
* [Identity Verification Base](#identity-verification-base)
* [Identity Verification Provider Reference](#identity-verification-provider-reference)
* [Identity Verification Provider Raw Output](#identity-verification-provider-raw-output)
* [Identity Verification-Response](#identity-verification-response)
* [Identity Verification Collection-Response](#identity-verification-collection-response)
* [Key Value Pair String String](#key-value-pair-string-string)
* [Key Value Pair Bank Field Types String](#key-value-pair-bank-field-types-string)
* [Key Value Pair Bank Currency Currency Types](#key-value-pair-bank-currency-currency-types)
* [Key Value Bank Country Country Types](#key-value-bank-country-country-types)
* [Bank Account Required Fields](#bank-account-required-fields)
* [Bank Account Requirement Format](#bank-account-requirement-format)
* [Bank Account Requirement Format Legend](#bank-account-requirement-format-legend)
* [Key Value Pair Language Type String](#key-value-pair-language-type-string)
* [Bank Account Requirement Validator](#bank-account-requirement-validator)
* [Bank Account Requirement](#bank-account-requirement)
* [Bank Account Requirement-Response](#bank-account-requirement-response)
* [Bank Account Requirement Collection-Response](#bank-account-requirement-collection-response)
* [Occupation](#occupation)
* [Tax Resident Status](#tax-resident-status)
* [Webhook-Subscription](#webhook-subscription)
* [Webhook-Subscription-Response](#webhook-subscription-response)
* [Webhook Collection-Response](#webhook-collection-response)
* [Prepaid Card Data-Response](#prepaid-card-data-response)
* [Prepaid Card Data Token](#prepaid-card-data-token)
* [Prepaid Card Data Token-Response](#prepaid-card-data-token-response)
* [Business Type](#business-type)
* [Country Nationality Information](#country-nationality-information)
* [Users Prepaid Cards Pin Response](#users-prepaid-cards-pin-response)

#### Source Monetary Required

Required details of the monetary source.

##### Class Name

`SourceMonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_amount` | `float` | Optional | Amount of the transfer in the specified currency. |
| `source_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "sourceAmount": null,
  "sourceCurrency": null
}
```

#### Haetos Self Ref

Indicates the external link with the full URL of the same page on which the link appears.

##### Class Name

`HaetosSelfRef`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "links": null
}
```

#### Haetos Params

Hypermedia as the Engine of Application State (HAETOS) parameters used in a query.

##### Class Name

`HaetosParams`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`HaetosRelationship`](#haetos-relationship) | Required | Indicates the HATEOS relationship between the target and current resources. |
| `href` | `string` | Required | URL for resource described by the relationship. |

##### Example (as JSON)

```json
{
  "params": {
    "rel": "self"
  },
  "href": null
}
```

#### Haetos Relationship

Indicates the HATEOS relationship between the target and current resources.

##### Class Name

`HaetosRelationship`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rel` | `string` | Required | Indicates the relationship between the target and current resources.<br>**Default**: `'self'`<br>*Default: `'self'`* |

##### Example (as JSON)

```json
{
  "rel": "self"
}
```

#### Transfer-Request

Request for the transfer

##### Class Name

`TransferRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `client_transfer_id` | `string` | Optional | Unique value provided by the client for the transfer. |
| `destination_amount` | `float` | Optional | Amount transferred to the destination |
| `destination_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "clientTransferId": null,
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Transfer

Description of the transfer request

##### Class Name

`Transfer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `destination_amount` | `float` | Optional | Amount transferred to the destination |
| `destination_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `client_transfer_id` | `string` | Optional | Unique value provided by the client for the transfer. |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `source_amount` | `float` | Optional | Amount of the transfer in the specified currency. |
| `source_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer |
| `fx` | [`FxObject`](#fx-object) | Optional | Currency conversion object details |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null
}
```

#### Expiration

Date and time the object will expire

##### Class Name

`Expiration`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `expires` | `datetime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |

##### Example (as JSON)

```json
{
  "expires": null
}
```

#### Transfer-Response

##### Class Name

`TransferResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `destination_amount` | `float` | Optional | Amount transferred to the destination |
| `destination_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `client_transfer_id` | `string` | Optional | Unique value provided by the client for the transfer. |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `source_amount` | `float` | Optional | Amount of the transfer in the specified currency. |
| `source_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer |
| `fx` | [`FxObject`](#fx-object) | Optional | Currency conversion object details |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null,
  "links": null
}
```

#### Not Before or After

##### Class Name

`NotBeforeOrAfter`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `not_before` | `datetime` | Optional | Transfer is scheduled and will not process before this time. |
| `not_after` | `datetime` | Optional | Transfer expires if not completed prior to this time. |

##### Example (as JSON)

```json
{
  "notBefore": null,
  "notAfter": null
}
```

#### Address

Classifies the mailing address

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |

##### Example (as JSON)

```json
{
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null
}
```

#### Business Address

Address of the business location

##### Class Name

`BusinessAddress`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_address_line_1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `business_address_line_2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `business_address_line_3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `business_address_line_4` | `string` | Optional | fourth line of the business address street address |
| `business_address_line_5` | `string` | Optional | Fifth line of the business address street address |
| `business_city` | `string` | Optional | City the business is registered |
| `business_region` | `string` | Optional | State, province, or region the business is registered |
| `business_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_postal_code` | `string` | Optional | Postal code for the business address |
| `business_premise_number` | `string` | Optional | House number for the business address |

##### Example (as JSON)

```json
{
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null
}
```

#### Monetary Formatted

Object representing monies, including currency, decimal, and formatted amounts

##### Class Name

`MonetaryFormatted`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formatted_amount` | `string` | Optional | Formatted monetary amount |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base

Base class for the transfer

##### Class Name

`TransferBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null
}
```

#### Payment Base

Base class for the payment

##### Class Name

`PaymentBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `client_payment_id` | `string` | Optional | Unique value provided by the client for the payment. |
| `auto_accept_quote` | `bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base Ext

Base extension for the transfer

##### Class Name

`TransferBaseExt`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `destination_amount` | `float` | Optional | Amount transferred to the destination |
| `destination_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `client_transfer_id` | `string` | Optional | Unique value provided by the client for the transfer. |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null
}
```

#### Destination Monetary Required

Monetary instruments required for the destination

##### Class Name

`DestinationMonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destination_amount` | `float` | Optional | Amount transferred to the destination |
| `destination_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Monetary Required

Monetary requirements for the transfer

##### Class Name

`MonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Balance

Account monetary balance

##### Class Name

`Balance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formatted_amount` | `string` | Optional | Formatted monetary amount |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Fx Object

Currency conversion object details

##### Class Name

`FxObject`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destination_amount` | `float` | Optional | Amount transferred to the destination |
| `destination_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `source_amount` | `float` | Optional | Amount of the transfer in the specified currency. |
| `source_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `rate` | `float` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "rate": null
}
```

#### User Base

Object for the established group of users

##### Class Name

`UserBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `last_name` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `date_of_birth` | `date` | Optional | User's date of birth |
| `business_name` | `string` | Optional | Legal name for the business |
| `business_operating_name` | `string` | Optional | Name under which the business operates |
| `business_registration_id` | `string` | Optional | Registration number or ID assigned by a government body |
| `business_registration_region` | `string` | Optional | State, province, or territory where the business is registered |
| `business_registration_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_contact_role` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business |
| `business_address_line_1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `business_address_line_2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `business_address_line_3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `business_address_line_4` | `string` | Optional | fourth line of the business address street address |
| `business_address_line_5` | `string` | Optional | Fifth line of the business address street address |
| `business_city` | `string` | Optional | City the business is registered |
| `business_region` | `string` | Optional | State, province, or region the business is registered |
| `business_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_postal_code` | `string` | Optional | Postal code for the business address |
| `business_premise_number` | `string` | Optional | House number for the business address |
| `business_type` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `driver_license_id` | `string` | Optional | User's driver's license number |
| `passport_id` | `string` | Optional | User's passport number |
| `government_id_type` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type |
| `government_id` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `phone_number` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobile_number` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phone_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobile_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `employer_id` | `string` | Optional | User's employer identifier |
| `gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies |
| `user_type` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type |
| `program_user_id` | `string` | Optional | Program identifier for the user |
| `language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `country_of_birth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `country_of_nationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user |
| `tax_resident_status` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null
}
```

#### User

Object for user

##### Class Name

`User`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `last_name` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `date_of_birth` | `date` | Optional | User's date of birth |
| `business_name` | `string` | Optional | Legal name for the business |
| `business_operating_name` | `string` | Optional | Name under which the business operates |
| `business_registration_id` | `string` | Optional | Registration number or ID assigned by a government body |
| `business_registration_region` | `string` | Optional | State, province, or territory where the business is registered |
| `business_registration_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_contact_role` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business |
| `business_address_line_1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `business_address_line_2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `business_address_line_3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `business_address_line_4` | `string` | Optional | fourth line of the business address street address |
| `business_address_line_5` | `string` | Optional | Fifth line of the business address street address |
| `business_city` | `string` | Optional | City the business is registered |
| `business_region` | `string` | Optional | State, province, or region the business is registered |
| `business_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_postal_code` | `string` | Optional | Postal code for the business address |
| `business_premise_number` | `string` | Optional | House number for the business address |
| `business_type` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `driver_license_id` | `string` | Optional | User's driver's license number |
| `passport_id` | `string` | Optional | User's passport number |
| `government_id_type` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type |
| `government_id` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `phone_number` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobile_number` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phone_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobile_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `employer_id` | `string` | Optional | User's employer identifier |
| `gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies |
| `user_type` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type |
| `program_user_id` | `string` | Optional | Program identifier for the user |
| `language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `country_of_birth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `country_of_nationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user |
| `tax_resident_status` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`UserStatusTypesEnum`](#user-status-types) | Optional | Current status of the user |
| `created_on` | `datetime` | Optional | Time at which the object was created. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null
}
```

#### User-Response

Response from a user request

##### Class Name

`UserResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `last_name` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `date_of_birth` | `date` | Optional | User's date of birth |
| `business_name` | `string` | Optional | Legal name for the business |
| `business_operating_name` | `string` | Optional | Name under which the business operates |
| `business_registration_id` | `string` | Optional | Registration number or ID assigned by a government body |
| `business_registration_region` | `string` | Optional | State, province, or territory where the business is registered |
| `business_registration_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_contact_role` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business |
| `business_address_line_1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `business_address_line_2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `business_address_line_3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `business_address_line_4` | `string` | Optional | fourth line of the business address street address |
| `business_address_line_5` | `string` | Optional | Fifth line of the business address street address |
| `business_city` | `string` | Optional | City the business is registered |
| `business_region` | `string` | Optional | State, province, or region the business is registered |
| `business_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_postal_code` | `string` | Optional | Postal code for the business address |
| `business_premise_number` | `string` | Optional | House number for the business address |
| `business_type` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `driver_license_id` | `string` | Optional | User's driver's license number |
| `passport_id` | `string` | Optional | User's passport number |
| `government_id_type` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type |
| `government_id` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `phone_number` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobile_number` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phone_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobile_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `employer_id` | `string` | Optional | User's employer identifier |
| `gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies |
| `user_type` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type |
| `program_user_id` | `string` | Optional | Program identifier for the user |
| `language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `country_of_birth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `country_of_nationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user |
| `tax_resident_status` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`UserStatusTypesEnum`](#user-status-types) | Optional | Current status of the user |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null,
  "links": null
}
```

#### Receipt Base

Base for the receipt

##### Class Name

`ReceiptBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formatted_amount` | `string` | Optional | Formatted monetary amount |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Receipt Collection-Response

Response from a Receipt Collection request

##### Class Name

`ReceiptCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of ReceiptBase`](#receipt-base) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Balance Collection-Response

Response from a Balance Collection request

##### Class Name

`BalanceCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of Balance`](#balance) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Collection-Response

Response from a User Collection request

##### Class Name

`UserCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of UserResponse`](#user-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Request

Payment request

##### Class Name

`PaymentRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `client_payment_id` | `string` | Optional | Unique value provided by the client for the payment. |
| `auto_accept_quote` | `bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `not_before` | `datetime` | Optional | Transfer is scheduled and will not process before this time. |
| `not_after` | `datetime` | Optional | Transfer expires if not completed prior to this time. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payment

Response from a Transfer request

##### Class Name

`Payment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `client_payment_id` | `string` | Optional | Unique value provided by the client for the payment. |
| `auto_accept_quote` | `bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `expires` | `datetime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `not_before` | `datetime` | Optional | Transfer is scheduled and will not process before this time. |
| `not_after` | `datetime` | Optional | Transfer expires if not completed prior to this time. |
| `status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payments Collection-Response

Response from a Payment collection request

##### Class Name

`PaymentsCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of PaymentResponse`](#payment-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Response

Response from a Payment request

##### Class Name

`PaymentResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |
| `notes` | `string` | Optional | Optional comments visible to the user. |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `client_payment_id` | `string` | Optional | Unique value provided by the client for the payment. |
| `auto_accept_quote` | `bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `expires` | `datetime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `not_before` | `datetime` | Optional | Transfer is scheduled and will not process before this time. |
| `not_after` | `datetime` | Optional | Transfer expires if not completed prior to this time. |
| `status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Collection-Response

Response from a Transfer request

##### Class Name

`TransferCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of TransferResponse`](#transfer-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Name

##### Class Name

`UserName`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `last_name` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

#### Dob

##### Class Name

`Dob`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date_of_birth` | `date` | Optional | User's date of birth |

##### Example (as JSON)

```json
{
  "dateOfBirth": null
}
```

#### Business Information

Physical address of the business and other information, such as <i>Operating Name</i>, <i>Registration ID</i>, etc.

##### Class Name

`BusinessInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_name` | `string` | Optional | Legal name for the business |
| `business_operating_name` | `string` | Optional | Name under which the business operates |
| `business_registration_id` | `string` | Optional | Registration number or ID assigned by a government body |
| `business_registration_region` | `string` | Optional | State, province, or territory where the business is registered |
| `business_registration_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_contact_role` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business |
| `business_address_line_1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `business_address_line_2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `business_address_line_3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `business_address_line_4` | `string` | Optional | fourth line of the business address street address |
| `business_address_line_5` | `string` | Optional | Fifth line of the business address street address |
| `business_city` | `string` | Optional | City the business is registered |
| `business_region` | `string` | Optional | State, province, or region the business is registered |
| `business_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `business_postal_code` | `string` | Optional | Postal code for the business address |
| `business_premise_number` | `string` | Optional | House number for the business address |
| `business_type` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |

##### Example (as JSON)

```json
{
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null
}
```

#### User Kyc Information

##### Class Name

`UserKycInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `driver_license_id` | `string` | Optional | User's driver's license number |
| `passport_id` | `string` | Optional | User's passport number |
| `government_id_type` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type |
| `government_id` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |

##### Example (as JSON)

```json
{
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null
}
```

#### Phone Numbers

##### Class Name

`PhoneNumbers`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `phone_number` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `mobile_number` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `phone_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `mobile_number_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |

##### Example (as JSON)

```json
{
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC"
}
```

#### Email Address

Contact email address for the user account

##### Class Name

`EmailAddress`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |

##### Example (as JSON)

```json
{
  "email": null
}
```

#### User Employer Id

User's employer identifier, generally used for tax purposes.

##### Class Name

`UserEmployerId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `employer_id` | `string` | Optional | User's employer identifier |

##### Example (as JSON)

```json
{
  "employerId": null
}
```

#### Gender

Gender as the user identifies

##### Class Name

`Gender`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies |

##### Example (as JSON)

```json
{
  "gender": null
}
```

#### Language

Preferred language for the user's account. <i>Defaults to English</i>

##### Class Name

`Language`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format |

##### Example (as JSON)

```json
{
  "language": null
}
```

#### User Type

User's profile type

##### Class Name

`UserType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_type` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type |

##### Example (as JSON)

```json
{
  "userType": null
}
```

#### Program User Id

Program identifier for the user

##### Class Name

`ProgramUserId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `program_user_id` | `string` | Optional | Program identifier for the user |

##### Example (as JSON)

```json
{
  "programUserId": null
}
```

#### Source Destination Token

Unique identifier representing the source of the funds.

##### Class Name

`SourceDestinationToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null
}
```

#### Token

Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.

##### Class Name

`Token`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Client Transfer Id

Unique value provided by the client for the transfer, utilized for reference and deduplication.

##### Class Name

`ClientTransferId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_transfer_id` | `string` | Optional | Unique value provided by the client for the transfer. |

##### Example (as JSON)

```json
{
  "clientTransferId": null
}
```

#### Notes

Optional comments visible to the user

##### Class Name

`Notes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notes` | `string` | Optional | Optional comments visible to the user. |

##### Example (as JSON)

```json
{
  "notes": null
}
```

#### Memo

Optional internal memo not visible to the user.

##### Class Name

`Memo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `memo` | `string` | Optional | Optional internal memo not visible to the user. |

##### Example (as JSON)

```json
{
  "memo": null
}
```

#### Created On

Time at which the object was created.

##### Class Name

`CreatedOn`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `created_on` | `datetime` | Optional | Time at which the object was created. |

##### Example (as JSON)

```json
{
  "createdOn": null
}
```

#### Transfer Status

Current status of the transfer.

##### Class Name

`TransferStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### User Status

Current status of the user.

##### Class Name

`UserStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`UserStatusTypesEnum`](#user-status-types) | Optional | Current status of the user |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Payment Purpose

Purpose for the payment being made.

##### Class Name

`PaymentPurpose`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |

##### Example (as JSON)

```json
{
  "purpose": null
}
```

#### Source Token

Unique identifier representing the source of funds.

##### Class Name

`SourceToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_token` | `string` | Optional | Unique identifier representing the source of funds. |

##### Example (as JSON)

```json
{
  "sourceToken": null
}
```

#### Destination Token

Unique identifier representing the destination of funds.

##### Class Name

`DestinationToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destination_token` | `string` | Optional | Unique identifier representing the destination of funds. |

##### Example (as JSON)

```json
{
  "destinationToken": null
}
```

#### Client Payment Id

Unique value provided by the client for the payment, utilized for reference and de-duplication.

##### Class Name

`ClientPaymentId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_payment_id` | `string` | Optional | Unique value provided by the client for the payment. |

##### Example (as JSON)

```json
{
  "clientPaymentId": null
}
```

#### Auto Accept Quote

Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.

##### Class Name

`AutoAcceptQuote`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auto_accept_quote` | `bool` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |

##### Example (as JSON)

```json
{
  "autoAcceptQuote": null
}
```

#### Rate

Exchange rate

##### Class Name

`Rate`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate` | `float` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` |

##### Example (as JSON)

```json
{
  "rate": null
}
```

#### Fx

The details of the country's foreign exchange currency.

##### Class Name

`Fx`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fx` | [`FxObject`](#fx-object) | Optional | Currency conversion object details |

##### Example (as JSON)

```json
{
  "fx": null
}
```

#### Paper Check Base

##### Class Name

`PaperCheckBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |
| `shipping_method` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Type

Type of transfer method

##### Class Name

`TransferType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account Ownership

Account ownership type

##### Class Name

`BankAccountOwnership`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null
}
```

#### Shipping Method

Shipping method desired

##### Class Name

`ShippingMethod`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipping_method` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "shippingMethod": null
}
```

#### Paper Check

Details of the paper check

##### Class Name

`PaperCheck`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `mtype` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |
| `shipping_method` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check-Response

Response to a paper check request

##### Class Name

`PaperCheckResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `mtype` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type |
| `amount` | `float` | Required | Amount of the transfer in the specified currency. |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `address_line_1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `address_line_2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `address_line_3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `address_line_4` | `string` | Optional | Fourth line of the address, if any |
| `address_line_5` | `string` | Optional | Fifth line of the address, if any |
| `city` | `string` | Optional | City or town of the business address |
| `region` | `string` | Optional | State, province, or territory of the business address |
| `country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `postal_code` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `premise_number` | `string` | Optional | House or building number of the business address |
| `address_type` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |
| `shipping_method` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check Collection-Response

Response to a paper check collection request

##### Class Name

`PaperCheckCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of PaperCheck`](#paper-check) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Bank Account Fields

Classifies account field objects

##### Class Name

`BankAccountFields`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |
| `mtype` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `fields` | [`List of KeyValuePairBankFieldTypesString`](#key-value-pair-bank-field-types-string) | Optional | - |
| `bank_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `bank_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `description` | `string` | Optional | User-supplied description of the bank account for reference |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Type

Type of bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account

Unique identifier for the bank account

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`BankAccountStatusTypesEnum`](#bank-account-status-types) | Optional | Current verification status type of the bank account |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |
| `mtype` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `fields` | [`List of KeyValuePairBankFieldTypesString`](#key-value-pair-bank-field-types-string) | Optional | - |
| `bank_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `bank_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `description` | `string` | Optional | User-supplied description of the bank account for reference |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Status

Verification status of the bank account (<i>Verified</i>, <i>Disabled</i>)

##### Class Name

`BankAccountStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`BankAccountStatusTypesEnum`](#bank-account-status-types) | Optional | Current verification status type of the bank account |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Bank Account-Response

Response to the bank account request

##### Class Name

`BankAccountResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`BankAccountStatusTypesEnum`](#bank-account-status-types) | Optional | Current verification status type of the bank account |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `bank_account_ownership_type` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types |
| `mtype` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `fields` | [`List of KeyValuePairBankFieldTypesString`](#key-value-pair-bank-field-types-string) | Optional | - |
| `bank_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `bank_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `description` | `string` | Optional | User-supplied description of the bank account for reference |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null,
  "links": null
}
```

#### Bank Account Collection-Response

Collection response to the bank account request

##### Class Name

`BankAccountCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of BankAccountResponse`](#bank-account-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Prepaid Card Package

Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>, including artwork, packaging, and delivery method

##### Class Name

`PrepaidCardPackage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_package` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |

##### Example (as JSON)

```json
{
  "cardPackage": null
}
```

#### Prepaid Card Base

Base class applied to the prepaid card

##### Class Name

`PrepaidCardBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_package` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `program_token` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2"
}
```

#### Prepaid Card Status

Current status of the prepaid card

##### Class Name

`PrepaidCardStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Token Type

##### Class Name

`TokenType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token_type` | [`TokenTypesEnum`](#token-types) | Optional | Types of resources represented by a token |

##### Example (as JSON)

```json
{
  "tokenType": null
}
```

#### Prepaid Card Base Ext

Base extension for the prepaid card

##### Class Name

`PrepaidCardBaseExt`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null
}
```

#### Card Network

Major credit card network

##### Class Name

`CardNetwork`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_network` | [`CardNetworkTypesEnum`](#card-network-types) | Optional | Major credit card network types |

##### Example (as JSON)

```json
{
  "cardNetwork": null
}
```

#### Card Personalization Type

Type of personalization for the prepaid card

##### Class Name

`CardPersonalizationType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_personalization` | [`PrepaidCardPersonalizationTypesEnum`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |

##### Example (as JSON)

```json
{
  "cardPersonalization": null
}
```

#### Prepaid Card

##### Class Name

`PrepaidCard`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `card_personalization` | [`PrepaidCardPersonalizationTypesEnum`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |
| `card_package` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `card_network` | [`CardNetworkTypesEnum`](#card-network-types) | Optional | Major credit card network types |
| `expires` | `datetime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `card_number` | `string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |
| `cvv` | `string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null
}
```

#### Currency

Currency code used for the object

##### Class Name

`Currency`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "currency": null
}
```

#### Country

Two-digit country code for the object

##### Class Name

`Country`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |

##### Example (as JSON)

```json
{
  "country": "FO"
}
```

#### Prepaid Card-Request Response

##### Class Name

`PrepaidCardRequestResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "links": null
}
```

#### Prepaid Card-Response

##### Class Name

`PrepaidCardResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `card_personalization` | [`PrepaidCardPersonalizationTypesEnum`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |
| `card_package` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `card_network` | [`CardNetworkTypesEnum`](#card-network-types) | Optional | Major credit card network types |
| `expires` | `datetime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `card_number` | `string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |
| `cvv` | `string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null,
  "links": null
}
```

#### Prepaid Card Collection-Response

##### Class Name

`PrepaidCardCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of PrepaidCardResponse`](#prepaid-card-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Card Masked Pan

Card number using PAN truncation

##### Class Name

`CardMaskedPan`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_number` | `string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |

##### Example (as JSON)

```json
{
  "cardNumber": null
}
```

#### Prepaid Card Replacement Reason

##### Class Name

`PrepaidCardReplacementReason`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_replacement_reason` | [`PrepaidCardReplacementReasonTypesEnum`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. |

##### Example (as JSON)

```json
{
  "cardReplacementReason": null
}
```

#### Prepaid Card Replacement Base

##### Class Name

`PrepaidCardReplacementBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_package` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `program_token` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` |
| `card_replacement_reason` | [`PrepaidCardReplacementReasonTypesEnum`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2",
  "cardReplacementReason": null
}
```

#### Prepaid Card Pin Token

##### Class Name

`PrepaidCardPinToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_pin_token` | `string` | Optional | Token used as part of a two-leg card PIN reveal request sent directly from the client that generally involves a second piece of data, such as the CVV code on the back of the card. |
| `url` | `string` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params |

##### Example (as JSON)

```json
{
  "cardPinToken": null,
  "url": null
}
```

#### Prepaid Card Pin

##### Class Name

`PrepaidCardPin`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_pin` | `string` | Optional | Card PIN for ATM and Debit usage |

##### Example (as JSON)

```json
{
  "cardPin": null
}
```

#### Cvv

Three- or four-digit Card Verification Value (CVV) number displayed on the back of a credit or debit card

##### Class Name

`Cvv`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cvv` | `string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |

##### Example (as JSON)

```json
{
  "cvv": null
}
```

#### Identity Verification Provider Type

Provider type of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_provider` | [`IdentityVerificationProviderTypesEnum`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |

##### Example (as JSON)

```json
{
  "idvProvider": null
}
```

#### Identity Verification Result Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_result` | [`IdentityVerificationResultTypesEnum`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |

##### Example (as JSON)

```json
{
  "idvResult": null
}
```

#### Identity Verification Sub Result Type

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationSubResultType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_sub_result` | [`IdentityVerificationResultSubTypesEnum`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |

##### Example (as JSON)

```json
{
  "idvSubResult": null
}
```

#### Identity Verification Disposition Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_dispostion` | [`IdentityVerificationDispositionTypesEnum`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |

##### Example (as JSON)

```json
{
  "idvDispostion": null
}
```

#### Identity Verification Check Type

Type of verification used for performing an identity check

##### Class Name

`IdentityVerificationCheckType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_check_type` | [`IdentityVerificationCheckTypesEnum`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |

##### Example (as JSON)

```json
{
  "idvCheckType": null
}
```

#### Identity Verification Base

##### Class Name

`IdentityVerificationBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_provider_reference` | `string` | Optional | IDV provider unique ID for the IDV check performed |
| `idv_result` | [`IdentityVerificationResultTypesEnum`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `idv_sub_result` | [`IdentityVerificationResultSubTypesEnum`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |
| `idv_provider` | [`IdentityVerificationProviderTypesEnum`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `raw` | `string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |
| `idv_check_type` | [`IdentityVerificationCheckTypesEnum`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |
| `idv_dispostion` | [`IdentityVerificationDispositionTypesEnum`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null
}
```

#### Identity Verification Provider Reference

Provider reference used for performing identity checks for the provider

##### Class Name

`IdentityVerificationProviderReference`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_provider_reference` | `string` | Optional | IDV provider unique ID for the IDV check performed |

##### Example (as JSON)

```json
{
  "idvProviderReference": null
}
```

#### Identity Verification Provider Raw Output

Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only

##### Class Name

`IdentityVerificationProviderRawOutput`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `raw` | `string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |

##### Example (as JSON)

```json
{
  "raw": null
}
```

#### Identity Verification-Response

##### Class Name

`IdentityVerificationResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idv_provider_reference` | `string` | Optional | IDV provider unique ID for the IDV check performed |
| `idv_result` | [`IdentityVerificationResultTypesEnum`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `idv_sub_result` | [`IdentityVerificationResultSubTypesEnum`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |
| `idv_provider` | [`IdentityVerificationProviderTypesEnum`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |
| `created_on` | `datetime` | Optional | Time at which the object was created. |
| `raw` | `string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |
| `idv_check_type` | [`IdentityVerificationCheckTypesEnum`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |
| `idv_dispostion` | [`IdentityVerificationDispositionTypesEnum`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null,
  "links": null
}
```

#### Identity Verification Collection-Response

##### Class Name

`IdentityVerificationCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of IdentityVerificationResponse`](#identity-verification-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Key Value Pair String String

##### Class Name

`KeyValuePairStringString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string` | Optional | - |
| `value` | `string` | Optional | - |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Pair Bank Field Types String

1...N required fields as determined by call to get requirements

##### Class Name

`KeyValuePairBankFieldTypesString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | [`BankAccountFieldTypesEnum`](#bank-account-field-types) | Required | Classifies account field types |
| `value` | `string` | Required | - |

##### Example (as JSON)

```json
{
  "key": "BANK_NON_SWIFT_BIC",
  "value": "value2"
}
```

#### Key Value Pair Bank Currency Currency Types

##### Class Name

`KeyValuePairBankCurrencyCurrencyTypes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string` | Optional | **Default**: `'BANK_CURRENCY'`<br>*Default: `'BANK_CURRENCY'`* |
| `value` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Bank Country Country Types

##### Class Name

`KeyValueBankCountryCountryTypes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string` | Optional | **Default**: `'BANK_COUNTRY'`<br>*Default: `'BANK_COUNTRY'`* |
| `value` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Bank Account Required Fields

Classifies the required account field objects

##### Class Name

`BankAccountRequiredFields`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `format` | [`BankAccountRequirementFormat`](#bank-account-requirement-format) | Optional | Classifies the format of the required information for a bank account |
| `requirement` | [`BankAccountFieldTypesEnum`](#bank-account-field-types) | Optional | Classifies account field types |
| `description` | [`List of KeyValuePairLanguageTypeString`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes |
| `validators` | [`List of BankAccountRequirementValidator`](#bank-account-requirement-validator) | Optional | - |

##### Example (as JSON)

```json
{
  "format": null,
  "requirement": null,
  "description": null,
  "validators": null
}
```

#### Bank Account Requirement Format

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `example` | `string` | Optional | Example of a requirement generated from the validator(s) |
| `legend` | [`List of BankAccountRequirementFormatLegend`](#bank-account-requirement-format-legend) | Optional | - |

##### Example (as JSON)

```json
{
  "example": null,
  "legend": null
}
```

#### Bank Account Requirement Format Legend

Classifies the legend format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormatLegend`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string` | Optional | - |
| `descriptions` | [`List of KeyValuePairLanguageTypeString`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes |

##### Example (as JSON)

```json
{
  "key": null,
  "descriptions": null
}
```

#### Key Value Pair Language Type String

Localized requirement description for display purposes

##### Class Name

`KeyValuePairLanguageTypeString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `translation` | `string` | Optional | Translated string in the specified language |

##### Example (as JSON)

```json
{
  "language": null,
  "translation": null
}
```

#### Bank Account Requirement Validator

Specifies the validator type for the required bank account information

##### Class Name

`BankAccountRequirementValidator`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `validator_type` | [`ValidatorTypesEnum`](#validator-types) | Optional | - |
| `expression` | `string` | Required | Validation regular expression |

##### Example (as JSON)

```json
{
  "validatorType": null,
  "expression": "expression2"
}
```

#### Bank Account Requirement

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirement`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bank_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `bank_currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `source_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `requirements` | [`List of BankAccountRequiredFields`](#bank-account-required-fields) | Optional | - |
| `quote` | [`MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null
}
```

#### Bank Account Requirement-Response

##### Class Name

`BankAccountRequirementResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bank_country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `bank_currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `source_country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `source_currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object |
| `requirements` | [`List of BankAccountRequiredFields`](#bank-account-required-fields) | Optional | - |
| `quote` | [`MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null,
  "links": null
}
```

#### Bank Account Requirement Collection-Response

##### Class Name

`BankAccountRequirementCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payload` | [`List of BankAccountRequirementResponse`](#bank-account-requirement-response) | Optional | - |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Occupation

##### Class Name

`Occupation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user |

##### Example (as JSON)

```json
{
  "occupation": null
}
```

#### Tax Resident Status

##### Class Name

`TaxResidentStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_resident_status` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country |

##### Example (as JSON)

```json
{
  "taxResidentStatus": null
}
```

#### Webhook-Subscription

Webhook subscription object

##### Class Name

`WebhookSubscription`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `string` | Optional | - |
| `namespace` | [`NamespaceEnum`](#namespace) | Optional | Namespace used to identify and refer to the object |

##### Example (as JSON)

```json
{
  "url": null,
  "namespace": null
}
```

#### Webhook-Subscription-Response

Webhook Subscription response

##### Class Name

`WebhookSubscriptionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |
| `url` | `string` | Optional | - |
| `namespace` | [`NamespaceEnum`](#namespace) | Optional | Namespace used to identify and refer to the object |
| `token` | `string` | Optional | Token for the webhook subscription |
| `created` | `string` | Optional | Time stamp for the date the webhook subscription was created |
| `last_updated` | `string` | Optional | Time stamp for the date the webhook subscription was updated |

##### Example (as JSON)

```json
{
  "links": null,
  "url": null,
  "namespace": null,
  "token": null,
  "created": null,
  "lastUpdated": null
}
```

#### Webhook Collection-Response

Webhook Subscription collection response

##### Class Name

`WebhookCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`List of HaetosParams`](#haetos-params) | Optional | - |
| `payload` | [`List of WebhookSubscriptionResponse`](#webhook-subscription-response) | Optional | - |

##### Example (as JSON)

```json
{
  "links": null,
  "payload": null
}
```

#### Prepaid Card Data-Response

Response to the prepaid card data request

##### Class Name

`PrepaidCardDataResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `card_image` | `string` | Optional | - |
| `card_number` | `float` | Optional | - |
| `cvv_number` | `string` | Optional | - |
| `expiration` | `string` | Optional | - |
| `name_on_card` | `string` | Optional | - |
| `side` | `string` | Optional | - |
| `token` | `string` | Optional | - |

##### Example (as JSON)

```json
{
  "cardImage": null,
  "cardNumber": null,
  "cvvNumber": null,
  "expiration": null,
  "nameOnCard": null,
  "side": null,
  "token": null
}
```

#### Prepaid Card Data Token

Token assigned to the prepaid card

##### Class Name

`PrepaidCardDataToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Required | **Constraints**: *Minimum Length*: `1` |
| `url` | `string` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params |

##### Example (as JSON)

```json
{
  "token": "token6",
  "url": null
}
```

#### Prepaid Card Data Token-Response

##### Class Name

`PrepaidCardDataTokenResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | [`PrepaidCardDataToken`](#prepaid-card-data-token) | Optional | Token assigned to the prepaid card |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Business Type

##### Class Name

`BusinessType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_type` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |

##### Example (as JSON)

```json
{
  "businessType": null
}
```

#### Country Nationality Information

##### Class Name

`CountryNationalityInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_of_birth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |
| `country_of_nationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types |

##### Example (as JSON)

```json
{
  "countryOfBirth": null,
  "countryOfNationality": null
}
```

#### Users Prepaid Cards Pin Response

##### Class Name

`UsersPrepaidCardsPinResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | `bool` | Optional | - |

##### Example (as JSON)

```json
{
  "result": null
}
```

### Enumerations

* [Transfer Status Types](#transfer-status-types)
* [Payment Purpose Types](#payment-purpose-types)
* [Address Types](#address-types)
* [User Types](#user-types)
* [User Status Types](#user-status-types)
* [Language Types](#language-types)
* [Gender Types](#gender-types)
* [Business Types](#business-types)
* [Transfer Types](#transfer-types)
* [Shipping Method Types](#shipping-method-types)
* [Bank Account Ownership Types](#bank-account-ownership-types)
* [Bank Account Types](#bank-account-types)
* [Bank Account Status Types](#bank-account-status-types)
* [Token Types](#token-types)
* [Card Network Types](#card-network-types)
* [Prepaid Card Personalization Types](#prepaid-card-personalization-types)
* [Currency Types](#currency-types)
* [Country Types](#country-types)
* [Prepaid Card Replacement Reason Types](#prepaid-card-replacement-reason-types)
* [Identity Verification Provider Types](#identity-verification-provider-types)
* [Identity Verification Result Types](#identity-verification-result-types)
* [Identity Verification Result Sub Types](#identity-verification-result-sub-types)
* [Identity Verification Disposition Types](#identity-verification-disposition-types)
* [Identity Verification Check Types](#identity-verification-check-types)
* [Bank Account Field Types](#bank-account-field-types)
* [Validator Types](#validator-types)
* [Occupation Types](#occupation-types)
* [Tax Resident Status Types](#tax-resident-status-types)
* [Namespace](#namespace)
* [Business Contact Role](#business-contact-role)
* [Format](#format)
* [Government Id Type](#government-id-type)
* [Side](#side)
* [Status](#status)

#### Transfer Status Types

Current status of a transfer

##### Class Name

`TransferStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `QUOTED` |
| `PENDING` |
| `SCHEDULED` |
| `COMPLETED` |
| `CANCELLED` |
| `RETURNED` |
| `FAILED` |
| `EXPIRED` |
| `VERIFICATION_HOLD` |

#### Payment Purpose Types

Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services)

##### Class Name

`PaymentPurposeTypesEnum`

##### Fields

| Name |
|  --- |
| `OTHER` |
| `TAXABLE` |
| `INCOME` |
| `BONUS` |
| `EXPENSE` |
| `NON_TAXABLE` |

#### Address Types

Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)

##### Class Name

`AddressTypesEnum`

##### Fields

| Name |
|  --- |
| `RESIDENTIAL` |
| `BUSINESS` |
| `MAILING` |

#### User Types

Account holder's profile type

##### Class Name

`UserTypesEnum`

##### Fields

| Name |
|  --- |
| `INDIVIDUAL` |
| `BUSINESS` |

#### User Status Types

Current status of the user

##### Class Name

`UserStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `ACTIVATED` |
| `PRE_ACTIVATED` |
| `PENDING_EMAIL_VERIFICATION` |
| `PENDING_KYC` |

#### Language Types

Language type in IETF's BCP 47 format

##### Class Name

`LanguageTypesEnum`

##### Fields

| Name |
|  --- |
| `ENUS` |
| `ENGB` |
| `FRCA` |
| `FRFR` |
| `ESMX` |
| `ESES` |
| `PTBR` |
| `PTPT` |
| `DEDE` |
| `ITIT` |
| `JAJP` |
| `ZHCN` |
| `ZHTW` |

#### Gender Types

Gender as a user identifies

##### Class Name

`GenderTypesEnum`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |
| `NOT_SPECIFIED` |

#### Business Types

Type of business (<i>Corporation</i> or <i>Partnership</i>)

##### Class Name

`BusinessTypesEnum`

##### Fields

| Name |
|  --- |
| `CORPORATION` |
| `PARTNERSHIP_DBA` |

#### Transfer Types

Transfer type

##### Class Name

`TransferTypesEnum`

##### Fields

| Name |
|  --- |
| `PAPER_CHECK` |
| `BANK_TRANSFER` |
| `PAYMENT` |
| `SPEND_BACK` |

#### Shipping Method Types

Shipping method type for a pre-paid card or paper check

##### Class Name

`ShippingMethodTypesEnum`

##### Fields

| Name |
|  --- |
| `STANDARD` |
| `EXPEDITED` |

#### Bank Account Ownership Types

Account ownership types

##### Class Name

`BankAccountOwnershipTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

#### Bank Account Types

Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountTypesEnum`

##### Fields

| Name |
|  --- |
| `CHECKING` |
| `SAVINGS` |
| `MONEY_MARKET` |

#### Bank Account Status Types

Current verification status type of the bank account

##### Class Name

`BankAccountStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `DELETED` |
| `ACTIVE` |
| `PENDING_VERIFICATION` |

#### Token Types

Types of resources represented by a token

##### Class Name

`TokenTypesEnum`

##### Fields

| Name |
|  --- |
| `BANK_ACCOUNT` |
| `TRANSFER` |
| `PAYMENT` |
| `SPEND_BACK` |
| `PREPAID_CARD` |
| `USER` |
| `DOCUMENT` |
| `ACCOUNT` |

#### Card Network Types

Major credit card network types

##### Class Name

`CardNetworkTypesEnum`

##### Fields

| Name |
|  --- |
| `VISA` |
| `MASTER_CARD` |

#### Prepaid Card Personalization Types

Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer)

##### Class Name

`PrepaidCardPersonalizationTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONALIZED` |
| `NON_PERSONALIZED` |

#### Currency Types

Currency code type for the object

##### Class Name

`CurrencyTypesEnum`

##### Fields

| Name |
|  --- |
| `USD` |
| `CAD` |
| `MXN` |
| `AUD` |
| `HKD` |
| `NZD` |
| `EUR` |
| `GBP` |

#### Country Types

Two-digit country code types

##### Class Name

`CountryTypesEnum`

##### Fields

| Name |
|  --- |
| `AD` |
| `AE` |
| `AF` |
| `AG` |
| `AI` |
| `AL` |
| `AM` |
| `AN` |
| `AO` |
| `AQ` |
| `AR` |
| `AS` |
| `AT` |
| `AU` |
| `AW` |
| `AX` |
| `AZ` |
| `BA` |
| `BB` |
| `BD` |
| `BE` |
| `BF` |
| `BG` |
| `BH` |
| `BI` |
| `BJ` |
| `BL` |
| `BM` |
| `BN` |
| `BO` |
| `BQ` |
| `BR` |
| `BS` |
| `BT` |
| `BV` |
| `BW` |
| `BY` |
| `BZ` |
| `CA` |
| `CC` |
| `CD` |
| `CF` |
| `CG` |
| `CH` |
| `CI` |
| `CK` |
| `CL` |
| `CM` |
| `CN` |
| `CO` |
| `CR` |
| `CU` |
| `CV` |
| `CW` |
| `CX` |
| `CY` |
| `CZ` |
| `DE` |
| `DJ` |
| `DK` |
| `DM` |
| `DO` |
| `DZ` |
| `EC` |
| `EE` |
| `EG` |
| `EH` |
| `ER` |
| `ES` |
| `ET` |
| `FI` |
| `FJ` |
| `FK` |
| `FM` |
| `FO` |
| `FR` |
| `GA` |
| `GB` |
| `GD` |
| `GE` |
| `GF` |
| `GG` |
| `GH` |
| `GI` |
| `GL` |
| `GM` |
| `GN` |
| `GP` |
| `GQ` |
| `GR` |
| `GS` |
| `GT` |
| `GU` |
| `GW` |
| `GY` |
| `HK` |
| `HM` |
| `HN` |
| `HR` |
| `HT` |
| `HU` |
| `ID` |
| `IE` |
| `IL` |
| `IM` |
| `IN` |
| `IO` |
| `IQ` |
| `IR` |
| `IS` |
| `IT` |
| `JE` |
| `JM` |
| `JO` |
| `JP` |
| `KE` |
| `KG` |
| `KH` |
| `KI` |
| `KM` |
| `KN` |
| `KP` |
| `KR` |
| `KW` |
| `KY` |
| `KZ` |
| `LA` |
| `LB` |
| `LC` |
| `LI` |
| `LK` |
| `LR` |
| `LS` |
| `LT` |
| `LU` |
| `LV` |
| `LY` |
| `MA` |
| `MC` |
| `MD` |
| `ME` |
| `MF` |
| `MG` |
| `MH` |
| `MK` |
| `ML` |
| `MM` |
| `MN` |
| `MO` |
| `MP` |
| `MQ` |
| `MR` |
| `MS` |
| `MT` |
| `MU` |
| `MV` |
| `MW` |
| `MX` |
| `MY` |
| `MZ` |
| `NA` |
| `NC` |
| `NE` |
| `NF` |
| `NG` |
| `NI` |
| `NL` |
| `NO` |
| `NP` |
| `NR` |
| `NU` |
| `NZ` |
| `OM` |
| `PA` |
| `PE` |
| `PF` |
| `PG` |
| `PH` |
| `PK` |
| `PL` |
| `PM` |
| `PN` |
| `PR` |
| `PS` |
| `PT` |
| `PW` |
| `PY` |
| `QA` |
| `RE` |
| `RO` |
| `RS` |
| `RU` |
| `RW` |
| `SA` |
| `SB` |
| `SC` |
| `SD` |
| `SE` |
| `SG` |
| `SH` |
| `SI` |
| `SJ` |
| `SK` |
| `SL` |
| `SM` |
| `SN` |
| `SO` |
| `SR` |
| `SS` |
| `ST` |
| `SV` |
| `SX` |
| `SY` |
| `SZ` |
| `TC` |
| `TD` |
| `TF` |
| `TG` |
| `TH` |
| `TJ` |
| `TK` |
| `TL` |
| `TM` |
| `TN` |
| `TO` |
| `TR` |
| `TT` |
| `TV` |
| `TW` |
| `TZ` |
| `UA` |
| `UG` |
| `UM` |
| `US` |
| `UY` |
| `UZ` |
| `VA` |
| `VC` |
| `VE` |
| `VG` |
| `VI` |
| `VN` |
| `VU` |
| `WF` |
| `WS` |
| `YE` |
| `YT` |
| `ZA` |
| `ZM` |
| `ZW` |

#### Prepaid Card Replacement Reason Types

Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility.

##### Class Name

`PrepaidCardReplacementReasonTypesEnum`

##### Fields

| Name |
|  --- |
| `LOST` |
| `STOLEN` |
| `DAMAGED` |
| `COMPROMISED` |
| `EXPIRED` |

#### Identity Verification Provider Types

Provider types of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderTypesEnum`

##### Fields

| Name |
|  --- |
| `W2` |
| `IDOLOGY` |
| `BANK` |
| `EQUIFAX` |
| `OFAC` |
| `LEXUS_NEXUS` |

#### Identity Verification Result Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultTypesEnum`

##### Fields

| Name |
|  --- |
| `PASS` |
| `FAIL` |
| `SERVICE_OFFLINE` |
| `PROCESSING` |

#### Identity Verification Result Sub Types

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationResultSubTypesEnum`

##### Fields

| Name |
|  --- |
| `HARD` |
| `SOFT` |

#### Identity Verification Disposition Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionTypesEnum`

##### Fields

| Name |
|  --- |
| `TRANSIENT` |
| `FINAL` |

#### Identity Verification Check Types

Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.)

##### Class Name

`IdentityVerificationCheckTypesEnum`

##### Fields

| Name |
|  --- |
| `DOCUMENTARY` |
| `NON_DOCUMENTARY` |
| `OFAC` |

#### Bank Account Field Types

Classifies account field types

##### Class Name

`BankAccountFieldTypesEnum`

##### Fields

| Name |
|  --- |
| `BANK_ACH_ABA` |
| `BANK_BBAN` |
| `BANK_BRANCH_CODE` |
| `BANK_BSB_CODE` |
| `BANK_CITY` |
| `BANK_CLABE` |
| `BANK_CODE` |
| `BANK_CURP` |
| `BANK_IBAN` |
| `BANK_NAME` |
| `BANK_NON_SWIFT_BIC` |
| `BANK_NUBAN` |
| `BANK_PHONE_NUMBER` |
| `BANK_POSTAL_CODE` |
| `BANK_REGION` |
| `BANK_RFC` |
| `BANK_SORT_CODE` |
| `BANK_STREET_ADDRESS` |
| `BANK_SWIFT_BIC` |
| `BANK_TRANSIT_CODE` |
| `BENEFICIARY_ACCOUNT_NUMBER` |
| `BENEFICIARY_PHONE_NUMBER` |
| `BENEFICIARY_TAX_ID` |
| `BENEFICIARY_NAME` |
| `BANK_BRANCH_NAME` |
| `BANK_PURPOSE_OF_PAYMENT_CODE` |
| `BANK_VALUE_ADD_TAX` |

#### Validator Types

##### Class Name

`ValidatorTypesEnum`

##### Fields

| Name |
|  --- |
| `REGEX` |
| `LENGTH` |

#### Occupation Types

Type of occupation for the user

##### Class Name

`OccupationTypesEnum`

##### Fields

| Name |
|  --- |
| `INDEPENDENT_BUSINESS_OWNER` |
| `SCIENCE` |
| `TECHNOLOGY` |
| `ENGINEERING` |
| `MATH` |
| `HEALTHCARE` |
| `SOCIAL_SERVICES` |
| `MEDIA` |
| `FINANCE` |
| `GOVERNMENT` |
| `MANUFACTURING` |
| `LAW` |
| `HOSPITALITY_AND_TOURISM` |
| `ARTS` |
| `DESIGN` |
| `OFFICE_AND_ADMIN_SUPPORT` |
| `EDUCATION` |

#### Tax Resident Status Types

Tax resident status type of a country

##### Class Name

`TaxResidentStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `YES` |
| `NO` |
| `PREFER_NOT_TO_ANSWER` |

#### Namespace

Namespace used to identify and refer to the object

##### Class Name

`NamespaceEnum`

##### Fields

| Name |
|  --- |
| `ENUM_BANKACCOUNTSUPDATEDSTATUSAPPROVED` |
| `ENUM_PREPAIDCARDSCREATED` |
| `ENUM_TRANSFERSACCEPTED` |

#### Business Contact Role

Role of the user within the business

##### Class Name

`BusinessContactRoleEnum`

##### Fields

| Name |
|  --- |
| `OWNER` |
| `MANAGER` |
| `PARTNER` |
| `OTHER` |

#### Format

##### Class Name

`FormatEnum`

##### Fields

| Name |
|  --- |
| `TEXT` |
| `IMAGE` |
| `ENUM_TEXTIMAGE` |

#### Government Id Type

User's government ID type

##### Class Name

`GovernmentIdTypeEnum`

##### Fields

| Name |
|  --- |
| `PASSPORT` |
| `NATIONAL_ID_CARD` |
| `CURP` |

#### Side

##### Class Name

`SideEnum`

##### Fields

| Name |
|  --- |
| `FRONT` |
| `BACK` |

#### Status

Current status of the prepaid card

##### Class Name

`StatusEnum`

##### Fields

| Name |
|  --- |
| `QUEUED` |
| `LOST_STOLEN_DAMAGED` |
| `ACTIVATED` |
| `PENDING_ACTIVATION` |
| `SUSPENDED` |
| `COMPLIANCE_HOLD` |
| `KYC_HOLD` |
| `LOCKED` |

## Utility Classes Documentation

### ApiHelper

A utility class for processing API Calls. Also contains classes for supporting standard datetime formats.

#### Methods

| Name | Description |
|  --- | --- |
| json_deserialize | Deserializes a JSON string to a Python dictionary. |

#### Classes

| Name | Description |
|  --- | --- |
| HttpDateTime | A wrapper for datetime to support HTTP date format. |
| UnixDateTime | A wrapper for datetime to support Unix date format. |
| RFC3339DateTime | A wrapper for datetime to support RFC3339 format. |

## Common Code Documentation

### HttpResponse

Http response received.

#### Parameters

| Name | Type | Description |
|  --- | --- | --- |
| status_code | int | The status code returned by the server. |
| reason_phrase | str | The reason phrase returned by the server. |
| headers | dict | Response headers. |
| text | str | Response body. |
| request | HttpRequest | The request that resulted in this response. |

### HttpRequest

Represents a single Http Request.

#### Parameters

| Name | Type | Tag | Description |
|  --- | --- | --- | --- |
| http_method | HttpMethodEnum |  | The HTTP method of the request. |
| query_url | str |  | The endpoint URL for the API request. |
| headers | dict | optional | Request headers. |
| query_parameters | dict | optional | Query parameters to add in the URL. |
| parameters | dict &#124; str | optional | Request body, either as a serialized string or else a list of parameters to form encode. |
| files | dict | optional | Files to be sent with the request. |

