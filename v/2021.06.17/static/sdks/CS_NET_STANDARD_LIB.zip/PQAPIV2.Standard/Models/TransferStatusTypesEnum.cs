// <copyright file="TransferStatusTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// TransferStatusTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TransferStatusTypesEnum
    {
        /// <summary>
        /// QUOTED.
        /// </summary>
        [EnumMember(Value = "QUOTED")]
        QUOTED,

        /// <summary>
        /// PENDING.
        /// </summary>
        [EnumMember(Value = "PENDING")]
        PENDING,

        /// <summary>
        /// SCHEDULED.
        /// </summary>
        [EnumMember(Value = "SCHEDULED")]
        SCHEDULED,

        /// <summary>
        /// COMPLETED.
        /// </summary>
        [EnumMember(Value = "COMPLETED")]
        COMPLETED,

        /// <summary>
        /// CANCELLED.
        /// </summary>
        [EnumMember(Value = "CANCELLED")]
        CANCELLED,

        /// <summary>
        /// RETURNED.
        /// </summary>
        [EnumMember(Value = "RETURNED")]
        RETURNED,

        /// <summary>
        /// FAILED.
        /// </summary>
        [EnumMember(Value = "FAILED")]
        FAILED,

        /// <summary>
        /// EXPIRED.
        /// </summary>
        [EnumMember(Value = "EXPIRED")]
        EXPIRED,

        /// <summary>
        /// VERIFICATIONHOLD.
        /// </summary>
        [EnumMember(Value = "VERIFICATION_HOLD")]
        VERIFICATIONHOLD,
    }
}