// <copyright file="WebhookSubscriptionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// WebhookSubscriptionResponse.
    /// </summary>
    public class WebhookSubscriptionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WebhookSubscriptionResponse"/> class.
        /// </summary>
        public WebhookSubscriptionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WebhookSubscriptionResponse"/> class.
        /// </summary>
        /// <param name="links">links.</param>
        /// <param name="url">url.</param>
        /// <param name="mNamespace">namespace.</param>
        /// <param name="token">token.</param>
        /// <param name="created">created.</param>
        /// <param name="lastUpdated">lastUpdated.</param>
        public WebhookSubscriptionResponse(
            List<Models.HaetosParams> links = null,
            string url = null,
            Models.NamespaceEnum? mNamespace = null,
            string token = null,
            string created = null,
            string lastUpdated = null)
        {
            this.Links = links;
            this.Url = url;
            this.MNamespace = mNamespace;
            this.Token = token;
            this.Created = created;
            this.LastUpdated = lastUpdated;
        }

        /// <summary>
        /// Gets or sets Links.
        /// </summary>
        [JsonProperty("links", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.HaetosParams> Links { get; set; }

        /// <summary>
        /// Gets or sets Url.
        /// </summary>
        [JsonProperty("url", NullValueHandling = NullValueHandling.Ignore)]
        public string Url { get; set; }

        /// <summary>
        /// Namespace used to identify and refer to the object
        /// </summary>
        [JsonProperty("namespace", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.NamespaceEnum? MNamespace { get; set; }

        /// <summary>
        /// Token for the webhook subscription
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// Time stamp for the date the webhook subscription was created
        /// </summary>
        [JsonProperty("created", NullValueHandling = NullValueHandling.Ignore)]
        public string Created { get; set; }

        /// <summary>
        /// Time stamp for the date the webhook subscription was updated
        /// </summary>
        [JsonProperty("lastUpdated", NullValueHandling = NullValueHandling.Ignore)]
        public string LastUpdated { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"WebhookSubscriptionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is WebhookSubscriptionResponse other &&
                ((this.Links == null && other.Links == null) || (this.Links?.Equals(other.Links) == true)) &&
                ((this.Url == null && other.Url == null) || (this.Url?.Equals(other.Url) == true)) &&
                ((this.MNamespace == null && other.MNamespace == null) || (this.MNamespace?.Equals(other.MNamespace) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.Created == null && other.Created == null) || (this.Created?.Equals(other.Created) == true)) &&
                ((this.LastUpdated == null && other.LastUpdated == null) || (this.LastUpdated?.Equals(other.LastUpdated) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -934157691;

            if (this.Links != null)
            {
               hashCode += this.Links.GetHashCode();
            }

            if (this.Url != null)
            {
               hashCode += this.Url.GetHashCode();
            }

            if (this.MNamespace != null)
            {
               hashCode += this.MNamespace.GetHashCode();
            }

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            if (this.Created != null)
            {
               hashCode += this.Created.GetHashCode();
            }

            if (this.LastUpdated != null)
            {
               hashCode += this.LastUpdated.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Links = {(this.Links == null ? "null" : $"[{string.Join(", ", this.Links)} ]")}");
            toStringOutput.Add($"this.Url = {(this.Url == null ? "null" : this.Url == string.Empty ? "" : this.Url)}");
            toStringOutput.Add($"this.MNamespace = {(this.MNamespace == null ? "null" : this.MNamespace.ToString())}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.Created = {(this.Created == null ? "null" : this.Created == string.Empty ? "" : this.Created)}");
            toStringOutput.Add($"this.LastUpdated = {(this.LastUpdated == null ? "null" : this.LastUpdated == string.Empty ? "" : this.LastUpdated)}");
        }
    }
}