// <copyright file="ShippingMethod.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// ShippingMethod.
    /// </summary>
    public class ShippingMethod
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingMethod"/> class.
        /// </summary>
        public ShippingMethod()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingMethod"/> class.
        /// </summary>
        /// <param name="shippingMethodProp">shippingMethod.</param>
        public ShippingMethod(
            Models.ShippingMethodTypesEnum? shippingMethodProp = null)
        {
            this.ShippingMethodProp = shippingMethodProp;
        }

        /// <summary>
        /// Shipping method type for a pre-paid card or paper check
        /// </summary>
        [JsonProperty("shippingMethod", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippingMethodTypesEnum? ShippingMethodProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippingMethod : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippingMethod other &&
                ((this.ShippingMethodProp == null && other.ShippingMethodProp == null) || (this.ShippingMethodProp?.Equals(other.ShippingMethodProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -909886199;

            if (this.ShippingMethodProp != null)
            {
               hashCode += this.ShippingMethodProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShippingMethodProp = {(this.ShippingMethodProp == null ? "null" : this.ShippingMethodProp.ToString())}");
        }
    }
}