// <copyright file="PhoneNumbers.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PhoneNumbers.
    /// </summary>
    public class PhoneNumbers
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PhoneNumbers"/> class.
        /// </summary>
        public PhoneNumbers()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PhoneNumbers"/> class.
        /// </summary>
        /// <param name="phoneNumber">phoneNumber.</param>
        /// <param name="mobileNumber">mobileNumber.</param>
        /// <param name="phoneNumberCountry">phoneNumberCountry.</param>
        /// <param name="mobileNumberCountry">mobileNumberCountry.</param>
        public PhoneNumbers(
            string phoneNumber,
            string mobileNumber,
            Models.CountryTypesEnum phoneNumberCountry,
            Models.CountryTypesEnum mobileNumberCountry)
        {
            this.PhoneNumber = phoneNumber;
            this.MobileNumber = mobileNumber;
            this.PhoneNumberCountry = phoneNumberCountry;
            this.MobileNumberCountry = mobileNumberCountry;
        }

        /// <summary>
        /// The E.164 formatted primary phone number. This can be the same as the mobile number.
        /// </summary>
        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared.
        /// </summary>
        [JsonProperty("mobileNumber")]
        public string MobileNumber { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("phoneNumberCountry", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CountryTypesEnum PhoneNumberCountry { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("mobileNumberCountry", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CountryTypesEnum MobileNumberCountry { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PhoneNumbers : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PhoneNumbers other &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true)) &&
                ((this.MobileNumber == null && other.MobileNumber == null) || (this.MobileNumber?.Equals(other.MobileNumber) == true)) &&
                this.PhoneNumberCountry.Equals(other.PhoneNumberCountry) &&
                this.MobileNumberCountry.Equals(other.MobileNumberCountry);
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1578494391;

            if (this.PhoneNumber != null)
            {
               hashCode += this.PhoneNumber.GetHashCode();
            }

            if (this.MobileNumber != null)
            {
               hashCode += this.MobileNumber.GetHashCode();
            }

            hashCode += this.PhoneNumberCountry.GetHashCode();
            hashCode += this.MobileNumberCountry.GetHashCode();

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber == string.Empty ? "" : this.PhoneNumber)}");
            toStringOutput.Add($"this.MobileNumber = {(this.MobileNumber == null ? "null" : this.MobileNumber == string.Empty ? "" : this.MobileNumber)}");
            toStringOutput.Add($"this.PhoneNumberCountry = {this.PhoneNumberCountry}");
            toStringOutput.Add($"this.MobileNumberCountry = {this.MobileNumberCountry}");
        }
    }
}