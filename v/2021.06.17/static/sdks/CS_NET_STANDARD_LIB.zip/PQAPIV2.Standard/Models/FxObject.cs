// <copyright file="FxObject.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// FxObject.
    /// </summary>
    public class FxObject
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FxObject"/> class.
        /// </summary>
        public FxObject()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FxObject"/> class.
        /// </summary>
        /// <param name="destinationAmount">destinationAmount.</param>
        /// <param name="destinationCurrency">destinationCurrency.</param>
        /// <param name="sourceAmount">sourceAmount.</param>
        /// <param name="sourceCurrency">sourceCurrency.</param>
        /// <param name="rate">rate.</param>
        public FxObject(
            double? destinationAmount = null,
            Models.CurrencyTypesEnum? destinationCurrency = null,
            double? sourceAmount = null,
            Models.CurrencyTypesEnum? sourceCurrency = null,
            double? rate = null)
        {
            this.DestinationAmount = destinationAmount;
            this.DestinationCurrency = destinationCurrency;
            this.SourceAmount = sourceAmount;
            this.SourceCurrency = sourceCurrency;
            this.Rate = rate;
        }

        /// <summary>
        /// Amount transferred to the destination
        /// </summary>
        [JsonProperty("destinationAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DestinationAmount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("destinationCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? DestinationCurrency { get; set; }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("sourceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? SourceAmount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("sourceCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? SourceCurrency { get; set; }

        /// <summary>
        /// Exchange rate
        /// </summary>
        [JsonProperty("rate", NullValueHandling = NullValueHandling.Ignore)]
        public double? Rate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FxObject : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FxObject other &&
                ((this.DestinationAmount == null && other.DestinationAmount == null) || (this.DestinationAmount?.Equals(other.DestinationAmount) == true)) &&
                ((this.DestinationCurrency == null && other.DestinationCurrency == null) || (this.DestinationCurrency?.Equals(other.DestinationCurrency) == true)) &&
                ((this.SourceAmount == null && other.SourceAmount == null) || (this.SourceAmount?.Equals(other.SourceAmount) == true)) &&
                ((this.SourceCurrency == null && other.SourceCurrency == null) || (this.SourceCurrency?.Equals(other.SourceCurrency) == true)) &&
                ((this.Rate == null && other.Rate == null) || (this.Rate?.Equals(other.Rate) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -2129160518;

            if (this.DestinationAmount != null)
            {
               hashCode += this.DestinationAmount.GetHashCode();
            }

            if (this.DestinationCurrency != null)
            {
               hashCode += this.DestinationCurrency.GetHashCode();
            }

            if (this.SourceAmount != null)
            {
               hashCode += this.SourceAmount.GetHashCode();
            }

            if (this.SourceCurrency != null)
            {
               hashCode += this.SourceCurrency.GetHashCode();
            }

            if (this.Rate != null)
            {
               hashCode += this.Rate.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DestinationAmount = {(this.DestinationAmount == null ? "null" : this.DestinationAmount.ToString())}");
            toStringOutput.Add($"this.DestinationCurrency = {(this.DestinationCurrency == null ? "null" : this.DestinationCurrency.ToString())}");
            toStringOutput.Add($"this.SourceAmount = {(this.SourceAmount == null ? "null" : this.SourceAmount.ToString())}");
            toStringOutput.Add($"this.SourceCurrency = {(this.SourceCurrency == null ? "null" : this.SourceCurrency.ToString())}");
            toStringOutput.Add($"this.Rate = {(this.Rate == null ? "null" : this.Rate.ToString())}");
        }
    }
}