// <copyright file="BankAccountFields.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountFields.
    /// </summary>
    public class BankAccountFields
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountFields"/> class.
        /// </summary>
        public BankAccountFields()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountFields"/> class.
        /// </summary>
        /// <param name="bankAccountOwnershipType">bankAccountOwnershipType.</param>
        /// <param name="type">type.</param>
        /// <param name="fields">fields.</param>
        /// <param name="bankCurrency">bankCurrency.</param>
        /// <param name="bankCountry">bankCountry.</param>
        /// <param name="description">description.</param>
        public BankAccountFields(
            Models.BankAccountOwnershipTypesEnum? bankAccountOwnershipType = null,
            Models.BankAccountTypesEnum? type = null,
            List<Models.KeyValuePairBankFieldTypesString> fields = null,
            Models.CurrencyTypesEnum? bankCurrency = null,
            Models.CountryTypesEnum? bankCountry = null,
            string description = null)
        {
            this.BankAccountOwnershipType = bankAccountOwnershipType;
            this.Type = type;
            this.Fields = fields;
            this.BankCurrency = bankCurrency;
            this.BankCountry = bankCountry;
            this.Description = description;
        }

        /// <summary>
        /// Account ownership types
        /// </summary>
        [JsonProperty("bankAccountOwnershipType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountOwnershipTypesEnum? BankAccountOwnershipType { get; set; }

        /// <summary>
        /// Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountTypesEnum? Type { get; set; }

        /// <summary>
        /// Gets or sets Fields.
        /// </summary>
        [JsonProperty("fields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.KeyValuePairBankFieldTypesString> Fields { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("bankCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? BankCurrency { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("bankCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? BankCountry { get; set; }

        /// <summary>
        /// User-supplied description of the bank account for reference
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccountFields : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccountFields other &&
                ((this.BankAccountOwnershipType == null && other.BankAccountOwnershipType == null) || (this.BankAccountOwnershipType?.Equals(other.BankAccountOwnershipType) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Fields == null && other.Fields == null) || (this.Fields?.Equals(other.Fields) == true)) &&
                ((this.BankCurrency == null && other.BankCurrency == null) || (this.BankCurrency?.Equals(other.BankCurrency) == true)) &&
                ((this.BankCountry == null && other.BankCountry == null) || (this.BankCountry?.Equals(other.BankCountry) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1285960372;

            if (this.BankAccountOwnershipType != null)
            {
               hashCode += this.BankAccountOwnershipType.GetHashCode();
            }

            if (this.Type != null)
            {
               hashCode += this.Type.GetHashCode();
            }

            if (this.Fields != null)
            {
               hashCode += this.Fields.GetHashCode();
            }

            if (this.BankCurrency != null)
            {
               hashCode += this.BankCurrency.GetHashCode();
            }

            if (this.BankCountry != null)
            {
               hashCode += this.BankCountry.GetHashCode();
            }

            if (this.Description != null)
            {
               hashCode += this.Description.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BankAccountOwnershipType = {(this.BankAccountOwnershipType == null ? "null" : this.BankAccountOwnershipType.ToString())}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type.ToString())}");
            toStringOutput.Add($"this.Fields = {(this.Fields == null ? "null" : $"[{string.Join(", ", this.Fields)} ]")}");
            toStringOutput.Add($"this.BankCurrency = {(this.BankCurrency == null ? "null" : this.BankCurrency.ToString())}");
            toStringOutput.Add($"this.BankCountry = {(this.BankCountry == null ? "null" : this.BankCountry.ToString())}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
        }
    }
}