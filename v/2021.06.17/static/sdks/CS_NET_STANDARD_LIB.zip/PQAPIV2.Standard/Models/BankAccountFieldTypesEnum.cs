// <copyright file="BankAccountFieldTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountFieldTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BankAccountFieldTypesEnum
    {
        /// <summary>
        /// BANKACHABA.
        /// </summary>
        [EnumMember(Value = "BANK_ACH_ABA")]
        BANKACHABA,

        /// <summary>
        /// BANKBBAN.
        /// </summary>
        [EnumMember(Value = "BANK_BBAN")]
        BANKBBAN,

        /// <summary>
        /// BANKBRANCHCODE.
        /// </summary>
        [EnumMember(Value = "BANK_BRANCH_CODE")]
        BANKBRANCHCODE,

        /// <summary>
        /// BANKBSBCODE.
        /// </summary>
        [EnumMember(Value = "BANK_BSB_CODE")]
        BANKBSBCODE,

        /// <summary>
        /// BANKCITY.
        /// </summary>
        [EnumMember(Value = "BANK_CITY")]
        BANKCITY,

        /// <summary>
        /// BANKCLABE.
        /// </summary>
        [EnumMember(Value = "BANK_CLABE")]
        BANKCLABE,

        /// <summary>
        /// BANKCODE.
        /// </summary>
        [EnumMember(Value = "BANK_CODE")]
        BANKCODE,

        /// <summary>
        /// BANKCURP.
        /// </summary>
        [EnumMember(Value = "BANK_CURP")]
        BANKCURP,

        /// <summary>
        /// BANKIBAN.
        /// </summary>
        [EnumMember(Value = "BANK_IBAN")]
        BANKIBAN,

        /// <summary>
        /// BANKNAME.
        /// </summary>
        [EnumMember(Value = "BANK_NAME")]
        BANKNAME,

        /// <summary>
        /// BANKNONSWIFTBIC.
        /// </summary>
        [EnumMember(Value = "BANK_NON_SWIFT_BIC")]
        BANKNONSWIFTBIC,

        /// <summary>
        /// BANKNUBAN.
        /// </summary>
        [EnumMember(Value = "BANK_NUBAN")]
        BANKNUBAN,

        /// <summary>
        /// BANKPHONENUMBER.
        /// </summary>
        [EnumMember(Value = "BANK_PHONE_NUMBER")]
        BANKPHONENUMBER,

        /// <summary>
        /// BANKPOSTALCODE.
        /// </summary>
        [EnumMember(Value = "BANK_POSTAL_CODE")]
        BANKPOSTALCODE,

        /// <summary>
        /// BANKREGION.
        /// </summary>
        [EnumMember(Value = "BANK_REGION")]
        BANKREGION,

        /// <summary>
        /// BANKRFC.
        /// </summary>
        [EnumMember(Value = "BANK_RFC")]
        BANKRFC,

        /// <summary>
        /// BANKSORTCODE.
        /// </summary>
        [EnumMember(Value = "BANK_SORT_CODE")]
        BANKSORTCODE,

        /// <summary>
        /// BANKSTREETADDRESS.
        /// </summary>
        [EnumMember(Value = "BANK_STREET_ADDRESS")]
        BANKSTREETADDRESS,

        /// <summary>
        /// BANKSWIFTBIC.
        /// </summary>
        [EnumMember(Value = "BANK_SWIFT_BIC")]
        BANKSWIFTBIC,

        /// <summary>
        /// BANKTRANSITCODE.
        /// </summary>
        [EnumMember(Value = "BANK_TRANSIT_CODE")]
        BANKTRANSITCODE,

        /// <summary>
        /// BENEFICIARYACCOUNTNUMBER.
        /// </summary>
        [EnumMember(Value = "BENEFICIARY_ACCOUNT_NUMBER")]
        BENEFICIARYACCOUNTNUMBER,

        /// <summary>
        /// BENEFICIARYPHONENUMBER.
        /// </summary>
        [EnumMember(Value = "BENEFICIARY_PHONE_NUMBER")]
        BENEFICIARYPHONENUMBER,

        /// <summary>
        /// BENEFICIARYTAXID.
        /// </summary>
        [EnumMember(Value = "BENEFICIARY_TAX_ID")]
        BENEFICIARYTAXID,

        /// <summary>
        /// BENEFICIARYNAME.
        /// </summary>
        [EnumMember(Value = "BENEFICIARY_NAME")]
        BENEFICIARYNAME,

        /// <summary>
        /// BANKBRANCHNAME.
        /// </summary>
        [EnumMember(Value = "BANK_BRANCH_NAME")]
        BANKBRANCHNAME,

        /// <summary>
        /// BANKPURPOSEOFPAYMENTCODE.
        /// </summary>
        [EnumMember(Value = "BANK_PURPOSE_OF_PAYMENT_CODE")]
        BANKPURPOSEOFPAYMENTCODE,

        /// <summary>
        /// BANKVALUEADDTAX.
        /// </summary>
        [EnumMember(Value = "BANK_VALUE_ADD_TAX")]
        BANKVALUEADDTAX,
    }
}