// <copyright file="SourceToken.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// SourceToken.
    /// </summary>
    public class SourceToken
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SourceToken"/> class.
        /// </summary>
        public SourceToken()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SourceToken"/> class.
        /// </summary>
        /// <param name="sourceTokenProp">sourceToken.</param>
        public SourceToken(
            string sourceTokenProp = null)
        {
            this.SourceTokenProp = sourceTokenProp;
        }

        /// <summary>
        /// Unique identifier representing the source of funds.
        /// </summary>
        [JsonProperty("sourceToken", NullValueHandling = NullValueHandling.Ignore)]
        public string SourceTokenProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SourceToken : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SourceToken other &&
                ((this.SourceTokenProp == null && other.SourceTokenProp == null) || (this.SourceTokenProp?.Equals(other.SourceTokenProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1872529352;

            if (this.SourceTokenProp != null)
            {
               hashCode += this.SourceTokenProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SourceTokenProp = {(this.SourceTokenProp == null ? "null" : this.SourceTokenProp == string.Empty ? "" : this.SourceTokenProp)}");
        }
    }
}