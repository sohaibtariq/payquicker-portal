// <copyright file="PaymentsCollectionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PaymentsCollectionResponse.
    /// </summary>
    public class PaymentsCollectionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentsCollectionResponse"/> class.
        /// </summary>
        public PaymentsCollectionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentsCollectionResponse"/> class.
        /// </summary>
        /// <param name="payload">payload.</param>
        /// <param name="links">links.</param>
        public PaymentsCollectionResponse(
            List<Models.PaymentResponse> payload = null,
            List<Models.HaetosParams> links = null)
        {
            this.Payload = payload;
            this.Links = links;
        }

        /// <summary>
        /// Gets or sets Payload.
        /// </summary>
        [JsonProperty("payload", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PaymentResponse> Payload { get; set; }

        /// <summary>
        /// Gets or sets Links.
        /// </summary>
        [JsonProperty("links", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.HaetosParams> Links { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PaymentsCollectionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PaymentsCollectionResponse other &&
                ((this.Payload == null && other.Payload == null) || (this.Payload?.Equals(other.Payload) == true)) &&
                ((this.Links == null && other.Links == null) || (this.Links?.Equals(other.Links) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -393714497;

            if (this.Payload != null)
            {
               hashCode += this.Payload.GetHashCode();
            }

            if (this.Links != null)
            {
               hashCode += this.Links.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Payload = {(this.Payload == null ? "null" : $"[{string.Join(", ", this.Payload)} ]")}");
            toStringOutput.Add($"this.Links = {(this.Links == null ? "null" : $"[{string.Join(", ", this.Links)} ]")}");
        }
    }
}