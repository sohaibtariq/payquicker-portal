// <copyright file="Address.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// Address.
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class.
        /// </summary>
        public Address()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class.
        /// </summary>
        /// <param name="addressLine1">addressLine1.</param>
        /// <param name="addressLine2">addressLine2.</param>
        /// <param name="addressLine3">addressLine3.</param>
        /// <param name="addressLine4">addressLine4.</param>
        /// <param name="addressLine5">addressLine5.</param>
        /// <param name="city">city.</param>
        /// <param name="region">region.</param>
        /// <param name="country">country.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="premiseNumber">premiseNumber.</param>
        /// <param name="addressType">addressType.</param>
        public Address(
            string addressLine1 = null,
            string addressLine2 = null,
            string addressLine3 = null,
            string addressLine4 = null,
            string addressLine5 = null,
            string city = null,
            string region = null,
            Models.CountryTypesEnum? country = null,
            string postalCode = null,
            string premiseNumber = null,
            Models.AddressTypesEnum? addressType = null)
        {
            this.AddressLine1 = addressLine1;
            this.AddressLine2 = addressLine2;
            this.AddressLine3 = addressLine3;
            this.AddressLine4 = addressLine4;
            this.AddressLine5 = addressLine5;
            this.City = city;
            this.Region = region;
            this.Country = country;
            this.PostalCode = postalCode;
            this.PremiseNumber = premiseNumber;
            this.AddressType = addressType;
        }

        /// <summary>
        /// First line of the address that specifies street number, street name, and building name
        /// </summary>
        [JsonProperty("addressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address)
        /// </summary>
        [JsonProperty("addressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Third line of the address that specifies the international or business addresses that do not fit on addressLine2
        /// </summary>
        [JsonProperty("addressLine3", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Fourth line of the address, if any
        /// </summary>
        [JsonProperty("addressLine4", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Fifth line of the address, if any
        /// </summary>
        [JsonProperty("addressLine5", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine5 { get; set; }

        /// <summary>
        /// City or town of the business address
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// State, province, or territory of the business address
        /// </summary>
        [JsonProperty("region", NullValueHandling = NullValueHandling.Ignore)]
        public string Region { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("country", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? Country { get; set; }

        /// <summary>
        /// Series of letters, digits, or both, included in a postal address for the purpose of sorting mail
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// House or building number of the business address
        /// </summary>
        [JsonProperty("premiseNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PremiseNumber { get; set; }

        /// <summary>
        /// Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)
        /// </summary>
        [JsonProperty("addressType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressTypesEnum? AddressType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Address : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Address other &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.AddressLine3 == null && other.AddressLine3 == null) || (this.AddressLine3?.Equals(other.AddressLine3) == true)) &&
                ((this.AddressLine4 == null && other.AddressLine4 == null) || (this.AddressLine4?.Equals(other.AddressLine4) == true)) &&
                ((this.AddressLine5 == null && other.AddressLine5 == null) || (this.AddressLine5?.Equals(other.AddressLine5) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.Region == null && other.Region == null) || (this.Region?.Equals(other.Region) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.PremiseNumber == null && other.PremiseNumber == null) || (this.PremiseNumber?.Equals(other.PremiseNumber) == true)) &&
                ((this.AddressType == null && other.AddressType == null) || (this.AddressType?.Equals(other.AddressType) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 484049148;

            if (this.AddressLine1 != null)
            {
               hashCode += this.AddressLine1.GetHashCode();
            }

            if (this.AddressLine2 != null)
            {
               hashCode += this.AddressLine2.GetHashCode();
            }

            if (this.AddressLine3 != null)
            {
               hashCode += this.AddressLine3.GetHashCode();
            }

            if (this.AddressLine4 != null)
            {
               hashCode += this.AddressLine4.GetHashCode();
            }

            if (this.AddressLine5 != null)
            {
               hashCode += this.AddressLine5.GetHashCode();
            }

            if (this.City != null)
            {
               hashCode += this.City.GetHashCode();
            }

            if (this.Region != null)
            {
               hashCode += this.Region.GetHashCode();
            }

            if (this.Country != null)
            {
               hashCode += this.Country.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.PremiseNumber != null)
            {
               hashCode += this.PremiseNumber.GetHashCode();
            }

            if (this.AddressType != null)
            {
               hashCode += this.AddressType.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1 == string.Empty ? "" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2 == string.Empty ? "" : this.AddressLine2)}");
            toStringOutput.Add($"this.AddressLine3 = {(this.AddressLine3 == null ? "null" : this.AddressLine3 == string.Empty ? "" : this.AddressLine3)}");
            toStringOutput.Add($"this.AddressLine4 = {(this.AddressLine4 == null ? "null" : this.AddressLine4 == string.Empty ? "" : this.AddressLine4)}");
            toStringOutput.Add($"this.AddressLine5 = {(this.AddressLine5 == null ? "null" : this.AddressLine5 == string.Empty ? "" : this.AddressLine5)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.Region = {(this.Region == null ? "null" : this.Region == string.Empty ? "" : this.Region)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country.ToString())}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.PremiseNumber = {(this.PremiseNumber == null ? "null" : this.PremiseNumber == string.Empty ? "" : this.PremiseNumber)}");
            toStringOutput.Add($"this.AddressType = {(this.AddressType == null ? "null" : this.AddressType.ToString())}");
        }
    }
}