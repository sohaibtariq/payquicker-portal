// <copyright file="ReceiptBase.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// ReceiptBase.
    /// </summary>
    public class ReceiptBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptBase"/> class.
        /// </summary>
        public ReceiptBase()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptBase"/> class.
        /// </summary>
        /// <param name="amount">amount.</param>
        /// <param name="currency">currency.</param>
        /// <param name="formattedAmount">formattedAmount.</param>
        /// <param name="sourceToken">sourceToken.</param>
        /// <param name="destinationToken">destinationToken.</param>
        /// <param name="createdOn">createdOn.</param>
        /// <param name="token">token.</param>
        /// <param name="status">status.</param>
        public ReceiptBase(
            double amount,
            Models.CurrencyTypesEnum currency,
            string formattedAmount = null,
            string sourceToken = null,
            string destinationToken = null,
            DateTime? createdOn = null,
            string token = null,
            Models.TransferStatusTypesEnum? status = null)
        {
            this.FormattedAmount = formattedAmount;
            this.Amount = amount;
            this.Currency = currency;
            this.SourceToken = sourceToken;
            this.DestinationToken = destinationToken;
            this.CreatedOn = createdOn;
            this.Token = token;
            this.Status = status;
        }

        /// <summary>
        /// Formatted monetary amount
        /// </summary>
        [JsonProperty("formattedAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string FormattedAmount { get; set; }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("currency", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CurrencyTypesEnum Currency { get; set; }

        /// <summary>
        /// Unique identifier representing the source of funds.
        /// </summary>
        [JsonProperty("sourceToken", NullValueHandling = NullValueHandling.Ignore)]
        public string SourceToken { get; set; }

        /// <summary>
        /// Unique identifier representing the destination of funds.
        /// </summary>
        [JsonProperty("destinationToken", NullValueHandling = NullValueHandling.Ignore)]
        public string DestinationToken { get; set; }

        /// <summary>
        /// Time at which the object was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("createdOn", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// Current status of a transfer
        /// </summary>
        [JsonProperty("status", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TransferStatusTypesEnum? Status { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReceiptBase : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReceiptBase other &&
                ((this.FormattedAmount == null && other.FormattedAmount == null) || (this.FormattedAmount?.Equals(other.FormattedAmount) == true)) &&
                this.Amount.Equals(other.Amount) &&
                this.Currency.Equals(other.Currency) &&
                ((this.SourceToken == null && other.SourceToken == null) || (this.SourceToken?.Equals(other.SourceToken) == true)) &&
                ((this.DestinationToken == null && other.DestinationToken == null) || (this.DestinationToken?.Equals(other.DestinationToken) == true)) &&
                ((this.CreatedOn == null && other.CreatedOn == null) || (this.CreatedOn?.Equals(other.CreatedOn) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1004235575;

            if (this.FormattedAmount != null)
            {
               hashCode += this.FormattedAmount.GetHashCode();
            }

            hashCode += this.Amount.GetHashCode();
            hashCode += this.Currency.GetHashCode();

            if (this.SourceToken != null)
            {
               hashCode += this.SourceToken.GetHashCode();
            }

            if (this.DestinationToken != null)
            {
               hashCode += this.DestinationToken.GetHashCode();
            }

            if (this.CreatedOn != null)
            {
               hashCode += this.CreatedOn.GetHashCode();
            }

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            if (this.Status != null)
            {
               hashCode += this.Status.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FormattedAmount = {(this.FormattedAmount == null ? "null" : this.FormattedAmount == string.Empty ? "" : this.FormattedAmount)}");
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Currency = {this.Currency}");
            toStringOutput.Add($"this.SourceToken = {(this.SourceToken == null ? "null" : this.SourceToken == string.Empty ? "" : this.SourceToken)}");
            toStringOutput.Add($"this.DestinationToken = {(this.DestinationToken == null ? "null" : this.DestinationToken == string.Empty ? "" : this.DestinationToken)}");
            toStringOutput.Add($"this.CreatedOn = {(this.CreatedOn == null ? "null" : this.CreatedOn.ToString())}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status.ToString())}");
        }
    }
}