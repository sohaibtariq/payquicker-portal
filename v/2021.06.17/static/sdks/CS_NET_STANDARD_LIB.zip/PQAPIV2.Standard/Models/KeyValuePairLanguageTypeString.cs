// <copyright file="KeyValuePairLanguageTypeString.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// KeyValuePairLanguageTypeString.
    /// </summary>
    public class KeyValuePairLanguageTypeString
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValuePairLanguageTypeString"/> class.
        /// </summary>
        public KeyValuePairLanguageTypeString()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValuePairLanguageTypeString"/> class.
        /// </summary>
        /// <param name="language">language.</param>
        /// <param name="translation">translation.</param>
        public KeyValuePairLanguageTypeString(
            Models.LanguageTypesEnum? language = null,
            string translation = null)
        {
            this.Language = language;
            this.Translation = translation;
        }

        /// <summary>
        /// Language type in IETF's BCP 47 format
        /// </summary>
        [JsonProperty("language", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.LanguageTypesEnum? Language { get; set; }

        /// <summary>
        /// Translated string in the specified language
        /// </summary>
        [JsonProperty("translation", NullValueHandling = NullValueHandling.Ignore)]
        public string Translation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"KeyValuePairLanguageTypeString : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is KeyValuePairLanguageTypeString other &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.Translation == null && other.Translation == null) || (this.Translation?.Equals(other.Translation) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 588592953;

            if (this.Language != null)
            {
               hashCode += this.Language.GetHashCode();
            }

            if (this.Translation != null)
            {
               hashCode += this.Translation.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language.ToString())}");
            toStringOutput.Add($"this.Translation = {(this.Translation == null ? "null" : this.Translation == string.Empty ? "" : this.Translation)}");
        }
    }
}