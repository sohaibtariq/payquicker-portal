// <copyright file="PaymentPurposeTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PaymentPurposeTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PaymentPurposeTypesEnum
    {
        /// <summary>
        /// OTHER.
        /// </summary>
        [EnumMember(Value = "OTHER")]
        OTHER,

        /// <summary>
        /// TAXABLE.
        /// </summary>
        [EnumMember(Value = "TAXABLE")]
        TAXABLE,

        /// <summary>
        /// INCOME.
        /// </summary>
        [EnumMember(Value = "INCOME")]
        INCOME,

        /// <summary>
        /// BONUS.
        /// </summary>
        [EnumMember(Value = "BONUS")]
        BONUS,

        /// <summary>
        /// EXPENSE.
        /// </summary>
        [EnumMember(Value = "EXPENSE")]
        EXPENSE,

        /// <summary>
        /// NONTAXABLE.
        /// </summary>
        [EnumMember(Value = "NON_TAXABLE")]
        NONTAXABLE,
    }
}