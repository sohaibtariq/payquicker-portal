// <copyright file="BankAccountTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BankAccountTypesEnum
    {
        /// <summary>
        /// CHECKING.
        /// </summary>
        [EnumMember(Value = "CHECKING")]
        CHECKING,

        /// <summary>
        /// SAVINGS.
        /// </summary>
        [EnumMember(Value = "SAVINGS")]
        SAVINGS,

        /// <summary>
        /// MONEYMARKET.
        /// </summary>
        [EnumMember(Value = "MONEY_MARKET")]
        MONEYMARKET,
    }
}