// <copyright file="NotBeforeOrAfter.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// NotBeforeOrAfter.
    /// </summary>
    public class NotBeforeOrAfter
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NotBeforeOrAfter"/> class.
        /// </summary>
        public NotBeforeOrAfter()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotBeforeOrAfter"/> class.
        /// </summary>
        /// <param name="notBefore">notBefore.</param>
        /// <param name="notAfter">notAfter.</param>
        public NotBeforeOrAfter(
            DateTime? notBefore = null,
            DateTime? notAfter = null)
        {
            this.NotBefore = notBefore;
            this.NotAfter = notAfter;
        }

        /// <summary>
        /// Transfer is scheduled and will not process before this time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("notBefore", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? NotBefore { get; set; }

        /// <summary>
        /// Transfer expires if not completed prior to this time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("notAfter", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? NotAfter { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"NotBeforeOrAfter : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is NotBeforeOrAfter other &&
                ((this.NotBefore == null && other.NotBefore == null) || (this.NotBefore?.Equals(other.NotBefore) == true)) &&
                ((this.NotAfter == null && other.NotAfter == null) || (this.NotAfter?.Equals(other.NotAfter) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -310332411;

            if (this.NotBefore != null)
            {
               hashCode += this.NotBefore.GetHashCode();
            }

            if (this.NotAfter != null)
            {
               hashCode += this.NotAfter.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.NotBefore = {(this.NotBefore == null ? "null" : this.NotBefore.ToString())}");
            toStringOutput.Add($"this.NotAfter = {(this.NotAfter == null ? "null" : this.NotAfter.ToString())}");
        }
    }
}