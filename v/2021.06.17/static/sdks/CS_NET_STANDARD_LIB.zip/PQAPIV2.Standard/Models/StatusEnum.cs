// <copyright file="StatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// StatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum StatusEnum
    {
        /// <summary>
        /// QUEUED.
        /// </summary>
        [EnumMember(Value = "QUEUED")]
        QUEUED,

        /// <summary>
        /// LOSTSTOLENDAMAGED.
        /// </summary>
        [EnumMember(Value = "LOST_STOLEN_DAMAGED")]
        LOSTSTOLENDAMAGED,

        /// <summary>
        /// ACTIVATED.
        /// </summary>
        [EnumMember(Value = "ACTIVATED")]
        ACTIVATED,

        /// <summary>
        /// PENDINGACTIVATION.
        /// </summary>
        [EnumMember(Value = "PENDING_ACTIVATION")]
        PENDINGACTIVATION,

        /// <summary>
        /// SUSPENDED.
        /// </summary>
        [EnumMember(Value = "SUSPENDED")]
        SUSPENDED,

        /// <summary>
        /// COMPLIANCEHOLD.
        /// </summary>
        [EnumMember(Value = "COMPLIANCE_HOLD")]
        COMPLIANCEHOLD,

        /// <summary>
        /// KYCHOLD.
        /// </summary>
        [EnumMember(Value = "KYC_HOLD")]
        KYCHOLD,

        /// <summary>
        /// LOCKED.
        /// </summary>
        [EnumMember(Value = "LOCKED")]
        LOCKED,
    }
}