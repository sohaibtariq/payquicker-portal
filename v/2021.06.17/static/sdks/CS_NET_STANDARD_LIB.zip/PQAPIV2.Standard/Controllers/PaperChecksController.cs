// <copyright file="PaperChecksController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Request;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PaperChecksController.
    /// </summary>
    public class PaperChecksController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaperChecksController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal PaperChecksController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.PaperCheckCollectionResponse response from the API call.</returns>
        public Models.PaperCheckCollectionResponse GetUsersUserTokenPaperChecks(
                string userToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.PaperCheckCollectionResponse> t = this.GetUsersUserTokenPaperChecksAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PaperCheckCollectionResponse response from the API call.</returns>
        public async Task<Models.PaperCheckCollectionResponse> GetUsersUserTokenPaperChecksAsync(
                string userToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/paperchecks");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PaperCheckCollectionResponse>(response.Body);
        }

        /// <summary>
        /// Create a quote for a paper check..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.PaperCheckResponse response from the API call.</returns>
        public Models.PaperCheckResponse PostUsersUserTokenPaperchecks(
                string userToken,
                string xMyPayQuickerVersion,
                Models.PaperCheckBase body = null)
        {
            Task<Models.PaperCheckResponse> t = this.PostUsersUserTokenPaperchecksAsync(userToken, xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a quote for a paper check..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PaperCheckResponse response from the API call.</returns>
        public async Task<Models.PaperCheckResponse> PostUsersUserTokenPaperchecksAsync(
                string userToken,
                string xMyPayQuickerVersion,
                Models.PaperCheckBase body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/paperchecks");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PaperCheckResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <returns>Returns the Models.PaperCheckResponse response from the API call.</returns>
        public Models.PaperCheckResponse GetUsersUserTokenPaperchecksDestToken(
                string userToken,
                string xferToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null)
        {
            Task<Models.PaperCheckResponse> t = this.GetUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="page">Optional parameter: Page number of specific page to return.</param>
        /// <param name="pageSize">Optional parameter: Number of items to be displayed per page.</param>
        /// <param name="filter">Optional parameter: Filter request results by specific criteria..</param>
        /// <param name="sort">Optional parameter: Sort request results by specific attribute..</param>
        /// <param name="language">Optional parameter: Filter results by language type..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PaperCheckResponse response from the API call.</returns>
        public async Task<Models.PaperCheckResponse> GetUsersUserTokenPaperchecksDestTokenAsync(
                string userToken,
                string xferToken,
                string xMyPayQuickerVersion,
                int? page = null,
                int? pageSize = 20,
                string filter = null,
                string sort = null,
                Models.LanguageTypesEnum? language = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/paper-checks/{xfer-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "xfer-token", xferToken },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "pageSize", (pageSize != null) ? pageSize : 20 },
                { "filter", filter },
                { "sort", sort },
                { "language", (language.HasValue) ? ApiHelper.JsonSerialize(language.Value) : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PaperCheckResponse>(response.Body);
        }

        /// <summary>
        /// Create a quote for a paper check..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.PaperCheckResponse response from the API call.</returns>
        public Models.PaperCheckResponse PutUsersUserTokenPaperchecksDestToken(
                string userToken,
                string xferToken,
                string xMyPayQuickerVersion,
                object body = null)
        {
            Task<Models.PaperCheckResponse> t = this.PutUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a quote for a paper check..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PaperCheckResponse response from the API call.</returns>
        public async Task<Models.PaperCheckResponse> PutUsersUserTokenPaperchecksDestTokenAsync(
                string userToken,
                string xferToken,
                string xMyPayQuickerVersion,
                object body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/paper-checks/{xfer-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "xfer-token", xferToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PaperCheckResponse>(response.Body);
        }

        /// <summary>
        /// Delete a paper check by destination token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        public void DeleteUsersUserTokenPaperChecksDestToken(
                string userToken,
                string xferToken,
                string xMyPayQuickerVersion)
        {
            Task t = this.DeleteUsersUserTokenPaperChecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Delete a paper check by destination token..
        /// </summary>
        /// <param name="userToken">Required parameter: Auto-generated unique identifier representing a user, prefixed with <i>user-</i>..</param>
        /// <param name="xferToken">Required parameter: Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>..</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteUsersUserTokenPaperChecksDestTokenAsync(
                string userToken,
                string xferToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/users/{user-token}/paper-checks/{xfer-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "user-token", userToken },
                { "xfer-token", xferToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}