// <copyright file="WebhooksController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Request;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// WebhooksController.
    /// </summary>
    public class WebhooksController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WebhooksController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal WebhooksController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <returns>Returns the Models.WebhookCollectionResponse response from the API call.</returns>
        public Models.WebhookCollectionResponse ListWebhookSubscriptions(
                string xMyPayQuickerVersion)
        {
            Task<Models.WebhookCollectionResponse> t = this.ListWebhookSubscriptionsAsync(xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WebhookCollectionResponse response from the API call.</returns>
        public async Task<Models.WebhookCollectionResponse> ListWebhookSubscriptionsAsync(
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/webhooks");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.WebhookCollectionResponse>(response.Body);
        }

        /// <summary>
        /// Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.WebhookSubscriptionResponse response from the API call.</returns>
        public Models.WebhookSubscriptionResponse CreateWebhookSubscription(
                string xMyPayQuickerVersion,
                Models.WebhookSubscription body = null)
        {
            Task<Models.WebhookSubscriptionResponse> t = this.CreateWebhookSubscriptionAsync(xMyPayQuickerVersion, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API..
        /// </summary>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WebhookSubscriptionResponse response from the API call.</returns>
        public async Task<Models.WebhookSubscriptionResponse> CreateWebhookSubscriptionAsync(
                string xMyPayQuickerVersion,
                Models.WebhookSubscription body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/webhooks");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.WebhookSubscriptionResponse>(response.Body);
        }

        /// <summary>
        /// Retrieve a single webhook subscription using the webhook token..
        /// </summary>
        /// <param name="webhToken">Required parameter: Example: .</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <returns>Returns the Models.WebhookSubscriptionResponse response from the API call.</returns>
        public Models.WebhookSubscriptionResponse RetrieveWebhookSubscription(
                string webhToken,
                string xMyPayQuickerVersion)
        {
            Task<Models.WebhookSubscriptionResponse> t = this.RetrieveWebhookSubscriptionAsync(webhToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retrieve a single webhook subscription using the webhook token..
        /// </summary>
        /// <param name="webhToken">Required parameter: Example: .</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WebhookSubscriptionResponse response from the API call.</returns>
        public async Task<Models.WebhookSubscriptionResponse> RetrieveWebhookSubscriptionAsync(
                string webhToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/webhooks/{webh-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "webh-token", webhToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.WebhookSubscriptionResponse>(response.Body);
        }

        /// <summary>
        /// Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code..
        /// </summary>
        /// <param name="webhToken">Required parameter: Example: .</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        public void DeleteWebhookSubscription(
                string webhToken,
                string xMyPayQuickerVersion)
        {
            Task t = this.DeleteWebhookSubscriptionAsync(webhToken, xMyPayQuickerVersion);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code..
        /// </summary>
        /// <param name="webhToken">Required parameter: Example: .</param>
        /// <param name="xMyPayQuickerVersion">Required parameter: Date-based API Version specified in the header <i>required</i> on all calls..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteWebhookSubscriptionAsync(
                string webhToken,
                string xMyPayQuickerVersion,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/webhooks/{webh-token}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "webh-token", webhToken },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "X-MyPayQuicker-Version", xMyPayQuickerVersion },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}