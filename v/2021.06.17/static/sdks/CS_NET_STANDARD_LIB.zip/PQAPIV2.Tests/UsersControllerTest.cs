// <copyright file="UsersControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// UsersControllerTest.
    /// </summary>
    [TestFixture]
    public class UsersControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private UsersController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.UsersController;
        }

        /// <summary>
        /// Update a user object (change email, address change, etc.) using a user token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestUpdateUser()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.UserBase body = null;

            // Perform API call
            Standard.Models.UserResponse result = null;
            try
            {
                result = await this.controller.UpdateUserAsync(userToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\",\"token\":\"user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\",\"status\":\"PRE_ACTIVATED\",\"createdOn\":\"2020-02-24T22:00:00Z\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a single user record by user token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRetrieveUser()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            Standard.Models.UserResponse result = null;
            try
            {
                result = await this.controller.RetrieveUserAsync(userToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\",\"token\":\"user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\",\"status\":\"PRE_ACTIVATED\",\"createdOn\":\"2020-02-24T22:00:00Z\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestListUsers()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.UserCollectionResponse result = null;
            try
            {
                result = await this.controller.ListUsersAsync(xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("X-TimeZone", "America/New_York");
            headers.Add("X-Paging-PageNo", null);
            headers.Add("X-Paging-PageCount", null);
            headers.Add("X-Paging-PageSize", null);
            headers.Add("X-Paging-TotalRecordCount", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\",\"token\":\"usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357\",\"status\":\"PRE_ACTIVATED\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357\"}]}],\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestCreateUser()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.UserBase body = ApiHelper.JsonDeserialize<Standard.Models.UserBase>("{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\"}");

            // Perform API call
            Standard.Models.UserResponse result = null;
            try
            {
                result = await this.controller.CreateUserAsync(xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\",\"token\":\"user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\",\"status\":\"PRE_ACTIVATED\",\"createdOn\":\"2020-02-24T22:00:00Z\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestCreateUser1()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.UserBase body = ApiHelper.JsonDeserialize<Standard.Models.UserBase>("{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\"}");

            // Perform API call
            Standard.Models.UserResponse result = null;
            try
            {
                result = await this.controller.CreateUserAsync(xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(201, this.HttpCallBackHandler.Response.StatusCode, "Status should be 201");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"firstName\":\"Jane\",\"lastName\":\"Smith\",\"dateOfBirth\":\"1977-12-14\",\"phoneNumber\":\"760-350-0324\",\"phoneNumberCountry\":\"US\",\"mobileNumber\":\"213-446-5755\",\"mobileNumberCountry\":\"US\",\"addressLine1\":\"290 Carriage Court\",\"city\":\"Los Angeles\",\"region\":\"CA\",\"country\":\"US\",\"postalCode\":\"90017\",\"addressType\":\"RESIDENTIAL\",\"email\":\"jsmith@payquicker.com\",\"gender\":\"FEMALE\",\"userType\":\"INDIVIDUAL\",\"programUserId\":\"d97ce0519b2d\",\"language\":\"en-US\",\"countryOfBirth\":\"US\",\"countryOfNationality\":\"US\",\"token\":\"user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\",\"status\":\"PRE_ACTIVATED\",\"createdOn\":\"2020-02-24T22:00:00Z\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestListUserIDVChecks()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            Standard.Models.IdentityVerificationCollectionResponse result = null;
            try
            {
                result = await this.controller.ListUserIDVChecksAsync(userToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"idvProviderReference\":\"yPV0h4o1Yw3QzdLAvA7a\",\"idvResult\":\"PASS\",\"idvSubResult\":\"HARD\",\"idvProvider\":\"IDOLOGY\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"raw\":\"<RAW IDV processor output, for informational /debugging purposes only>\",\"idvCheckType\":\"NON_DOCUMENTARY\",\"idvDisposition\":\"FINAL\",\"token\":\"idvc-7e7567e0-c2db-485d-896d-45901a10baa9\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9\"}]}],\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRetrieveUserIDVCheck()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string idvcToken = "idvc-7e7567e0-c2db-485d-896d-45901a10baa9";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            Standard.Models.IdentityVerificationResponse result = null;
            try
            {
                result = await this.controller.RetrieveUserIDVCheckAsync(userToken, idvcToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"idvProviderReference\":\"yPV0h4o1Yw3QzdLAvA7a\",\"idvResult\":\"PASS\",\"idvSubResult\":\"HARD\",\"idvProvider\":\"IDOLOGY\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"raw\":\"<RAW IDV processor output, for informational/debugging purposes only>\",\"idvCheckType\":\"NON_DOCUMENTARY\",\"idvDispostion\":\"FINAL\",\"token\":\"idvc-7e7567e0-c2db-485d-896d-45901a10baa9\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestListUserEvents()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";

            // Perform API call
            try
            {
                await this.controller.ListUserEventsAsync(userToken);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Retrieve a single user event.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRetrieveUserEvent()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string evntToken = "evnt-28491de2-5b22-4e30-028a-45901a10baa9";

            // Perform API call
            try
            {
                await this.controller.RetrieveUserEventAsync(userToken, evntToken);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Accept a single program agreement.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestAcceptProgramAgreement()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string agmtToken = "agmt-45901a10-5b22-4e30-028a-45901a10baa9";

            // Perform API call
            try
            {
                await this.controller.AcceptProgramAgreementAsync(userToken, agmtToken);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestListAcceptedProgramAgreements()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";

            // Perform API call
            try
            {
                await this.controller.ListAcceptedProgramAgreementsAsync(userToken);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}