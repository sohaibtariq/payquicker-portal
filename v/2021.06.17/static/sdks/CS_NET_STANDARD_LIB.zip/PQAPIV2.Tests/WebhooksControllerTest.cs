// <copyright file="WebhooksControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// WebhooksControllerTest.
    /// </summary>
    [TestFixture]
    public class WebhooksControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private WebhooksController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.WebhooksController;
        }

        /// <summary>
        /// Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetWebhook()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            Standard.Models.WebhookCollectionResponse result = null;
            try
            {
                result = await this.controller.GetWebhookAsync(xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}],\"payload\":[{\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}],\"url\":\"https://www.example.com/webhooks\",\"namespace\":\"BANKACCOUNTS.UPDATED.STATUS.APPROVED\",\"token\":\"webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a\",\"created\":\"2020-01-01\",\"lastUpdated\":\"2020-02-01\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostWebhooks()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.WebhookSubscription body = null;

            // Perform API call
            Standard.Models.WebhookSubscriptionResponse result = null;
            try
            {
                result = await this.controller.PostWebhooksAsync(xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}],\"url\":\"https://www.example.com/webhooks\",\"namespace\":\"BANKACCOUNTS.UPDATED.STATUS.APPROVED\",\"token\":\"webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a\",\"created\":\"2020-01-01\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostWebhooks1()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.WebhookSubscription body = null;

            // Perform API call
            Standard.Models.WebhookSubscriptionResponse result = null;
            try
            {
                result = await this.controller.PostWebhooksAsync(xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(201, this.HttpCallBackHandler.Response.StatusCode, "Status should be 201");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }
    }
}