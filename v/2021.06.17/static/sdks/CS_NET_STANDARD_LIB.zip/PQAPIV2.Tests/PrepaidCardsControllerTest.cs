// <copyright file="PrepaidCardsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// PrepaidCardsControllerTest.
    /// </summary>
    [TestFixture]
    public class PrepaidCardsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PrepaidCardsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PrepaidCardsController;
        }

        /// <summary>
        /// Replace an existing Prepaid Card specifying the replacement reason and the card package for the replacement card..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostUsersUserTokenPrepaidcardsDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";
            object body = null;

            // Perform API call
            Standard.Models.PrepaidCardResponse result = null;
            try
            {
                result = await this.controller.PostUsersUserTokenPrepaidcardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\",\"status\":\"QUEUED\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"country\":\"US\",\"currency\":\"USD\",\"cardPersonalization\":\"PERSONALIZED\",\"cardPackage\":\"blue_consumer_10k\",\"cardNetwork\":\"VISA\",\"expires\":\"2023-02-21T00:00:00Z\",\"cardNumber\":\"1234 56** **** 1234\",\"cvv\":\"123\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve Prepaid Card details by destination token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenPrepaidCardsDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            Standard.Models.PrepaidCardResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenPrepaidCardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\",\"status\":\"QUEUED\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"country\":\"US\",\"currency\":\"USD\",\"cardPersonalization\":\"PERSONALIZED\",\"cardPackage\":\"blue_consumer_10k\",\"cardNetwork\":\"VISA\",\"expires\":\"2023-02-21T00:00:00Z\",\"cardNumber\":\"1234 56** **** 1234\",\"cvv\":\"123\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Partial Prepaid Card update typically used when modifying card status. <i>*Does not require the entire object be passed in the request</i>.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPatchUsersUserTokenPrepaidcardsDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.PrepaidCardStatus body = null;

            // Perform API call
            Standard.Models.PrepaidCardResponse result = null;
            try
            {
                result = await this.controller.PatchUsersUserTokenPrepaidcardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\",\"status\":\"LOCKED\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"country\":\"US\",\"currency\":\"USD\",\"cardPersonalization\":\"PERSONALIZED\",\"cardPackage\":\"blue_consumer_10k\",\"cardNetwork\":\"VISA\",\"expires\":\"2023-02-21T00:00:00Z\",\"cardNumber\":\"1234 56** **** 1234\",\"cvv\":\"123\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve one part of a two-part token required to reveal or set a client side PIN. <i>*Not all programs support a reveal or set PIN operation.</i>.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenPrepaidcardsDestTokenPin()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            Standard.Models.PrepaidCardPinToken result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenPrepaidcardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve a list of all pre-paid cards by user token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenPrepaidcards()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.PrepaidCardCollectionResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenPrepaidcardsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"token\":\"dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\",\"status\":\"QUEUED\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"country\":\"US\",\"currency\":\"USD\",\"cardPersonalization\":\"PERSONALIZED\",\"cardPackage\":\"blue_consumer_10k\",\"cardNetwork\":\"VISA\",\"expires\":\"2023-02-21T00:00:00Z\",\"cardNumber\":\"1234 56** **** 1234\",\"cvv\":\"123\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\"}]}],\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Order a pre-paid card for the user by specifying a cardPackage. <i>*A package defines the type of card, currency, artwork utilized, and often the method of delivery.</i>.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostUsersUserTokenPrepaidcards()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.PrepaidCardBase body = null;

            // Perform API call
            Standard.Models.PrepaidCardRequestResponse result = null;
            try
            {
                result = await this.controller.PostUsersUserTokenPrepaidcardsAsync(userToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\",\"status\":\"QUEUED\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"country\":\"US\",\"currency\":\"USD\",\"cardPersonalization\":\"PERSONALIZED\",\"cardPackage\":\"blue_consumer_10k\",\"cardNetwork\":\"VISA\",\"expires\":\"2023-02-21T00:00:00Z\",\"cardNumber\":\"1234 56** **** 1234\",\"cvv\":\"123\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}