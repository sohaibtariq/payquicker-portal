// <copyright file="PaperChecksControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// PaperChecksControllerTest.
    /// </summary>
    [TestFixture]
    public class PaperChecksControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PaperChecksController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PaperChecksController;
        }

        /// <summary>
        /// Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenPaperChecks()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.PaperCheckCollectionResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenPaperChecksAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Create a quote for a paper check..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostUsersUserTokenPaperchecks()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.PaperCheckBase body = null;

            // Perform API call
            Standard.Models.PaperCheckResponse result = null;
            try
            {
                result = await this.controller.PostUsersUserTokenPaperchecksAsync(userToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenPaperchecksDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.PaperCheckResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Create a quote for a paper check..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPutUsersUserTokenPaperchecksDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
            string xMyPayQuickerVersion = "2020.02.24";
            object body = null;

            // Perform API call
            Standard.Models.PaperCheckResponse result = null;
            try
            {
                result = await this.controller.PutUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Delete a paper check by destination token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteUsersUserTokenPaperChecksDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.DeleteUsersUserTokenPaperChecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}