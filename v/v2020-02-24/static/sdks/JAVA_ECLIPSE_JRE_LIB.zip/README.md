# Getting Started with PQ API v2

## Getting Started

### Introduction

desc older version

### Install the Package

Install the SDK by adding the following dependency in your project's pom.xml file:

```xml
<dependency>
  <groupId>com.payquicker</groupId>
  <artifactId>sample-sdk-artifact-id</artifactId>
  <version>1.0.0</version>
</dependency>
```

You can also view the package at:
https://mvnrepository.com/artifact/com.payquicker/sample-sdk-artifact-id/1.0.0

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance.<br>* See available [builder methods here](#httpclientconfiguration.builder-class). |

The API client can be initialized as follows:

```java
PQAPIV2Client client = new PQAPIV2Client.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .build();
```

### Test the SDK

The generated code and the server can be tested using automatically generated test cases.
JUnit is used as the testing framework and test runner.

In Eclipse, for running the tests do the following:

1. Select the project PQAPIV2Lib from the package explorer.
2. Select `Run -> Run as -> JUnit Test` or use `Alt + Shift + X` followed by `T` to run the Tests.

## Client Class Documentation

### PQ API v2Client Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

#### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getPaymentsController()` | Provides access to Payments controller. | `PaymentsController` |
| `getTransfersController()` | Provides access to Transfers controller. | `TransfersController` |
| `getSpendBackController()` | Provides access to SpendBack controller. | `SpendBackController` |
| `getPrepaidCardsController()` | Provides access to PrepaidCards controller. | `PrepaidCardsController` |
| `getPaperChecksController()` | Provides access to PaperChecks controller. | `PaperChecksController` |
| `getBankAccountsController()` | Provides access to BankAccounts controller. | `BankAccountsController` |
| `getBalancesController()` | Provides access to Balances controller. | `BalancesController` |
| `getReceiptsController()` | Provides access to Receipts controller. | `ReceiptsController` |
| `getUsersController()` | Provides access to Users controller. | `UsersController` |
| `getDocumentsController()` | Provides access to Documents controller. | `DocumentsController` |
| `getWebhooksController()` | Provides access to Webhooks controller. | `WebhooksController` |
| `getProgramController()` | Provides access to Program controller. | `ProgramController` |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | `ReadonlyHttpClientConfiguration` |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

## API Reference

### List of APIs

* [Payments](#payments)
* [Transfers](#transfers)
* [Spend Back](#spend-back)
* [Prepaid Cards](#prepaid-cards)
* [Paper Checks](#paper-checks)
* [Bank Accounts](#bank-accounts)
* [Balances](#balances)
* [Receipts](#receipts)
* [Users](#users)
* [Documents](#documents)
* [Webhooks](#webhooks)
* [Program](#program)

### Payments

#### Overview

Payment-related operations

##### Get instance

An instance of the `PaymentsController` class can be accessed from the API Client.

```
PaymentsController paymentsController = client.getPaymentsController();
```

#### Get-Payments-Pmnt Token

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentResponse> getPaymentsPmntTokenAsync(
    final String pmntToken,
    final String xMyPayQuickerVersion,
    final String filter,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```java
String pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
String xMyPayQuickerVersion = "2020.02.24";
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

paymentsController.getPaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion, filter, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Payments-Pmnt Token

Accept an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentResponse> postPaymentsPmntTokenAsync(
    final String pmntToken,
    final String xMyPayQuickerVersion,
    final Object body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `Object` | Body, Optional | - |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```java
String pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
String xMyPayQuickerVersion = "2020.02.24";

paymentsController.postPaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Delete-Payments-Pmnt Token

Cancel an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> deletePaymentsPmntTokenAsync(
    final String pmntToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
String xMyPayQuickerVersion = "2020.02.24";

paymentsController.deletePaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Put-Payments-Pmnt Token-Retract

Perform a payment retraction for the full payment amount.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> putPaymentsPmntTokenRetractAsync(
    final String pmntToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
String xMyPayQuickerVersion = "2020.02.24";

paymentsController.putPaymentsPmntTokenRetractAsync(pmntToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Patch-Payments-Pmnt Token-Retract

Perform a payment retraction for a partial payment amount.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> patchPaymentsPmntTokenRetractAsync(
    final String pmntToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
String xMyPayQuickerVersion = "2020.02.24";

paymentsController.patchPaymentsPmntTokenRetractAsync(pmntToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Payments

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentsCollectionResponse> getPaymentsAsync(
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaymentsCollectionResponse`](#payments-collection-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

paymentsController.getPaymentsAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Payments

Create a payment quote.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentResponse> postPaymentsAsync(
    final String xMyPayQuickerVersion,
    final PaymentRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PaymentRequest`](#payment-request) | Body, Optional | - |

##### Response Type

[`PaymentResponse`](#payment-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
PaymentRequest body = new PaymentRequest();
body.setAmount(78.98);
body.setCurrency(CurrencyTypesEnum.HKD);

paymentsController.postPaymentsAsync(xMyPayQuickerVersion, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Transfers

#### Overview

Transfer-related operations

##### Get instance

An instance of the `TransfersController` class can be accessed from the API Client.

```
TransfersController transfersController = client.getTransfersController();
```

#### Get-Transfers-Xfer Token

Retrieve details of a specific transfer represented by a transfer token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TransferResponse> getTransfersXferTokenAsync(
    final String xferToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```java
String xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

transfersController.getTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Transfers-Xfer Token

Accept a transfer quote

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> postTransfersXferTokenAsync(
    final String xferToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
String xMyPayQuickerVersion = "2020.02.24";

transfersController.postTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Delete-Transfers-Xfer Token

Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> deleteTransfersXferTokenAsync(
    final String xferToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
String xMyPayQuickerVersion = "2020.02.24";

transfersController.deleteTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Transfers

Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TransferCollectionResponse> getTransfersAsync(
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`TransferCollectionResponse`](#transfer-collection-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

transfersController.getTransfersAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Transfers

Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TransferResponse> postTransfersAsync(
    final String xMyPayQuickerVersion,
    final TransferRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`TransferRequest`](#transfer-request) | Body, Required | - |

##### Response Type

[`TransferResponse`](#transfer-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
TransferRequest body = new TransferRequest();

transfersController.postTransfersAsync(xMyPayQuickerVersion, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "sourceToken": "user-114773fd-85c1-4977-8ce5-24af71f744e9",
  "destinationToken": "dest-63947e68-5393-4d00-955d-e0020017924b",
  "notes": "string",
  "memo": "string",
  "destinationAmount": -1.79,
  "destinationCurrency": "USD",
  "clientTransferId": "DKKde3Meeiiw34",
  "token": "xfer-0c0f2727-6521-47c9-b1fa-f132306d456a",
  "sourceAmount": -1.79,
  "sourceCurrency": "USD",
  "status": "QUOTED",
  "fx": {
    "destinationAmount": -1.79,
    "destinationCurrency": "USD",
    "sourceAmount": -1.79,
    "sourceCurrency": "USD",
    "rate": 0.85
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://url.to.com/xfer-0c0f2727-6521-47c9-b1fa-f132306d456a"
    }
  ]
}
```

### Spend Back

#### Overview

Spendback-related operations

##### Get instance

An instance of the `SpendBackController` class can be accessed from the API Client.

```
SpendBackController spendBackController = client.getSpendBackController();
```

#### Get-Spendback-Spnd Token

Retrieve a single spendback quote using the spendback token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getSpendbackSpndTokenAsync(
    final String spndToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```java
String spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

spendBackController.getSpendbackSpndTokenAsync(spndToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Spendback-Spnd Token

Accept an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> postSpendbackSpndTokenAsync(
    final String spndToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
String xMyPayQuickerVersion = "2020.02.24";

spendBackController.postSpendbackSpndTokenAsync(spndToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Delete-Spendback-Spnd Token

Cancel an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> deleteSpendbackSpndTokenAsync(
    final String spndToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
String xMyPayQuickerVersion = "2020.02.24";

spendBackController.deleteSpendbackSpndTokenAsync(spndToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Put-Spendback-Spnd Token-Refund

Perform a spendback refund for the full amount.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> putSpendbackSpndTokenRefundAsync(
    final String spndToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
String xMyPayQuickerVersion = "2020.02.24";

spendBackController.putSpendbackSpndTokenRefundAsync(spndToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Patch-Spendback-Spnd Token-Refund

Perform a spendback refund for a partial amount.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> patchSpendbackSpndTokenRefundAsync(
    final String spndToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
String xMyPayQuickerVersion = "2020.02.24";

spendBackController.patchSpendbackSpndTokenRefundAsync(spndToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Spendback

Retrieve a list of all spendbacks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getSpendbackAsync(
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

spendBackController.getSpendbackAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Spendback

Create a spendback quote. <i>*Spendbacks can be automatically accepted by setting the `autoAcceptQuote` flag. If not automatically accepted, a POST is required to the spendback endpoint using the token returned in the response. Quotes can be accepted, cancelled, or allowed to expire.</i>

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> postSpendbackAsync(
    final String xMyPayQuickerVersion,
    final Object body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `Object` | Body, Optional | - |

##### Response Type

`void`

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";

spendBackController.postSpendbackAsync(xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Prepaid Cards

#### Overview

Prepaid Card-related operations

##### Get instance

An instance of the `PrepaidCardsController` class can be accessed from the API Client.

```
PrepaidCardsController prepaidCardsController = client.getPrepaidCardsController();
```

#### Post-Users-User Token-Prepaidcards-Dest Token

Replace an existing Prepaid Card specifying the replacement reason and the card package for the replacement card.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardResponse> postUsersUserTokenPrepaidcardsDestTokenAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final Object body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `Object` | Body, Optional | - |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";

prepaidCardsController.postUsersUserTokenPrepaidcardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaid-Cards-Dest Token

Retrieve Prepaid Card details by destination token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardResponse> getUsersUserTokenPrepaidCardsDestTokenAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";

prepaidCardsController.getUsersUserTokenPrepaidCardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Patch-Users-User Token-Prepaidcards-Dest Token

Partial Prepaid Card update typically used when modifying card status. <i>*Does not require the entire object be passed in the request</i>

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardResponse> patchUsersUserTokenPrepaidcardsDestTokenAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final PrepaidCardStatus body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PrepaidCardStatus`](#prepaid-card-status) | Body, Optional | - |

##### Response Type

[`PrepaidCardResponse`](#prepaid-card-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";

prepaidCardsController.patchUsersUserTokenPrepaidcardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "LOCKED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Pin

Retrieve one part of a two-part token required to reveal or set a client side PIN. <i>*Not all programs support a reveal or set PIN operation.</i>

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardPinToken> getUsersUserTokenPrepaidcardsDestTokenPinAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`PrepaidCardPinToken`](#prepaid-card-pin-token)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";

prepaidCardsController.getUsersUserTokenPrepaidcardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Put-Users-User Token-Prepaidcards-Dest Token-Pin

Allows the setting of a PIN if supported by program.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UsersPrepaidCardsPinResponse> putUsersUserTokenPrepaidcardsDestTokenPinAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final String token,
    final String cardPin)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `String` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cardPin` | `String` | Query, Required | Prepaid card PIN for ATM and Debit usage |

##### Response Type

[`UsersPrepaidCardsPinResponse`](#users-prepaid-cards-pin-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";
String token = "token6";
String cardPin = "cardPin4";

prepaidCardsController.putUsersUserTokenPrepaidcardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion, token, cardPin).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Users-User Token-Prepaid-Cards-Dest Token-Pin

Reveals the PIN for a card where PIN reveal functionality is supported in the program and hosted by PayQuicker.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardPin> postUsersUserTokenPrepaidCardsDestTokenPinAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final String token,
    final String cvc2,
    final Object body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `String` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cvc2` | `String` | Query, Required | Card Verification Value (CVV) located on the back of your credit card or debit card is a 3-digit number on VISA® and MasterCard® branded credit cards, and debit cards. |
| `body` | `Object` | Body, Optional | - |

##### Response Type

[`PrepaidCardPin`](#prepaid-card-pin)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";
String token = "token6";
String cvc2 = "cvc20";

prepaidCardsController.postUsersUserTokenPrepaidCardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion, token, cvc2, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Users-User Token-Prepaidcards

Retrieve a list of all pre-paid cards by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardCollectionResponse> getUsersUserTokenPrepaidcardsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PrepaidCardCollectionResponse`](#prepaid-card-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

prepaidCardsController.getUsersUserTokenPrepaidcardsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
      "status": "QUEUED",
      "createdOn": "2020-02-21T22:00:00Z",
      "country": "US",
      "currency": "USD",
      "cardPersonalization": "PERSONALIZED",
      "cardPackage": "blue_consumer_10k",
      "cardNetwork": "VISA",
      "expires": "2023-02-21T00:00:00Z",
      "cardNumber": "1234 56** **** 1234",
      "cvv": "123",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards"
    }
  ]
}
```

#### Post-Users-User Token-Prepaidcards

Order a pre-paid card for the user by specifying a cardPackage. <i>*A package defines the type of card, currency, artwork utilized, and often the method of delivery.</i>

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardRequestResponse> postUsersUserTokenPrepaidcardsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final PrepaidCardBase body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PrepaidCardBase`](#prepaid-card-base) | Body, Optional | - |

##### Response Type

[`PrepaidCardRequestResponse`](#prepaid-card-request-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";

prepaidCardsController.postUsersUserTokenPrepaidcardsAsync(userToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Generate a token used to reveal prepaid card information in the form of image data (base64) or JSON.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardDataTokenResponse> getUsersUserTokenPrepaidCardsDestTokenPciAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final FormatEnum format,
    final SideEnum side)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | - |
| `destToken` | `String` | Template, Required | - |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `side` | [`SideEnum`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`PrepaidCardDataTokenResponse`](#prepaid-card-data-token-response)

##### Example Usage

```java
String userToken = "user-token6";
String destToken = "dest-token2";
String xMyPayQuickerVersion = "2020.02.24";
FormatEnum format = FormatEnum.ENUM_TEXTIMAGE;

prepaidCardsController.getUsersUserTokenPrepaidCardsDestTokenPciAsync(userToken, destToken, xMyPayQuickerVersion, format, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Return prepaid card data in the form of image data, text, or both.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PrepaidCardDataResponse> postUsersUserTokenPrepaidCardsDestTokenPciAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final FormatEnum format,
    final String token,
    final SideEnum side)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | - |
| `destToken` | `String` | Template, Required | - |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `token` | `String` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `side` | [`SideEnum`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`PrepaidCardDataResponse`](#prepaid-card-data-response)

##### Example Usage

```java
String userToken = "user-token6";
String destToken = "dest-token2";
String xMyPayQuickerVersion = "2020.02.24";
FormatEnum format = FormatEnum.ENUM_TEXTIMAGE;
String token = "token6";

prepaidCardsController.postUsersUserTokenPrepaidCardsDestTokenPciAsync(userToken, destToken, xMyPayQuickerVersion, format, token, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Paper Checks

#### Overview

Paper check-related operations

##### Get instance

An instance of the `PaperChecksController` class can be accessed from the API Client.

```
PaperChecksController paperChecksController = client.getPaperChecksController();
```

#### Get-Users-User Token-Paper-Checks

Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaperCheckCollectionResponse> getUsersUserTokenPaperChecksAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaperCheckCollectionResponse`](#paper-check-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

paperChecksController.getUsersUserTokenPaperChecksAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Users-User Token-Paperchecks

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaperCheckResponse> postUsersUserTokenPaperchecksAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final PaperCheckBase body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`PaperCheckBase`](#paper-check-base) | Body, Optional | - |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
PaperCheckBase body = new PaperCheckBase();
body.setAmount(78.98);
body.setCurrency(CurrencyTypesEnum.HKD);

paperChecksController.postUsersUserTokenPaperchecksAsync(userToken, xMyPayQuickerVersion, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Users-User Token-Paperchecks-Dest Token

Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaperCheckResponse> getUsersUserTokenPaperchecksDestTokenAsync(
    final String userToken,
    final String xferToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

paperChecksController.getUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Put-Users-User Token-Paperchecks-Dest Token

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaperCheckResponse> putUsersUserTokenPaperchecksDestTokenAsync(
    final String userToken,
    final String xferToken,
    final String xMyPayQuickerVersion,
    final Object body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `Object` | Body, Optional | - |

##### Response Type

[`PaperCheckResponse`](#paper-check-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
String xMyPayQuickerVersion = "2020.02.24";

paperChecksController.putUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Delete-Users-User Token-Paper-Checks-Dest Token

Delete a paper check by destination token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> deleteUsersUserTokenPaperChecksDestTokenAsync(
    final String userToken,
    final String xferToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `String` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
String xMyPayQuickerVersion = "2020.02.24";

paperChecksController.deleteUsersUserTokenPaperChecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Bank Accounts

#### Overview

Bank account-related operations

##### Get instance

An instance of the `BankAccountsController` class can be accessed from the API Client.

```
BankAccountsController bankAccountsController = client.getBankAccountsController();
```

#### Get-Users-User Token-Bankaccounts

Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BankAccountCollectionResponse> getUsersUserTokenBankaccountsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountCollectionResponse`](#bank-account-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

bankAccountsController.getUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-7d8b1c83-01bb-40fb-87d7-26bd4c303f01",
      "status": "DELETED",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "333333333"
        },
        {
          "key": "BANK_BBAN",
          "value": "4444444444"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "My account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    },
    {
      "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
      "status": "ACTIVE",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "012346789"
        },
        {
          "key": "BANK_BBAN",
          "value": "987654321"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "Personal checking account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Post-Users-User Token-Bankaccounts

Create a quote for a bank account using a user token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BankAccountResponse> postUsersUserTokenBankaccountsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final BankAccountFields body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";

bankAccountsController.postUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Get-Users-User Token-Bankaccounts-Dest Token

Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BankAccountResponse> getUsersUserTokenBankaccountsDestTokenAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

bankAccountsController.getUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Put-Users-User Token-Bankaccounts-Dest Token

Update a bank account.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BankAccountResponse> putUsersUserTokenBankaccountsDestTokenAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final BankAccountFields body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`BankAccountResponse`](#bank-account-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";

bankAccountsController.putUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Delete-Users-User Token-Bankaccounts-Dest Token

Delete (cloak) a user bank account.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> deleteUsersUserTokenBankaccountsDestTokenAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";

bankAccountsController.deleteUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Users-User Token-Bankaccounts-Requirements

Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BankAccountRequirementCollectionResponse> getUsersUserTokenBankaccountsRequirementsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BankAccountRequirementCollectionResponse`](#bank-account-requirement-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

bankAccountsController.getUsersUserTokenBankaccountsRequirementsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "bankCountry": "IT",
      "bankCurrency": "EUR",
      "requirements": [
        {
          "requirement": "BANK_IBAN",
          "format": {
            "example": "IT43K0310412701000000820420",
            "legend": [
              {
                "key": "IT43K0310412701000000820420",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example IBAN"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio IBAN"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "IBAN"
            },
            {
              "language": "it-IT",
              "translation": "IBAN"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^IT\\\\d{2}[A-Z]\\\\d{10}[0-9A-Z]{12}$"
            }
          ]
        },
        {
          "requirement": "BANK_SWIFT_BIC",
          "format": {
            "example": "01234567890",
            "legend": [
              {
                "key": "01234567890",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example Swift/BIC"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio Swift/BIC"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "Swift/BIC"
            },
            {
              "language": "it-IT",
              "translation": "Swift/BIC"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^[a-z0-9A-Z]{8,11}$"
            }
          ]
        }
      ],
      "quote": {
        "formattedAmount": "$4.32 USD (USD, en-US), 0,00 € EUR (EUR, fr-FR)",
        "amount": 4.32,
        "currency": "USD"
      },
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

### Balances

#### Overview

Balance-related operations

##### Get instance

An instance of the `BalancesController` class can be accessed from the API Client.

```
BalancesController balancesController = client.getBalancesController();
```

#### Get-Users-User Token-Balances

Retrieve a list of user balances that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BalanceCollectionResponse> getUsersUserTokenBalancesAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

balancesController.getUsersUserTokenBalancesAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$4.32 USD",
      "amount": 4.32,
      "currency": "USD",
      "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/balances"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Balances

Retrieve a list of balances by destination token that supports filtering, sorting, and pagination through existing mechanisms. <i>*If the user belongs to a Flex-based program, balances against the user resource will return the wallet balance only. If it is a pre-paid card program (i.e., Meta USD), this balance and its associated pre-paid card balance will be the same.</i>

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BalanceCollectionResponse> getUsersUserTokenPrepaidcardsDestTokenBalancesAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

balancesController.getUsersUserTokenPrepaidcardsDestTokenBalancesAsync(userToken, destToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "formattedAmount": "$4.32",
  "amount": 4.32,
  "currency": "USD",
  "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
    }
  ]
}
```

#### Get-Accounts-Acct Token-Balances

Retrieve a single account balance.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BalanceCollectionResponse> getAccountsAcctTokenBalancesAsync(
    final String acctToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `String` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`BalanceCollectionResponse`](#balance-collection-response)

##### Example Usage

```java
String acctToken = "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

balancesController.getAccountsAcctTokenBalancesAsync(acctToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$5.00",
      "amount": 5,
      "currency": "USD",
      "token": "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4"
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4/balances"
    }
  ]
}
```

### Receipts

#### Overview

Receipt-related operations

##### Get instance

An instance of the `ReceiptsController` class can be accessed from the API Client.

```
ReceiptsController receiptsController = client.getReceiptsController();
```

#### Get-Accounts-Receipts

Retrieve a list of all account(s) receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Object> getAccountsReceiptsAsync(
    final String acctToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `String` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`Object`

##### Example Usage

```java
String acctToken = "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

receiptsController.getAccountsReceiptsAsync(acctToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response

```
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "acct-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Receipts

Retrieve a list all prepaid-card receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ReceiptCollectionResponse> getUsersUserTokenPrepaidcardsReceiptsAsync(
    final String userToken,
    final String destToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `String` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

receiptsController.getUsersUserTokenPrepaidcardsReceiptsAsync(userToken, destToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.05,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/prepaid-cards/dest-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-Receipts

Retrieve a list all user receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ReceiptCollectionResponse> getUsersReceiptsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`ReceiptCollectionResponse`](#receipt-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

receiptsController.getUsersReceiptsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

### Users

#### Overview

User-related operations

##### Get instance

An instance of the `UsersController` class can be accessed from the API Client.

```
UsersController usersController = client.getUsersController();
```

#### Put-Users-User Token

Update a user object (change email, address change, etc.) using a user token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UserResponse> putUsersUserTokenAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final UserBase body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase`](#user-base) | Body, Optional | - |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";

usersController.putUsersUserTokenAsync(userToken, xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token

Retrieve a single user record by user token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UserResponse> getUsersUserTokenAsync(
    final String userToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";

usersController.getUsersUserTokenAsync(userToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users

Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UserCollectionResponse> getUsersAsync(
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`UserCollectionResponse`](#user-collection-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

usersController.getUsersAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "firstName": "Jane",
      "lastName": "Smith",
      "dateOfBirth": "1977-12-14",
      "phoneNumber": "760-350-0324",
      "phoneNumberCountry": "US",
      "mobileNumber": "213-446-5755",
      "mobileNumberCountry": "US",
      "addressLine1": "290 Carriage Court",
      "city": "Los Angeles",
      "region": "CA",
      "country": "US",
      "postalCode": "90017",
      "addressType": "RESIDENTIAL",
      "email": "jsmith@payquicker.com",
      "gender": "FEMALE",
      "userType": "INDIVIDUAL",
      "programUserId": "d97ce0519b2d",
      "language": "en-US",
      "countryOfBirth": "US",
      "countryOfNationality": "US",
      "token": "usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357",
      "status": "PRE_ACTIVATED",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users"
    }
  ]
}
```

#### Post-Users

Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UserResponse> postUsersAsync(
    final String xMyPayQuickerVersion,
    final UserBase body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`UserBase`](#user-base) | Body, Required | Body details of the request |

##### Response Type

[`UserResponse`](#user-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";
UserBase body = new UserBase();
body.setPhoneNumber("760-350-0324");
body.setMobileNumber("213-446-5755");
body.setPhoneNumberCountry(CountryTypesEnum.US);
body.setMobileNumberCountry(CountryTypesEnum.US);
body.setFirstName("Jane");
body.setLastName("Smith");
body.setDateOfBirth(LocalDate.parse("1977-12-14"));
body.setAddressLine1("290 Carriage Court");
body.setCity("Los Angeles");
body.setRegion("CA");
body.setCountry(CountryTypesEnum.US);
body.setPostalCode("90017");
body.setAddressType(AddressTypesEnum.RESIDENTIAL);
body.setEmail("jsmith@payquicker.com");
body.setGender(GenderTypesEnum.FEMALE);
body.setUserType(UserTypesEnum.INDIVIDUAL);
body.setProgramUserId("d97ce0519b2d");
body.setLanguage(LanguageTypesEnum.ENUS);
body.setCountryOfBirth(CountryTypesEnum.US);
body.setCountryOfNationality(CountryTypesEnum.US);

usersController.postUsersAsync(xMyPayQuickerVersion, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks

Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<IdentityVerificationCollectionResponse> getUsersUserTokenIdvChecksAsync(
    final String userToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`IdentityVerificationCollectionResponse`](#identity-verification-collection-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";

usersController.getUsersUserTokenIdvChecksAsync(userToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
      "idvResult": "PASS",
      "idvSubResult": "HARD",
      "idvProvider": "IDOLOGY",
      "createdOn": "2020-02-21T22:00:00Z",
      "raw": "<RAW IDV processor output, for informational /debugging purposes only>",
      "idvCheckType": "NON_DOCUMENTARY",
      "idvDisposition": "FINAL",
      "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks-Idvc Token

Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<IdentityVerificationResponse> getUsersUserTokenIdvChecksIdvcTokenAsync(
    final String userToken,
    final String idvcToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `idvcToken` | `String` | Template, Required | Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`IdentityVerificationResponse`](#identity-verification-response)

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String idvcToken = "idvc-7e7567e0-c2db-485d-896d-45901a10baa9";
String xMyPayQuickerVersion = "2020.02.24";

usersController.getUsersUserTokenIdvChecksIdvcTokenAsync(userToken, idvcToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
  "idvResult": "PASS",
  "idvSubResult": "HARD",
  "idvProvider": "IDOLOGY",
  "createdOn": "2020-02-21T22:00:00Z",
  "raw": "<RAW IDV processor output, for informational/debugging purposes only>",
  "idvCheckType": "NON_DOCUMENTARY",
  "idvDispostion": "FINAL",
  "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
    }
  ]
}
```

#### Get-Users-User Token-Events

Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getUsersUserTokenEventsAsync(
    final String userToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";

usersController.getUsersUserTokenEventsAsync(userToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Users-User Token-Events-Event Token

Retrieve a single user event

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getUsersUserTokenEventsEventTokenAsync(
    final String userToken,
    final String evntToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `evntToken` | `String` | Template, Required | Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String evntToken = "evnt-28491de2-5b22-4e30-028a-45901a10baa9";

usersController.getUsersUserTokenEventsEventTokenAsync(userToken, evntToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Users-User Token-Agreements-Agmt Token

Accept a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> postUsersUserTokenAgreementsAgmtTokenAsync(
    final String userToken,
    final String agmtToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `agmtToken` | `String` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String agmtToken = "agmt-45901a10-5b22-4e30-028a-45901a10baa9";

usersController.postUsersUserTokenAgreementsAgmtTokenAsync(userToken, agmtToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Users-User Token-Agreements

Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getUsersUserTokenAgreementsAsync(
    final String userToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";

usersController.getUsersUserTokenAgreementsAsync(userToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Documents

#### Overview

Document-related operations

##### Get instance

An instance of the `DocumentsController` class can be accessed from the API Client.

```
DocumentsController documentsController = client.getDocumentsController();
```

#### Get-Users-User Token-Documents

Retrieve a list of user documents that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getUsersUserTokenDocumentsAsync(
    final String userToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

documentsController.getUsersUserTokenDocumentsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Post-Users-User Token-Documents

Create a quote for a user document.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> postUsersUserTokenDocumentsAsync(
    final String userToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String xMyPayQuickerVersion = "2020.02.24";

documentsController.postUsersUserTokenDocumentsAsync(userToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Users-User Token-Documents-Docu Token

Retrieve an individual user document by its document token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getUsersUserTokenDocumentsDocuTokenAsync(
    final String userToken,
    final String docuToken,
    final String xMyPayQuickerVersion,
    final Integer page,
    final Integer pageSize,
    final String filter,
    final String sort,
    final LanguageTypesEnum language)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `String` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `Integer` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `Integer` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `String` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `String` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`LanguageTypesEnum`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String docuToken = "docu-6260c132-5cb1-4e30-8b08-9ce559893acb";
String xMyPayQuickerVersion = "2020.02.24";
Integer pageSize = 20;
String filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
String sort = "-name";
LanguageTypesEnum language = LanguageTypesEnum.ENUS;

documentsController.getUsersUserTokenDocumentsDocuTokenAsync(userToken, docuToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Put-Users-User Token-Documents-Docu Token

Replace the user document at the given document token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> putUsersUserTokenDocumentsDocuTokenAsync(
    final String userToken,
    final String docuToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `String` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `String` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
String docuToken = "docu-6260c132-5cb1-4e30-8b08-9ce559893acb";
String xMyPayQuickerVersion = "2020.02.24";

documentsController.putUsersUserTokenDocumentsDocuTokenAsync(userToken, docuToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Webhooks

#### Overview

Webhook-related operations

##### Get instance

An instance of the `WebhooksController` class can be accessed from the API Client.

```
WebhooksController webhooksController = client.getWebhooksController();
```

#### Get-Webhook

Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<WebhookCollectionResponse> getWebhookAsync(
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`WebhookCollectionResponse`](#webhook-collection-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";

webhooksController.getWebhookAsync(xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "payload": [
    {
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ],
      "url": "https://www.example.com/webhooks",
      "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
      "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
      "created": "2020-01-01",
      "lastUpdated": "2020-02-01"
    }
  ]
}
```

#### Post-Webhooks

Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<WebhookSubscriptionResponse> postWebhooksAsync(
    final String xMyPayQuickerVersion,
    final WebhookSubscription body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`WebhookSubscription`](#webhook-subscription) | Body, Optional | - |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```java
String xMyPayQuickerVersion = "2020.02.24";

webhooksController.postWebhooksAsync(xMyPayQuickerVersion, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01"
}
```

#### Get-Webhooks-Webh-Token

Retrieve a single webhook subscription using the webhook token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<WebhookSubscriptionResponse> getWebhooksWebhTokenAsync(
    final String webhToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `String` | Template, Required | - |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`WebhookSubscriptionResponse`](#webhook-subscription-response)

##### Example Usage

```java
String webhToken = "webh-token0";
String xMyPayQuickerVersion = "2020.02.24";

webhooksController.getWebhooksWebhTokenAsync(webhToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01",
  "lastUpdated": "2020-02-01"
}
```

#### Delete-Webhooks-Webh-Token

Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> deleteWebhooksWebhTokenAsync(
    final String webhToken,
    final String xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `String` | Template, Required | - |
| `xMyPayQuickerVersion` | `String` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`void`

##### Example Usage

```java
String webhToken = "webh-token0";
String xMyPayQuickerVersion = "2020.02.24";

webhooksController.deleteWebhooksWebhTokenAsync(webhToken, xMyPayQuickerVersion).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Program

#### Overview

##### Get instance

An instance of the `ProgramController` class can be accessed from the API Client.

```
ProgramController programController = client.getProgramController();
```

#### Get-Programs

Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getProgramsAsync()
```

##### Response Type

`void`

##### Example Usage

```java
programController.getProgramsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Programs-Prog Token

Retrieve a single program configuration

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getProgramsProgTokenAsync(
    final String progToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `String` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |

##### Response Type

`void`

##### Example Usage

```java
String progToken = "prog-4525ab9c-5b22-4e30-028a-45901a10aa0c";

programController.getProgramsProgTokenAsync(progToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Programs-Prog Token-Agreements

Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getProgramsProgTokenAgreementsAsync(
    final String progToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `String` | Template, Required | - |

##### Response Type

`void`

##### Example Usage

```java
String progToken = "prog-token4";

programController.getProgramsProgTokenAgreementsAsync(progToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get-Programs-Prog Token-Agreements-Agmt Token

Retrieve a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> getProgramsProgTokenAgreementsAgmtTokenAsync(
    final String progToken,
    final String agmtToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `String` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |
| `agmtToken` | `String` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`void`

##### Example Usage

```java
String progToken = "prog-4525ab9c-5b22-4e30-028a-45901a10aa0c";
String agmtToken = "agmt-45901a10-5b22-4e30-028a-45901a10baa9";

programController.getProgramsProgTokenAgreementsAgmtTokenAsync(progToken, agmtToken).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Model Reference

### Structures

* [Source Monetary Required](#source-monetary-required)
* [Haetos Self Ref](#haetos-self-ref)
* [Haetos Params](#haetos-params)
* [Haetos Relationship](#haetos-relationship)
* [Transfer-Request](#transfer-request)
* [Transfer](#transfer)
* [Expiration](#expiration)
* [Transfer-Response](#transfer-response)
* [Not Before or After](#not-before-or-after)
* [Address](#address)
* [Business Address](#business-address)
* [Monetary Formatted](#monetary-formatted)
* [Transfer Base](#transfer-base)
* [Payment Base](#payment-base)
* [Transfer Base Ext](#transfer-base-ext)
* [Destination Monetary Required](#destination-monetary-required)
* [Monetary Required](#monetary-required)
* [Balance](#balance)
* [Fx Object](#fx-object)
* [User Base](#user-base)
* [User](#user)
* [User-Response](#user-response)
* [Receipt Base](#receipt-base)
* [Receipt Collection-Response](#receipt-collection-response)
* [Balance Collection-Response](#balance-collection-response)
* [User Collection-Response](#user-collection-response)
* [Payment-Request](#payment-request)
* [Payment](#payment)
* [Payments Collection-Response](#payments-collection-response)
* [Payment-Response](#payment-response)
* [Transfer Collection-Response](#transfer-collection-response)
* [User Name](#user-name)
* [Dob](#dob)
* [Business Information](#business-information)
* [User Kyc Information](#user-kyc-information)
* [Phone Numbers](#phone-numbers)
* [Email Address](#email-address)
* [User Employer Id](#user-employer-id)
* [Gender](#gender)
* [Language](#language)
* [User Type](#user-type)
* [Program User Id](#program-user-id)
* [Source Destination Token](#source-destination-token)
* [Token](#token)
* [Client Transfer Id](#client-transfer-id)
* [Notes](#notes)
* [Memo](#memo)
* [Created On](#created-on)
* [Transfer Status](#transfer-status)
* [User Status](#user-status)
* [Payment Purpose](#payment-purpose)
* [Source Token](#source-token)
* [Destination Token](#destination-token)
* [Client Payment Id](#client-payment-id)
* [Auto Accept Quote](#auto-accept-quote)
* [Rate](#rate)
* [Fx](#fx)
* [Paper Check Base](#paper-check-base)
* [Transfer Type](#transfer-type)
* [Bank Account Ownership](#bank-account-ownership)
* [Shipping Method](#shipping-method)
* [Paper Check](#paper-check)
* [Paper Check-Response](#paper-check-response)
* [Paper Check Collection-Response](#paper-check-collection-response)
* [Bank Account Fields](#bank-account-fields)
* [Bank Account Type](#bank-account-type)
* [Bank Account](#bank-account)
* [Bank Account Status](#bank-account-status)
* [Bank Account-Response](#bank-account-response)
* [Bank Account Collection-Response](#bank-account-collection-response)
* [Prepaid Card Package](#prepaid-card-package)
* [Prepaid Card Base](#prepaid-card-base)
* [Prepaid Card Status](#prepaid-card-status)
* [Token Type](#token-type)
* [Prepaid Card Base Ext](#prepaid-card-base-ext)
* [Card Network](#card-network)
* [Card Personalization Type](#card-personalization-type)
* [Prepaid Card](#prepaid-card)
* [Currency](#currency)
* [Country](#country)
* [Prepaid Card-Request Response](#prepaid-card-request-response)
* [Prepaid Card-Response](#prepaid-card-response)
* [Prepaid Card Collection-Response](#prepaid-card-collection-response)
* [Card Masked Pan](#card-masked-pan)
* [Prepaid Card Replacement Reason](#prepaid-card-replacement-reason)
* [Prepaid Card Replacement Base](#prepaid-card-replacement-base)
* [Prepaid Card Pin Token](#prepaid-card-pin-token)
* [Prepaid Card Pin](#prepaid-card-pin)
* [Cvv](#cvv)
* [Identity Verification Provider Type](#identity-verification-provider-type)
* [Identity Verification Result Type](#identity-verification-result-type)
* [Identity Verification Sub Result Type](#identity-verification-sub-result-type)
* [Identity Verification Disposition Type](#identity-verification-disposition-type)
* [Identity Verification Check Type](#identity-verification-check-type)
* [Identity Verification Base](#identity-verification-base)
* [Identity Verification Provider Reference](#identity-verification-provider-reference)
* [Identity Verification Provider Raw Output](#identity-verification-provider-raw-output)
* [Identity Verification-Response](#identity-verification-response)
* [Identity Verification Collection-Response](#identity-verification-collection-response)
* [Key Value Pair String String](#key-value-pair-string-string)
* [Key Value Pair Bank Field Types String](#key-value-pair-bank-field-types-string)
* [Key Value Pair Bank Currency Currency Types](#key-value-pair-bank-currency-currency-types)
* [Key Value Bank Country Country Types](#key-value-bank-country-country-types)
* [Bank Account Required Fields](#bank-account-required-fields)
* [Bank Account Requirement Format](#bank-account-requirement-format)
* [Bank Account Requirement Format Legend](#bank-account-requirement-format-legend)
* [Key Value Pair Language Type String](#key-value-pair-language-type-string)
* [Bank Account Requirement Validator](#bank-account-requirement-validator)
* [Bank Account Requirement](#bank-account-requirement)
* [Bank Account Requirement-Response](#bank-account-requirement-response)
* [Bank Account Requirement Collection-Response](#bank-account-requirement-collection-response)
* [Occupation](#occupation)
* [Tax Resident Status](#tax-resident-status)
* [Webhook-Subscription](#webhook-subscription)
* [Webhook-Subscription-Response](#webhook-subscription-response)
* [Webhook Collection-Response](#webhook-collection-response)
* [Prepaid Card Data-Response](#prepaid-card-data-response)
* [Prepaid Card Data Token](#prepaid-card-data-token)
* [Prepaid Card Data Token-Response](#prepaid-card-data-token-response)
* [Business Type](#business-type)
* [Country Nationality Information](#country-nationality-information)
* [Users Prepaid Cards Pin Response](#users-prepaid-cards-pin-response)

#### Source Monetary Required

Required details of the monetary source.

##### Class Name

`SourceMonetaryRequired`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceAmount` | `Double` | Optional | Amount of the transfer in the specified currency. | Double getSourceAmount() | setSourceAmount(Double sourceAmount) |
| `SourceCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getSourceCurrency() | setSourceCurrency(CurrencyTypesEnum sourceCurrency) |

##### Example (as JSON)

```json
{
  "sourceAmount": null,
  "sourceCurrency": null
}
```

#### Haetos Self Ref

Indicates the external link with the full URL of the same page on which the link appears.

##### Class Name

`HaetosSelfRef`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "links": null
}
```

#### Haetos Params

Hypermedia as the Engine of Application State (HAETOS) parameters used in a query.

##### Class Name

`HaetosParams`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Params` | [`HaetosRelationship`](#haetos-relationship) | Required | Indicates the HATEOS relationship between the target and current resources. | HaetosRelationship getParams() | setParams(HaetosRelationship params) |
| `Href` | `String` | Required | URL for resource described by the relationship. | String getHref() | setHref(String href) |

##### Example (as JSON)

```json
{
  "params": {
    "rel": "self"
  },
  "href": null
}
```

#### Haetos Relationship

Indicates the HATEOS relationship between the target and current resources.

##### Class Name

`HaetosRelationship`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rel` | `String` | Required | Indicates the relationship between the target and current resources.<br>**Default**: `"self"`<br>*Default: `"self"`* | String getRel() | setRel(String rel) |

##### Example (as JSON)

```json
{
  "rel": "self"
}
```

#### Transfer-Request

Request for the transfer

##### Class Name

`TransferRequest`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `ClientTransferId` | `String` | Optional | Unique value provided by the client for the transfer. | String getClientTransferId() | setClientTransferId(String clientTransferId) |
| `DestinationAmount` | `Double` | Optional | Amount transferred to the destination | Double getDestinationAmount() | setDestinationAmount(Double destinationAmount) |
| `DestinationCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getDestinationCurrency() | setDestinationCurrency(CurrencyTypesEnum destinationCurrency) |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "clientTransferId": null,
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Transfer

Description of the transfer request

##### Class Name

`Transfer`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `DestinationAmount` | `Double` | Optional | Amount transferred to the destination | Double getDestinationAmount() | setDestinationAmount(Double destinationAmount) |
| `DestinationCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getDestinationCurrency() | setDestinationCurrency(CurrencyTypesEnum destinationCurrency) |
| `ClientTransferId` | `String` | Optional | Unique value provided by the client for the transfer. | String getClientTransferId() | setClientTransferId(String clientTransferId) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `SourceAmount` | `Double` | Optional | Amount of the transfer in the specified currency. | Double getSourceAmount() | setSourceAmount(Double sourceAmount) |
| `SourceCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getSourceCurrency() | setSourceCurrency(CurrencyTypesEnum sourceCurrency) |
| `Status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer | TransferStatusTypesEnum getStatus() | setStatus(TransferStatusTypesEnum status) |
| `Fx` | [`FxObject`](#fx-object) | Optional | Currency conversion object details | FxObject getFx() | setFx(FxObject fx) |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null
}
```

#### Expiration

Date and time the object will expire

##### Class Name

`Expiration`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Expires` | `LocalDateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | LocalDateTime getExpires() | setExpires(LocalDateTime expires) |

##### Example (as JSON)

```json
{
  "expires": null
}
```

#### Transfer-Response

##### Class Name

`TransferResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `DestinationAmount` | `Double` | Optional | Amount transferred to the destination | Double getDestinationAmount() | setDestinationAmount(Double destinationAmount) |
| `DestinationCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getDestinationCurrency() | setDestinationCurrency(CurrencyTypesEnum destinationCurrency) |
| `ClientTransferId` | `String` | Optional | Unique value provided by the client for the transfer. | String getClientTransferId() | setClientTransferId(String clientTransferId) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `SourceAmount` | `Double` | Optional | Amount of the transfer in the specified currency. | Double getSourceAmount() | setSourceAmount(Double sourceAmount) |
| `SourceCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getSourceCurrency() | setSourceCurrency(CurrencyTypesEnum sourceCurrency) |
| `Status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer | TransferStatusTypesEnum getStatus() | setStatus(TransferStatusTypesEnum status) |
| `Fx` | [`FxObject`](#fx-object) | Optional | Currency conversion object details | FxObject getFx() | setFx(FxObject fx) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null,
  "links": null
}
```

#### Not Before or After

##### Class Name

`NotBeforeOrAfter`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotBefore` | `LocalDateTime` | Optional | Transfer is scheduled and will not process before this time. | LocalDateTime getNotBefore() | setNotBefore(LocalDateTime notBefore) |
| `NotAfter` | `LocalDateTime` | Optional | Transfer expires if not completed prior to this time. | LocalDateTime getNotAfter() | setNotAfter(LocalDateTime notAfter) |

##### Example (as JSON)

```json
{
  "notBefore": null,
  "notAfter": null
}
```

#### Address

Classifies the mailing address

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |

##### Example (as JSON)

```json
{
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null
}
```

#### Business Address

Address of the business location

##### Class Name

`BusinessAddress`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BusinessAddressLine1` | `String` | Optional | First line of the business address that specifies street number, street name, and building name | String getBusinessAddressLine1() | setBusinessAddressLine1(String businessAddressLine1) |
| `BusinessAddressLine2` | `String` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getBusinessAddressLine2() | setBusinessAddressLine2(String businessAddressLine2) |
| `BusinessAddressLine3` | `String` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | String getBusinessAddressLine3() | setBusinessAddressLine3(String businessAddressLine3) |
| `BusinessAddressLine4` | `String` | Optional | fourth line of the business address street address | String getBusinessAddressLine4() | setBusinessAddressLine4(String businessAddressLine4) |
| `BusinessAddressLine5` | `String` | Optional | Fifth line of the business address street address | String getBusinessAddressLine5() | setBusinessAddressLine5(String businessAddressLine5) |
| `BusinessCity` | `String` | Optional | City the business is registered | String getBusinessCity() | setBusinessCity(String businessCity) |
| `BusinessRegion` | `String` | Optional | State, province, or region the business is registered | String getBusinessRegion() | setBusinessRegion(String businessRegion) |
| `BusinessCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessCountry() | setBusinessCountry(CountryTypesEnum businessCountry) |
| `BusinessPostalCode` | `String` | Optional | Postal code for the business address | String getBusinessPostalCode() | setBusinessPostalCode(String businessPostalCode) |
| `BusinessPremiseNumber` | `String` | Optional | House number for the business address | String getBusinessPremiseNumber() | setBusinessPremiseNumber(String businessPremiseNumber) |

##### Example (as JSON)

```json
{
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null
}
```

#### Monetary Formatted

Object representing monies, including currency, decimal, and formatted amounts

##### Class Name

`MonetaryFormatted`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FormattedAmount` | `String` | Optional | Formatted monetary amount | String getFormattedAmount() | setFormattedAmount(String formattedAmount) |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base

Base class for the transfer

##### Class Name

`TransferBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null
}
```

#### Payment Base

Base class for the payment

##### Class Name

`PaymentBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `Purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | PaymentPurposeTypesEnum getPurpose() | setPurpose(PaymentPurposeTypesEnum purpose) |
| `ClientPaymentId` | `String` | Optional | Unique value provided by the client for the payment. | String getClientPaymentId() | setClientPaymentId(String clientPaymentId) |
| `AutoAcceptQuote` | `Boolean` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | Boolean getAutoAcceptQuote() | setAutoAcceptQuote(Boolean autoAcceptQuote) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base Ext

Base extension for the transfer

##### Class Name

`TransferBaseExt`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `DestinationAmount` | `Double` | Optional | Amount transferred to the destination | Double getDestinationAmount() | setDestinationAmount(Double destinationAmount) |
| `DestinationCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getDestinationCurrency() | setDestinationCurrency(CurrencyTypesEnum destinationCurrency) |
| `ClientTransferId` | `String` | Optional | Unique value provided by the client for the transfer. | String getClientTransferId() | setClientTransferId(String clientTransferId) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null
}
```

#### Destination Monetary Required

Monetary instruments required for the destination

##### Class Name

`DestinationMonetaryRequired`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DestinationAmount` | `Double` | Optional | Amount transferred to the destination | Double getDestinationAmount() | setDestinationAmount(Double destinationAmount) |
| `DestinationCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getDestinationCurrency() | setDestinationCurrency(CurrencyTypesEnum destinationCurrency) |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Monetary Required

Monetary requirements for the transfer

##### Class Name

`MonetaryRequired`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Balance

Account monetary balance

##### Class Name

`Balance`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FormattedAmount` | `String` | Optional | Formatted monetary amount | String getFormattedAmount() | setFormattedAmount(String formattedAmount) |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Fx Object

Currency conversion object details

##### Class Name

`FxObject`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DestinationAmount` | `Double` | Optional | Amount transferred to the destination | Double getDestinationAmount() | setDestinationAmount(Double destinationAmount) |
| `DestinationCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getDestinationCurrency() | setDestinationCurrency(CurrencyTypesEnum destinationCurrency) |
| `SourceAmount` | `Double` | Optional | Amount of the transfer in the specified currency. | Double getSourceAmount() | setSourceAmount(Double sourceAmount) |
| `SourceCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getSourceCurrency() | setSourceCurrency(CurrencyTypesEnum sourceCurrency) |
| `Rate` | `Double` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` | Double getRate() | setRate(Double rate) |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "rate": null
}
```

#### User Base

Object for the established group of users

##### Class Name

`UserBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | String getLastName() | setLastName(String lastName) |
| `DateOfBirth` | `LocalDate` | Optional | User's date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `BusinessName` | `String` | Optional | Legal name for the business | String getBusinessName() | setBusinessName(String businessName) |
| `BusinessOperatingName` | `String` | Optional | Name under which the business operates | String getBusinessOperatingName() | setBusinessOperatingName(String businessOperatingName) |
| `BusinessRegistrationId` | `String` | Optional | Registration number or ID assigned by a government body | String getBusinessRegistrationId() | setBusinessRegistrationId(String businessRegistrationId) |
| `BusinessRegistrationRegion` | `String` | Optional | State, province, or territory where the business is registered | String getBusinessRegistrationRegion() | setBusinessRegistrationRegion(String businessRegistrationRegion) |
| `BusinessRegistrationCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessRegistrationCountry() | setBusinessRegistrationCountry(CountryTypesEnum businessRegistrationCountry) |
| `BusinessContactRole` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business | BusinessContactRoleEnum getBusinessContactRole() | setBusinessContactRole(BusinessContactRoleEnum businessContactRole) |
| `BusinessAddressLine1` | `String` | Optional | First line of the business address that specifies street number, street name, and building name | String getBusinessAddressLine1() | setBusinessAddressLine1(String businessAddressLine1) |
| `BusinessAddressLine2` | `String` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getBusinessAddressLine2() | setBusinessAddressLine2(String businessAddressLine2) |
| `BusinessAddressLine3` | `String` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | String getBusinessAddressLine3() | setBusinessAddressLine3(String businessAddressLine3) |
| `BusinessAddressLine4` | `String` | Optional | fourth line of the business address street address | String getBusinessAddressLine4() | setBusinessAddressLine4(String businessAddressLine4) |
| `BusinessAddressLine5` | `String` | Optional | Fifth line of the business address street address | String getBusinessAddressLine5() | setBusinessAddressLine5(String businessAddressLine5) |
| `BusinessCity` | `String` | Optional | City the business is registered | String getBusinessCity() | setBusinessCity(String businessCity) |
| `BusinessRegion` | `String` | Optional | State, province, or region the business is registered | String getBusinessRegion() | setBusinessRegion(String businessRegion) |
| `BusinessCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessCountry() | setBusinessCountry(CountryTypesEnum businessCountry) |
| `BusinessPostalCode` | `String` | Optional | Postal code for the business address | String getBusinessPostalCode() | setBusinessPostalCode(String businessPostalCode) |
| `BusinessPremiseNumber` | `String` | Optional | House number for the business address | String getBusinessPremiseNumber() | setBusinessPremiseNumber(String businessPremiseNumber) |
| `BusinessType` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | BusinessTypesEnum getBusinessType() | setBusinessType(BusinessTypesEnum businessType) |
| `DriverLicenseId` | `String` | Optional | User's driver's license number | String getDriverLicenseId() | setDriverLicenseId(String driverLicenseId) |
| `PassportId` | `String` | Optional | User's passport number | String getPassportId() | setPassportId(String passportId) |
| `GovernmentIdType` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type | GovernmentIdTypeEnum getGovernmentIdType() | setGovernmentIdType(GovernmentIdTypeEnum governmentIdType) |
| `GovernmentId` | `String` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | String getGovernmentId() | setGovernmentId(String governmentId) |
| `PhoneNumber` | `String` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `MobileNumber` | `String` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `PhoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getPhoneNumberCountry() | setPhoneNumberCountry(CountryTypesEnum phoneNumberCountry) |
| `MobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getMobileNumberCountry() | setMobileNumberCountry(CountryTypesEnum mobileNumberCountry) |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |
| `Email` | `String` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | String getEmail() | setEmail(String email) |
| `EmployerId` | `String` | Optional | User's employer identifier | String getEmployerId() | setEmployerId(String employerId) |
| `Gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies | GenderTypesEnum getGender() | setGender(GenderTypesEnum gender) |
| `UserType` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type | UserTypesEnum getUserType() | setUserType(UserTypesEnum userType) |
| `ProgramUserId` | `String` | Optional | Program identifier for the user | String getProgramUserId() | setProgramUserId(String programUserId) |
| `Language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format | LanguageTypesEnum getLanguage() | setLanguage(LanguageTypesEnum language) |
| `CountryOfBirth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfBirth() | setCountryOfBirth(CountryTypesEnum countryOfBirth) |
| `CountryOfNationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfNationality() | setCountryOfNationality(CountryTypesEnum countryOfNationality) |
| `Occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user | OccupationTypesEnum getOccupation() | setOccupation(OccupationTypesEnum occupation) |
| `TaxResidentStatus` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country | TaxResidentStatusTypesEnum getTaxResidentStatus() | setTaxResidentStatus(TaxResidentStatusTypesEnum taxResidentStatus) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null
}
```

#### User

Object for user

##### Class Name

`User`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | String getLastName() | setLastName(String lastName) |
| `DateOfBirth` | `LocalDate` | Optional | User's date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `BusinessName` | `String` | Optional | Legal name for the business | String getBusinessName() | setBusinessName(String businessName) |
| `BusinessOperatingName` | `String` | Optional | Name under which the business operates | String getBusinessOperatingName() | setBusinessOperatingName(String businessOperatingName) |
| `BusinessRegistrationId` | `String` | Optional | Registration number or ID assigned by a government body | String getBusinessRegistrationId() | setBusinessRegistrationId(String businessRegistrationId) |
| `BusinessRegistrationRegion` | `String` | Optional | State, province, or territory where the business is registered | String getBusinessRegistrationRegion() | setBusinessRegistrationRegion(String businessRegistrationRegion) |
| `BusinessRegistrationCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessRegistrationCountry() | setBusinessRegistrationCountry(CountryTypesEnum businessRegistrationCountry) |
| `BusinessContactRole` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business | BusinessContactRoleEnum getBusinessContactRole() | setBusinessContactRole(BusinessContactRoleEnum businessContactRole) |
| `BusinessAddressLine1` | `String` | Optional | First line of the business address that specifies street number, street name, and building name | String getBusinessAddressLine1() | setBusinessAddressLine1(String businessAddressLine1) |
| `BusinessAddressLine2` | `String` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getBusinessAddressLine2() | setBusinessAddressLine2(String businessAddressLine2) |
| `BusinessAddressLine3` | `String` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | String getBusinessAddressLine3() | setBusinessAddressLine3(String businessAddressLine3) |
| `BusinessAddressLine4` | `String` | Optional | fourth line of the business address street address | String getBusinessAddressLine4() | setBusinessAddressLine4(String businessAddressLine4) |
| `BusinessAddressLine5` | `String` | Optional | Fifth line of the business address street address | String getBusinessAddressLine5() | setBusinessAddressLine5(String businessAddressLine5) |
| `BusinessCity` | `String` | Optional | City the business is registered | String getBusinessCity() | setBusinessCity(String businessCity) |
| `BusinessRegion` | `String` | Optional | State, province, or region the business is registered | String getBusinessRegion() | setBusinessRegion(String businessRegion) |
| `BusinessCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessCountry() | setBusinessCountry(CountryTypesEnum businessCountry) |
| `BusinessPostalCode` | `String` | Optional | Postal code for the business address | String getBusinessPostalCode() | setBusinessPostalCode(String businessPostalCode) |
| `BusinessPremiseNumber` | `String` | Optional | House number for the business address | String getBusinessPremiseNumber() | setBusinessPremiseNumber(String businessPremiseNumber) |
| `BusinessType` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | BusinessTypesEnum getBusinessType() | setBusinessType(BusinessTypesEnum businessType) |
| `DriverLicenseId` | `String` | Optional | User's driver's license number | String getDriverLicenseId() | setDriverLicenseId(String driverLicenseId) |
| `PassportId` | `String` | Optional | User's passport number | String getPassportId() | setPassportId(String passportId) |
| `GovernmentIdType` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type | GovernmentIdTypeEnum getGovernmentIdType() | setGovernmentIdType(GovernmentIdTypeEnum governmentIdType) |
| `GovernmentId` | `String` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | String getGovernmentId() | setGovernmentId(String governmentId) |
| `PhoneNumber` | `String` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `MobileNumber` | `String` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `PhoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getPhoneNumberCountry() | setPhoneNumberCountry(CountryTypesEnum phoneNumberCountry) |
| `MobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getMobileNumberCountry() | setMobileNumberCountry(CountryTypesEnum mobileNumberCountry) |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |
| `Email` | `String` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | String getEmail() | setEmail(String email) |
| `EmployerId` | `String` | Optional | User's employer identifier | String getEmployerId() | setEmployerId(String employerId) |
| `Gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies | GenderTypesEnum getGender() | setGender(GenderTypesEnum gender) |
| `UserType` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type | UserTypesEnum getUserType() | setUserType(UserTypesEnum userType) |
| `ProgramUserId` | `String` | Optional | Program identifier for the user | String getProgramUserId() | setProgramUserId(String programUserId) |
| `Language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format | LanguageTypesEnum getLanguage() | setLanguage(LanguageTypesEnum language) |
| `CountryOfBirth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfBirth() | setCountryOfBirth(CountryTypesEnum countryOfBirth) |
| `CountryOfNationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfNationality() | setCountryOfNationality(CountryTypesEnum countryOfNationality) |
| `Occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user | OccupationTypesEnum getOccupation() | setOccupation(OccupationTypesEnum occupation) |
| `TaxResidentStatus` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country | TaxResidentStatusTypesEnum getTaxResidentStatus() | setTaxResidentStatus(TaxResidentStatusTypesEnum taxResidentStatus) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`UserStatusTypesEnum`](#user-status-types) | Optional | Current status of the user | UserStatusTypesEnum getStatus() | setStatus(UserStatusTypesEnum status) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null
}
```

#### User-Response

Response from a user request

##### Class Name

`UserResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | String getLastName() | setLastName(String lastName) |
| `DateOfBirth` | `LocalDate` | Optional | User's date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `BusinessName` | `String` | Optional | Legal name for the business | String getBusinessName() | setBusinessName(String businessName) |
| `BusinessOperatingName` | `String` | Optional | Name under which the business operates | String getBusinessOperatingName() | setBusinessOperatingName(String businessOperatingName) |
| `BusinessRegistrationId` | `String` | Optional | Registration number or ID assigned by a government body | String getBusinessRegistrationId() | setBusinessRegistrationId(String businessRegistrationId) |
| `BusinessRegistrationRegion` | `String` | Optional | State, province, or territory where the business is registered | String getBusinessRegistrationRegion() | setBusinessRegistrationRegion(String businessRegistrationRegion) |
| `BusinessRegistrationCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessRegistrationCountry() | setBusinessRegistrationCountry(CountryTypesEnum businessRegistrationCountry) |
| `BusinessContactRole` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business | BusinessContactRoleEnum getBusinessContactRole() | setBusinessContactRole(BusinessContactRoleEnum businessContactRole) |
| `BusinessAddressLine1` | `String` | Optional | First line of the business address that specifies street number, street name, and building name | String getBusinessAddressLine1() | setBusinessAddressLine1(String businessAddressLine1) |
| `BusinessAddressLine2` | `String` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getBusinessAddressLine2() | setBusinessAddressLine2(String businessAddressLine2) |
| `BusinessAddressLine3` | `String` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | String getBusinessAddressLine3() | setBusinessAddressLine3(String businessAddressLine3) |
| `BusinessAddressLine4` | `String` | Optional | fourth line of the business address street address | String getBusinessAddressLine4() | setBusinessAddressLine4(String businessAddressLine4) |
| `BusinessAddressLine5` | `String` | Optional | Fifth line of the business address street address | String getBusinessAddressLine5() | setBusinessAddressLine5(String businessAddressLine5) |
| `BusinessCity` | `String` | Optional | City the business is registered | String getBusinessCity() | setBusinessCity(String businessCity) |
| `BusinessRegion` | `String` | Optional | State, province, or region the business is registered | String getBusinessRegion() | setBusinessRegion(String businessRegion) |
| `BusinessCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessCountry() | setBusinessCountry(CountryTypesEnum businessCountry) |
| `BusinessPostalCode` | `String` | Optional | Postal code for the business address | String getBusinessPostalCode() | setBusinessPostalCode(String businessPostalCode) |
| `BusinessPremiseNumber` | `String` | Optional | House number for the business address | String getBusinessPremiseNumber() | setBusinessPremiseNumber(String businessPremiseNumber) |
| `BusinessType` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | BusinessTypesEnum getBusinessType() | setBusinessType(BusinessTypesEnum businessType) |
| `DriverLicenseId` | `String` | Optional | User's driver's license number | String getDriverLicenseId() | setDriverLicenseId(String driverLicenseId) |
| `PassportId` | `String` | Optional | User's passport number | String getPassportId() | setPassportId(String passportId) |
| `GovernmentIdType` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type | GovernmentIdTypeEnum getGovernmentIdType() | setGovernmentIdType(GovernmentIdTypeEnum governmentIdType) |
| `GovernmentId` | `String` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | String getGovernmentId() | setGovernmentId(String governmentId) |
| `PhoneNumber` | `String` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `MobileNumber` | `String` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `PhoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getPhoneNumberCountry() | setPhoneNumberCountry(CountryTypesEnum phoneNumberCountry) |
| `MobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getMobileNumberCountry() | setMobileNumberCountry(CountryTypesEnum mobileNumberCountry) |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |
| `Email` | `String` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | String getEmail() | setEmail(String email) |
| `EmployerId` | `String` | Optional | User's employer identifier | String getEmployerId() | setEmployerId(String employerId) |
| `Gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies | GenderTypesEnum getGender() | setGender(GenderTypesEnum gender) |
| `UserType` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type | UserTypesEnum getUserType() | setUserType(UserTypesEnum userType) |
| `ProgramUserId` | `String` | Optional | Program identifier for the user | String getProgramUserId() | setProgramUserId(String programUserId) |
| `Language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format | LanguageTypesEnum getLanguage() | setLanguage(LanguageTypesEnum language) |
| `CountryOfBirth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfBirth() | setCountryOfBirth(CountryTypesEnum countryOfBirth) |
| `CountryOfNationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfNationality() | setCountryOfNationality(CountryTypesEnum countryOfNationality) |
| `Occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user | OccupationTypesEnum getOccupation() | setOccupation(OccupationTypesEnum occupation) |
| `TaxResidentStatus` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country | TaxResidentStatusTypesEnum getTaxResidentStatus() | setTaxResidentStatus(TaxResidentStatusTypesEnum taxResidentStatus) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`UserStatusTypesEnum`](#user-status-types) | Optional | Current status of the user | UserStatusTypesEnum getStatus() | setStatus(UserStatusTypesEnum status) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null,
  "links": null
}
```

#### Receipt Base

Base for the receipt

##### Class Name

`ReceiptBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FormattedAmount` | `String` | Optional | Formatted monetary amount | String getFormattedAmount() | setFormattedAmount(String formattedAmount) |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer | TransferStatusTypesEnum getStatus() | setStatus(TransferStatusTypesEnum status) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Receipt Collection-Response

Response from a Receipt Collection request

##### Class Name

`ReceiptCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<ReceiptBase>`](#receipt-base) | Optional | - | List<ReceiptBase> getPayload() | setPayload(List<ReceiptBase> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Balance Collection-Response

Response from a Balance Collection request

##### Class Name

`BalanceCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<Balance>`](#balance) | Optional | - | List<Balance> getPayload() | setPayload(List<Balance> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Collection-Response

Response from a User Collection request

##### Class Name

`UserCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<UserResponse>`](#user-response) | Optional | - | List<UserResponse> getPayload() | setPayload(List<UserResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Request

Payment request

##### Class Name

`PaymentRequest`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `Purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | PaymentPurposeTypesEnum getPurpose() | setPurpose(PaymentPurposeTypesEnum purpose) |
| `ClientPaymentId` | `String` | Optional | Unique value provided by the client for the payment. | String getClientPaymentId() | setClientPaymentId(String clientPaymentId) |
| `AutoAcceptQuote` | `Boolean` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | Boolean getAutoAcceptQuote() | setAutoAcceptQuote(Boolean autoAcceptQuote) |
| `NotBefore` | `LocalDateTime` | Optional | Transfer is scheduled and will not process before this time. | LocalDateTime getNotBefore() | setNotBefore(LocalDateTime notBefore) |
| `NotAfter` | `LocalDateTime` | Optional | Transfer expires if not completed prior to this time. | LocalDateTime getNotAfter() | setNotAfter(LocalDateTime notAfter) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payment

Response from a Transfer request

##### Class Name

`Payment`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `Purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | PaymentPurposeTypesEnum getPurpose() | setPurpose(PaymentPurposeTypesEnum purpose) |
| `ClientPaymentId` | `String` | Optional | Unique value provided by the client for the payment. | String getClientPaymentId() | setClientPaymentId(String clientPaymentId) |
| `AutoAcceptQuote` | `Boolean` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | Boolean getAutoAcceptQuote() | setAutoAcceptQuote(Boolean autoAcceptQuote) |
| `Expires` | `LocalDateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | LocalDateTime getExpires() | setExpires(LocalDateTime expires) |
| `NotBefore` | `LocalDateTime` | Optional | Transfer is scheduled and will not process before this time. | LocalDateTime getNotBefore() | setNotBefore(LocalDateTime notBefore) |
| `NotAfter` | `LocalDateTime` | Optional | Transfer expires if not completed prior to this time. | LocalDateTime getNotAfter() | setNotAfter(LocalDateTime notAfter) |
| `Status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer | TransferStatusTypesEnum getStatus() | setStatus(TransferStatusTypesEnum status) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payments Collection-Response

Response from a Payment collection request

##### Class Name

`PaymentsCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<PaymentResponse>`](#payment-response) | Optional | - | List<PaymentResponse> getPayload() | setPayload(List<PaymentResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Response

Response from a Payment request

##### Class Name

`PaymentResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |
| `Purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | PaymentPurposeTypesEnum getPurpose() | setPurpose(PaymentPurposeTypesEnum purpose) |
| `ClientPaymentId` | `String` | Optional | Unique value provided by the client for the payment. | String getClientPaymentId() | setClientPaymentId(String clientPaymentId) |
| `AutoAcceptQuote` | `Boolean` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | Boolean getAutoAcceptQuote() | setAutoAcceptQuote(Boolean autoAcceptQuote) |
| `Expires` | `LocalDateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | LocalDateTime getExpires() | setExpires(LocalDateTime expires) |
| `NotBefore` | `LocalDateTime` | Optional | Transfer is scheduled and will not process before this time. | LocalDateTime getNotBefore() | setNotBefore(LocalDateTime notBefore) |
| `NotAfter` | `LocalDateTime` | Optional | Transfer expires if not completed prior to this time. | LocalDateTime getNotAfter() | setNotAfter(LocalDateTime notAfter) |
| `Status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer | TransferStatusTypesEnum getStatus() | setStatus(TransferStatusTypesEnum status) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Collection-Response

Response from a Transfer request

##### Class Name

`TransferCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<TransferResponse>`](#transfer-response) | Optional | - | List<TransferResponse> getPayload() | setPayload(List<TransferResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Name

##### Class Name

`UserName`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. | String getLastName() | setLastName(String lastName) |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

#### Dob

##### Class Name

`Dob`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DateOfBirth` | `LocalDate` | Optional | User's date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |

##### Example (as JSON)

```json
{
  "dateOfBirth": null
}
```

#### Business Information

Physical address of the business and other information, such as <i>Operating Name</i>, <i>Registration ID</i>, etc.

##### Class Name

`BusinessInformation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BusinessName` | `String` | Optional | Legal name for the business | String getBusinessName() | setBusinessName(String businessName) |
| `BusinessOperatingName` | `String` | Optional | Name under which the business operates | String getBusinessOperatingName() | setBusinessOperatingName(String businessOperatingName) |
| `BusinessRegistrationId` | `String` | Optional | Registration number or ID assigned by a government body | String getBusinessRegistrationId() | setBusinessRegistrationId(String businessRegistrationId) |
| `BusinessRegistrationRegion` | `String` | Optional | State, province, or territory where the business is registered | String getBusinessRegistrationRegion() | setBusinessRegistrationRegion(String businessRegistrationRegion) |
| `BusinessRegistrationCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessRegistrationCountry() | setBusinessRegistrationCountry(CountryTypesEnum businessRegistrationCountry) |
| `BusinessContactRole` | [`BusinessContactRoleEnum`](#business-contact-role) | Optional | Role of the user within the business | BusinessContactRoleEnum getBusinessContactRole() | setBusinessContactRole(BusinessContactRoleEnum businessContactRole) |
| `BusinessAddressLine1` | `String` | Optional | First line of the business address that specifies street number, street name, and building name | String getBusinessAddressLine1() | setBusinessAddressLine1(String businessAddressLine1) |
| `BusinessAddressLine2` | `String` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getBusinessAddressLine2() | setBusinessAddressLine2(String businessAddressLine2) |
| `BusinessAddressLine3` | `String` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 | String getBusinessAddressLine3() | setBusinessAddressLine3(String businessAddressLine3) |
| `BusinessAddressLine4` | `String` | Optional | fourth line of the business address street address | String getBusinessAddressLine4() | setBusinessAddressLine4(String businessAddressLine4) |
| `BusinessAddressLine5` | `String` | Optional | Fifth line of the business address street address | String getBusinessAddressLine5() | setBusinessAddressLine5(String businessAddressLine5) |
| `BusinessCity` | `String` | Optional | City the business is registered | String getBusinessCity() | setBusinessCity(String businessCity) |
| `BusinessRegion` | `String` | Optional | State, province, or region the business is registered | String getBusinessRegion() | setBusinessRegion(String businessRegion) |
| `BusinessCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBusinessCountry() | setBusinessCountry(CountryTypesEnum businessCountry) |
| `BusinessPostalCode` | `String` | Optional | Postal code for the business address | String getBusinessPostalCode() | setBusinessPostalCode(String businessPostalCode) |
| `BusinessPremiseNumber` | `String` | Optional | House number for the business address | String getBusinessPremiseNumber() | setBusinessPremiseNumber(String businessPremiseNumber) |
| `BusinessType` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | BusinessTypesEnum getBusinessType() | setBusinessType(BusinessTypesEnum businessType) |

##### Example (as JSON)

```json
{
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null
}
```

#### User Kyc Information

##### Class Name

`UserKycInformation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DriverLicenseId` | `String` | Optional | User's driver's license number | String getDriverLicenseId() | setDriverLicenseId(String driverLicenseId) |
| `PassportId` | `String` | Optional | User's passport number | String getPassportId() | setPassportId(String passportId) |
| `GovernmentIdType` | [`GovernmentIdTypeEnum`](#government-id-type) | Optional | User's government ID type | GovernmentIdTypeEnum getGovernmentIdType() | setGovernmentIdType(GovernmentIdTypeEnum governmentIdType) |
| `GovernmentId` | `String` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> | String getGovernmentId() | setGovernmentId(String governmentId) |

##### Example (as JSON)

```json
{
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null
}
```

#### Phone Numbers

##### Class Name

`PhoneNumbers`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PhoneNumber` | `String` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `MobileNumber` | `String` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `PhoneNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getPhoneNumberCountry() | setPhoneNumberCountry(CountryTypesEnum phoneNumberCountry) |
| `MobileNumberCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getMobileNumberCountry() | setMobileNumberCountry(CountryTypesEnum mobileNumberCountry) |

##### Example (as JSON)

```json
{
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC"
}
```

#### Email Address

Contact email address for the user account

##### Class Name

`EmailAddress`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Email` | `String` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` | String getEmail() | setEmail(String email) |

##### Example (as JSON)

```json
{
  "email": null
}
```

#### User Employer Id

User's employer identifier, generally used for tax purposes.

##### Class Name

`UserEmployerId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EmployerId` | `String` | Optional | User's employer identifier | String getEmployerId() | setEmployerId(String employerId) |

##### Example (as JSON)

```json
{
  "employerId": null
}
```

#### Gender

Gender as the user identifies

##### Class Name

`Gender`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Gender` | [`GenderTypesEnum`](#gender-types) | Optional | Gender as a user identifies | GenderTypesEnum getGender() | setGender(GenderTypesEnum gender) |

##### Example (as JSON)

```json
{
  "gender": null
}
```

#### Language

Preferred language for the user's account. <i>Defaults to English</i>

##### Class Name

`Language`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format | LanguageTypesEnum getLanguage() | setLanguage(LanguageTypesEnum language) |

##### Example (as JSON)

```json
{
  "language": null
}
```

#### User Type

User's profile type

##### Class Name

`UserType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `UserType` | [`UserTypesEnum`](#user-types) | Optional | Account holder's profile type | UserTypesEnum getUserType() | setUserType(UserTypesEnum userType) |

##### Example (as JSON)

```json
{
  "userType": null
}
```

#### Program User Id

Program identifier for the user

##### Class Name

`ProgramUserId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProgramUserId` | `String` | Optional | Program identifier for the user | String getProgramUserId() | setProgramUserId(String programUserId) |

##### Example (as JSON)

```json
{
  "programUserId": null
}
```

#### Source Destination Token

Unique identifier representing the source of the funds.

##### Class Name

`SourceDestinationToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null
}
```

#### Token

Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.

##### Class Name

`Token`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Client Transfer Id

Unique value provided by the client for the transfer, utilized for reference and deduplication.

##### Class Name

`ClientTransferId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ClientTransferId` | `String` | Optional | Unique value provided by the client for the transfer. | String getClientTransferId() | setClientTransferId(String clientTransferId) |

##### Example (as JSON)

```json
{
  "clientTransferId": null
}
```

#### Notes

Optional comments visible to the user

##### Class Name

`Notes`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Notes` | `String` | Optional | Optional comments visible to the user. | String getNotes() | setNotes(String notes) |

##### Example (as JSON)

```json
{
  "notes": null
}
```

#### Memo

Optional internal memo not visible to the user.

##### Class Name

`Memo`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Memo` | `String` | Optional | Optional internal memo not visible to the user. | String getMemo() | setMemo(String memo) |

##### Example (as JSON)

```json
{
  "memo": null
}
```

#### Created On

Time at which the object was created.

##### Class Name

`CreatedOn`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |

##### Example (as JSON)

```json
{
  "createdOn": null
}
```

#### Transfer Status

Current status of the transfer.

##### Class Name

`TransferStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`TransferStatusTypesEnum`](#transfer-status-types) | Optional | Current status of a transfer | TransferStatusTypesEnum getStatus() | setStatus(TransferStatusTypesEnum status) |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### User Status

Current status of the user.

##### Class Name

`UserStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`UserStatusTypesEnum`](#user-status-types) | Optional | Current status of the user | UserStatusTypesEnum getStatus() | setStatus(UserStatusTypesEnum status) |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Payment Purpose

Purpose for the payment being made.

##### Class Name

`PaymentPurpose`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Purpose` | [`PaymentPurposeTypesEnum`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) | PaymentPurposeTypesEnum getPurpose() | setPurpose(PaymentPurposeTypesEnum purpose) |

##### Example (as JSON)

```json
{
  "purpose": null
}
```

#### Source Token

Unique identifier representing the source of funds.

##### Class Name

`SourceToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SourceToken` | `String` | Optional | Unique identifier representing the source of funds. | String getSourceToken() | setSourceToken(String sourceToken) |

##### Example (as JSON)

```json
{
  "sourceToken": null
}
```

#### Destination Token

Unique identifier representing the destination of funds.

##### Class Name

`DestinationToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DestinationToken` | `String` | Optional | Unique identifier representing the destination of funds. | String getDestinationToken() | setDestinationToken(String destinationToken) |

##### Example (as JSON)

```json
{
  "destinationToken": null
}
```

#### Client Payment Id

Unique value provided by the client for the payment, utilized for reference and de-duplication.

##### Class Name

`ClientPaymentId`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ClientPaymentId` | `String` | Optional | Unique value provided by the client for the payment. | String getClientPaymentId() | setClientPaymentId(String clientPaymentId) |

##### Example (as JSON)

```json
{
  "clientPaymentId": null
}
```

#### Auto Accept Quote

Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.

##### Class Name

`AutoAcceptQuote`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AutoAcceptQuote` | `Boolean` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. | Boolean getAutoAcceptQuote() | setAutoAcceptQuote(Boolean autoAcceptQuote) |

##### Example (as JSON)

```json
{
  "autoAcceptQuote": null
}
```

#### Rate

Exchange rate

##### Class Name

`Rate`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | `Double` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` | Double getRate() | setRate(Double rate) |

##### Example (as JSON)

```json
{
  "rate": null
}
```

#### Fx

The details of the country's foreign exchange currency.

##### Class Name

`Fx`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Fx` | [`FxObject`](#fx-object) | Optional | Currency conversion object details | FxObject getFx() | setFx(FxObject fx) |

##### Example (as JSON)

```json
{
  "fx": null
}
```

#### Paper Check Base

##### Class Name

`PaperCheckBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type | TransferTypesEnum getType() | setType(TransferTypesEnum type) |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |
| `ShippingMethod` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | ShippingMethodTypesEnum getShippingMethod() | setShippingMethod(ShippingMethodTypesEnum shippingMethod) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Type

Type of transfer method

##### Class Name

`TransferType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type | TransferTypesEnum getType() | setType(TransferTypesEnum type) |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account Ownership

Account ownership type

##### Class Name

`BankAccountOwnership`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null
}
```

#### Shipping Method

Shipping method desired

##### Class Name

`ShippingMethod`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShippingMethod` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | ShippingMethodTypesEnum getShippingMethod() | setShippingMethod(ShippingMethodTypesEnum shippingMethod) |

##### Example (as JSON)

```json
{
  "shippingMethod": null
}
```

#### Paper Check

Details of the paper check

##### Class Name

`PaperCheck`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Type` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type | TransferTypesEnum getType() | setType(TransferTypesEnum type) |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |
| `ShippingMethod` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | ShippingMethodTypesEnum getShippingMethod() | setShippingMethod(ShippingMethodTypesEnum shippingMethod) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check-Response

Response to a paper check request

##### Class Name

`PaperCheckResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Type` | [`TransferTypesEnum`](#transfer-types) | Optional | Transfer type | TransferTypesEnum getType() | setType(TransferTypesEnum type) |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. | double getAmount() | setAmount(double amount) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `AddressLine1` | `String` | Optional | First line of the address that specifies street number, street name, and building name | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) | String getAddressLine2() | setAddressLine2(String addressLine2) |
| `AddressLine3` | `String` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 | String getAddressLine3() | setAddressLine3(String addressLine3) |
| `AddressLine4` | `String` | Optional | Fourth line of the address, if any | String getAddressLine4() | setAddressLine4(String addressLine4) |
| `AddressLine5` | `String` | Optional | Fifth line of the address, if any | String getAddressLine5() | setAddressLine5(String addressLine5) |
| `City` | `String` | Optional | City or town of the business address | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | State, province, or territory of the business address | String getRegion() | setRegion(String region) |
| `Country` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `PostalCode` | `String` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail | String getPostalCode() | setPostalCode(String postalCode) |
| `PremiseNumber` | `String` | Optional | House or building number of the business address | String getPremiseNumber() | setPremiseNumber(String premiseNumber) |
| `AddressType` | [`AddressTypesEnum`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) | AddressTypesEnum getAddressType() | setAddressType(AddressTypesEnum addressType) |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |
| `ShippingMethod` | [`ShippingMethodTypesEnum`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check | ShippingMethodTypesEnum getShippingMethod() | setShippingMethod(ShippingMethodTypesEnum shippingMethod) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check Collection-Response

Response to a paper check collection request

##### Class Name

`PaperCheckCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<PaperCheck>`](#paper-check) | Optional | - | List<PaperCheck> getPayload() | setPayload(List<PaperCheck> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Bank Account Fields

Classifies account field objects

##### Class Name

`BankAccountFields`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |
| `Type` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | BankAccountTypesEnum getType() | setType(BankAccountTypesEnum type) |
| `Fields` | [`List<KeyValuePairBankFieldTypesString>`](#key-value-pair-bank-field-types-string) | Optional | - | List<KeyValuePairBankFieldTypesString> getFields() | setFields(List<KeyValuePairBankFieldTypesString> fields) |
| `BankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getBankCurrency() | setBankCurrency(CurrencyTypesEnum bankCurrency) |
| `BankCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBankCountry() | setBankCountry(CountryTypesEnum bankCountry) |
| `Description` | `String` | Optional | User-supplied description of the bank account for reference | String getDescription() | setDescription(String description) |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Type

Type of bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | BankAccountTypesEnum getType() | setType(BankAccountTypesEnum type) |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account

Unique identifier for the bank account

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`BankAccountStatusTypesEnum`](#bank-account-status-types) | Optional | Current verification status type of the bank account | BankAccountStatusTypesEnum getStatus() | setStatus(BankAccountStatusTypesEnum status) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |
| `Type` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | BankAccountTypesEnum getType() | setType(BankAccountTypesEnum type) |
| `Fields` | [`List<KeyValuePairBankFieldTypesString>`](#key-value-pair-bank-field-types-string) | Optional | - | List<KeyValuePairBankFieldTypesString> getFields() | setFields(List<KeyValuePairBankFieldTypesString> fields) |
| `BankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getBankCurrency() | setBankCurrency(CurrencyTypesEnum bankCurrency) |
| `BankCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBankCountry() | setBankCountry(CountryTypesEnum bankCountry) |
| `Description` | `String` | Optional | User-supplied description of the bank account for reference | String getDescription() | setDescription(String description) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Status

Verification status of the bank account (<i>Verified</i>, <i>Disabled</i>)

##### Class Name

`BankAccountStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`BankAccountStatusTypesEnum`](#bank-account-status-types) | Optional | Current verification status type of the bank account | BankAccountStatusTypesEnum getStatus() | setStatus(BankAccountStatusTypesEnum status) |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Bank Account-Response

Response to the bank account request

##### Class Name

`BankAccountResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`BankAccountStatusTypesEnum`](#bank-account-status-types) | Optional | Current verification status type of the bank account | BankAccountStatusTypesEnum getStatus() | setStatus(BankAccountStatusTypesEnum status) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `BankAccountOwnershipType` | [`BankAccountOwnershipTypesEnum`](#bank-account-ownership-types) | Optional | Account ownership types | BankAccountOwnershipTypesEnum getBankAccountOwnershipType() | setBankAccountOwnershipType(BankAccountOwnershipTypesEnum bankAccountOwnershipType) |
| `Type` | [`BankAccountTypesEnum`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) | BankAccountTypesEnum getType() | setType(BankAccountTypesEnum type) |
| `Fields` | [`List<KeyValuePairBankFieldTypesString>`](#key-value-pair-bank-field-types-string) | Optional | - | List<KeyValuePairBankFieldTypesString> getFields() | setFields(List<KeyValuePairBankFieldTypesString> fields) |
| `BankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getBankCurrency() | setBankCurrency(CurrencyTypesEnum bankCurrency) |
| `BankCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getBankCountry() | setBankCountry(CountryTypesEnum bankCountry) |
| `Description` | `String` | Optional | User-supplied description of the bank account for reference | String getDescription() | setDescription(String description) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null,
  "links": null
}
```

#### Bank Account Collection-Response

Collection response to the bank account request

##### Class Name

`BankAccountCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<BankAccountResponse>`](#bank-account-response) | Optional | - | List<BankAccountResponse> getPayload() | setPayload(List<BankAccountResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Prepaid Card Package

Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>, including artwork, packaging, and delivery method

##### Class Name

`PrepaidCardPackage`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardPackage` | `String` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | String getCardPackage() | setCardPackage(String cardPackage) |

##### Example (as JSON)

```json
{
  "cardPackage": null
}
```

#### Prepaid Card Base

Base class applied to the prepaid card

##### Class Name

`PrepaidCardBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardPackage` | `String` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | String getCardPackage() | setCardPackage(String cardPackage) |
| `ProgramToken` | `String` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` | String getProgramToken() | setProgramToken(String programToken) |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2"
}
```

#### Prepaid Card Status

Current status of the prepaid card

##### Class Name

`PrepaidCardStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card | StatusEnum getStatus() | setStatus(StatusEnum status) |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Token Type

##### Class Name

`TokenType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TokenType` | [`TokenTypesEnum`](#token-types) | Optional | Types of resources represented by a token | TokenTypesEnum getTokenType() | setTokenType(TokenTypesEnum tokenType) |

##### Example (as JSON)

```json
{
  "tokenType": null
}
```

#### Prepaid Card Base Ext

Base extension for the prepaid card

##### Class Name

`PrepaidCardBaseExt`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card | StatusEnum getStatus() | setStatus(StatusEnum status) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null
}
```

#### Card Network

Major credit card network

##### Class Name

`CardNetwork`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardNetwork` | [`CardNetworkTypesEnum`](#card-network-types) | Optional | Major credit card network types | CardNetworkTypesEnum getCardNetwork() | setCardNetwork(CardNetworkTypesEnum cardNetwork) |

##### Example (as JSON)

```json
{
  "cardNetwork": null
}
```

#### Card Personalization Type

Type of personalization for the prepaid card

##### Class Name

`CardPersonalizationType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardPersonalization` | [`PrepaidCardPersonalizationTypesEnum`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) | PrepaidCardPersonalizationTypesEnum getCardPersonalization() | setCardPersonalization(PrepaidCardPersonalizationTypesEnum cardPersonalization) |

##### Example (as JSON)

```json
{
  "cardPersonalization": null
}
```

#### Prepaid Card

##### Class Name

`PrepaidCard`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card | StatusEnum getStatus() | setStatus(StatusEnum status) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `CardPersonalization` | [`PrepaidCardPersonalizationTypesEnum`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) | PrepaidCardPersonalizationTypesEnum getCardPersonalization() | setCardPersonalization(PrepaidCardPersonalizationTypesEnum cardPersonalization) |
| `CardPackage` | `String` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | String getCardPackage() | setCardPackage(String cardPackage) |
| `CardNetwork` | [`CardNetworkTypesEnum`](#card-network-types) | Optional | Major credit card network types | CardNetworkTypesEnum getCardNetwork() | setCardNetwork(CardNetworkTypesEnum cardNetwork) |
| `Expires` | `LocalDateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | LocalDateTime getExpires() | setExpires(LocalDateTime expires) |
| `CardNumber` | `String` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` | String getCardNumber() | setCardNumber(String cardNumber) |
| `Cvv` | `String` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) | String getCvv() | setCvv(String cvv) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null
}
```

#### Currency

Currency code used for the object

##### Class Name

`Currency`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |

##### Example (as JSON)

```json
{
  "currency": null
}
```

#### Country

Two-digit country code for the object

##### Class Name

`Country`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |

##### Example (as JSON)

```json
{
  "country": "FO"
}
```

#### Prepaid Card-Request Response

##### Class Name

`PrepaidCardRequestResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card | StatusEnum getStatus() | setStatus(StatusEnum status) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "links": null
}
```

#### Prepaid Card-Response

##### Class Name

`PrepaidCardResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Status` | [`StatusEnum`](#status) | Optional | Current status of the prepaid card | StatusEnum getStatus() | setStatus(StatusEnum status) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Country` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getCountry() | setCountry(CountryTypesEnum country) |
| `Currency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getCurrency() | setCurrency(CurrencyTypesEnum currency) |
| `CardPersonalization` | [`PrepaidCardPersonalizationTypesEnum`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) | PrepaidCardPersonalizationTypesEnum getCardPersonalization() | setCardPersonalization(PrepaidCardPersonalizationTypesEnum cardPersonalization) |
| `CardPackage` | `String` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | String getCardPackage() | setCardPackage(String cardPackage) |
| `CardNetwork` | [`CardNetworkTypesEnum`](#card-network-types) | Optional | Major credit card network types | CardNetworkTypesEnum getCardNetwork() | setCardNetwork(CardNetworkTypesEnum cardNetwork) |
| `Expires` | `LocalDateTime` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. | LocalDateTime getExpires() | setExpires(LocalDateTime expires) |
| `CardNumber` | `String` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` | String getCardNumber() | setCardNumber(String cardNumber) |
| `Cvv` | `String` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) | String getCvv() | setCvv(String cvv) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null,
  "links": null
}
```

#### Prepaid Card Collection-Response

##### Class Name

`PrepaidCardCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<PrepaidCardResponse>`](#prepaid-card-response) | Optional | - | List<PrepaidCardResponse> getPayload() | setPayload(List<PrepaidCardResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Card Masked Pan

Card number using PAN truncation

##### Class Name

`CardMaskedPan`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardNumber` | `String` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` | String getCardNumber() | setCardNumber(String cardNumber) |

##### Example (as JSON)

```json
{
  "cardNumber": null
}
```

#### Prepaid Card Replacement Reason

##### Class Name

`PrepaidCardReplacementReason`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardReplacementReason` | [`PrepaidCardReplacementReasonTypesEnum`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. | PrepaidCardReplacementReasonTypesEnum getCardReplacementReason() | setCardReplacementReason(PrepaidCardReplacementReasonTypesEnum cardReplacementReason) |

##### Example (as JSON)

```json
{
  "cardReplacementReason": null
}
```

#### Prepaid Card Replacement Base

##### Class Name

`PrepaidCardReplacementBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardPackage` | `String` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> | String getCardPackage() | setCardPackage(String cardPackage) |
| `ProgramToken` | `String` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` | String getProgramToken() | setProgramToken(String programToken) |
| `CardReplacementReason` | [`PrepaidCardReplacementReasonTypesEnum`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. | PrepaidCardReplacementReasonTypesEnum getCardReplacementReason() | setCardReplacementReason(PrepaidCardReplacementReasonTypesEnum cardReplacementReason) |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2",
  "cardReplacementReason": null
}
```

#### Prepaid Card Pin Token

##### Class Name

`PrepaidCardPinToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardPinToken` | `String` | Optional | Token used as part of a two-leg card PIN reveal request sent directly from the client that generally involves a second piece of data, such as the CVV code on the back of the card. | String getCardPinToken() | setCardPinToken(String cardPinToken) |
| `Url` | `String` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params | String getUrl() | setUrl(String url) |

##### Example (as JSON)

```json
{
  "cardPinToken": null,
  "url": null
}
```

#### Prepaid Card Pin

##### Class Name

`PrepaidCardPin`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardPin` | `String` | Optional | Card PIN for ATM and Debit usage | String getCardPin() | setCardPin(String cardPin) |

##### Example (as JSON)

```json
{
  "cardPin": null
}
```

#### Cvv

Three- or four-digit Card Verification Value (CVV) number displayed on the back of a credit or debit card

##### Class Name

`Cvv`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Cvv` | `String` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) | String getCvv() | setCvv(String cvv) |

##### Example (as JSON)

```json
{
  "cvv": null
}
```

#### Identity Verification Provider Type

Provider type of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvProvider` | [`IdentityVerificationProviderTypesEnum`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks | IdentityVerificationProviderTypesEnum getIdvProvider() | setIdvProvider(IdentityVerificationProviderTypesEnum idvProvider) |

##### Example (as JSON)

```json
{
  "idvProvider": null
}
```

#### Identity Verification Result Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvResult` | [`IdentityVerificationResultTypesEnum`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | IdentityVerificationResultTypesEnum getIdvResult() | setIdvResult(IdentityVerificationResultTypesEnum idvResult) |

##### Example (as JSON)

```json
{
  "idvResult": null
}
```

#### Identity Verification Sub Result Type

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationSubResultType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvSubResult` | [`IdentityVerificationResultSubTypesEnum`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. | IdentityVerificationResultSubTypesEnum getIdvSubResult() | setIdvSubResult(IdentityVerificationResultSubTypesEnum idvSubResult) |

##### Example (as JSON)

```json
{
  "idvSubResult": null
}
```

#### Identity Verification Disposition Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvDispostion` | [`IdentityVerificationDispositionTypesEnum`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | IdentityVerificationDispositionTypesEnum getIdvDispostion() | setIdvDispostion(IdentityVerificationDispositionTypesEnum idvDispostion) |

##### Example (as JSON)

```json
{
  "idvDispostion": null
}
```

#### Identity Verification Check Type

Type of verification used for performing an identity check

##### Class Name

`IdentityVerificationCheckType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvCheckType` | [`IdentityVerificationCheckTypesEnum`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) | IdentityVerificationCheckTypesEnum getIdvCheckType() | setIdvCheckType(IdentityVerificationCheckTypesEnum idvCheckType) |

##### Example (as JSON)

```json
{
  "idvCheckType": null
}
```

#### Identity Verification Base

##### Class Name

`IdentityVerificationBase`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvProviderReference` | `String` | Optional | IDV provider unique ID for the IDV check performed | String getIdvProviderReference() | setIdvProviderReference(String idvProviderReference) |
| `IdvResult` | [`IdentityVerificationResultTypesEnum`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | IdentityVerificationResultTypesEnum getIdvResult() | setIdvResult(IdentityVerificationResultTypesEnum idvResult) |
| `IdvSubResult` | [`IdentityVerificationResultSubTypesEnum`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. | IdentityVerificationResultSubTypesEnum getIdvSubResult() | setIdvSubResult(IdentityVerificationResultSubTypesEnum idvSubResult) |
| `IdvProvider` | [`IdentityVerificationProviderTypesEnum`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks | IdentityVerificationProviderTypesEnum getIdvProvider() | setIdvProvider(IdentityVerificationProviderTypesEnum idvProvider) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Raw` | `String` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only | String getRaw() | setRaw(String raw) |
| `IdvCheckType` | [`IdentityVerificationCheckTypesEnum`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) | IdentityVerificationCheckTypesEnum getIdvCheckType() | setIdvCheckType(IdentityVerificationCheckTypesEnum idvCheckType) |
| `IdvDispostion` | [`IdentityVerificationDispositionTypesEnum`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | IdentityVerificationDispositionTypesEnum getIdvDispostion() | setIdvDispostion(IdentityVerificationDispositionTypesEnum idvDispostion) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null
}
```

#### Identity Verification Provider Reference

Provider reference used for performing identity checks for the provider

##### Class Name

`IdentityVerificationProviderReference`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvProviderReference` | `String` | Optional | IDV provider unique ID for the IDV check performed | String getIdvProviderReference() | setIdvProviderReference(String idvProviderReference) |

##### Example (as JSON)

```json
{
  "idvProviderReference": null
}
```

#### Identity Verification Provider Raw Output

Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only

##### Class Name

`IdentityVerificationProviderRawOutput`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Raw` | `String` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only | String getRaw() | setRaw(String raw) |

##### Example (as JSON)

```json
{
  "raw": null
}
```

#### Identity Verification-Response

##### Class Name

`IdentityVerificationResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdvProviderReference` | `String` | Optional | IDV provider unique ID for the IDV check performed | String getIdvProviderReference() | setIdvProviderReference(String idvProviderReference) |
| `IdvResult` | [`IdentityVerificationResultTypesEnum`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | IdentityVerificationResultTypesEnum getIdvResult() | setIdvResult(IdentityVerificationResultTypesEnum idvResult) |
| `IdvSubResult` | [`IdentityVerificationResultSubTypesEnum`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. | IdentityVerificationResultSubTypesEnum getIdvSubResult() | setIdvSubResult(IdentityVerificationResultSubTypesEnum idvSubResult) |
| `IdvProvider` | [`IdentityVerificationProviderTypesEnum`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks | IdentityVerificationProviderTypesEnum getIdvProvider() | setIdvProvider(IdentityVerificationProviderTypesEnum idvProvider) |
| `CreatedOn` | `LocalDateTime` | Optional | Time at which the object was created. | LocalDateTime getCreatedOn() | setCreatedOn(LocalDateTime createdOn) |
| `Raw` | `String` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only | String getRaw() | setRaw(String raw) |
| `IdvCheckType` | [`IdentityVerificationCheckTypesEnum`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) | IdentityVerificationCheckTypesEnum getIdvCheckType() | setIdvCheckType(IdentityVerificationCheckTypesEnum idvCheckType) |
| `IdvDispostion` | [`IdentityVerificationDispositionTypesEnum`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. | IdentityVerificationDispositionTypesEnum getIdvDispostion() | setIdvDispostion(IdentityVerificationDispositionTypesEnum idvDispostion) |
| `Token` | `String` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. | String getToken() | setToken(String token) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null,
  "links": null
}
```

#### Identity Verification Collection-Response

##### Class Name

`IdentityVerificationCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<IdentityVerificationResponse>`](#identity-verification-response) | Optional | - | List<IdentityVerificationResponse> getPayload() | setPayload(List<IdentityVerificationResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Key Value Pair String String

##### Class Name

`KeyValuePairStringString`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key` | `String` | Optional | - | String getKey() | setKey(String key) |
| `Value` | `String` | Optional | - | String getValue() | setValue(String value) |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Pair Bank Field Types String

1...N required fields as determined by call to get requirements

##### Class Name

`KeyValuePairBankFieldTypesString`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key` | [`BankAccountFieldTypesEnum`](#bank-account-field-types) | Required | Classifies account field types | BankAccountFieldTypesEnum getKey() | setKey(BankAccountFieldTypesEnum key) |
| `Value` | `String` | Required | - | String getValue() | setValue(String value) |

##### Example (as JSON)

```json
{
  "key": "BANK_NON_SWIFT_BIC",
  "value": "value2"
}
```

#### Key Value Pair Bank Currency Currency Types

##### Class Name

`KeyValuePairBankCurrencyCurrencyTypes`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key` | `String` | Optional | **Default**: `"BANK_CURRENCY"`<br>*Default: `"BANK_CURRENCY"`* | String getKey() | setKey(String key) |
| `Value` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getValue() | setValue(CurrencyTypesEnum value) |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Bank Country Country Types

##### Class Name

`KeyValueBankCountryCountryTypes`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key` | `String` | Optional | **Default**: `"BANK_COUNTRY"`<br>*Default: `"BANK_COUNTRY"`* | String getKey() | setKey(String key) |
| `Value` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getValue() | setValue(CountryTypesEnum value) |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Bank Account Required Fields

Classifies the required account field objects

##### Class Name

`BankAccountRequiredFields`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Format` | [`BankAccountRequirementFormat`](#bank-account-requirement-format) | Optional | Classifies the format of the required information for a bank account | BankAccountRequirementFormat getFormat() | setFormat(BankAccountRequirementFormat format) |
| `Requirement` | [`BankAccountFieldTypesEnum`](#bank-account-field-types) | Optional | Classifies account field types | BankAccountFieldTypesEnum getRequirement() | setRequirement(BankAccountFieldTypesEnum requirement) |
| `Description` | [`List<KeyValuePairLanguageTypeString>`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes | List<KeyValuePairLanguageTypeString> getDescription() | setDescription(List<KeyValuePairLanguageTypeString> description) |
| `Validators` | [`List<BankAccountRequirementValidator>`](#bank-account-requirement-validator) | Optional | - | List<BankAccountRequirementValidator> getValidators() | setValidators(List<BankAccountRequirementValidator> validators) |

##### Example (as JSON)

```json
{
  "format": null,
  "requirement": null,
  "description": null,
  "validators": null
}
```

#### Bank Account Requirement Format

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormat`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Example` | `String` | Optional | Example of a requirement generated from the validator(s) | String getExample() | setExample(String example) |
| `Legend` | [`List<BankAccountRequirementFormatLegend>`](#bank-account-requirement-format-legend) | Optional | - | List<BankAccountRequirementFormatLegend> getLegend() | setLegend(List<BankAccountRequirementFormatLegend> legend) |

##### Example (as JSON)

```json
{
  "example": null,
  "legend": null
}
```

#### Bank Account Requirement Format Legend

Classifies the legend format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormatLegend`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key` | `String` | Optional | - | String getKey() | setKey(String key) |
| `Descriptions` | [`List<KeyValuePairLanguageTypeString>`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes | List<KeyValuePairLanguageTypeString> getDescriptions() | setDescriptions(List<KeyValuePairLanguageTypeString> descriptions) |

##### Example (as JSON)

```json
{
  "key": null,
  "descriptions": null
}
```

#### Key Value Pair Language Type String

Localized requirement description for display purposes

##### Class Name

`KeyValuePairLanguageTypeString`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Language` | [`LanguageTypesEnum`](#language-types) | Optional | Language type in IETF's BCP 47 format | LanguageTypesEnum getLanguage() | setLanguage(LanguageTypesEnum language) |
| `Translation` | `String` | Optional | Translated string in the specified language | String getTranslation() | setTranslation(String translation) |

##### Example (as JSON)

```json
{
  "language": null,
  "translation": null
}
```

#### Bank Account Requirement Validator

Specifies the validator type for the required bank account information

##### Class Name

`BankAccountRequirementValidator`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ValidatorType` | [`ValidatorTypesEnum`](#validator-types) | Optional | - | ValidatorTypesEnum getValidatorType() | setValidatorType(ValidatorTypesEnum validatorType) |
| `Expression` | `String` | Required | Validation regular expression | String getExpression() | setExpression(String expression) |

##### Example (as JSON)

```json
{
  "validatorType": null,
  "expression": "expression2"
}
```

#### Bank Account Requirement

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirement`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BankCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getBankCountry() | setBankCountry(CountryTypesEnum bankCountry) |
| `BankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getBankCurrency() | setBankCurrency(CurrencyTypesEnum bankCurrency) |
| `SourceCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getSourceCountry() | setSourceCountry(CountryTypesEnum sourceCountry) |
| `SourceCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getSourceCurrency() | setSourceCurrency(CurrencyTypesEnum sourceCurrency) |
| `Requirements` | [`List<BankAccountRequiredFields>`](#bank-account-required-fields) | Optional | - | List<BankAccountRequiredFields> getRequirements() | setRequirements(List<BankAccountRequiredFields> requirements) |
| `Quote` | [`MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts | MonetaryFormatted getQuote() | setQuote(MonetaryFormatted quote) |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null
}
```

#### Bank Account Requirement-Response

##### Class Name

`BankAccountRequirementResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BankCountry` | [`CountryTypesEnum`](#country-types) | Required | Two-digit country code types | CountryTypesEnum getBankCountry() | setBankCountry(CountryTypesEnum bankCountry) |
| `BankCurrency` | [`CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object | CurrencyTypesEnum getBankCurrency() | setBankCurrency(CurrencyTypesEnum bankCurrency) |
| `SourceCountry` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getSourceCountry() | setSourceCountry(CountryTypesEnum sourceCountry) |
| `SourceCurrency` | [`CurrencyTypesEnum`](#currency-types) | Optional | Currency code type for the object | CurrencyTypesEnum getSourceCurrency() | setSourceCurrency(CurrencyTypesEnum sourceCurrency) |
| `Requirements` | [`List<BankAccountRequiredFields>`](#bank-account-required-fields) | Optional | - | List<BankAccountRequiredFields> getRequirements() | setRequirements(List<BankAccountRequiredFields> requirements) |
| `Quote` | [`MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts | MonetaryFormatted getQuote() | setQuote(MonetaryFormatted quote) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null,
  "links": null
}
```

#### Bank Account Requirement Collection-Response

##### Class Name

`BankAccountRequirementCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Payload` | [`List<BankAccountRequirementResponse>`](#bank-account-requirement-response) | Optional | - | List<BankAccountRequirementResponse> getPayload() | setPayload(List<BankAccountRequirementResponse> payload) |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Occupation

##### Class Name

`Occupation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Occupation` | [`OccupationTypesEnum`](#occupation-types) | Optional | Type of occupation for the user | OccupationTypesEnum getOccupation() | setOccupation(OccupationTypesEnum occupation) |

##### Example (as JSON)

```json
{
  "occupation": null
}
```

#### Tax Resident Status

##### Class Name

`TaxResidentStatus`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxResidentStatus` | [`TaxResidentStatusTypesEnum`](#tax-resident-status-types) | Optional | Tax resident status type of a country | TaxResidentStatusTypesEnum getTaxResidentStatus() | setTaxResidentStatus(TaxResidentStatusTypesEnum taxResidentStatus) |

##### Example (as JSON)

```json
{
  "taxResidentStatus": null
}
```

#### Webhook-Subscription

Webhook subscription object

##### Class Name

`WebhookSubscription`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Url` | `String` | Optional | - | String getUrl() | setUrl(String url) |
| `Namespace` | [`NamespaceEnum`](#namespace) | Optional | Namespace used to identify and refer to the object | NamespaceEnum getNamespace() | setNamespace(NamespaceEnum namespace) |

##### Example (as JSON)

```json
{
  "url": null,
  "namespace": null
}
```

#### Webhook-Subscription-Response

Webhook Subscription response

##### Class Name

`WebhookSubscriptionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |
| `Url` | `String` | Optional | - | String getUrl() | setUrl(String url) |
| `Namespace` | [`NamespaceEnum`](#namespace) | Optional | Namespace used to identify and refer to the object | NamespaceEnum getNamespace() | setNamespace(NamespaceEnum namespace) |
| `Token` | `String` | Optional | Token for the webhook subscription | String getToken() | setToken(String token) |
| `Created` | `String` | Optional | Time stamp for the date the webhook subscription was created | String getCreated() | setCreated(String created) |
| `LastUpdated` | `String` | Optional | Time stamp for the date the webhook subscription was updated | String getLastUpdated() | setLastUpdated(String lastUpdated) |

##### Example (as JSON)

```json
{
  "links": null,
  "url": null,
  "namespace": null,
  "token": null,
  "created": null,
  "lastUpdated": null
}
```

#### Webhook Collection-Response

Webhook Subscription collection response

##### Class Name

`WebhookCollectionResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Links` | [`List<HaetosParams>`](#haetos-params) | Optional | - | List<HaetosParams> getLinks() | setLinks(List<HaetosParams> links) |
| `Payload` | [`List<WebhookSubscriptionResponse>`](#webhook-subscription-response) | Optional | - | List<WebhookSubscriptionResponse> getPayload() | setPayload(List<WebhookSubscriptionResponse> payload) |

##### Example (as JSON)

```json
{
  "links": null,
  "payload": null
}
```

#### Prepaid Card Data-Response

Response to the prepaid card data request

##### Class Name

`PrepaidCardDataResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CardImage` | `String` | Optional | - | String getCardImage() | setCardImage(String cardImage) |
| `CardNumber` | `Double` | Optional | - | Double getCardNumber() | setCardNumber(Double cardNumber) |
| `CvvNumber` | `String` | Optional | - | String getCvvNumber() | setCvvNumber(String cvvNumber) |
| `Expiration` | `String` | Optional | - | String getExpiration() | setExpiration(String expiration) |
| `NameOnCard` | `String` | Optional | - | String getNameOnCard() | setNameOnCard(String nameOnCard) |
| `Side` | `String` | Optional | - | String getSide() | setSide(String side) |
| `Token` | `String` | Optional | - | String getToken() | setToken(String token) |

##### Example (as JSON)

```json
{
  "cardImage": null,
  "cardNumber": null,
  "cvvNumber": null,
  "expiration": null,
  "nameOnCard": null,
  "side": null,
  "token": null
}
```

#### Prepaid Card Data Token

Token assigned to the prepaid card

##### Class Name

`PrepaidCardDataToken`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Required | **Constraints**: *Minimum Length*: `1` | String getToken() | setToken(String token) |
| `Url` | `String` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params | String getUrl() | setUrl(String url) |

##### Example (as JSON)

```json
{
  "token": "token6",
  "url": null
}
```

#### Prepaid Card Data Token-Response

##### Class Name

`PrepaidCardDataTokenResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | [`PrepaidCardDataToken`](#prepaid-card-data-token) | Optional | Token assigned to the prepaid card | PrepaidCardDataToken getToken() | setToken(PrepaidCardDataToken token) |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Business Type

##### Class Name

`BusinessType`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BusinessType` | [`BusinessTypesEnum`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) | BusinessTypesEnum getBusinessType() | setBusinessType(BusinessTypesEnum businessType) |

##### Example (as JSON)

```json
{
  "businessType": null
}
```

#### Country Nationality Information

##### Class Name

`CountryNationalityInformation`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CountryOfBirth` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfBirth() | setCountryOfBirth(CountryTypesEnum countryOfBirth) |
| `CountryOfNationality` | [`CountryTypesEnum`](#country-types) | Optional | Two-digit country code types | CountryTypesEnum getCountryOfNationality() | setCountryOfNationality(CountryTypesEnum countryOfNationality) |

##### Example (as JSON)

```json
{
  "countryOfBirth": null,
  "countryOfNationality": null
}
```

#### Users Prepaid Cards Pin Response

##### Class Name

`UsersPrepaidCardsPinResponse`

##### Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Result` | `Boolean` | Optional | - | Boolean getResult() | setResult(Boolean result) |

##### Example (as JSON)

```json
{
  "result": null
}
```

### Enumerations

* [Transfer Status Types](#transfer-status-types)
* [Payment Purpose Types](#payment-purpose-types)
* [Address Types](#address-types)
* [User Types](#user-types)
* [User Status Types](#user-status-types)
* [Language Types](#language-types)
* [Gender Types](#gender-types)
* [Business Types](#business-types)
* [Transfer Types](#transfer-types)
* [Shipping Method Types](#shipping-method-types)
* [Bank Account Ownership Types](#bank-account-ownership-types)
* [Bank Account Types](#bank-account-types)
* [Bank Account Status Types](#bank-account-status-types)
* [Token Types](#token-types)
* [Card Network Types](#card-network-types)
* [Prepaid Card Personalization Types](#prepaid-card-personalization-types)
* [Currency Types](#currency-types)
* [Country Types](#country-types)
* [Prepaid Card Replacement Reason Types](#prepaid-card-replacement-reason-types)
* [Identity Verification Provider Types](#identity-verification-provider-types)
* [Identity Verification Result Types](#identity-verification-result-types)
* [Identity Verification Result Sub Types](#identity-verification-result-sub-types)
* [Identity Verification Disposition Types](#identity-verification-disposition-types)
* [Identity Verification Check Types](#identity-verification-check-types)
* [Bank Account Field Types](#bank-account-field-types)
* [Validator Types](#validator-types)
* [Occupation Types](#occupation-types)
* [Tax Resident Status Types](#tax-resident-status-types)
* [Namespace](#namespace)
* [Business Contact Role](#business-contact-role)
* [Format](#format)
* [Government Id Type](#government-id-type)
* [Side](#side)
* [Status](#status)

#### Transfer Status Types

Current status of a transfer

##### Class Name

`TransferStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `QUOTED` |
| `PENDING` |
| `SCHEDULED` |
| `COMPLETED` |
| `CANCELLED` |
| `RETURNED` |
| `FAILED` |
| `EXPIRED` |
| `VERIFICATIONHOLD` |

#### Payment Purpose Types

Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services)

##### Class Name

`PaymentPurposeTypesEnum`

##### Fields

| Name |
|  --- |
| `OTHER` |
| `TAXABLE` |
| `INCOME` |
| `BONUS` |
| `EXPENSE` |
| `NONTAXABLE` |

#### Address Types

Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)

##### Class Name

`AddressTypesEnum`

##### Fields

| Name |
|  --- |
| `RESIDENTIAL` |
| `BUSINESS` |
| `MAILING` |

#### User Types

Account holder's profile type

##### Class Name

`UserTypesEnum`

##### Fields

| Name |
|  --- |
| `INDIVIDUAL` |
| `BUSINESS` |

#### User Status Types

Current status of the user

##### Class Name

`UserStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `ACTIVATED` |
| `PREACTIVATED` |
| `PENDINGEMAILVERIFICATION` |
| `PENDINGKYC` |

#### Language Types

Language type in IETF's BCP 47 format

##### Class Name

`LanguageTypesEnum`

##### Fields

| Name |
|  --- |
| `EnUS` |
| `EnGB` |
| `FrCA` |
| `FrFR` |
| `EsMX` |
| `EsES` |
| `PtBR` |
| `PtPT` |
| `DeDE` |
| `ItIT` |
| `JaJP` |
| `ZhCN` |
| `ZhTW` |

#### Gender Types

Gender as a user identifies

##### Class Name

`GenderTypesEnum`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |
| `NOTSPECIFIED` |

#### Business Types

Type of business (<i>Corporation</i> or <i>Partnership</i>)

##### Class Name

`BusinessTypesEnum`

##### Fields

| Name |
|  --- |
| `CORPORATION` |
| `PARTNERSHIPDBA` |

#### Transfer Types

Transfer type

##### Class Name

`TransferTypesEnum`

##### Fields

| Name |
|  --- |
| `PAPERCHECK` |
| `BANKTRANSFER` |
| `PAYMENT` |
| `SPENDBACK` |

#### Shipping Method Types

Shipping method type for a pre-paid card or paper check

##### Class Name

`ShippingMethodTypesEnum`

##### Fields

| Name |
|  --- |
| `STANDARD` |
| `EXPEDITED` |

#### Bank Account Ownership Types

Account ownership types

##### Class Name

`BankAccountOwnershipTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

#### Bank Account Types

Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountTypesEnum`

##### Fields

| Name |
|  --- |
| `CHECKING` |
| `SAVINGS` |
| `MONEYMARKET` |

#### Bank Account Status Types

Current verification status type of the bank account

##### Class Name

`BankAccountStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `DELETED` |
| `ACTIVE` |
| `PENDINGVERIFICATION` |

#### Token Types

Types of resources represented by a token

##### Class Name

`TokenTypesEnum`

##### Fields

| Name |
|  --- |
| `BANKACCOUNT` |
| `TRANSFER` |
| `PAYMENT` |
| `SPENDBACK` |
| `PREPAIDCARD` |
| `USER` |
| `DOCUMENT` |
| `ACCOUNT` |

#### Card Network Types

Major credit card network types

##### Class Name

`CardNetworkTypesEnum`

##### Fields

| Name |
|  --- |
| `VISA` |
| `MASTERCARD` |

#### Prepaid Card Personalization Types

Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer)

##### Class Name

`PrepaidCardPersonalizationTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONALIZED` |
| `NONPERSONALIZED` |

#### Currency Types

Currency code type for the object

##### Class Name

`CurrencyTypesEnum`

##### Fields

| Name |
|  --- |
| `USD` |
| `CAD` |
| `MXN` |
| `AUD` |
| `HKD` |
| `NZD` |
| `EUR` |
| `GBP` |

#### Country Types

Two-digit country code types

##### Class Name

`CountryTypesEnum`

##### Fields

| Name |
|  --- |
| `AD` |
| `AE` |
| `AF` |
| `AG` |
| `AI` |
| `AL` |
| `AM` |
| `AN` |
| `AO` |
| `AQ` |
| `AR` |
| `AS` |
| `AT` |
| `AU` |
| `AW` |
| `AX` |
| `AZ` |
| `BA` |
| `BB` |
| `BD` |
| `BE` |
| `BF` |
| `BG` |
| `BH` |
| `BI` |
| `BJ` |
| `BL` |
| `BM` |
| `BN` |
| `BO` |
| `BQ` |
| `BR` |
| `BS` |
| `BT` |
| `BV` |
| `BW` |
| `BY` |
| `BZ` |
| `CA` |
| `CC` |
| `CD` |
| `CF` |
| `CG` |
| `CH` |
| `CI` |
| `CK` |
| `CL` |
| `CM` |
| `CN` |
| `CO` |
| `CR` |
| `CU` |
| `CV` |
| `CW` |
| `CX` |
| `CY` |
| `CZ` |
| `DE` |
| `DJ` |
| `DK` |
| `DM` |
| `DO` |
| `DZ` |
| `EC` |
| `EE` |
| `EG` |
| `EH` |
| `ER` |
| `ES` |
| `ET` |
| `FI` |
| `FJ` |
| `FK` |
| `FM` |
| `FO` |
| `FR` |
| `GA` |
| `GB` |
| `GD` |
| `GE` |
| `GF` |
| `GG` |
| `GH` |
| `GI` |
| `GL` |
| `GM` |
| `GN` |
| `GP` |
| `GQ` |
| `GR` |
| `GS` |
| `GT` |
| `GU` |
| `GW` |
| `GY` |
| `HK` |
| `HM` |
| `HN` |
| `HR` |
| `HT` |
| `HU` |
| `ID` |
| `IE` |
| `IL` |
| `IM` |
| `IN` |
| `IO` |
| `IQ` |
| `IR` |
| `IS` |
| `IT` |
| `JE` |
| `JM` |
| `JO` |
| `JP` |
| `KE` |
| `KG` |
| `KH` |
| `KI` |
| `KM` |
| `KN` |
| `KP` |
| `KR` |
| `KW` |
| `KY` |
| `KZ` |
| `LA` |
| `LB` |
| `LC` |
| `LI` |
| `LK` |
| `LR` |
| `LS` |
| `LT` |
| `LU` |
| `LV` |
| `LY` |
| `MA` |
| `MC` |
| `MD` |
| `ME` |
| `MF` |
| `MG` |
| `MH` |
| `MK` |
| `ML` |
| `MM` |
| `MN` |
| `MO` |
| `MP` |
| `MQ` |
| `MR` |
| `MS` |
| `MT` |
| `MU` |
| `MV` |
| `MW` |
| `MX` |
| `MY` |
| `MZ` |
| `NA` |
| `NC` |
| `NE` |
| `NF` |
| `NG` |
| `NI` |
| `NL` |
| `NO` |
| `NP` |
| `NR` |
| `NU` |
| `NZ` |
| `OM` |
| `PA` |
| `PE` |
| `PF` |
| `PG` |
| `PH` |
| `PK` |
| `PL` |
| `PM` |
| `PN` |
| `PR` |
| `PS` |
| `PT` |
| `PW` |
| `PY` |
| `QA` |
| `RE` |
| `RO` |
| `RS` |
| `RU` |
| `RW` |
| `SA` |
| `SB` |
| `SC` |
| `SD` |
| `SE` |
| `SG` |
| `SH` |
| `SI` |
| `SJ` |
| `SK` |
| `SL` |
| `SM` |
| `SN` |
| `SO` |
| `SR` |
| `SS` |
| `ST` |
| `SV` |
| `SX` |
| `SY` |
| `SZ` |
| `TC` |
| `TD` |
| `TF` |
| `TG` |
| `TH` |
| `TJ` |
| `TK` |
| `TL` |
| `TM` |
| `TN` |
| `TO` |
| `TR` |
| `TT` |
| `TV` |
| `TW` |
| `TZ` |
| `UA` |
| `UG` |
| `UM` |
| `US` |
| `UY` |
| `UZ` |
| `VA` |
| `VC` |
| `VE` |
| `VG` |
| `VI` |
| `VN` |
| `VU` |
| `WF` |
| `WS` |
| `YE` |
| `YT` |
| `ZA` |
| `ZM` |
| `ZW` |

#### Prepaid Card Replacement Reason Types

Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility.

##### Class Name

`PrepaidCardReplacementReasonTypesEnum`

##### Fields

| Name |
|  --- |
| `LOST` |
| `STOLEN` |
| `DAMAGED` |
| `COMPROMISED` |
| `EXPIRED` |

#### Identity Verification Provider Types

Provider types of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderTypesEnum`

##### Fields

| Name |
|  --- |
| `W2` |
| `IDOLOGY` |
| `BANK` |
| `EQUIFAX` |
| `OFAC` |
| `LEXUSNEXUS` |

#### Identity Verification Result Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultTypesEnum`

##### Fields

| Name |
|  --- |
| `PASS` |
| `FAIL` |
| `SERVICEOFFLINE` |
| `PROCESSING` |

#### Identity Verification Result Sub Types

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationResultSubTypesEnum`

##### Fields

| Name |
|  --- |
| `HARD` |
| `SOFT` |

#### Identity Verification Disposition Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionTypesEnum`

##### Fields

| Name |
|  --- |
| `TRANSIENT` |
| `FINAL` |

#### Identity Verification Check Types

Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.)

##### Class Name

`IdentityVerificationCheckTypesEnum`

##### Fields

| Name |
|  --- |
| `DOCUMENTARY` |
| `NONDOCUMENTARY` |
| `OFAC` |

#### Bank Account Field Types

Classifies account field types

##### Class Name

`BankAccountFieldTypesEnum`

##### Fields

| Name |
|  --- |
| `BANKACHABA` |
| `BANKBBAN` |
| `BANKBRANCHCODE` |
| `BANKBSBCODE` |
| `BANKCITY` |
| `BANKCLABE` |
| `BANKCODE` |
| `BANKCURP` |
| `BANKIBAN` |
| `BANKNAME` |
| `BANKNONSWIFTBIC` |
| `BANKNUBAN` |
| `BANKPHONENUMBER` |
| `BANKPOSTALCODE` |
| `BANKREGION` |
| `BANKRFC` |
| `BANKSORTCODE` |
| `BANKSTREETADDRESS` |
| `BANKSWIFTBIC` |
| `BANKTRANSITCODE` |
| `BENEFICIARYACCOUNTNUMBER` |
| `BENEFICIARYPHONENUMBER` |
| `BENEFICIARYTAXID` |
| `BENEFICIARYNAME` |
| `BANKBRANCHNAME` |
| `BANKPURPOSEOFPAYMENTCODE` |
| `BANKVALUEADDTAX` |

#### Validator Types

##### Class Name

`ValidatorTypesEnum`

##### Fields

| Name |
|  --- |
| `REGEX` |
| `LENGTH` |

#### Occupation Types

Type of occupation for the user

##### Class Name

`OccupationTypesEnum`

##### Fields

| Name |
|  --- |
| `INDEPENDENTBUSINESSOWNER` |
| `SCIENCE` |
| `TECHNOLOGY` |
| `ENGINEERING` |
| `MATH` |
| `HEALTHCARE` |
| `SOCIALSERVICES` |
| `MEDIA` |
| `FINANCE` |
| `GOVERNMENT` |
| `MANUFACTURING` |
| `LAW` |
| `HOSPITALITYANDTOURISM` |
| `ARTS` |
| `DESIGN` |
| `OFFICEANDADMINSUPPORT` |
| `EDUCATION` |

#### Tax Resident Status Types

Tax resident status type of a country

##### Class Name

`TaxResidentStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `YES` |
| `NO` |
| `PREFERNOTTOANSWER` |

#### Namespace

Namespace used to identify and refer to the object

##### Class Name

`NamespaceEnum`

##### Fields

| Name |
|  --- |
| `EnumBANKACCOUNTSUPDATEDSTATUSAPPROVED` |
| `EnumPREPAIDCARDSCREATED` |
| `EnumTRANSFERSACCEPTED` |

#### Business Contact Role

Role of the user within the business

##### Class Name

`BusinessContactRoleEnum`

##### Fields

| Name |
|  --- |
| `OWNER` |
| `MANAGER` |
| `PARTNER` |
| `OTHER` |

#### Format

##### Class Name

`FormatEnum`

##### Fields

| Name |
|  --- |
| `TEXT` |
| `IMAGE` |
| `EnumTEXTIMAGE` |

#### Government Id Type

User's government ID type

##### Class Name

`GovernmentIdTypeEnum`

##### Fields

| Name |
|  --- |
| `PASSPORT` |
| `NATIONALIDCARD` |
| `CURP` |

#### Side

##### Class Name

`SideEnum`

##### Fields

| Name |
|  --- |
| `FRONT` |
| `BACK` |

#### Status

Current status of the prepaid card

##### Class Name

`StatusEnum`

##### Fields

| Name |
|  --- |
| `QUEUED` |
| `LOSTSTOLENDAMAGED` |
| `ACTIVATED` |
| `PENDINGACTIVATION` |
| `SUSPENDED` |
| `COMPLIANCEHOLD` |
| `KYCHOLD` |
| `LOCKED` |

## Utility Classes Documentation

### ApiHelper Class

This is a Helper class with commonly used utilities for the SDK.

#### Fields

| Name | Description | Type |
|  --- | --- | --- |
| mapper | Deserialization of Json data. | `ObjectMapper` |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `serialize(Object obj)` | Json Serialization of a given object. | `String` |
| `deserialize(String json)` | Json deserialization of the given Json string. | `LinkedHashMap<String, Object>` |
| `deserialize(String json, Class<T> clazz)` | Json deserialization of the given Json string. | `<T extends Object> T` |
| `deserialize(String json, TypeReference<T> typeReference)` | JSON Deserialization of the given json string. | `<T extends Object> T` |
| `deserializeArray(String json, Class<T[]> classArray)` | JSON Deserialization of the given json string. | `<T extends Object> List<T>` |

### FileWrapper Class

Class to wrap file and contentType to be sent as part of a HTTP request.

#### Constructors

| Name | Description |
|  --- | --- |
| `FileWrapper(File file)` | Initialization constructor. |
| `FileWrapper(File file, String contentType)` | Initialization constructor. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getFile()` | File instance. | `File` |
| `getContentType()` | Content type of the file. | `String` |

### LocalDateTime Class

This is a utility class for DateTime operations.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `fromUnixTimestamp(Long date)` | Parse a Unix Timestamp to a DateTime object. | `LocalDateTime` |
| `fromUnixTimestamp(String date)` | Parse a Unix Timestamp string to a DateTime object. | `LocalDateTime` |
| `toUnixTimestamp(LocalDateTime value)` | Convert a DateTime object to a Unix Timestamp string. | `String` |
| `toUnixTimestamp(List<LocalDateTime> values)` | Convert a List of DateTime objects to Unix Timestamp strings. | `List<String>` |
| `fromRfc1123DateTime(String date)` | Parse a datetime string in Rfc1123 format to a DateTime object. | `LocalDateTime` |
| `toRfc1123DateTime(LocalDateTime value)` | Convert a DateTime object to a Rfc1123 formatted string. | `String` |
| `toRfc1123DateTime(List<LocalDateTime> values)` | Convert a List of DateTime objects to Rfc1123 formatted strings. | `List<String>` |
| `fromRfc8601DateTime(String date)` | Parse a datetime string in Rfc8601(Rfc3339) format to a DateTime object. | `LocalDateTime` |
| `toRfc8601DateTime(LocalDateTime value)` | Convert a DateTime object to a Rfc8601(Rfc3339) formatted string. | `String` |
| `toRfc8601DateTime(List<LocalDateTime> values)` | Convert a List of DateTime objects to Rfc8601(Rfc3339) formatted strings. | `List<String>` |
| `fromSimpleDate(String date)` | Parse a simple date string to a LocalDate object. | `LocalDate` |
| `toSimpleDate(LocalDate value)` | Convert a LocalDate object to a string. | `String` |
| `toSimpleDate(List<LocalDate> values)` | Convert a List of LocalDate objects to strings. | `List<String>` |

## Common Code Documentation

### HttpRequest Class

Class for creating and managing HTTP Requests.

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpRequest(HttpMethod method, StringBuilder queryUrlBuilder, Headers headers, Map<String, Object> queryParameters, List< SimpleEntry < String, Object >> parameters)` | Initializes a simple http request. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getHttpMethod()` | HttpMethod for the http request. | `HttpMethod` |
| `getHeaders()` | Headers for the http request. | `Headers` |
| `getQueryUrl()` | Query url for the http request. | `String` |
| `getParameters()` | Parameters for the http request. | `List<SimpleEntry<String, Object>>` |
| `getQueryParameters()` | Query parameters for the http request. | `Map<String, Object>` |
| `addQueryParameter(String key, Object value)` | Add Query parameter in http request. | `void` |

### HttpResponse Class

Class to hold HTTP Response.

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpResponse(int code, Headers headers, InputStream rawBody)` | Constructor for HttpResponse. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getStatusCode()` | HTTP Status code of the http response.. | `int` |
| `getHeaders()` | Headers of the http response. | `Headers` |
| `getRawBody()` | Raw body of the http response. | `InputStream` |

### HttpStringResponse Class

Class to hold response body as string.

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpStringResponse(int code, Headers headers, InputStream rawBody, String body)` | Constructor for HttpStringResponse. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getStatusCode()` | HTTP Status code of the http response. | `int` |
| `getHeaders()` | Headers of the http response. | `Headers` |
| `getBody()` | String body of the http response. | `String` |

### HttpContext Class

Class to wrap the request sent to the server and the response received from the server.

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpContext(HttpRequest request, HttpResponse response)` | Constructor for HttpContext. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getRequest()` | Getter for the Http Request. | `HttpRequest` |
| `getHttpContext()` | Getter for the Http Response. | `HttpContext` |

### HttpBodyRequest Class

HTTP Request with an explicit body.

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpBodyRequest(HttpMethod method, StringBuilder queryUrlBuilder, Headers headers, Map<String, Object> queryParams, Object body)` | Create a request with explicit body. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getBody()` | Body for the http request. | `Object` |

### HttpCallback Interface

Callback to be called before and after the HTTP call for an endpoint is made.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `onBeforeRequest(HttpRequest request)` | Callback called just before the HTTP request is sent. | `void` |
| `onAfterResponse(HttpContext context)` | Callback called just after the HTTP response is received. | `void` |

### Headers Class

Class for creating and managing HTTP Headers.

#### Constructors

| Name | Description |
|  --- | --- |
| `Headers()` | Default constructor. |
| `Headers(Map<String, List<String>> headers)` | Constructor that creates a new instance using a given Map. |
| `Headers(Headers h)` | Copy Constructor. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `has(String headerName)` | Use to check if the given name is present in headers. | `boolean` |
| `names()` | Returns a Set containing all header names. | `Set<String>` |
| `value(String headerName)` | Returns the first value associated with a given header name, or null if the header name is not found. | `String` |
| `values(String headerName)` | Returns a List of all values associated with a given header name, or null if the header name is not found. | `List<String>` |
| `asSimpleMap()` | Returns a Map of the headers, giving only one value for each header name. | `Map<String, String>` |
| `asMultimap()` | Returns a simulated MultiMap of the headers. | `Map<String, List<String>>` |
| `cloneHeaderMap(Map<String, List<String>> headerMap)` | Clones a header map. | `Map<String, List<String>>` |
| `add(String headerName, String value)` | Adds a value for a header name to this object. | `void` |
| `add(String headerName, List<String> values)` | Adds a List of values for a header name to this object. | `void` |
| `addAllFromMap(Map<String, String> headers)` | Adds values from a Map to this object. | `void` |
| `addAllFromMultiMap(Map<String, List<String>> headers)` | Adds values from a simulated Multi-Map to this object. | `void` |
| `addAll(Headers headers)` | Adds all the entries in a Headers object to this object. | `void` |
| `remove(String headerName)` | Removes the mapping for a header name if it is present. | `List<String>` |

### ApiException Class

This is the base class for all exceptions that represent an error response from the server.

#### Constructors

| Name | Description |
|  --- | --- |
| `ApiException(String reason)` | Initialization constructor. |
| `ApiException(String reason, HttpContext context)` | Initialization constructor. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getResponseCode()` | The HTTP response code from the API request | `int` |
| `getHeaders()` | The HTTP response body from the API request. | `Headers` |

### Configuration Interface

This is the base class for all exceptions that represent an error response from the server.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClientConfig()` | Http Client Configuration instance.<br>* See available [builder methods here](#httpclientconfiguration.builder-class). | `ReadonlyHttpClientConfiguration` |
| `getBaseUri(Server server)` | Get base URI by current environment. | `String` |
| `getBaseUri()` | Get base URI by current environment. | `String` |

### HttpClientConfiguration Class

Class for holding http client configuration.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `getTimeout()` | The timeout in seconds to use for making HTTP requests. | `long` |
| `getNumberOfRetries()` | The number of retries to make. | `int` |
| `getBackOffFactor()` | To use in calculation of wait time for next request in case of failure. | `int` |
| `getRetryInterval()` | To use in calculation of wait time for next request in case of failure. | `long` |
| `getHttpStatusCodesToRetry()` | Http status codes to retry against. | `Set<Integer>` |
| `getHttpMethodsToRetry()` | Http methods to retry against. | `Set<HttpMethod>` |
| `getMaxBackOff()` | The maximum wait time for overall retrying requests. | `long` |
| `shouldRetryOnTimeout()` | Whether to retry on request timeout. | `boolean` |
| `toString()` | Converts this HttpClientConfiguration into string format. | `String` |
| `newBuilder()` | Builds a new {@link HttpClientConfiguration.Builder} object. Creates the instance with the current state. | `HttpClientConfiguration.Builder` |

### HttpClientConfiguration.Builder Class

Class to build instances of {@link HttpClientConfiguration}.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `timeout()` | The timeout in seconds to use for making HTTP requests. | `long` |
| `numberOfRetries()` | The number of retries to make. | `int` |
| `backOffFactor()` | To use in calculation of wait time for next request in case of failure. | `int` |
| `retryInterval()` | To use in calculation of wait time for next request in case of failure. | `long` |
| `httpStatusCodesToRetry()` | Http status codes to retry against. | `Set<Integer>` |
| `httpMethodsToRetry()` | Http methods to retry against. | `Set<HttpMethod>` |
| `maxBackOff()` | The maximum wait time for overall retrying requests. | `long` |
| `shouldRetryOnTimeout()` | Whether to retry on request timeout. | `boolean` |

