// <copyright file="BankAccountsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// BankAccountsControllerTest.
    /// </summary>
    [TestFixture]
    public class BankAccountsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private BankAccountsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.BankAccountsController;
        }

        /// <summary>
        /// Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenBankaccounts()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.BankAccountCollectionResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"token\":\"dest-7d8b1c83-01bb-40fb-87d7-26bd4c303f01\",\"status\":\"DELETED\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"bankAccountOwnershipType\":\"PERSONAL\",\"type\":\"CHECKING\",\"fields\":[{\"key\":\"BANK_ACH_ABA\",\"value\":\"333333333\"},{\"key\":\"BANK_BBAN\",\"value\":\"4444444444\"}],\"bankCurrency\":\"USD\",\"bankCountry\":\"US\",\"description\":\"My account\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]},{\"token\":\"dest-efacd12b-a86e-4f44-bbea-927955ec1634\",\"status\":\"ACTIVE\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"bankAccountOwnershipType\":\"PERSONAL\",\"type\":\"CHECKING\",\"fields\":[{\"key\":\"BANK_ACH_ABA\",\"value\":\"012346789\"},{\"key\":\"BANK_BBAN\",\"value\":\"987654321\"}],\"bankCurrency\":\"USD\",\"bankCountry\":\"US\",\"description\":\"Personal checking account\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}],\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Create a quote for a bank account using a user token..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostUsersUserTokenBankaccounts()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.BankAccountFields body = null;

            // Perform API call
            Standard.Models.BankAccountResponse result = null;
            try
            {
                result = await this.controller.PostUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-efacd12b-a86e-4f44-bbea-927955ec1634\",\"status\":\"ACTIVE\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"bankAccountOwnershipType\":\"PERSONAL\",\"type\":\"CHECKING\",\"fields\":[{\"key\":\"BANK_ACH_ABA\",\"value\":\"012346789\"},{\"key\":\"BANK_BBAN\",\"value\":\"987654321\"}],\"bankCurrency\":\"USD\",\"bankCountry\":\"US\",\"description\":\"Personal checking account\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenBankaccountsDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.BankAccountResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-efacd12b-a86e-4f44-bbea-927955ec1634\",\"status\":\"ACTIVE\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"bankAccountOwnershipType\":\"PERSONAL\",\"type\":\"CHECKING\",\"fields\":[{\"key\":\"BANK_ACH_ABA\",\"value\":\"012346789\"},{\"key\":\"BANK_BBAN\",\"value\":\"987654321\"}],\"bankCurrency\":\"USD\",\"bankCountry\":\"US\",\"description\":\"Personal checking account\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Update a bank account..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPutUsersUserTokenBankaccountsDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.BankAccountFields body = null;

            // Perform API call
            Standard.Models.BankAccountResponse result = null;
            try
            {
                result = await this.controller.PutUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"token\":\"dest-efacd12b-a86e-4f44-bbea-927955ec1634\",\"status\":\"ACTIVE\",\"createdOn\":\"2020-02-21T22:00:00Z\",\"bankAccountOwnershipType\":\"PERSONAL\",\"type\":\"CHECKING\",\"fields\":[{\"key\":\"BANK_ACH_ABA\",\"value\":\"012346789\"},{\"key\":\"BANK_BBAN\",\"value\":\"987654321\"}],\"bankCurrency\":\"USD\",\"bankCountry\":\"US\",\"description\":\"Personal checking account\",\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Delete (cloak) a user bank account..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteUsersUserTokenBankaccountsDestToken()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.DeleteUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenBankaccountsRequirements()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.BankAccountRequirementCollectionResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenBankaccountsRequirementsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"bankCountry\":\"IT\",\"bankCurrency\":\"EUR\",\"requirements\":[{\"requirement\":\"BANK_IBAN\",\"format\":{\"example\":\"IT43K0310412701000000820420\",\"legend\":[{\"key\":\"IT43K0310412701000000820420\",\"descriptions\":[{\"language\":\"en-US\",\"translation\":\"Example IBAN\"},{\"language\":\"it-IT\",\"translation\":\"Esempio IBAN\"}]}]},\"description\":[{\"language\":\"en-US\",\"translation\":\"IBAN\"},{\"language\":\"it-IT\",\"translation\":\"IBAN\"}],\"validators\":[{\"validatorType\":\"REGEX\",\"expression\":\"^IT\\\\\\\\d{2}[A-Z]\\\\\\\\d{10}[0-9A-Z]{12}$\"}]},{\"requirement\":\"BANK_SWIFT_BIC\",\"format\":{\"example\":\"01234567890\",\"legend\":[{\"key\":\"01234567890\",\"descriptions\":[{\"language\":\"en-US\",\"translation\":\"Example Swift/BIC\"},{\"language\":\"it-IT\",\"translation\":\"Esempio Swift/BIC\"}]}]},\"description\":[{\"language\":\"en-US\",\"translation\":\"Swift/BIC\"},{\"language\":\"it-IT\",\"translation\":\"Swift/BIC\"}],\"validators\":[{\"validatorType\":\"REGEX\",\"expression\":\"^[a-z0-9A-Z]{8,11}$\"}]}],\"quote\":{\"formattedAmount\":\"$4.32 USD (USD, en-US), 0,00 € EUR (EUR, fr-FR)\",\"amount\":4.32,\"currency\":\"USD\"},\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}],\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"string\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}