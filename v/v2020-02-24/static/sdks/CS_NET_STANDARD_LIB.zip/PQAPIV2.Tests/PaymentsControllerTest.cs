// <copyright file="PaymentsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// PaymentsControllerTest.
    /// </summary>
    [TestFixture]
    public class PaymentsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PaymentsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PaymentsController;
        }

        /// <summary>
        /// Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetPaymentsPmntToken()
        {
            // Parameters for the API call
            string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
            string xMyPayQuickerVersion = "2020.02.24";
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.PaymentResponse result = null;
            try
            {
                result = await this.controller.GetPaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion, filter, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Accept an open payment quote..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostPaymentsPmntToken()
        {
            // Parameters for the API call
            string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
            string xMyPayQuickerVersion = "2020.02.24";
            object body = null;

            // Perform API call
            Standard.Models.PaymentResponse result = null;
            try
            {
                result = await this.controller.PostPaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(201, this.HttpCallBackHandler.Response.StatusCode, "Status should be 201");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Cancel an open payment quote..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeletePaymentsPmntToken()
        {
            // Parameters for the API call
            string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.DeletePaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Perform a payment retraction for the full payment amount..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPutPaymentsPmntTokenRetract()
        {
            // Parameters for the API call
            string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.PutPaymentsPmntTokenRetractAsync(pmntToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Perform a payment retraction for a partial payment amount..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPatchPaymentsPmntTokenRetract()
        {
            // Parameters for the API call
            string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
            string xMyPayQuickerVersion = "2020.02.24";

            // Perform API call
            try
            {
                await this.controller.PatchPaymentsPmntTokenRetractAsync(pmntToken, xMyPayQuickerVersion);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetPayments()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.PaymentsCollectionResponse result = null;
            try
            {
                result = await this.controller.GetPaymentsAsync(xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Create a payment quote. .
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostPayments()
        {
            // Parameters for the API call
            string xMyPayQuickerVersion = "2020.02.24";
            Standard.Models.PaymentRequest body = null;

            // Perform API call
            Standard.Models.PaymentResponse result = null;
            try
            {
                result = await this.controller.PostPaymentsAsync(xMyPayQuickerVersion, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(201, this.HttpCallBackHandler.Response.StatusCode, "Status should be 201");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }
    }
}