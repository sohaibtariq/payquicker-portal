// <copyright file="ReceiptsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Exceptions;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Http.Response;
    using PQAPIV2.Standard.Utilities;
    using PQAPIV2.Tests.Helpers;

    /// <summary>
    /// ReceiptsControllerTest.
    /// </summary>
    [TestFixture]
    public class ReceiptsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ReceiptsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ReceiptsController;
        }

        /// <summary>
        /// Retrieve a list of all account(s) receipts that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAccountsReceipts()
        {
            // Parameters for the API call
            string acctToken = "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            object result = null;
            try
            {
                result = await this.controller.GetAccountsReceiptsAsync(acctToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"amount\":5000.01,\"currency\":\"USD\",\"sourceToken\":\"acct-04017f57-8526-4b0c-9152-5252975a86e4\",\"destinationToken\":\"dest-04017f57-8526-4b0c-9152-5252975a86e4\",\"createdOn\":\"2023-02-21T00:00:00Z\"}],\"meta\":{\"pageNo\":\"1\",\"pageSize\":\"20\",\"pageCount\":\"85\",\"recordCount\":\"1685\",\"timezone\":\"GMT\"},\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/accounts/acct-04017f57-8526-4b0c-9152-5252975a86e4/receipts\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list all prepaid-card receipts that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersUserTokenPrepaidcardsReceipts()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.ReceiptCollectionResponse result = null;
            try
            {
                result = await this.controller.GetUsersUserTokenPrepaidcardsReceiptsAsync(userToken, destToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("X-TimeZone", "America/New_York");
            headers.Add("X-Paging-PageNo", null);
            headers.Add("X-Paging-PageCount", null);
            headers.Add("X-Paging-PageSize", null);
            headers.Add("X-Paging-TotalRecordCount", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"amount\":5000.05,\"currency\":\"USD\",\"sourceToken\":\"user-04017f57-8526-4b0c-9152-5252975a86e4\",\"destinationToken\":\"dest-04017f57-8526-4b0c-9152-5252975a86e4\",\"createdOn\":\"2023-02-21T00:00:00Z\"}],\"meta\":{\"pageNo\":\"1\",\"pageSize\":\"20\",\"pageCount\":\"85\",\"recordCount\":\"1685\",\"timezone\":\"GMT\"},\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/prepaid-cards/dest-04017f57-8526-4b0c-9152-5252975a86e4/receipts\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve a list all user receipts that supports filtering, sorting, and pagination through existing mechanisms..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetUsersReceipts()
        {
            // Parameters for the API call
            string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
            string xMyPayQuickerVersion = "2020.02.24";
            int? page = null;
            int? pageSize = 20;
            string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
            string sort = "-name";
            Standard.Models.LanguageTypesEnum language = (Standard.Models.LanguageTypesEnum)Enum.Parse(typeof(Standard.Models.LanguageTypesEnum), "en-US");

            // Perform API call
            Standard.Models.ReceiptCollectionResponse result = null;
            try
            {
                result = await this.controller.GetUsersReceiptsAsync(userToken, xMyPayQuickerVersion, page, pageSize, filter, sort, language);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("X-TimeZone", "America/New_York");
            headers.Add("X-Paging-PageNo", null);
            headers.Add("X-Paging-PageCount", null);
            headers.Add("X-Paging-PageSize", null);
            headers.Add("X-Paging-TotalRecordCount", null);
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"payload\":[{\"amount\":5000.01,\"currency\":\"USD\",\"sourceToken\":\"user-04017f57-8526-4b0c-9152-5252975a86e4\",\"destinationToken\":\"dest-04017f57-8526-4b0c-9152-5252975a86e4\",\"createdOn\":\"2023-02-21T00:00:00Z\"}],\"meta\":{\"pageNo\":\"1\",\"pageSize\":\"20\",\"pageCount\":\"85\",\"recordCount\":\"1685\",\"timezone\":\"GMT\"},\"links\":[{\"params\":{\"rel\":\"self\"},\"href\":\"https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/receipts\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}