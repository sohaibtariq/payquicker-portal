# Getting Started with PQ API v2

## Getting Started

### Introduction

desc older version

### Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (PQAPIV2.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. The generated library is compatible with Windows Forms, Windows RT, Windows Phone 8, Silverlight 5, Xamarin iOS, Xamarin Android and Mono. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

### Installation

The following section explains how to use the PQAPIV2.Standard library in a new project.

#### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=PQ%20API%20v2-CSharp&workspaceName=PQAPIV2&projectName=PQAPIV2.Standard&rootNamespace=PQAPIV2.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=PQ%20API%20v2-CSharp&workspaceName=PQAPIV2&projectName=PQAPIV2.Standard&rootNamespace=PQAPIV2.Standard&step=createProject)

#### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=PQ%20API%20v2-CSharp&workspaceName=PQAPIV2&projectName=PQAPIV2.Standard&rootNamespace=PQAPIV2.Standard&step=setStartup)

#### 3. Add reference of the library project

In order to use the Tester library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=PQ%20API%20v2-CSharp&workspaceName=PQAPIV2&projectName=PQAPIV2.Standard&rootNamespace=PQAPIV2.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `Tester.Tests` and click `OK`. By doing this, we have added a reference of the `Tester.Tests` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=PQ%20API%20v2-CSharp&workspaceName=PQAPIV2&projectName=PQAPIV2.Standard&rootNamespace=PQAPIV2.Standard&step=createReference)

#### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=PQ%20API%20v2-CSharp&workspaceName=PQAPIV2&projectName=PQAPIV2.Standard&rootNamespace=PQAPIV2.Standard&step=addCode)

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |

The API client can be initialized as follows:

```csharp
PQAPIV2.Standard.PQAPIV2Client client = new PQAPIV2.Standard.PQAPIV2Client();
```

Parameters for retries can be configured through the HttpClientConfiguration in the API Client:

| Parameters | Type | Description |
|  --- | --- | --- |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `NumberOfRetries` | `int` | Number of times the request is retried.<br>*Default*: `0` |
| `BackoffFactor` | `int` | Exponential backoff factor for duration between retry calls.<br>*Default*: `2` |
| `RetryInterval` | `double` | The time interval between the endpoint calls.<br>*Default*: `1` |
| `BackoffMax` | `TimeSpan` | The maximum back off time.<br>*Default*: `TimeSpan.FromSeconds(0)` |
| `StatusCodesToRetry` | `IList<int>` | List of Http status codes to invoke retry.<br>*Default*: `new List<int> { 408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524, }` |
| `RequestMethodsToRetry` | `IList<HttpMethod>` | List of Http request methods to invoke retry.<br>*Default*: `new List<string> { "GET", "PUT", "GET", "PUT", }.Select(val => new HttpMethod(val))` |

### Test the SDK

The generated SDK also contain one or more Tests, which are contained in the Tests project. In order to invoke these test cases, you will need `NUnit 3.0 Test Adapter Extension` for Visual Studio. Once the SDK is complied, the test cases should appear in the Test Explorer window. Here, you can click `Run All` to execute these test cases.

## Client Class Documentation

### PQ API v2Client Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

#### Controllers

| Name | Description |
|  --- | --- |
| PaymentsController | Gets PaymentsController controller. |
| TransfersController | Gets TransfersController controller. |
| SpendBackController | Gets SpendBackController controller. |
| PrepaidCardsController | Gets PrepaidCardsController controller. |
| PaperChecksController | Gets PaperChecksController controller. |
| BankAccountsController | Gets BankAccountsController controller. |
| BalancesController | Gets BalancesController controller. |
| ReceiptsController | Gets ReceiptsController controller. |
| UsersController | Gets UsersController controller. |
| DocumentsController | Gets DocumentsController controller. |
| WebhooksController | Gets WebhooksController controller. |
| ProgramController | Gets ProgramController controller. |

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | `IHttpClientConfiguration` |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the PQ API v2Client using the values provided for the builder. | `Builder` |

### PQ API v2Client Builder Class

Class to build instances of PQ API v2Client.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<HttpClientConfiguration.Builder> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `HttpClientConfiguration(Action<HttpClientConfiguration.Builder> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `HttpClientConfiguration(Action<HttpClientConfiguration.Builder> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `HttpClientConfiguration(Action<HttpClientConfiguration.Builder> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |

## API Reference

### List of APIs

* [Payments](#payments)
* [Transfers](#transfers)
* [Spend Back](#spend-back)
* [Prepaid Cards](#prepaid-cards)
* [Paper Checks](#paper-checks)
* [Bank Accounts](#bank-accounts)
* [Balances](#balances)
* [Receipts](#receipts)
* [Users](#users)
* [Documents](#documents)
* [Webhooks](#webhooks)
* [Program](#program)

### Payments

#### Overview

Payment-related operations

##### Get instance

An instance of the `PaymentsController` class can be accessed from the API Client.

```
PaymentsController paymentsController = client.PaymentsController;
```

#### Get-Payments-Pmnt Token

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetPaymentsPmntTokenAsync(
    string pmntToken,
    string xMyPayQuickerVersion,
    string filter = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.PaymentResponse>`](#payment-response)

##### Example Usage

```csharp
string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
string xMyPayQuickerVersion = "2020.02.24";
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    PaymentResponse result = await paymentsController.GetPaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion, filter, language);
}
catch (ApiException e){};
```

#### Post-Payments-Pmnt Token

Accept an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostPaymentsPmntTokenAsync(
    string pmntToken,
    string xMyPayQuickerVersion,
    object body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`Task<Models.PaymentResponse>`](#payment-response)

##### Example Usage

```csharp
string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PaymentResponse result = await paymentsController.PostPaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

#### Delete-Payments-Pmnt Token

Cancel an open payment quote.

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeletePaymentsPmntTokenAsync(
    string pmntToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await paymentsController.DeletePaymentsPmntTokenAsync(pmntToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Put-Payments-Pmnt Token-Retract

Perform a payment retraction for the full payment amount.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutPaymentsPmntTokenRetractAsync(
    string pmntToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await paymentsController.PutPaymentsPmntTokenRetractAsync(pmntToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Patch-Payments-Pmnt Token-Retract

Perform a payment retraction for a partial payment amount.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PatchPaymentsPmntTokenRetractAsync(
    string pmntToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pmntToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual payment transaction and quote, prefixed with <i>pmnt-</i>.<br>**Constraints**: *Pattern*: `^pmnt-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string pmntToken = "pmnt-d3ff8a0d-aec9-49a6-a95b-6191aebeca20";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await paymentsController.PatchPaymentsPmntTokenRetractAsync(pmntToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Get-Payments

Retrieve a list of all payments that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetPaymentsAsync(
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.PaymentsCollectionResponse>`](#payments-collection-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    PaymentsCollectionResponse result = await paymentsController.GetPaymentsAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Payments

Create a payment quote.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostPaymentsAsync(
    string xMyPayQuickerVersion,
    Models.PaymentRequest body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.PaymentRequest`](#payment-request) | Body, Optional | - |

##### Response Type

[`Task<Models.PaymentResponse>`](#payment-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
var body = new PaymentRequest();
body.Amount = 78.98;
body.Currency = CurrencyTypesEnum.HKD;

try
{
    PaymentResponse result = await paymentsController.PostPaymentsAsync(xMyPayQuickerVersion, body);
}
catch (ApiException e){};
```

### Transfers

#### Overview

Transfer-related operations

##### Get instance

An instance of the `TransfersController` class can be accessed from the API Client.

```
TransfersController transfersController = client.TransfersController;
```

#### Get-Transfers-Xfer Token

Retrieve details of a specific transfer represented by a transfer token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetTransfersXferTokenAsync(
    string xferToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.TransferResponse>`](#transfer-response)

##### Example Usage

```csharp
string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    TransferResponse result = await transfersController.GetTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Transfers-Xfer Token

Accept a transfer quote

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostTransfersXferTokenAsync(
    string xferToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await transfersController.PostTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Delete-Transfers-Xfer Token

Optional cancellation that auto-cancels after a period organically expires or when account activity invalidates the quote.

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeleteTransfersXferTokenAsync(
    string xferToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await transfersController.DeleteTransfersXferTokenAsync(xferToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Get-Transfers

Retrieve a list of all transfers that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetTransfersAsync(
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.TransferCollectionResponse>`](#transfer-collection-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    TransferCollectionResponse result = await transfersController.GetTransfersAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Transfers

Create a new quote. <i>*This can be a non-payment card-to-card transfer, prepaid card from Flex (wallet), bank account, or user-to-user transfer.</i>

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostTransfersAsync(
    string xMyPayQuickerVersion,
    Models.TransferRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.TransferRequest`](#transfer-request) | Body, Required | - |

##### Response Type

[`Task<Models.TransferResponse>`](#transfer-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
var body = new TransferRequest();

try
{
    TransferResponse result = await transfersController.PostTransfersAsync(xMyPayQuickerVersion, body);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "sourceToken": "user-114773fd-85c1-4977-8ce5-24af71f744e9",
  "destinationToken": "dest-63947e68-5393-4d00-955d-e0020017924b",
  "notes": "string",
  "memo": "string",
  "destinationAmount": -1.79,
  "destinationCurrency": "USD",
  "clientTransferId": "DKKde3Meeiiw34",
  "token": "xfer-0c0f2727-6521-47c9-b1fa-f132306d456a",
  "sourceAmount": -1.79,
  "sourceCurrency": "USD",
  "status": "QUOTED",
  "fx": {
    "destinationAmount": -1.79,
    "destinationCurrency": "USD",
    "sourceAmount": -1.79,
    "sourceCurrency": "USD",
    "rate": 0.85
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://url.to.com/xfer-0c0f2727-6521-47c9-b1fa-f132306d456a"
    }
  ]
}
```

### Spend Back

#### Overview

Spendback-related operations

##### Get instance

An instance of the `SpendBackController` class can be accessed from the API Client.

```
SpendBackController spendBackController = client.SpendBackController;
```

#### Get-Spendback-Spnd Token

Retrieve a single spendback quote using the spendback token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetSpendbackSpndTokenAsync(
    string spndToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`Task`

##### Example Usage

```csharp
string spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    await spendBackController.GetSpendbackSpndTokenAsync(spndToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Spendback-Spnd Token

Accept an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostSpendbackSpndTokenAsync(
    string spndToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await spendBackController.PostSpendbackSpndTokenAsync(spndToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Delete-Spendback-Spnd Token

Cancel an open spendback quote.

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeleteSpendbackSpndTokenAsync(
    string spndToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await spendBackController.DeleteSpendbackSpndTokenAsync(spndToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Put-Spendback-Spnd Token-Refund

Perform a spendback refund for the full amount.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutSpendbackSpndTokenRefundAsync(
    string spndToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await spendBackController.PutSpendbackSpndTokenRefundAsync(spndToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Patch-Spendback-Spnd Token-Refund

Perform a spendback refund for a partial amount.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PatchSpendbackSpndTokenRefundAsync(
    string spndToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `spndToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual spendback transaction and quote, prefixed with <i>spnd-</i>.<br>**Constraints**: *Pattern*: `^spnd-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string spndToken = "spnd-c39437e1-dc80-4293-8211-c14b5a32f762";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await spendBackController.PatchSpendbackSpndTokenRefundAsync(spndToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Get-Spendback

Retrieve a list of all spendbacks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetSpendbackAsync(
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`Task`

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    await spendBackController.GetSpendbackAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Spendback

Create a spendback quote. <i>*Spendbacks can be automatically accepted by setting the `autoAcceptQuote` flag. If not automatically accepted, a POST is required to the spendback endpoint using the token returned in the response. Quotes can be accepted, cancelled, or allowed to expire.</i>

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostSpendbackAsync(
    string xMyPayQuickerVersion,
    object body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

`Task`

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await spendBackController.PostSpendbackAsync(xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

### Prepaid Cards

#### Overview

Prepaid Card-related operations

##### Get instance

An instance of the `PrepaidCardsController` class can be accessed from the API Client.

```
PrepaidCardsController prepaidCardsController = client.PrepaidCardsController;
```

#### Post-Users-User Token-Prepaidcards-Dest Token

Replace an existing Prepaid Card specifying the replacement reason and the card package for the replacement card.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenPrepaidcardsDestTokenAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    object body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`Task<Models.PrepaidCardResponse>`](#prepaid-card-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PrepaidCardResponse result = await prepaidCardsController.PostUsersUserTokenPrepaidcardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaid-Cards-Dest Token

Retrieve Prepaid Card details by destination token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPrepaidCardsDestTokenAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.PrepaidCardResponse>`](#prepaid-card-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PrepaidCardResponse result = await prepaidCardsController.GetUsersUserTokenPrepaidCardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Patch-Users-User Token-Prepaidcards-Dest Token

Partial Prepaid Card update typically used when modifying card status. <i>*Does not require the entire object be passed in the request</i>

:information_source: **Note** This endpoint does not require authentication.

```csharp
PatchUsersUserTokenPrepaidcardsDestTokenAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    Models.PrepaidCardStatus body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.PrepaidCardStatus`](#prepaid-card-status) | Body, Optional | - |

##### Response Type

[`Task<Models.PrepaidCardResponse>`](#prepaid-card-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PrepaidCardResponse result = await prepaidCardsController.PatchUsersUserTokenPrepaidcardsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "LOCKED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Pin

Retrieve one part of a two-part token required to reveal or set a client side PIN. <i>*Not all programs support a reveal or set PIN operation.</i>

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPrepaidcardsDestTokenPinAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.PrepaidCardPinToken>`](#prepaid-card-pin-token)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PrepaidCardPinToken result = await prepaidCardsController.GetUsersUserTokenPrepaidcardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Put-Users-User Token-Prepaidcards-Dest Token-Pin

Allows the setting of a PIN if supported by program.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutUsersUserTokenPrepaidcardsDestTokenPinAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    string token,
    string cardPin)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cardPin` | `string` | Query, Required | Prepaid card PIN for ATM and Debit usage |

##### Response Type

[`Task<Models.UsersPrepaidCardsPinResponse>`](#users-prepaid-cards-pin-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";
string token = "token6";
string cardPin = "cardPin4";

try
{
    UsersPrepaidCardsPinResponse result = await prepaidCardsController.PutUsersUserTokenPrepaidcardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion, token, cardPin);
}
catch (ApiException e){};
```

#### Post-Users-User Token-Prepaid-Cards-Dest Token-Pin

Reveals the PIN for a card where PIN reveal functionality is supported in the program and hosted by PayQuicker.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenPrepaidCardsDestTokenPinAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    string token,
    string cvc2,
    object body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `cvc2` | `string` | Query, Required | Card Verification Value (CVV) located on the back of your credit card or debit card is a 3-digit number on VISA® and MasterCard® branded credit cards, and debit cards. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`Task<Models.PrepaidCardPin>`](#prepaid-card-pin)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";
string token = "token6";
string cvc2 = "cvc20";

try
{
    PrepaidCardPin result = await prepaidCardsController.PostUsersUserTokenPrepaidCardsDestTokenPinAsync(userToken, destToken, xMyPayQuickerVersion, token, cvc2, null);
}
catch (ApiException e){};
```

#### Get-Users-User Token-Prepaidcards

Retrieve a list of all pre-paid cards by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPrepaidcardsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.PrepaidCardCollectionResponse>`](#prepaid-card-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    PrepaidCardCollectionResponse result = await prepaidCardsController.GetUsersUserTokenPrepaidcardsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
      "status": "QUEUED",
      "createdOn": "2020-02-21T22:00:00Z",
      "country": "US",
      "currency": "USD",
      "cardPersonalization": "PERSONALIZED",
      "cardPackage": "blue_consumer_10k",
      "cardNetwork": "VISA",
      "expires": "2023-02-21T00:00:00Z",
      "cardNumber": "1234 56** **** 1234",
      "cvv": "123",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards"
    }
  ]
}
```

#### Post-Users-User Token-Prepaidcards

Order a pre-paid card for the user by specifying a cardPackage. <i>*A package defines the type of card, currency, artwork utilized, and often the method of delivery.</i>

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenPrepaidcardsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    Models.PrepaidCardBase body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.PrepaidCardBase`](#prepaid-card-base) | Body, Optional | - |

##### Response Type

[`Task<Models.PrepaidCardRequestResponse>`](#prepaid-card-request-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PrepaidCardRequestResponse result = await prepaidCardsController.PostUsersUserTokenPrepaidcardsAsync(userToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d",
  "status": "QUEUED",
  "createdOn": "2020-02-21T22:00:00Z",
  "country": "US",
  "currency": "USD",
  "cardPersonalization": "PERSONALIZED",
  "cardPackage": "blue_consumer_10k",
  "cardNetwork": "VISA",
  "expires": "2023-02-21T00:00:00Z",
  "cardNumber": "1234 56** **** 1234",
  "cvv": "123",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/xxx/prepaid-cards/dest-37ba1fb7-6136-4216-bb13-f903af6b9f0d"
    }
  ]
}
```

#### Get-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Generate a token used to reveal prepaid card information in the form of image data (base64) or JSON.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPrepaidCardsDestTokenPciAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    Models.FormatEnum format,
    Models.SideEnum? side = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | - |
| `destToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`Models.FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `side` | [`Models.SideEnum?`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`Task<Models.PrepaidCardDataTokenResponse>`](#prepaid-card-data-token-response)

##### Example Usage

```csharp
string userToken = "user-token6";
string destToken = "dest-token2";
string xMyPayQuickerVersion = "2020.02.24";
FormatEnum format = FormatEnum.EnumTEXTIMAGE;

try
{
    PrepaidCardDataTokenResponse result = await prepaidCardsController.GetUsersUserTokenPrepaidCardsDestTokenPciAsync(userToken, destToken, xMyPayQuickerVersion, format, null);
}
catch (ApiException e){};
```

#### Post-Users-User-Token-Prepaid-Cards-Dest-Token-Pci

Return prepaid card data in the form of image data, text, or both.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenPrepaidCardsDestTokenPciAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    Models.FormatEnum format,
    string token,
    Models.SideEnum? side = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | - |
| `destToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `format` | [`Models.FormatEnum`](#format) | Query, Required | Desired format for the prepaid card data. |
| `token` | `string` | Query, Required | Token used as part of a two-leg card PIN reveal request sent directly from the client, generally involving a second piece of data such as the CVV code on the back of a card. |
| `side` | [`Models.SideEnum?`](#side) | Query, Optional | Side to specify when retrieving a prepaid card's image data. *Required if IMAGE format specified. |

##### Response Type

[`Task<Models.PrepaidCardDataResponse>`](#prepaid-card-data-response)

##### Example Usage

```csharp
string userToken = "user-token6";
string destToken = "dest-token2";
string xMyPayQuickerVersion = "2020.02.24";
FormatEnum format = FormatEnum.EnumTEXTIMAGE;
string token = "token6";

try
{
    PrepaidCardDataResponse result = await prepaidCardsController.PostUsersUserTokenPrepaidCardsDestTokenPciAsync(userToken, destToken, xMyPayQuickerVersion, format, token, null);
}
catch (ApiException e){};
```

### Paper Checks

#### Overview

Paper check-related operations

##### Get instance

An instance of the `PaperChecksController` class can be accessed from the API Client.

```
PaperChecksController paperChecksController = client.PaperChecksController;
```

#### Get-Users-User Token-Paper-Checks

Retrieve a list of paper checks that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPaperChecksAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.PaperCheckCollectionResponse>`](#paper-check-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    PaperCheckCollectionResponse result = await paperChecksController.GetUsersUserTokenPaperChecksAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Users-User Token-Paperchecks

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenPaperchecksAsync(
    string userToken,
    string xMyPayQuickerVersion,
    Models.PaperCheckBase body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.PaperCheckBase`](#paper-check-base) | Body, Optional | - |

##### Response Type

[`Task<Models.PaperCheckResponse>`](#paper-check-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
var body = new PaperCheckBase();
body.Amount = 78.98;
body.Currency = CurrencyTypesEnum.HKD;

try
{
    PaperCheckResponse result = await paperChecksController.PostUsersUserTokenPaperchecksAsync(userToken, xMyPayQuickerVersion, body);
}
catch (ApiException e){};
```

#### Get-Users-User Token-Paperchecks-Dest Token

Retrieve a list of paper checks by destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPaperchecksDestTokenAsync(
    string userToken,
    string xferToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.PaperCheckResponse>`](#paper-check-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    PaperCheckResponse result = await paperChecksController.GetUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Put-Users-User Token-Paperchecks-Dest Token

Create a quote for a paper check.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutUsersUserTokenPaperchecksDestTokenAsync(
    string userToken,
    string xferToken,
    string xMyPayQuickerVersion,
    object body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | `object` | Body, Optional | - |

##### Response Type

[`Task<Models.PaperCheckResponse>`](#paper-check-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    PaperCheckResponse result = await paperChecksController.PutUsersUserTokenPaperchecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

#### Delete-Users-User Token-Paper-Checks-Dest Token

Delete a paper check by destination token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeleteUsersUserTokenPaperChecksDestTokenAsync(
    string userToken,
    string xferToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xferToken` | `string` | Template, Required | Auto-generated unique identifier representing an individual transfer transaction, prefixed with <i>xfer-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xferToken = "xfer-0fac4aa8-43ac-447e-95f9-827f908a82ff";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await paperChecksController.DeleteUsersUserTokenPaperChecksDestTokenAsync(userToken, xferToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

### Bank Accounts

#### Overview

Bank account-related operations

##### Get instance

An instance of the `BankAccountsController` class can be accessed from the API Client.

```
BankAccountsController bankAccountsController = client.BankAccountsController;
```

#### Get-Users-User Token-Bankaccounts

Retrieve a list of bank accounts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenBankaccountsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.BankAccountCollectionResponse>`](#bank-account-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    BankAccountCollectionResponse result = await bankAccountsController.GetUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "token": "dest-7d8b1c83-01bb-40fb-87d7-26bd4c303f01",
      "status": "DELETED",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "333333333"
        },
        {
          "key": "BANK_BBAN",
          "value": "4444444444"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "My account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    },
    {
      "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
      "status": "ACTIVE",
      "createdOn": "2020-02-21T22:00:00Z",
      "bankAccountOwnershipType": "PERSONAL",
      "type": "CHECKING",
      "fields": [
        {
          "key": "BANK_ACH_ABA",
          "value": "012346789"
        },
        {
          "key": "BANK_BBAN",
          "value": "987654321"
        }
      ],
      "bankCurrency": "USD",
      "bankCountry": "US",
      "description": "Personal checking account",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Post-Users-User Token-Bankaccounts

Create a quote for a bank account using a user token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenBankaccountsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    Models.BankAccountFields body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`Task<Models.BankAccountResponse>`](#bank-account-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    BankAccountResponse result = await bankAccountsController.PostUsersUserTokenBankaccountsAsync(userToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Get-Users-User Token-Bankaccounts-Dest Token

Retrieve a list of bank accounts using a destination token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenBankaccountsDestTokenAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.BankAccountResponse>`](#bank-account-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    BankAccountResponse result = await bankAccountsController.GetUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Put-Users-User Token-Bankaccounts-Dest Token

Update a bank account.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutUsersUserTokenBankaccountsDestTokenAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    Models.BankAccountFields body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.BankAccountFields`](#bank-account-fields) | Body, Optional | - |

##### Response Type

[`Task<Models.BankAccountResponse>`](#bank-account-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    BankAccountResponse result = await bankAccountsController.PutUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "token": "dest-efacd12b-a86e-4f44-bbea-927955ec1634",
  "status": "ACTIVE",
  "createdOn": "2020-02-21T22:00:00Z",
  "bankAccountOwnershipType": "PERSONAL",
  "type": "CHECKING",
  "fields": [
    {
      "key": "BANK_ACH_ABA",
      "value": "012346789"
    },
    {
      "key": "BANK_BBAN",
      "value": "987654321"
    }
  ],
  "bankCurrency": "USD",
  "bankCountry": "US",
  "description": "Personal checking account",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

#### Delete-Users-User Token-Bankaccounts-Dest Token

Delete (cloak) a user bank account.

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeleteUsersUserTokenBankaccountsDestTokenAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await bankAccountsController.DeleteUsersUserTokenBankaccountsDestTokenAsync(userToken, destToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Get-Users-User Token-Bankaccounts-Requirements

Retrieve requirements for adding a bank account using the parameters provided (user context, given country of residence, supported EFT provider(s), destination currency, destination country, required fields, with names, and regex validation expression) for easy customer wire-up and validation.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenBankaccountsRequirementsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.BankAccountRequirementCollectionResponse>`](#bank-account-requirement-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    BankAccountRequirementCollectionResponse result = await bankAccountsController.GetUsersUserTokenBankaccountsRequirementsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "bankCountry": "IT",
      "bankCurrency": "EUR",
      "requirements": [
        {
          "requirement": "BANK_IBAN",
          "format": {
            "example": "IT43K0310412701000000820420",
            "legend": [
              {
                "key": "IT43K0310412701000000820420",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example IBAN"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio IBAN"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "IBAN"
            },
            {
              "language": "it-IT",
              "translation": "IBAN"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^IT\\\\d{2}[A-Z]\\\\d{10}[0-9A-Z]{12}$"
            }
          ]
        },
        {
          "requirement": "BANK_SWIFT_BIC",
          "format": {
            "example": "01234567890",
            "legend": [
              {
                "key": "01234567890",
                "descriptions": [
                  {
                    "language": "en-US",
                    "translation": "Example Swift/BIC"
                  },
                  {
                    "language": "it-IT",
                    "translation": "Esempio Swift/BIC"
                  }
                ]
              }
            ]
          },
          "description": [
            {
              "language": "en-US",
              "translation": "Swift/BIC"
            },
            {
              "language": "it-IT",
              "translation": "Swift/BIC"
            }
          ],
          "validators": [
            {
              "validatorType": "REGEX",
              "expression": "^[a-z0-9A-Z]{8,11}$"
            }
          ]
        }
      ],
      "quote": {
        "formattedAmount": "$4.32 USD (USD, en-US), 0,00 € EUR (EUR, fr-FR)",
        "amount": 4.32,
        "currency": "USD"
      },
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ]
}
```

### Balances

#### Overview

Balance-related operations

##### Get instance

An instance of the `BalancesController` class can be accessed from the API Client.

```
BalancesController balancesController = client.BalancesController;
```

#### Get-Users-User Token-Balances

Retrieve a list of user balances that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenBalancesAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.BalanceCollectionResponse>`](#balance-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    BalanceCollectionResponse result = await balancesController.GetUsersUserTokenBalancesAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$4.32 USD",
      "amount": 4.32,
      "currency": "USD",
      "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/balances"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Dest Token-Balances

Retrieve a list of balances by destination token that supports filtering, sorting, and pagination through existing mechanisms. <i>*If the user belongs to a Flex-based program, balances against the user resource will return the wallet balance only. If it is a pre-paid card program (i.e., Meta USD), this balance and its associated pre-paid card balance will be the same.</i>

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPrepaidcardsDestTokenBalancesAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.BalanceCollectionResponse>`](#balance-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    BalanceCollectionResponse result = await balancesController.GetUsersUserTokenPrepaidcardsDestTokenBalancesAsync(userToken, destToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "formattedAmount": "$4.32",
  "amount": 4.32,
  "currency": "USD",
  "token": "dest-4aed86e2-4929-45bf-814d-9030aef21e79",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/prepaid-cards/dest-4aed86e2-4929-45bf-814d-9030aef21e79/balances"
    }
  ]
}
```

#### Get-Accounts-Acct Token-Balances

Retrieve a single account balance.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetAccountsAcctTokenBalancesAsync(
    string acctToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.BalanceCollectionResponse>`](#balance-collection-response)

##### Example Usage

```csharp
string acctToken = "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    BalanceCollectionResponse result = await balancesController.GetAccountsAcctTokenBalancesAsync(acctToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "formattedAmount": "$5.00",
      "amount": 5,
      "currency": "USD",
      "token": "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4"
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4/balances"
    }
  ]
}
```

### Receipts

#### Overview

Receipt-related operations

##### Get instance

An instance of the `ReceiptsController` class can be accessed from the API Client.

```
ReceiptsController receiptsController = client.ReceiptsController;
```

#### Get-Accounts-Receipts

Retrieve a list of all account(s) receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetAccountsReceiptsAsync(
    string acctToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acctToken` | `string` | Template, Required | Auto-generated unique identifier representing a company account, prefixed with <i>acct-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`Task<object>`

##### Example Usage

```csharp
string acctToken = "acct-b3f0570a-6586-4e00-8d6e-8a2bf93cfae4";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    object result = await receiptsController.GetAccountsReceiptsAsync(acctToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response

```
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "acct-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/accounts/acct-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-User Token-Prepaidcards-Receipts

Retrieve a list all prepaid-card receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenPrepaidcardsReceiptsAsync(
    string userToken,
    string destToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `destToken` | `string` | Template, Required | Auto-generated unique identifier representing a transfer destination, including prepaid cards, bank accounts, paper checks, and other users, prefixed with <i>dest->.<br>**Constraints**: *Pattern*: `^dest-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$` |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.ReceiptCollectionResponse>`](#receipt-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string destToken = "dest-4aed86e2-4929-45bf-814d-9030aef21e79";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    ReceiptCollectionResponse result = await receiptsController.GetUsersUserTokenPrepaidcardsReceiptsAsync(userToken, destToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.05,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/prepaid-cards/dest-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

#### Get-Users-Receipts

Retrieve a list all user receipts that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersReceiptsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.ReceiptCollectionResponse>`](#receipt-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    ReceiptCollectionResponse result = await receiptsController.GetUsersReceiptsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "amount": 5000.01,
      "currency": "USD",
      "sourceToken": "user-04017f57-8526-4b0c-9152-5252975a86e4",
      "destinationToken": "dest-04017f57-8526-4b0c-9152-5252975a86e4",
      "createdOn": "2023-02-21T00:00:00Z"
    }
  ],
  "meta": {
    "pageNo": "1",
    "pageSize": "20",
    "pageCount": "85",
    "recordCount": "1685",
    "timezone": "GMT"
  },
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-04017f57-8526-4b0c-9152-5252975a86e4/receipts"
    }
  ]
}
```

### Users

#### Overview

User-related operations

##### Get instance

An instance of the `UsersController` class can be accessed from the API Client.

```
UsersController usersController = client.UsersController;
```

#### Put-Users-User Token

Update a user object (change email, address change, etc.) using a user token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutUsersUserTokenAsync(
    string userToken,
    string xMyPayQuickerVersion,
    Models.UserBase body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.UserBase`](#user-base) | Body, Optional | - |

##### Response Type

[`Task<Models.UserResponse>`](#user-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    UserResponse result = await usersController.PutUsersUserTokenAsync(userToken, xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token

Retrieve a single user record by user token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenAsync(
    string userToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.UserResponse>`](#user-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    UserResponse result = await usersController.GetUsersUserTokenAsync(userToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users

Retrieve a list of all users that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersAsync(
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

[`Task<Models.UserCollectionResponse>`](#user-collection-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    UserCollectionResponse result = await usersController.GetUsersAsync(xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "firstName": "Jane",
      "lastName": "Smith",
      "dateOfBirth": "1977-12-14",
      "phoneNumber": "760-350-0324",
      "phoneNumberCountry": "US",
      "mobileNumber": "213-446-5755",
      "mobileNumberCountry": "US",
      "addressLine1": "290 Carriage Court",
      "city": "Los Angeles",
      "region": "CA",
      "country": "US",
      "postalCode": "90017",
      "addressType": "RESIDENTIAL",
      "email": "jsmith@payquicker.com",
      "gender": "FEMALE",
      "userType": "INDIVIDUAL",
      "programUserId": "d97ce0519b2d",
      "language": "en-US",
      "countryOfBirth": "US",
      "countryOfNationality": "US",
      "token": "usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357",
      "status": "PRE_ACTIVATED",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/usr-3b8a0c25-c7e2-4bb7-904e-0a2a66001357"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users"
    }
  ]
}
```

#### Post-Users

Create a new user. Payload contains both required and optional fields for user- and company-based users, allowing for the creation of a corporate/partnership/dba (i.e., Grubhub model) user along with a standard end user (i.e., <i>Payee</i>). The type of the user (<i>Business</i> vs. <i>User</i>) and type of business (<i>Corporation</i> vs. <i>Partnership</i>) provide context that impacts KYC etc.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersAsync(
    string xMyPayQuickerVersion,
    Models.UserBase body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.UserBase`](#user-base) | Body, Required | Body details of the request |

##### Response Type

[`Task<Models.UserResponse>`](#user-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";
var body = new UserBase();
body.PhoneNumber = "760-350-0324";
body.MobileNumber = "213-446-5755";
body.PhoneNumberCountry = CountryTypesEnum.US;
body.MobileNumberCountry = CountryTypesEnum.US;
body.FirstName = "Jane";
body.LastName = "Smith";
body.DateOfBirth = DateTime.Parse("1977-12-14");
body.AddressLine1 = "290 Carriage Court";
body.City = "Los Angeles";
body.Region = "CA";
body.Country = CountryTypesEnum.US;
body.PostalCode = "90017";
body.AddressType = AddressTypesEnum.RESIDENTIAL;
body.Email = "jsmith@payquicker.com";
body.Gender = GenderTypesEnum.FEMALE;
body.UserType = UserTypesEnum.INDIVIDUAL;
body.ProgramUserId = "d97ce0519b2d";
body.Language = LanguageTypesEnum.EnUS;
body.CountryOfBirth = CountryTypesEnum.US;
body.CountryOfNationality = CountryTypesEnum.US;

try
{
    UserResponse result = await usersController.PostUsersAsync(xMyPayQuickerVersion, body);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "dateOfBirth": "1977-12-14",
  "phoneNumber": "760-350-0324",
  "phoneNumberCountry": "US",
  "mobileNumber": "213-446-5755",
  "mobileNumberCountry": "US",
  "addressLine1": "290 Carriage Court",
  "city": "Los Angeles",
  "region": "CA",
  "country": "US",
  "postalCode": "90017",
  "addressType": "RESIDENTIAL",
  "email": "jsmith@payquicker.com",
  "gender": "FEMALE",
  "userType": "INDIVIDUAL",
  "programUserId": "d97ce0519b2d",
  "language": "en-US",
  "countryOfBirth": "US",
  "countryOfNationality": "US",
  "token": "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a",
  "status": "PRE_ACTIVATED",
  "createdOn": "2020-02-24T22:00:00Z",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks

Retrieve a list of IDV checks by user token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenIdvChecksAsync(
    string userToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.IdentityVerificationCollectionResponse>`](#identity-verification-collection-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    IdentityVerificationCollectionResponse result = await usersController.GetUsersUserTokenIdvChecksAsync(userToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "payload": [
    {
      "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
      "idvResult": "PASS",
      "idvSubResult": "HARD",
      "idvProvider": "IDOLOGY",
      "createdOn": "2020-02-21T22:00:00Z",
      "raw": "<RAW IDV processor output, for informational /debugging purposes only>",
      "idvCheckType": "NON_DOCUMENTARY",
      "idvDisposition": "FINAL",
      "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
        }
      ]
    }
  ],
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks"
    }
  ]
}
```

#### Get-Users-User Token-Idv-Checks-Idvc Token

Retrieve a list of all IDV check by IDVC token that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenIdvChecksIdvcTokenAsync(
    string userToken,
    string idvcToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `idvcToken` | `string` | Template, Required | Auto-generated unique identifier representing a user IDV check, prefixed with <i>idvc-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.IdentityVerificationResponse>`](#identity-verification-response)

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string idvcToken = "idvc-7e7567e0-c2db-485d-896d-45901a10baa9";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    IdentityVerificationResponse result = await usersController.GetUsersUserTokenIdvChecksIdvcTokenAsync(userToken, idvcToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "idvProviderReference": "yPV0h4o1Yw3QzdLAvA7a",
  "idvResult": "PASS",
  "idvSubResult": "HARD",
  "idvProvider": "IDOLOGY",
  "createdOn": "2020-02-21T22:00:00Z",
  "raw": "<RAW IDV processor output, for informational/debugging purposes only>",
  "idvCheckType": "NON_DOCUMENTARY",
  "idvDispostion": "FINAL",
  "token": "idvc-7e7567e0-c2db-485d-896d-45901a10baa9",
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "https://platform.mypayquicker.com/api/v2/users/user-f012bc86-4d42-415b-a8b2-be5e0b90e59a/idv-checks/idvc-7e7567e0-c2db-485d-896d-45901a10baa9"
    }
  ]
}
```

#### Get-Users-User Token-Events

Retrieve a list of all user events that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenEventsAsync(
    string userToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";

try
{
    await usersController.GetUsersUserTokenEventsAsync(userToken);
}
catch (ApiException e){};
```

#### Get-Users-User Token-Events-Event Token

Retrieve a single user event

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenEventsEventTokenAsync(
    string userToken,
    string evntToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `evntToken` | `string` | Template, Required | Auto-generated unique identifier representing an event, prefixed with <i>evnt-</i>. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string evntToken = "evnt-28491de2-5b22-4e30-028a-45901a10baa9";

try
{
    await usersController.GetUsersUserTokenEventsEventTokenAsync(userToken, evntToken);
}
catch (ApiException e){};
```

#### Post-Users-User Token-Agreements-Agmt Token

Accept a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenAgreementsAgmtTokenAsync(
    string userToken,
    string agmtToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `agmtToken` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string agmtToken = "agmt-45901a10-5b22-4e30-028a-45901a10baa9";

try
{
    await usersController.PostUsersUserTokenAgreementsAgmtTokenAsync(userToken, agmtToken);
}
catch (ApiException e){};
```

#### Get-Users-User Token-Agreements

Retrieve a list of all accepted program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenAgreementsAsync(
    string userToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";

try
{
    await usersController.GetUsersUserTokenAgreementsAsync(userToken);
}
catch (ApiException e){};
```

### Documents

#### Overview

Document-related operations

##### Get instance

An instance of the `DocumentsController` class can be accessed from the API Client.

```
DocumentsController documentsController = client.DocumentsController;
```

#### Get-Users-User Token-Documents

Retrieve a list of user documents that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenDocumentsAsync(
    string userToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    await documentsController.GetUsersUserTokenDocumentsAsync(userToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Post-Users-User Token-Documents

Create a quote for a user document.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostUsersUserTokenDocumentsAsync(
    string userToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await documentsController.PostUsersUserTokenDocumentsAsync(userToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

#### Get-Users-User Token-Documents-Docu Token

Retrieve an individual user document by its document token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetUsersUserTokenDocumentsDocuTokenAsync(
    string userToken,
    string docuToken,
    string xMyPayQuickerVersion,
    int? page = null,
    int? pageSize = 20,
    string filter = null,
    string sort = null,
    Models.LanguageTypesEnum? language = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `page` | `int?` | Query, Optional | Page number of specific page to return<br>**Constraints**: `>= 1` |
| `pageSize` | `int?` | Query, Optional | Number of items to be displayed per page<br>**Default**: `20`<br>**Constraints**: `>= 1`, `<= 50` |
| `filter` | `string` | Query, Optional | Filter request results by specific criteria. |
| `sort` | `string` | Query, Optional | Sort request results by specific attribute. |
| `language` | [`Models.LanguageTypesEnum?`](#language-types) | Query, Optional | Filter results by language type. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string docuToken = "docu-6260c132-5cb1-4e30-8b08-9ce559893acb";
string xMyPayQuickerVersion = "2020.02.24";
int? pageSize = 20;
string filter = "'name'*'Fra'||*'Ger','numericCode'>'5'";
string sort = "-name";
LanguageTypesEnum? language = LanguageTypesEnum.EnUS;

try
{
    await documentsController.GetUsersUserTokenDocumentsDocuTokenAsync(userToken, docuToken, xMyPayQuickerVersion, null, pageSize, filter, sort, language);
}
catch (ApiException e){};
```

#### Put-Users-User Token-Documents-Docu Token

Replace the user document at the given document token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PutUsersUserTokenDocumentsDocuTokenAsync(
    string userToken,
    string docuToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userToken` | `string` | Template, Required | Auto-generated unique identifier representing a user, prefixed with <i>user-</i>. |
| `docuToken` | `string` | Template, Required | Auto-generated unique identifier representing an uploaded document, prefixed with <i>docu-</i>. |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string userToken = "user-f012bc86-4d42-415b-a8b2-be5e0b90e59a";
string docuToken = "docu-6260c132-5cb1-4e30-8b08-9ce559893acb";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await documentsController.PutUsersUserTokenDocumentsDocuTokenAsync(userToken, docuToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

### Webhooks

#### Overview

Webhook-related operations

##### Get instance

An instance of the `WebhooksController` class can be accessed from the API Client.

```
WebhooksController webhooksController = client.WebhooksController;
```

#### Get-Webhook

Retrieve a list of all webhook subscriptions that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetWebhookAsync(
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.WebhookCollectionResponse>`](#webhook-collection-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";

try
{
    WebhookCollectionResponse result = await webhooksController.GetWebhookAsync(xMyPayQuickerVersion);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "payload": [
    {
      "links": [
        {
          "params": {
            "rel": "self"
          },
          "href": "string"
        }
      ],
      "url": "https://www.example.com/webhooks",
      "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
      "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
      "created": "2020-01-01",
      "lastUpdated": "2020-02-01"
    }
  ]
}
```

#### Post-Webhooks

Create a webhook subscription for a given URL and namespace. When this event fires, the webhook receives a call from the API.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostWebhooksAsync(
    string xMyPayQuickerVersion,
    Models.WebhookSubscription body = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |
| `body` | [`Models.WebhookSubscription`](#webhook-subscription) | Body, Optional | - |

##### Response Type

[`Task<Models.WebhookSubscriptionResponse>`](#webhook-subscription-response)

##### Example Usage

```csharp
string xMyPayQuickerVersion = "2020.02.24";

try
{
    WebhookSubscriptionResponse result = await webhooksController.PostWebhooksAsync(xMyPayQuickerVersion, null);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01"
}
```

#### Get-Webhooks-Webh-Token

Retrieve a single webhook subscription using the webhook token.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetWebhooksWebhTokenAsync(
    string webhToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

[`Task<Models.WebhookSubscriptionResponse>`](#webhook-subscription-response)

##### Example Usage

```csharp
string webhToken = "webh-token0";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    WebhookSubscriptionResponse result = await webhooksController.GetWebhooksWebhTokenAsync(webhToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

##### Example Response *(as JSON)*

```json
{
  "links": [
    {
      "params": {
        "rel": "self"
      },
      "href": "string"
    }
  ],
  "url": "https://www.example.com/webhooks",
  "namespace": "BANKACCOUNTS.UPDATED.STATUS.APPROVED",
  "token": "webh-2dd54a53-3814-4ce1-862f-dc06b09ead4a",
  "created": "2020-01-01",
  "lastUpdated": "2020-02-01"
}
```

#### Delete-Webhooks-Webh-Token

Delete a webhook subscription. Deleted webhooks no longer receive notifications about events. Deleting an already deleted webhook will result in a successful 200 (OK) response code.

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeleteWebhooksWebhTokenAsync(
    string webhToken,
    string xMyPayQuickerVersion)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `webhToken` | `string` | Template, Required | - |
| `xMyPayQuickerVersion` | `string` | Header, Required | Date-based API Version specified in the header <i>required</i> on all calls. |

##### Response Type

`Task`

##### Example Usage

```csharp
string webhToken = "webh-token0";
string xMyPayQuickerVersion = "2020.02.24";

try
{
    await webhooksController.DeleteWebhooksWebhTokenAsync(webhToken, xMyPayQuickerVersion);
}
catch (ApiException e){};
```

### Program

#### Overview

##### Get instance

An instance of the `ProgramController` class can be accessed from the API Client.

```
ProgramController programController = client.ProgramController;
```

#### Get-Programs

Retrieve a list of all programs that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetProgramsAsync()
```

##### Response Type

`Task`

##### Example Usage

```csharp
try
{
    await programController.GetProgramsAsync();
}
catch (ApiException e){};
```

#### Get-Programs-Prog Token

Retrieve a single program configuration

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetProgramsProgTokenAsync(
    string progToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |

##### Response Type

`Task`

##### Example Usage

```csharp
string progToken = "prog-4525ab9c-5b22-4e30-028a-45901a10aa0c";

try
{
    await programController.GetProgramsProgTokenAsync(progToken);
}
catch (ApiException e){};
```

#### Get-Programs-Prog Token-Agreements

Retrieve a list of all program agreements that supports filtering, sorting, and pagination through existing mechanisms.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetProgramsProgTokenAgreementsAsync(
    string progToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | - |

##### Response Type

`Task`

##### Example Usage

```csharp
string progToken = "prog-token4";

try
{
    await programController.GetProgramsProgTokenAgreementsAsync(progToken);
}
catch (ApiException e){};
```

#### Get-Programs-Prog Token-Agreements-Agmt Token

Retrieve a single program agreement

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetProgramsProgTokenAgreementsAgmtTokenAsync(
    string progToken,
    string agmtToken)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `progToken` | `string` | Template, Required | Auto-generated unique identifier representing a program, prefixed with <i>prog-</i>. |
| `agmtToken` | `string` | Template, Required | Auto-generated unique identifier representing a program agreement, prefixed with <i>agmt-</i>. |

##### Response Type

`Task`

##### Example Usage

```csharp
string progToken = "prog-4525ab9c-5b22-4e30-028a-45901a10aa0c";
string agmtToken = "agmt-45901a10-5b22-4e30-028a-45901a10baa9";

try
{
    await programController.GetProgramsProgTokenAgreementsAgmtTokenAsync(progToken, agmtToken);
}
catch (ApiException e){};
```

## Model Reference

### Structures

* [Source Monetary Required](#source-monetary-required)
* [Haetos Self Ref](#haetos-self-ref)
* [Haetos Params](#haetos-params)
* [Haetos Relationship](#haetos-relationship)
* [Transfer-Request](#transfer-request)
* [Transfer](#transfer)
* [Expiration](#expiration)
* [Transfer-Response](#transfer-response)
* [Not Before or After](#not-before-or-after)
* [Address](#address)
* [Business Address](#business-address)
* [Monetary Formatted](#monetary-formatted)
* [Transfer Base](#transfer-base)
* [Payment Base](#payment-base)
* [Transfer Base Ext](#transfer-base-ext)
* [Destination Monetary Required](#destination-monetary-required)
* [Monetary Required](#monetary-required)
* [Balance](#balance)
* [Fx Object](#fx-object)
* [User Base](#user-base)
* [User](#user)
* [User-Response](#user-response)
* [Receipt Base](#receipt-base)
* [Receipt Collection-Response](#receipt-collection-response)
* [Balance Collection-Response](#balance-collection-response)
* [User Collection-Response](#user-collection-response)
* [Payment-Request](#payment-request)
* [Payment](#payment)
* [Payments Collection-Response](#payments-collection-response)
* [Payment-Response](#payment-response)
* [Transfer Collection-Response](#transfer-collection-response)
* [User Name](#user-name)
* [Dob](#dob)
* [Business Information](#business-information)
* [User Kyc Information](#user-kyc-information)
* [Phone Numbers](#phone-numbers)
* [Email Address](#email-address)
* [User Employer Id](#user-employer-id)
* [Gender](#gender)
* [Language](#language)
* [User Type](#user-type)
* [Program User Id](#program-user-id)
* [Source Destination Token](#source-destination-token)
* [Token](#token)
* [Client Transfer Id](#client-transfer-id)
* [Notes](#notes)
* [Memo](#memo)
* [Created On](#created-on)
* [Transfer Status](#transfer-status)
* [User Status](#user-status)
* [Payment Purpose](#payment-purpose)
* [Source Token](#source-token)
* [Destination Token](#destination-token)
* [Client Payment Id](#client-payment-id)
* [Auto Accept Quote](#auto-accept-quote)
* [Rate](#rate)
* [Fx](#fx)
* [Paper Check Base](#paper-check-base)
* [Transfer Type](#transfer-type)
* [Bank Account Ownership](#bank-account-ownership)
* [Shipping Method](#shipping-method)
* [Paper Check](#paper-check)
* [Paper Check-Response](#paper-check-response)
* [Paper Check Collection-Response](#paper-check-collection-response)
* [Bank Account Fields](#bank-account-fields)
* [Bank Account Type](#bank-account-type)
* [Bank Account](#bank-account)
* [Bank Account Status](#bank-account-status)
* [Bank Account-Response](#bank-account-response)
* [Bank Account Collection-Response](#bank-account-collection-response)
* [Prepaid Card Package](#prepaid-card-package)
* [Prepaid Card Base](#prepaid-card-base)
* [Prepaid Card Status](#prepaid-card-status)
* [Token Type](#token-type)
* [Prepaid Card Base Ext](#prepaid-card-base-ext)
* [Card Network](#card-network)
* [Card Personalization Type](#card-personalization-type)
* [Prepaid Card](#prepaid-card)
* [Currency](#currency)
* [Country](#country)
* [Prepaid Card-Request Response](#prepaid-card-request-response)
* [Prepaid Card-Response](#prepaid-card-response)
* [Prepaid Card Collection-Response](#prepaid-card-collection-response)
* [Card Masked Pan](#card-masked-pan)
* [Prepaid Card Replacement Reason](#prepaid-card-replacement-reason)
* [Prepaid Card Replacement Base](#prepaid-card-replacement-base)
* [Prepaid Card Pin Token](#prepaid-card-pin-token)
* [Prepaid Card Pin](#prepaid-card-pin)
* [Cvv](#cvv)
* [Identity Verification Provider Type](#identity-verification-provider-type)
* [Identity Verification Result Type](#identity-verification-result-type)
* [Identity Verification Sub Result Type](#identity-verification-sub-result-type)
* [Identity Verification Disposition Type](#identity-verification-disposition-type)
* [Identity Verification Check Type](#identity-verification-check-type)
* [Identity Verification Base](#identity-verification-base)
* [Identity Verification Provider Reference](#identity-verification-provider-reference)
* [Identity Verification Provider Raw Output](#identity-verification-provider-raw-output)
* [Identity Verification-Response](#identity-verification-response)
* [Identity Verification Collection-Response](#identity-verification-collection-response)
* [Key Value Pair String String](#key-value-pair-string-string)
* [Key Value Pair Bank Field Types String](#key-value-pair-bank-field-types-string)
* [Key Value Pair Bank Currency Currency Types](#key-value-pair-bank-currency-currency-types)
* [Key Value Bank Country Country Types](#key-value-bank-country-country-types)
* [Bank Account Required Fields](#bank-account-required-fields)
* [Bank Account Requirement Format](#bank-account-requirement-format)
* [Bank Account Requirement Format Legend](#bank-account-requirement-format-legend)
* [Key Value Pair Language Type String](#key-value-pair-language-type-string)
* [Bank Account Requirement Validator](#bank-account-requirement-validator)
* [Bank Account Requirement](#bank-account-requirement)
* [Bank Account Requirement-Response](#bank-account-requirement-response)
* [Bank Account Requirement Collection-Response](#bank-account-requirement-collection-response)
* [Occupation](#occupation)
* [Tax Resident Status](#tax-resident-status)
* [Webhook-Subscription](#webhook-subscription)
* [Webhook-Subscription-Response](#webhook-subscription-response)
* [Webhook Collection-Response](#webhook-collection-response)
* [Prepaid Card Data-Response](#prepaid-card-data-response)
* [Prepaid Card Data Token](#prepaid-card-data-token)
* [Prepaid Card Data Token-Response](#prepaid-card-data-token-response)
* [Business Type](#business-type)
* [Country Nationality Information](#country-nationality-information)
* [Users Prepaid Cards Pin Response](#users-prepaid-cards-pin-response)

#### Source Monetary Required

Required details of the monetary source.

##### Class Name

`SourceMonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceAmount` | `double?` | Optional | Amount of the transfer in the specified currency. |
| `SourceCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "sourceAmount": null,
  "sourceCurrency": null
}
```

#### Haetos Self Ref

Indicates the external link with the full URL of the same page on which the link appears.

##### Class Name

`HaetosSelfRef`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "links": null
}
```

#### Haetos Params

Hypermedia as the Engine of Application State (HAETOS) parameters used in a query.

##### Class Name

`HaetosParams`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Params` | [`Models.HaetosRelationship`](#haetos-relationship) | Required | Indicates the HATEOS relationship between the target and current resources. |
| `Href` | `string` | Required | URL for resource described by the relationship. |

##### Example (as JSON)

```json
{
  "params": {
    "rel": "self"
  },
  "href": null
}
```

#### Haetos Relationship

Indicates the HATEOS relationship between the target and current resources.

##### Class Name

`HaetosRelationship`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rel` | `string` | Required | Indicates the relationship between the target and current resources.<br>**Default**: `"self"`<br>*Default: `"self"`* |

##### Example (as JSON)

```json
{
  "rel": "self"
}
```

#### Transfer-Request

Request for the transfer

##### Class Name

`TransferRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `ClientTransferId` | `string` | Optional | Unique value provided by the client for the transfer. |
| `DestinationAmount` | `double?` | Optional | Amount transferred to the destination |
| `DestinationCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "clientTransferId": null,
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Transfer

Description of the transfer request

##### Class Name

`Transfer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `DestinationAmount` | `double?` | Optional | Amount transferred to the destination |
| `DestinationCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `ClientTransferId` | `string` | Optional | Unique value provided by the client for the transfer. |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `SourceAmount` | `double?` | Optional | Amount of the transfer in the specified currency. |
| `SourceCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Status` | [`Models.TransferStatusTypesEnum?`](#transfer-status-types) | Optional | Current status of a transfer |
| `Fx` | [`Models.FxObject`](#fx-object) | Optional | Currency conversion object details |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null
}
```

#### Expiration

Date and time the object will expire

##### Class Name

`Expiration`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Expires` | `DateTime?` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |

##### Example (as JSON)

```json
{
  "expires": null
}
```

#### Transfer-Response

##### Class Name

`TransferResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `DestinationAmount` | `double?` | Optional | Amount transferred to the destination |
| `DestinationCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `ClientTransferId` | `string` | Optional | Unique value provided by the client for the transfer. |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `SourceAmount` | `double?` | Optional | Amount of the transfer in the specified currency. |
| `SourceCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Status` | [`Models.TransferStatusTypesEnum?`](#transfer-status-types) | Optional | Current status of a transfer |
| `Fx` | [`Models.FxObject`](#fx-object) | Optional | Currency conversion object details |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "status": null,
  "fx": null,
  "links": null
}
```

#### Not Before or After

##### Class Name

`NotBeforeOrAfter`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotBefore` | `DateTime?` | Optional | Transfer is scheduled and will not process before this time. |
| `NotAfter` | `DateTime?` | Optional | Transfer expires if not completed prior to this time. |

##### Example (as JSON)

```json
{
  "notBefore": null,
  "notAfter": null
}
```

#### Address

Classifies the mailing address

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |

##### Example (as JSON)

```json
{
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null
}
```

#### Business Address

Address of the business location

##### Class Name

`BusinessAddress`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessAddressLine1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `BusinessAddressLine2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `BusinessAddressLine3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `BusinessAddressLine4` | `string` | Optional | fourth line of the business address street address |
| `BusinessAddressLine5` | `string` | Optional | Fifth line of the business address street address |
| `BusinessCity` | `string` | Optional | City the business is registered |
| `BusinessRegion` | `string` | Optional | State, province, or region the business is registered |
| `BusinessCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessPostalCode` | `string` | Optional | Postal code for the business address |
| `BusinessPremiseNumber` | `string` | Optional | House number for the business address |

##### Example (as JSON)

```json
{
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null
}
```

#### Monetary Formatted

Object representing monies, including currency, decimal, and formatted amounts

##### Class Name

`MonetaryFormatted`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FormattedAmount` | `string` | Optional | Formatted monetary amount |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base

Base class for the transfer

##### Class Name

`TransferBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null
}
```

#### Payment Base

Base class for the payment

##### Class Name

`PaymentBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `Purpose` | [`Models.PaymentPurposeTypesEnum?`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `ClientPaymentId` | `string` | Optional | Unique value provided by the client for the payment. |
| `AutoAcceptQuote` | `bool?` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Base Ext

Base extension for the transfer

##### Class Name

`TransferBaseExt`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `DestinationAmount` | `double?` | Optional | Amount transferred to the destination |
| `DestinationCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `ClientTransferId` | `string` | Optional | Unique value provided by the client for the transfer. |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null,
  "notes": null,
  "memo": null,
  "destinationAmount": null,
  "destinationCurrency": null,
  "clientTransferId": null,
  "token": null
}
```

#### Destination Monetary Required

Monetary instruments required for the destination

##### Class Name

`DestinationMonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DestinationAmount` | `double?` | Optional | Amount transferred to the destination |
| `DestinationCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null
}
```

#### Monetary Required

Monetary requirements for the transfer

##### Class Name

`MonetaryRequired`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Balance

Account monetary balance

##### Class Name

`Balance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FormattedAmount` | `string` | Optional | Formatted monetary amount |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Fx Object

Currency conversion object details

##### Class Name

`FxObject`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DestinationAmount` | `double?` | Optional | Amount transferred to the destination |
| `DestinationCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `SourceAmount` | `double?` | Optional | Amount of the transfer in the specified currency. |
| `SourceCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Rate` | `double?` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` |

##### Example (as JSON)

```json
{
  "destinationAmount": null,
  "destinationCurrency": null,
  "sourceAmount": null,
  "sourceCurrency": null,
  "rate": null
}
```

#### User Base

Object for the established group of users

##### Class Name

`UserBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `LastName` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `DateOfBirth` | `DateTime?` | Optional | User's date of birth |
| `BusinessName` | `string` | Optional | Legal name for the business |
| `BusinessOperatingName` | `string` | Optional | Name under which the business operates |
| `BusinessRegistrationId` | `string` | Optional | Registration number or ID assigned by a government body |
| `BusinessRegistrationRegion` | `string` | Optional | State, province, or territory where the business is registered |
| `BusinessRegistrationCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessContactRole` | [`Models.BusinessContactRoleEnum?`](#business-contact-role) | Optional | Role of the user within the business |
| `BusinessAddressLine1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `BusinessAddressLine2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `BusinessAddressLine3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `BusinessAddressLine4` | `string` | Optional | fourth line of the business address street address |
| `BusinessAddressLine5` | `string` | Optional | Fifth line of the business address street address |
| `BusinessCity` | `string` | Optional | City the business is registered |
| `BusinessRegion` | `string` | Optional | State, province, or region the business is registered |
| `BusinessCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessPostalCode` | `string` | Optional | Postal code for the business address |
| `BusinessPremiseNumber` | `string` | Optional | House number for the business address |
| `BusinessType` | [`Models.BusinessTypesEnum?`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `DriverLicenseId` | `string` | Optional | User's driver's license number |
| `PassportId` | `string` | Optional | User's passport number |
| `GovernmentIdType` | [`Models.GovernmentIdTypeEnum?`](#government-id-type) | Optional | User's government ID type |
| `GovernmentId` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `PhoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `MobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `PhoneNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `MobileNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `Email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `EmployerId` | `string` | Optional | User's employer identifier |
| `Gender` | [`Models.GenderTypesEnum?`](#gender-types) | Optional | Gender as a user identifies |
| `UserType` | [`Models.UserTypesEnum?`](#user-types) | Optional | Account holder's profile type |
| `ProgramUserId` | `string` | Optional | Program identifier for the user |
| `Language` | [`Models.LanguageTypesEnum?`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `CountryOfBirth` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `CountryOfNationality` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `Occupation` | [`Models.OccupationTypesEnum?`](#occupation-types) | Optional | Type of occupation for the user |
| `TaxResidentStatus` | [`Models.TaxResidentStatusTypesEnum?`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `Currency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null
}
```

#### User

Object for user

##### Class Name

`User`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `LastName` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `DateOfBirth` | `DateTime?` | Optional | User's date of birth |
| `BusinessName` | `string` | Optional | Legal name for the business |
| `BusinessOperatingName` | `string` | Optional | Name under which the business operates |
| `BusinessRegistrationId` | `string` | Optional | Registration number or ID assigned by a government body |
| `BusinessRegistrationRegion` | `string` | Optional | State, province, or territory where the business is registered |
| `BusinessRegistrationCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessContactRole` | [`Models.BusinessContactRoleEnum?`](#business-contact-role) | Optional | Role of the user within the business |
| `BusinessAddressLine1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `BusinessAddressLine2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `BusinessAddressLine3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `BusinessAddressLine4` | `string` | Optional | fourth line of the business address street address |
| `BusinessAddressLine5` | `string` | Optional | Fifth line of the business address street address |
| `BusinessCity` | `string` | Optional | City the business is registered |
| `BusinessRegion` | `string` | Optional | State, province, or region the business is registered |
| `BusinessCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessPostalCode` | `string` | Optional | Postal code for the business address |
| `BusinessPremiseNumber` | `string` | Optional | House number for the business address |
| `BusinessType` | [`Models.BusinessTypesEnum?`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `DriverLicenseId` | `string` | Optional | User's driver's license number |
| `PassportId` | `string` | Optional | User's passport number |
| `GovernmentIdType` | [`Models.GovernmentIdTypeEnum?`](#government-id-type) | Optional | User's government ID type |
| `GovernmentId` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `PhoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `MobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `PhoneNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `MobileNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `Email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `EmployerId` | `string` | Optional | User's employer identifier |
| `Gender` | [`Models.GenderTypesEnum?`](#gender-types) | Optional | Gender as a user identifies |
| `UserType` | [`Models.UserTypesEnum?`](#user-types) | Optional | Account holder's profile type |
| `ProgramUserId` | `string` | Optional | Program identifier for the user |
| `Language` | [`Models.LanguageTypesEnum?`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `CountryOfBirth` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `CountryOfNationality` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `Occupation` | [`Models.OccupationTypesEnum?`](#occupation-types) | Optional | Type of occupation for the user |
| `TaxResidentStatus` | [`Models.TaxResidentStatusTypesEnum?`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `Currency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.UserStatusTypesEnum?`](#user-status-types) | Optional | Current status of the user |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null
}
```

#### User-Response

Response from a user request

##### Class Name

`UserResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `LastName` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |
| `DateOfBirth` | `DateTime?` | Optional | User's date of birth |
| `BusinessName` | `string` | Optional | Legal name for the business |
| `BusinessOperatingName` | `string` | Optional | Name under which the business operates |
| `BusinessRegistrationId` | `string` | Optional | Registration number or ID assigned by a government body |
| `BusinessRegistrationRegion` | `string` | Optional | State, province, or territory where the business is registered |
| `BusinessRegistrationCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessContactRole` | [`Models.BusinessContactRoleEnum?`](#business-contact-role) | Optional | Role of the user within the business |
| `BusinessAddressLine1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `BusinessAddressLine2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `BusinessAddressLine3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `BusinessAddressLine4` | `string` | Optional | fourth line of the business address street address |
| `BusinessAddressLine5` | `string` | Optional | Fifth line of the business address street address |
| `BusinessCity` | `string` | Optional | City the business is registered |
| `BusinessRegion` | `string` | Optional | State, province, or region the business is registered |
| `BusinessCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessPostalCode` | `string` | Optional | Postal code for the business address |
| `BusinessPremiseNumber` | `string` | Optional | House number for the business address |
| `BusinessType` | [`Models.BusinessTypesEnum?`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |
| `DriverLicenseId` | `string` | Optional | User's driver's license number |
| `PassportId` | `string` | Optional | User's passport number |
| `GovernmentIdType` | [`Models.GovernmentIdTypeEnum?`](#government-id-type) | Optional | User's government ID type |
| `GovernmentId` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |
| `PhoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `MobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `PhoneNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `MobileNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `Email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |
| `EmployerId` | `string` | Optional | User's employer identifier |
| `Gender` | [`Models.GenderTypesEnum?`](#gender-types) | Optional | Gender as a user identifies |
| `UserType` | [`Models.UserTypesEnum?`](#user-types) | Optional | Account holder's profile type |
| `ProgramUserId` | `string` | Optional | Program identifier for the user |
| `Language` | [`Models.LanguageTypesEnum?`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `CountryOfBirth` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `CountryOfNationality` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `Occupation` | [`Models.OccupationTypesEnum?`](#occupation-types) | Optional | Type of occupation for the user |
| `TaxResidentStatus` | [`Models.TaxResidentStatusTypesEnum?`](#tax-resident-status-types) | Optional | Tax resident status type of a country |
| `Currency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.UserStatusTypesEnum?`](#user-status-types) | Optional | Current status of the user |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "dateOfBirth": null,
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null,
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null,
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC",
  "addressLine1": null,
  "addressLine2": null,
  "addressLine3": null,
  "addressLine4": null,
  "addressLine5": null,
  "city": null,
  "region": null,
  "country": null,
  "postalCode": null,
  "premiseNumber": null,
  "addressType": null,
  "email": null,
  "employerId": null,
  "gender": null,
  "userType": null,
  "programUserId": null,
  "language": null,
  "countryOfBirth": null,
  "countryOfNationality": null,
  "occupation": null,
  "taxResidentStatus": null,
  "currency": null,
  "token": null,
  "status": null,
  "createdOn": null,
  "links": null
}
```

#### Receipt Base

Base for the receipt

##### Class Name

`ReceiptBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FormattedAmount` | `string` | Optional | Formatted monetary amount |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.TransferStatusTypesEnum?`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Receipt Collection-Response

Response from a Receipt Collection request

##### Class Name

`ReceiptCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.ReceiptBase>`](#receipt-base) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Balance Collection-Response

Response from a Balance Collection request

##### Class Name

`BalanceCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.Balance>`](#balance) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Collection-Response

Response from a User Collection request

##### Class Name

`UserCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.UserResponse>`](#user-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Request

Payment request

##### Class Name

`PaymentRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `Purpose` | [`Models.PaymentPurposeTypesEnum?`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `ClientPaymentId` | `string` | Optional | Unique value provided by the client for the payment. |
| `AutoAcceptQuote` | `bool?` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `NotBefore` | `DateTime?` | Optional | Transfer is scheduled and will not process before this time. |
| `NotAfter` | `DateTime?` | Optional | Transfer expires if not completed prior to this time. |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payment

Response from a Transfer request

##### Class Name

`Payment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `Purpose` | [`Models.PaymentPurposeTypesEnum?`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `ClientPaymentId` | `string` | Optional | Unique value provided by the client for the payment. |
| `AutoAcceptQuote` | `bool?` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `Expires` | `DateTime?` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `NotBefore` | `DateTime?` | Optional | Transfer is scheduled and will not process before this time. |
| `NotAfter` | `DateTime?` | Optional | Transfer expires if not completed prior to this time. |
| `Status` | [`Models.TransferStatusTypesEnum?`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Payments Collection-Response

Response from a Payment collection request

##### Class Name

`PaymentsCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.PaymentResponse>`](#payment-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Payment-Response

Response from a Payment request

##### Class Name

`PaymentResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |
| `Notes` | `string` | Optional | Optional comments visible to the user. |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |
| `Purpose` | [`Models.PaymentPurposeTypesEnum?`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |
| `ClientPaymentId` | `string` | Optional | Unique value provided by the client for the payment. |
| `AutoAcceptQuote` | `bool?` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |
| `Expires` | `DateTime?` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `NotBefore` | `DateTime?` | Optional | Transfer is scheduled and will not process before this time. |
| `NotAfter` | `DateTime?` | Optional | Transfer expires if not completed prior to this time. |
| `Status` | [`Models.TransferStatusTypesEnum?`](#transfer-status-types) | Optional | Current status of a transfer |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Collection-Response

Response from a Transfer request

##### Class Name

`TransferCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.TransferResponse>`](#transfer-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### User Name

##### Class Name

`UserName`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | User's first name. <i>Required</i> if the user is registered as an individual. |
| `LastName` | `string` | Optional | User's last name. <i>Required</i> if the user is registered as an individual. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

#### Dob

##### Class Name

`Dob`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DateOfBirth` | `DateTime?` | Optional | User's date of birth |

##### Example (as JSON)

```json
{
  "dateOfBirth": null
}
```

#### Business Information

Physical address of the business and other information, such as <i>Operating Name</i>, <i>Registration ID</i>, etc.

##### Class Name

`BusinessInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessName` | `string` | Optional | Legal name for the business |
| `BusinessOperatingName` | `string` | Optional | Name under which the business operates |
| `BusinessRegistrationId` | `string` | Optional | Registration number or ID assigned by a government body |
| `BusinessRegistrationRegion` | `string` | Optional | State, province, or territory where the business is registered |
| `BusinessRegistrationCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessContactRole` | [`Models.BusinessContactRoleEnum?`](#business-contact-role) | Optional | Role of the user within the business |
| `BusinessAddressLine1` | `string` | Optional | First line of the business address that specifies street number, street name, and building name |
| `BusinessAddressLine2` | `string` | Optional | Second line of the business address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `BusinessAddressLine3` | `string` | Optional | Third line of the business address that specifies the international or business addresses that do not fit on businessAddressLine3 |
| `BusinessAddressLine4` | `string` | Optional | fourth line of the business address street address |
| `BusinessAddressLine5` | `string` | Optional | Fifth line of the business address street address |
| `BusinessCity` | `string` | Optional | City the business is registered |
| `BusinessRegion` | `string` | Optional | State, province, or region the business is registered |
| `BusinessCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `BusinessPostalCode` | `string` | Optional | Postal code for the business address |
| `BusinessPremiseNumber` | `string` | Optional | House number for the business address |
| `BusinessType` | [`Models.BusinessTypesEnum?`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |

##### Example (as JSON)

```json
{
  "businessName": null,
  "businessOperatingName": null,
  "businessRegistrationId": null,
  "businessRegistrationRegion": null,
  "businessRegistrationCountry": null,
  "businessContactRole": null,
  "businessAddressLine1": null,
  "businessAddressLine2": null,
  "businessAddressLine3": null,
  "businessAddressLine4": null,
  "businessAddressLine5": null,
  "businessCity": null,
  "businessRegion": null,
  "businessCountry": null,
  "businessPostalCode": null,
  "businessPremiseNumber": null,
  "businessType": null
}
```

#### User Kyc Information

##### Class Name

`UserKycInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DriverLicenseId` | `string` | Optional | User's driver's license number |
| `PassportId` | `string` | Optional | User's passport number |
| `GovernmentIdType` | [`Models.GovernmentIdTypeEnum?`](#government-id-type) | Optional | User's government ID type |
| `GovernmentId` | `string` | Optional | User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i> |

##### Example (as JSON)

```json
{
  "driverLicenseId": null,
  "passportId": null,
  "governmentIdType": null,
  "governmentId": null
}
```

#### Phone Numbers

##### Class Name

`PhoneNumbers`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PhoneNumber` | `string` | Required | The E.164 formatted primary phone number. This can be the same as the mobile number. |
| `MobileNumber` | `string` | Required | The E.164 formatted mobile phone number, required by most financial institutions for account creation, verification, or PSD2 (3DS). Mobile numbers must be unique to a user within a tenant and cannot be shared. |
| `PhoneNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `MobileNumberCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |

##### Example (as JSON)

```json
{
  "phoneNumber": "phoneNumber0",
  "mobileNumber": "mobileNumber8",
  "phoneNumberCountry": "UM",
  "mobileNumberCountry": "TC"
}
```

#### Email Address

Contact email address for the user account

##### Class Name

`EmailAddress`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Email` | `string` | Optional | Email address for the user account<br>**Constraints**: *Maximum Length*: `150` |

##### Example (as JSON)

```json
{
  "email": null
}
```

#### User Employer Id

User's employer identifier, generally used for tax purposes.

##### Class Name

`UserEmployerId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EmployerId` | `string` | Optional | User's employer identifier |

##### Example (as JSON)

```json
{
  "employerId": null
}
```

#### Gender

Gender as the user identifies

##### Class Name

`Gender`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gender` | [`Models.GenderTypesEnum?`](#gender-types) | Optional | Gender as a user identifies |

##### Example (as JSON)

```json
{
  "gender": null
}
```

#### Language

Preferred language for the user's account. <i>Defaults to English</i>

##### Class Name

`Language`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Language` | [`Models.LanguageTypesEnum?`](#language-types) | Optional | Language type in IETF's BCP 47 format |

##### Example (as JSON)

```json
{
  "language": null
}
```

#### User Type

User's profile type

##### Class Name

`UserType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserType` | [`Models.UserTypesEnum?`](#user-types) | Optional | Account holder's profile type |

##### Example (as JSON)

```json
{
  "userType": null
}
```

#### Program User Id

Program identifier for the user

##### Class Name

`ProgramUserId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProgramUserId` | `string` | Optional | Program identifier for the user |

##### Example (as JSON)

```json
{
  "programUserId": null
}
```

#### Source Destination Token

Unique identifier representing the source of the funds.

##### Class Name

`SourceDestinationToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |

##### Example (as JSON)

```json
{
  "sourceToken": null,
  "destinationToken": null
}
```

#### Token

Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.

##### Class Name

`Token`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Client Transfer Id

Unique value provided by the client for the transfer, utilized for reference and deduplication.

##### Class Name

`ClientTransferId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientTransferId` | `string` | Optional | Unique value provided by the client for the transfer. |

##### Example (as JSON)

```json
{
  "clientTransferId": null
}
```

#### Notes

Optional comments visible to the user

##### Class Name

`Notes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Notes` | `string` | Optional | Optional comments visible to the user. |

##### Example (as JSON)

```json
{
  "notes": null
}
```

#### Memo

Optional internal memo not visible to the user.

##### Class Name

`Memo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Memo` | `string` | Optional | Optional internal memo not visible to the user. |

##### Example (as JSON)

```json
{
  "memo": null
}
```

#### Created On

Time at which the object was created.

##### Class Name

`CreatedOn`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |

##### Example (as JSON)

```json
{
  "createdOn": null
}
```

#### Transfer Status

Current status of the transfer.

##### Class Name

`TransferStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Models.TransferStatusTypesEnum?`](#transfer-status-types) | Optional | Current status of a transfer |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### User Status

Current status of the user.

##### Class Name

`UserStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Models.UserStatusTypesEnum?`](#user-status-types) | Optional | Current status of the user |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Payment Purpose

Purpose for the payment being made.

##### Class Name

`PaymentPurpose`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Purpose` | [`Models.PaymentPurposeTypesEnum?`](#payment-purpose-types) | Optional | Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services) |

##### Example (as JSON)

```json
{
  "purpose": null
}
```

#### Source Token

Unique identifier representing the source of funds.

##### Class Name

`SourceToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceToken` | `string` | Optional | Unique identifier representing the source of funds. |

##### Example (as JSON)

```json
{
  "sourceToken": null
}
```

#### Destination Token

Unique identifier representing the destination of funds.

##### Class Name

`DestinationToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DestinationToken` | `string` | Optional | Unique identifier representing the destination of funds. |

##### Example (as JSON)

```json
{
  "destinationToken": null
}
```

#### Client Payment Id

Unique value provided by the client for the payment, utilized for reference and de-duplication.

##### Class Name

`ClientPaymentId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientPaymentId` | `string` | Optional | Unique value provided by the client for the payment. |

##### Example (as JSON)

```json
{
  "clientPaymentId": null
}
```

#### Auto Accept Quote

Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.

##### Class Name

`AutoAcceptQuote`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AutoAcceptQuote` | `bool?` | Optional | Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required. |

##### Example (as JSON)

```json
{
  "autoAcceptQuote": null
}
```

#### Rate

Exchange rate

##### Class Name

`Rate`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rate` | `double?` | Optional | Exchange rate<br>**Constraints**: `>= 0`, `<= 1` |

##### Example (as JSON)

```json
{
  "rate": null
}
```

#### Fx

The details of the country's foreign exchange currency.

##### Class Name

`Fx`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Fx` | [`Models.FxObject`](#fx-object) | Optional | Currency conversion object details |

##### Example (as JSON)

```json
{
  "fx": null
}
```

#### Paper Check Base

##### Class Name

`PaperCheckBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Models.TransferTypesEnum?`](#transfer-types) | Optional | Transfer type |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |
| `ShippingMethod` | [`Models.ShippingMethodTypesEnum?`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Transfer Type

Type of transfer method

##### Class Name

`TransferType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Models.TransferTypesEnum?`](#transfer-types) | Optional | Transfer type |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account Ownership

Account ownership type

##### Class Name

`BankAccountOwnership`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null
}
```

#### Shipping Method

Shipping method desired

##### Class Name

`ShippingMethod`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShippingMethod` | [`Models.ShippingMethodTypesEnum?`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "shippingMethod": null
}
```

#### Paper Check

Details of the paper check

##### Class Name

`PaperCheck`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Type` | [`Models.TransferTypesEnum?`](#transfer-types) | Optional | Transfer type |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |
| `ShippingMethod` | [`Models.ShippingMethodTypesEnum?`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check-Response

Response to a paper check request

##### Class Name

`PaperCheckResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Type` | [`Models.TransferTypesEnum?`](#transfer-types) | Optional | Transfer type |
| `Amount` | `double` | Required | Amount of the transfer in the specified currency. |
| `Currency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `AddressLine1` | `string` | Optional | First line of the address that specifies street number, street name, and building name |
| `AddressLine2` | `string` | Optional | Second line of the address that specifies the apartment, suite, or space number (or any other designation not literally part of the physical address) |
| `AddressLine3` | `string` | Optional | Third line of the address that specifies the international or business addresses that do not fit on addressLine2 |
| `AddressLine4` | `string` | Optional | Fourth line of the address, if any |
| `AddressLine5` | `string` | Optional | Fifth line of the address, if any |
| `City` | `string` | Optional | City or town of the business address |
| `Region` | `string` | Optional | State, province, or territory of the business address |
| `Country` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `PostalCode` | `string` | Optional | Series of letters, digits, or both, included in a postal address for the purpose of sorting mail |
| `PremiseNumber` | `string` | Optional | House or building number of the business address |
| `AddressType` | [`Models.AddressTypesEnum?`](#address-types) | Optional | Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>) |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |
| `ShippingMethod` | [`Models.ShippingMethodTypesEnum?`](#shipping-method-types) | Optional | Shipping method type for a pre-paid card or paper check |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "amount": 5,
  "currency": null
}
```

#### Paper Check Collection-Response

Response to a paper check collection request

##### Class Name

`PaperCheckCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.PaperCheck>`](#paper-check) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Bank Account Fields

Classifies account field objects

##### Class Name

`BankAccountFields`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |
| `Type` | [`Models.BankAccountTypesEnum?`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `Fields` | [`List<Models.KeyValuePairBankFieldTypesString>`](#key-value-pair-bank-field-types-string) | Optional | - |
| `BankCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `BankCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `Description` | `string` | Optional | User-supplied description of the bank account for reference |

##### Example (as JSON)

```json
{
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Type

Type of bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Models.BankAccountTypesEnum?`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |

##### Example (as JSON)

```json
{
  "type": null
}
```

#### Bank Account

Unique identifier for the bank account

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.BankAccountStatusTypesEnum?`](#bank-account-status-types) | Optional | Current verification status type of the bank account |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |
| `Type` | [`Models.BankAccountTypesEnum?`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `Fields` | [`List<Models.KeyValuePairBankFieldTypesString>`](#key-value-pair-bank-field-types-string) | Optional | - |
| `BankCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `BankCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `Description` | `string` | Optional | User-supplied description of the bank account for reference |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null
}
```

#### Bank Account Status

Verification status of the bank account (<i>Verified</i>, <i>Disabled</i>)

##### Class Name

`BankAccountStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Models.BankAccountStatusTypesEnum?`](#bank-account-status-types) | Optional | Current verification status type of the bank account |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Bank Account-Response

Response to the bank account request

##### Class Name

`BankAccountResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.BankAccountStatusTypesEnum?`](#bank-account-status-types) | Optional | Current verification status type of the bank account |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `BankAccountOwnershipType` | [`Models.BankAccountOwnershipTypesEnum?`](#bank-account-ownership-types) | Optional | Account ownership types |
| `Type` | [`Models.BankAccountTypesEnum?`](#bank-account-types) | Optional | Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>) |
| `Fields` | [`List<Models.KeyValuePairBankFieldTypesString>`](#key-value-pair-bank-field-types-string) | Optional | - |
| `BankCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `BankCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `Description` | `string` | Optional | User-supplied description of the bank account for reference |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "bankAccountOwnershipType": null,
  "type": null,
  "fields": null,
  "bankCurrency": null,
  "bankCountry": null,
  "description": null,
  "links": null
}
```

#### Bank Account Collection-Response

Collection response to the bank account request

##### Class Name

`BankAccountCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.BankAccountResponse>`](#bank-account-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Prepaid Card Package

Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i>, including artwork, packaging, and delivery method

##### Class Name

`PrepaidCardPackage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardPackage` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |

##### Example (as JSON)

```json
{
  "cardPackage": null
}
```

#### Prepaid Card Base

Base class applied to the prepaid card

##### Class Name

`PrepaidCardBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardPackage` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `ProgramToken` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2"
}
```

#### Prepaid Card Status

Current status of the prepaid card

##### Class Name

`PrepaidCardStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Models.StatusEnum?`](#status) | Optional | Current status of the prepaid card |

##### Example (as JSON)

```json
{
  "status": null
}
```

#### Token Type

##### Class Name

`TokenType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TokenType` | [`Models.TokenTypesEnum?`](#token-types) | Optional | Types of resources represented by a token |

##### Example (as JSON)

```json
{
  "tokenType": null
}
```

#### Prepaid Card Base Ext

Base extension for the prepaid card

##### Class Name

`PrepaidCardBaseExt`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.StatusEnum?`](#status) | Optional | Current status of the prepaid card |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null
}
```

#### Card Network

Major credit card network

##### Class Name

`CardNetwork`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardNetwork` | [`Models.CardNetworkTypesEnum?`](#card-network-types) | Optional | Major credit card network types |

##### Example (as JSON)

```json
{
  "cardNetwork": null
}
```

#### Card Personalization Type

Type of personalization for the prepaid card

##### Class Name

`CardPersonalizationType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardPersonalization` | [`Models.PrepaidCardPersonalizationTypesEnum?`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |

##### Example (as JSON)

```json
{
  "cardPersonalization": null
}
```

#### Prepaid Card

##### Class Name

`PrepaidCard`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.StatusEnum?`](#status) | Optional | Current status of the prepaid card |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Country` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `Currency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `CardPersonalization` | [`Models.PrepaidCardPersonalizationTypesEnum?`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |
| `CardPackage` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `CardNetwork` | [`Models.CardNetworkTypesEnum?`](#card-network-types) | Optional | Major credit card network types |
| `Expires` | `DateTime?` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `CardNumber` | `string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |
| `Cvv` | `string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null
}
```

#### Currency

Currency code used for the object

##### Class Name

`Currency`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Currency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "currency": null
}
```

#### Country

Two-digit country code for the object

##### Class Name

`Country`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Country` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |

##### Example (as JSON)

```json
{
  "country": "FO"
}
```

#### Prepaid Card-Request Response

##### Class Name

`PrepaidCardRequestResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.StatusEnum?`](#status) | Optional | Current status of the prepaid card |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "links": null
}
```

#### Prepaid Card-Response

##### Class Name

`PrepaidCardResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Status` | [`Models.StatusEnum?`](#status) | Optional | Current status of the prepaid card |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Country` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `Currency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `CardPersonalization` | [`Models.PrepaidCardPersonalizationTypesEnum?`](#prepaid-card-personalization-types) | Optional | Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer) |
| `CardPackage` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `CardNetwork` | [`Models.CardNetworkTypesEnum?`](#card-network-types) | Optional | Major credit card network types |
| `Expires` | `DateTime?` | Optional | Quote expiration, ISO-8601 format, UTC by default unless overridden. |
| `CardNumber` | `string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |
| `Cvv` | `string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "token": null,
  "status": null,
  "createdOn": null,
  "country": "FO",
  "currency": null,
  "cardPersonalization": null,
  "cardPackage": null,
  "cardNetwork": null,
  "expires": null,
  "cardNumber": null,
  "cvv": null,
  "links": null
}
```

#### Prepaid Card Collection-Response

##### Class Name

`PrepaidCardCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.PrepaidCardResponse>`](#prepaid-card-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Card Masked Pan

Card number using PAN truncation

##### Class Name

`CardMaskedPan`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardNumber` | `string` | Optional | Masked card number with only the first 6 and last 4 digits visible<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19`, *Pattern*: `^\d{4} \d{2}\*{2} \*{4} \d{4}$` |

##### Example (as JSON)

```json
{
  "cardNumber": null
}
```

#### Prepaid Card Replacement Reason

##### Class Name

`PrepaidCardReplacementReason`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardReplacementReason` | [`Models.PrepaidCardReplacementReasonTypesEnum?`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. |

##### Example (as JSON)

```json
{
  "cardReplacementReason": null
}
```

#### Prepaid Card Replacement Base

##### Class Name

`PrepaidCardReplacementBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardPackage` | `string` | Optional | Package for the card being displayed (<i>Virtual<,i>) or <i>Produced (physical)</i> |
| `ProgramToken` | `string` | Required | Token representing a program<br>**Constraints**: *Pattern*: `'^prog-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$'` |
| `CardReplacementReason` | [`Models.PrepaidCardReplacementReasonTypesEnum?`](#prepaid-card-replacement-reason-types) | Optional | Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility. |

##### Example (as JSON)

```json
{
  "cardPackage": null,
  "programToken": "programToken2",
  "cardReplacementReason": null
}
```

#### Prepaid Card Pin Token

##### Class Name

`PrepaidCardPinToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardPinToken` | `string` | Optional | Token used as part of a two-leg card PIN reveal request sent directly from the client that generally involves a second piece of data, such as the CVV code on the back of the card. |
| `Url` | `string` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params |

##### Example (as JSON)

```json
{
  "cardPinToken": null,
  "url": null
}
```

#### Prepaid Card Pin

##### Class Name

`PrepaidCardPin`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardPin` | `string` | Optional | Card PIN for ATM and Debit usage |

##### Example (as JSON)

```json
{
  "cardPin": null
}
```

#### Cvv

Three- or four-digit Card Verification Value (CVV) number displayed on the back of a credit or debit card

##### Class Name

`Cvv`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Cvv` | `string` | Optional | Card Verification Value (CVV) on the credit card or debit card. (3-digit number on VISA®, MasterCard® branded credit and debit cards) |

##### Example (as JSON)

```json
{
  "cvv": null
}
```

#### Identity Verification Provider Type

Provider type of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvProvider` | [`Models.IdentityVerificationProviderTypesEnum?`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |

##### Example (as JSON)

```json
{
  "idvProvider": null
}
```

#### Identity Verification Result Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvResult` | [`Models.IdentityVerificationResultTypesEnum?`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |

##### Example (as JSON)

```json
{
  "idvResult": null
}
```

#### Identity Verification Sub Result Type

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationSubResultType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvSubResult` | [`Models.IdentityVerificationResultSubTypesEnum?`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |

##### Example (as JSON)

```json
{
  "idvSubResult": null
}
```

#### Identity Verification Disposition Type

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvDispostion` | [`Models.IdentityVerificationDispositionTypesEnum?`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |

##### Example (as JSON)

```json
{
  "idvDispostion": null
}
```

#### Identity Verification Check Type

Type of verification used for performing an identity check

##### Class Name

`IdentityVerificationCheckType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvCheckType` | [`Models.IdentityVerificationCheckTypesEnum?`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |

##### Example (as JSON)

```json
{
  "idvCheckType": null
}
```

#### Identity Verification Base

##### Class Name

`IdentityVerificationBase`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvProviderReference` | `string` | Optional | IDV provider unique ID for the IDV check performed |
| `IdvResult` | [`Models.IdentityVerificationResultTypesEnum?`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `IdvSubResult` | [`Models.IdentityVerificationResultSubTypesEnum?`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |
| `IdvProvider` | [`Models.IdentityVerificationProviderTypesEnum?`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Raw` | `string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |
| `IdvCheckType` | [`Models.IdentityVerificationCheckTypesEnum?`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |
| `IdvDispostion` | [`Models.IdentityVerificationDispositionTypesEnum?`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null
}
```

#### Identity Verification Provider Reference

Provider reference used for performing identity checks for the provider

##### Class Name

`IdentityVerificationProviderReference`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvProviderReference` | `string` | Optional | IDV provider unique ID for the IDV check performed |

##### Example (as JSON)

```json
{
  "idvProviderReference": null
}
```

#### Identity Verification Provider Raw Output

Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only

##### Class Name

`IdentityVerificationProviderRawOutput`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Raw` | `string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |

##### Example (as JSON)

```json
{
  "raw": null
}
```

#### Identity Verification-Response

##### Class Name

`IdentityVerificationResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IdvProviderReference` | `string` | Optional | IDV provider unique ID for the IDV check performed |
| `IdvResult` | [`Models.IdentityVerificationResultTypesEnum?`](#identity-verification-result-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `IdvSubResult` | [`Models.IdentityVerificationResultSubTypesEnum?`](#identity-verification-result-sub-types) | Optional | If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity. |
| `IdvProvider` | [`Models.IdentityVerificationProviderTypesEnum?`](#identity-verification-provider-types) | Optional | Provider types of verification that can be used for performing identity checks |
| `CreatedOn` | `DateTime?` | Optional | Time at which the object was created. |
| `Raw` | `string` | Optional | Contains the raw (unprocessed) output from the IDV provider. Format of the raw output can vary widely and is not documented. *For reference/debugging only |
| `IdvCheckType` | [`Models.IdentityVerificationCheckTypesEnum?`](#identity-verification-check-types) | Optional | Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.) |
| `IdvDispostion` | [`Models.IdentityVerificationDispositionTypesEnum?`](#identity-verification-disposition-types) | Optional | In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined. |
| `Token` | `string` | Optional | Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>. |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "idvProviderReference": null,
  "idvResult": null,
  "idvSubResult": null,
  "idvProvider": null,
  "createdOn": null,
  "raw": null,
  "idvCheckType": null,
  "idvDispostion": null,
  "token": null,
  "links": null
}
```

#### Identity Verification Collection-Response

##### Class Name

`IdentityVerificationCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.IdentityVerificationResponse>`](#identity-verification-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Key Value Pair String String

##### Class Name

`KeyValuePairStringString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | - |
| `MValue` | `string` | Optional | - |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Pair Bank Field Types String

1...N required fields as determined by call to get requirements

##### Class Name

`KeyValuePairBankFieldTypesString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | [`Models.BankAccountFieldTypesEnum`](#bank-account-field-types) | Required | Classifies account field types |
| `MValue` | `string` | Required | - |

##### Example (as JSON)

```json
{
  "key": "BANK_NON_SWIFT_BIC",
  "value": "value2"
}
```

#### Key Value Pair Bank Currency Currency Types

##### Class Name

`KeyValuePairBankCurrencyCurrencyTypes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | **Default**: `"BANK_CURRENCY"`<br>*Default: `"BANK_CURRENCY"`* |
| `MValue` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Key Value Bank Country Country Types

##### Class Name

`KeyValueBankCountryCountryTypes`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | **Default**: `"BANK_COUNTRY"`<br>*Default: `"BANK_COUNTRY"`* |
| `MValue` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |

##### Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

#### Bank Account Required Fields

Classifies the required account field objects

##### Class Name

`BankAccountRequiredFields`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Format` | [`Models.BankAccountRequirementFormat`](#bank-account-requirement-format) | Optional | Classifies the format of the required information for a bank account |
| `Requirement` | [`Models.BankAccountFieldTypesEnum?`](#bank-account-field-types) | Optional | Classifies account field types |
| `Description` | [`List<Models.KeyValuePairLanguageTypeString>`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes |
| `Validators` | [`List<Models.BankAccountRequirementValidator>`](#bank-account-requirement-validator) | Optional | - |

##### Example (as JSON)

```json
{
  "format": null,
  "requirement": null,
  "description": null,
  "validators": null
}
```

#### Bank Account Requirement Format

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Example` | `string` | Optional | Example of a requirement generated from the validator(s) |
| `Legend` | [`List<Models.BankAccountRequirementFormatLegend>`](#bank-account-requirement-format-legend) | Optional | - |

##### Example (as JSON)

```json
{
  "example": null,
  "legend": null
}
```

#### Bank Account Requirement Format Legend

Classifies the legend format of the required information for a bank account

##### Class Name

`BankAccountRequirementFormatLegend`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | - |
| `Descriptions` | [`List<Models.KeyValuePairLanguageTypeString>`](#key-value-pair-language-type-string) | Optional | Localized requirement description for display purposes |

##### Example (as JSON)

```json
{
  "key": null,
  "descriptions": null
}
```

#### Key Value Pair Language Type String

Localized requirement description for display purposes

##### Class Name

`KeyValuePairLanguageTypeString`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Language` | [`Models.LanguageTypesEnum?`](#language-types) | Optional | Language type in IETF's BCP 47 format |
| `Translation` | `string` | Optional | Translated string in the specified language |

##### Example (as JSON)

```json
{
  "language": null,
  "translation": null
}
```

#### Bank Account Requirement Validator

Specifies the validator type for the required bank account information

##### Class Name

`BankAccountRequirementValidator`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ValidatorType` | [`Models.ValidatorTypesEnum?`](#validator-types) | Optional | - |
| `Expression` | `string` | Required | Validation regular expression |

##### Example (as JSON)

```json
{
  "validatorType": null,
  "expression": "expression2"
}
```

#### Bank Account Requirement

Classifies the format of the required information for a bank account

##### Class Name

`BankAccountRequirement`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BankCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `BankCurrency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `SourceCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Requirements` | [`List<Models.BankAccountRequiredFields>`](#bank-account-required-fields) | Optional | - |
| `Quote` | [`Models.MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null
}
```

#### Bank Account Requirement-Response

##### Class Name

`BankAccountRequirementResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BankCountry` | [`Models.CountryTypesEnum`](#country-types) | Required | Two-digit country code types |
| `BankCurrency` | [`Models.CurrencyTypesEnum`](#currency-types) | Required | Currency code type for the object |
| `SourceCountry` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `SourceCurrency` | [`Models.CurrencyTypesEnum?`](#currency-types) | Optional | Currency code type for the object |
| `Requirements` | [`List<Models.BankAccountRequiredFields>`](#bank-account-required-fields) | Optional | - |
| `Quote` | [`Models.MonetaryFormatted`](#monetary-formatted) | Optional | Object representing monies, including currency, decimal, and formatted amounts |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "bankCountry": "WS",
  "bankCurrency": "EUR",
  "sourceCountry": null,
  "sourceCurrency": null,
  "requirements": null,
  "quote": null,
  "links": null
}
```

#### Bank Account Requirement Collection-Response

##### Class Name

`BankAccountRequirementCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payload` | [`List<Models.BankAccountRequirementResponse>`](#bank-account-requirement-response) | Optional | - |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |

##### Example (as JSON)

```json
{
  "payload": null,
  "links": null
}
```

#### Occupation

##### Class Name

`Occupation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Occupation` | [`Models.OccupationTypesEnum?`](#occupation-types) | Optional | Type of occupation for the user |

##### Example (as JSON)

```json
{
  "occupation": null
}
```

#### Tax Resident Status

##### Class Name

`TaxResidentStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxResidentStatus` | [`Models.TaxResidentStatusTypesEnum?`](#tax-resident-status-types) | Optional | Tax resident status type of a country |

##### Example (as JSON)

```json
{
  "taxResidentStatus": null
}
```

#### Webhook-Subscription

Webhook subscription object

##### Class Name

`WebhookSubscription`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Url` | `string` | Optional | - |
| `Namespace` | [`Models.NamespaceEnum?`](#namespace) | Optional | Namespace used to identify and refer to the object |

##### Example (as JSON)

```json
{
  "url": null,
  "namespace": null
}
```

#### Webhook-Subscription-Response

Webhook Subscription response

##### Class Name

`WebhookSubscriptionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |
| `Url` | `string` | Optional | - |
| `Namespace` | [`Models.NamespaceEnum?`](#namespace) | Optional | Namespace used to identify and refer to the object |
| `Token` | `string` | Optional | Token for the webhook subscription |
| `Created` | `string` | Optional | Time stamp for the date the webhook subscription was created |
| `LastUpdated` | `string` | Optional | Time stamp for the date the webhook subscription was updated |

##### Example (as JSON)

```json
{
  "links": null,
  "url": null,
  "namespace": null,
  "token": null,
  "created": null,
  "lastUpdated": null
}
```

#### Webhook Collection-Response

Webhook Subscription collection response

##### Class Name

`WebhookCollectionResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Links` | [`List<Models.HaetosParams>`](#haetos-params) | Optional | - |
| `Payload` | [`List<Models.WebhookSubscriptionResponse>`](#webhook-subscription-response) | Optional | - |

##### Example (as JSON)

```json
{
  "links": null,
  "payload": null
}
```

#### Prepaid Card Data-Response

Response to the prepaid card data request

##### Class Name

`PrepaidCardDataResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardImage` | `string` | Optional | - |
| `CardNumber` | `double?` | Optional | - |
| `CvvNumber` | `string` | Optional | - |
| `Expiration` | `string` | Optional | - |
| `NameOnCard` | `string` | Optional | - |
| `Side` | `string` | Optional | - |
| `Token` | `string` | Optional | - |

##### Example (as JSON)

```json
{
  "cardImage": null,
  "cardNumber": null,
  "cvvNumber": null,
  "expiration": null,
  "nameOnCard": null,
  "side": null,
  "token": null
}
```

#### Prepaid Card Data Token

Token assigned to the prepaid card

##### Class Name

`PrepaidCardDataToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Required | **Constraints**: *Minimum Length*: `1` |
| `Url` | `string` | Optional | Full path of the URI to perform the request action against a prepaid card that replaces the need to build the URL with query params |

##### Example (as JSON)

```json
{
  "token": "token6",
  "url": null
}
```

#### Prepaid Card Data Token-Response

##### Class Name

`PrepaidCardDataTokenResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | [`Models.PrepaidCardDataToken`](#prepaid-card-data-token) | Optional | Token assigned to the prepaid card |

##### Example (as JSON)

```json
{
  "token": null
}
```

#### Business Type

##### Class Name

`BusinessType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessType` | [`Models.BusinessTypesEnum?`](#business-types) | Optional | Type of business (<i>Corporation</i> or <i>Partnership</i>) |

##### Example (as JSON)

```json
{
  "businessType": null
}
```

#### Country Nationality Information

##### Class Name

`CountryNationalityInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryOfBirth` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |
| `CountryOfNationality` | [`Models.CountryTypesEnum?`](#country-types) | Optional | Two-digit country code types |

##### Example (as JSON)

```json
{
  "countryOfBirth": null,
  "countryOfNationality": null
}
```

#### Users Prepaid Cards Pin Response

##### Class Name

`UsersPrepaidCardsPinResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | `bool?` | Optional | - |

##### Example (as JSON)

```json
{
  "result": null
}
```

### Enumerations

* [Transfer Status Types](#transfer-status-types)
* [Payment Purpose Types](#payment-purpose-types)
* [Address Types](#address-types)
* [User Types](#user-types)
* [User Status Types](#user-status-types)
* [Language Types](#language-types)
* [Gender Types](#gender-types)
* [Business Types](#business-types)
* [Transfer Types](#transfer-types)
* [Shipping Method Types](#shipping-method-types)
* [Bank Account Ownership Types](#bank-account-ownership-types)
* [Bank Account Types](#bank-account-types)
* [Bank Account Status Types](#bank-account-status-types)
* [Token Types](#token-types)
* [Card Network Types](#card-network-types)
* [Prepaid Card Personalization Types](#prepaid-card-personalization-types)
* [Currency Types](#currency-types)
* [Country Types](#country-types)
* [Prepaid Card Replacement Reason Types](#prepaid-card-replacement-reason-types)
* [Identity Verification Provider Types](#identity-verification-provider-types)
* [Identity Verification Result Types](#identity-verification-result-types)
* [Identity Verification Result Sub Types](#identity-verification-result-sub-types)
* [Identity Verification Disposition Types](#identity-verification-disposition-types)
* [Identity Verification Check Types](#identity-verification-check-types)
* [Bank Account Field Types](#bank-account-field-types)
* [Validator Types](#validator-types)
* [Occupation Types](#occupation-types)
* [Tax Resident Status Types](#tax-resident-status-types)
* [Namespace](#namespace)
* [Business Contact Role](#business-contact-role)
* [Format](#format)
* [Government Id Type](#government-id-type)
* [Side](#side)
* [Status](#status)

#### Transfer Status Types

Current status of a transfer

##### Class Name

`TransferStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `QUOTED` |
| `PENDING` |
| `SCHEDULED` |
| `COMPLETED` |
| `CANCELLED` |
| `RETURNED` |
| `FAILED` |
| `EXPIRED` |
| `VERIFICATIONHOLD` |

#### Payment Purpose Types

Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services)

##### Class Name

`PaymentPurposeTypesEnum`

##### Fields

| Name |
|  --- |
| `OTHER` |
| `TAXABLE` |
| `INCOME` |
| `BONUS` |
| `EXPENSE` |
| `NONTAXABLE` |

#### Address Types

Classifies the address type (<i>Home</i>, <i>Business</i>, <i>Billing</i>, <i>Shipping</i>)

##### Class Name

`AddressTypesEnum`

##### Fields

| Name |
|  --- |
| `RESIDENTIAL` |
| `BUSINESS` |
| `MAILING` |

#### User Types

Account holder's profile type

##### Class Name

`UserTypesEnum`

##### Fields

| Name |
|  --- |
| `INDIVIDUAL` |
| `BUSINESS` |

#### User Status Types

Current status of the user

##### Class Name

`UserStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `ACTIVATED` |
| `PREACTIVATED` |
| `PENDINGEMAILVERIFICATION` |
| `PENDINGKYC` |

#### Language Types

Language type in IETF's BCP 47 format

##### Class Name

`LanguageTypesEnum`

##### Fields

| Name |
|  --- |
| `EnUS` |
| `EnGB` |
| `FrCA` |
| `FrFR` |
| `EsMX` |
| `EsES` |
| `PtBR` |
| `PtPT` |
| `DeDE` |
| `ItIT` |
| `JaJP` |
| `ZhCN` |
| `ZhTW` |

#### Gender Types

Gender as a user identifies

##### Class Name

`GenderTypesEnum`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |
| `NOTSPECIFIED` |

#### Business Types

Type of business (<i>Corporation</i> or <i>Partnership</i>)

##### Class Name

`BusinessTypesEnum`

##### Fields

| Name |
|  --- |
| `CORPORATION` |
| `PARTNERSHIPDBA` |

#### Transfer Types

Transfer type

##### Class Name

`TransferTypesEnum`

##### Fields

| Name |
|  --- |
| `PAPERCHECK` |
| `BANKTRANSFER` |
| `PAYMENT` |
| `SPENDBACK` |

#### Shipping Method Types

Shipping method type for a pre-paid card or paper check

##### Class Name

`ShippingMethodTypesEnum`

##### Fields

| Name |
|  --- |
| `STANDARD` |
| `EXPEDITED` |

#### Bank Account Ownership Types

Account ownership types

##### Class Name

`BankAccountOwnershipTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

#### Bank Account Types

Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)

##### Class Name

`BankAccountTypesEnum`

##### Fields

| Name |
|  --- |
| `CHECKING` |
| `SAVINGS` |
| `MONEYMARKET` |

#### Bank Account Status Types

Current verification status type of the bank account

##### Class Name

`BankAccountStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `DELETED` |
| `ACTIVE` |
| `PENDINGVERIFICATION` |

#### Token Types

Types of resources represented by a token

##### Class Name

`TokenTypesEnum`

##### Fields

| Name |
|  --- |
| `BANKACCOUNT` |
| `TRANSFER` |
| `PAYMENT` |
| `SPENDBACK` |
| `PREPAIDCARD` |
| `USER` |
| `DOCUMENT` |
| `ACCOUNT` |

#### Card Network Types

Major credit card network types

##### Class Name

`CardNetworkTypesEnum`

##### Fields

| Name |
|  --- |
| `VISA` |
| `MASTERCARD` |

#### Prepaid Card Personalization Types

Specifies a card is <i>Personalized</i> or <i>Non-personalized</i> (i.e., issued to Preferred Customer)

##### Class Name

`PrepaidCardPersonalizationTypesEnum`

##### Fields

| Name |
|  --- |
| `PERSONALIZED` |
| `NONPERSONALIZED` |

#### Currency Types

Currency code type for the object

##### Class Name

`CurrencyTypesEnum`

##### Fields

| Name |
|  --- |
| `USD` |
| `CAD` |
| `MXN` |
| `AUD` |
| `HKD` |
| `NZD` |
| `EUR` |
| `GBP` |

#### Country Types

Two-digit country code types

##### Class Name

`CountryTypesEnum`

##### Fields

| Name |
|  --- |
| `AD` |
| `AE` |
| `AF` |
| `AG` |
| `AI` |
| `AL` |
| `AM` |
| `AN` |
| `AO` |
| `AQ` |
| `AR` |
| `AS` |
| `AT` |
| `AU` |
| `AW` |
| `AX` |
| `AZ` |
| `BA` |
| `BB` |
| `BD` |
| `BE` |
| `BF` |
| `BG` |
| `BH` |
| `BI` |
| `BJ` |
| `BL` |
| `BM` |
| `BN` |
| `BO` |
| `BQ` |
| `BR` |
| `BS` |
| `BT` |
| `BV` |
| `BW` |
| `BY` |
| `BZ` |
| `CA` |
| `CC` |
| `CD` |
| `CF` |
| `CG` |
| `CH` |
| `CI` |
| `CK` |
| `CL` |
| `CM` |
| `CN` |
| `CO` |
| `CR` |
| `CU` |
| `CV` |
| `CW` |
| `CX` |
| `CY` |
| `CZ` |
| `DE` |
| `DJ` |
| `DK` |
| `DM` |
| `DO` |
| `DZ` |
| `EC` |
| `EE` |
| `EG` |
| `EH` |
| `ER` |
| `ES` |
| `ET` |
| `FI` |
| `FJ` |
| `FK` |
| `FM` |
| `FO` |
| `FR` |
| `GA` |
| `GB` |
| `GD` |
| `GE` |
| `GF` |
| `GG` |
| `GH` |
| `GI` |
| `GL` |
| `GM` |
| `GN` |
| `GP` |
| `GQ` |
| `GR` |
| `GS` |
| `GT` |
| `GU` |
| `GW` |
| `GY` |
| `HK` |
| `HM` |
| `HN` |
| `HR` |
| `HT` |
| `HU` |
| `ID` |
| `IE` |
| `IL` |
| `IM` |
| `IN` |
| `IO` |
| `IQ` |
| `IR` |
| `IS` |
| `IT` |
| `JE` |
| `JM` |
| `JO` |
| `JP` |
| `KE` |
| `KG` |
| `KH` |
| `KI` |
| `KM` |
| `KN` |
| `KP` |
| `KR` |
| `KW` |
| `KY` |
| `KZ` |
| `LA` |
| `LB` |
| `LC` |
| `LI` |
| `LK` |
| `LR` |
| `LS` |
| `LT` |
| `LU` |
| `LV` |
| `LY` |
| `MA` |
| `MC` |
| `MD` |
| `ME` |
| `MF` |
| `MG` |
| `MH` |
| `MK` |
| `ML` |
| `MM` |
| `MN` |
| `MO` |
| `MP` |
| `MQ` |
| `MR` |
| `MS` |
| `MT` |
| `MU` |
| `MV` |
| `MW` |
| `MX` |
| `MY` |
| `MZ` |
| `NA` |
| `NC` |
| `NE` |
| `NF` |
| `NG` |
| `NI` |
| `NL` |
| `NO` |
| `NP` |
| `NR` |
| `NU` |
| `NZ` |
| `OM` |
| `PA` |
| `PE` |
| `PF` |
| `PG` |
| `PH` |
| `PK` |
| `PL` |
| `PM` |
| `PN` |
| `PR` |
| `PS` |
| `PT` |
| `PW` |
| `PY` |
| `QA` |
| `RE` |
| `RO` |
| `RS` |
| `RU` |
| `RW` |
| `SA` |
| `SB` |
| `SC` |
| `SD` |
| `SE` |
| `SG` |
| `SH` |
| `SI` |
| `SJ` |
| `SK` |
| `SL` |
| `SM` |
| `SN` |
| `SO` |
| `SR` |
| `SS` |
| `ST` |
| `SV` |
| `SX` |
| `SY` |
| `SZ` |
| `TC` |
| `TD` |
| `TF` |
| `TG` |
| `TH` |
| `TJ` |
| `TK` |
| `TL` |
| `TM` |
| `TN` |
| `TO` |
| `TR` |
| `TT` |
| `TV` |
| `TW` |
| `TZ` |
| `UA` |
| `UG` |
| `UM` |
| `US` |
| `UY` |
| `UZ` |
| `VA` |
| `VC` |
| `VE` |
| `VG` |
| `VI` |
| `VN` |
| `VU` |
| `WF` |
| `WS` |
| `YE` |
| `YT` |
| `ZA` |
| `ZM` |
| `ZW` |

#### Prepaid Card Replacement Reason Types

Reason for card replacement. In certain programs, the replacement reason code impacts replacement cost and responsibility.

##### Class Name

`PrepaidCardReplacementReasonTypesEnum`

##### Fields

| Name |
|  --- |
| `LOST` |
| `STOLEN` |
| `DAMAGED` |
| `COMPROMISED` |
| `EXPIRED` |

#### Identity Verification Provider Types

Provider types of verification that can be used for performing identity checks

##### Class Name

`IdentityVerificationProviderTypesEnum`

##### Fields

| Name |
|  --- |
| `W2` |
| `IDOLOGY` |
| `BANK` |
| `EQUIFAX` |
| `OFAC` |
| `LEXUSNEXUS` |

#### Identity Verification Result Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationResultTypesEnum`

##### Fields

| Name |
|  --- |
| `PASS` |
| `FAIL` |
| `SERVICEOFFLINE` |
| `PROCESSING` |

#### Identity Verification Result Sub Types

If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.

##### Class Name

`IdentityVerificationResultSubTypesEnum`

##### Fields

| Name |
|  --- |
| `HARD` |
| `SOFT` |

#### Identity Verification Disposition Types

In combination with the <i>Disposition</i> type, the <i>Result</i> type provides the results of an IDV check. A <i>Dispositioned</i> result of <i>FINAL PASS</i> represents a passing check, whereas a <i>TRANSIENT FAIL</i> is still being processed but has failed at least one phase of the check. Until the disposition is <i>FINAL</i>, a result has not been determined.

##### Class Name

`IdentityVerificationDispositionTypesEnum`

##### Fields

| Name |
|  --- |
| `TRANSIENT` |
| `FINAL` |

#### Identity Verification Check Types

Types of verification used for performing identity checks (<i>documentary</i>, <i>non-documentary</i>, <i>OFAC</i>, etc.)

##### Class Name

`IdentityVerificationCheckTypesEnum`

##### Fields

| Name |
|  --- |
| `DOCUMENTARY` |
| `NONDOCUMENTARY` |
| `OFAC` |

#### Bank Account Field Types

Classifies account field types

##### Class Name

`BankAccountFieldTypesEnum`

##### Fields

| Name |
|  --- |
| `BANKACHABA` |
| `BANKBBAN` |
| `BANKBRANCHCODE` |
| `BANKBSBCODE` |
| `BANKCITY` |
| `BANKCLABE` |
| `BANKCODE` |
| `BANKCURP` |
| `BANKIBAN` |
| `BANKNAME` |
| `BANKNONSWIFTBIC` |
| `BANKNUBAN` |
| `BANKPHONENUMBER` |
| `BANKPOSTALCODE` |
| `BANKREGION` |
| `BANKRFC` |
| `BANKSORTCODE` |
| `BANKSTREETADDRESS` |
| `BANKSWIFTBIC` |
| `BANKTRANSITCODE` |
| `BENEFICIARYACCOUNTNUMBER` |
| `BENEFICIARYPHONENUMBER` |
| `BENEFICIARYTAXID` |
| `BENEFICIARYNAME` |
| `BANKBRANCHNAME` |
| `BANKPURPOSEOFPAYMENTCODE` |
| `BANKVALUEADDTAX` |

#### Validator Types

##### Class Name

`ValidatorTypesEnum`

##### Fields

| Name |
|  --- |
| `REGEX` |
| `LENGTH` |

#### Occupation Types

Type of occupation for the user

##### Class Name

`OccupationTypesEnum`

##### Fields

| Name |
|  --- |
| `INDEPENDENTBUSINESSOWNER` |
| `SCIENCE` |
| `TECHNOLOGY` |
| `ENGINEERING` |
| `MATH` |
| `HEALTHCARE` |
| `SOCIALSERVICES` |
| `MEDIA` |
| `FINANCE` |
| `GOVERNMENT` |
| `MANUFACTURING` |
| `LAW` |
| `HOSPITALITYANDTOURISM` |
| `ARTS` |
| `DESIGN` |
| `OFFICEANDADMINSUPPORT` |
| `EDUCATION` |

#### Tax Resident Status Types

Tax resident status type of a country

##### Class Name

`TaxResidentStatusTypesEnum`

##### Fields

| Name |
|  --- |
| `YES` |
| `NO` |
| `PREFERNOTTOANSWER` |

#### Namespace

Namespace used to identify and refer to the object

##### Class Name

`NamespaceEnum`

##### Fields

| Name |
|  --- |
| `EnumBANKACCOUNTSUPDATEDSTATUSAPPROVED` |
| `EnumPREPAIDCARDSCREATED` |
| `EnumTRANSFERSACCEPTED` |

#### Business Contact Role

Role of the user within the business

##### Class Name

`BusinessContactRoleEnum`

##### Fields

| Name |
|  --- |
| `OWNER` |
| `MANAGER` |
| `PARTNER` |
| `OTHER` |

#### Format

##### Class Name

`FormatEnum`

##### Fields

| Name |
|  --- |
| `TEXT` |
| `IMAGE` |
| `EnumTEXTIMAGE` |

#### Government Id Type

User's government ID type

##### Class Name

`GovernmentIdTypeEnum`

##### Fields

| Name |
|  --- |
| `PASSPORT` |
| `NATIONALIDCARD` |
| `CURP` |

#### Side

##### Class Name

`SideEnum`

##### Fields

| Name |
|  --- |
| `FRONT` |
| `BACK` |

#### Status

Current status of the prepaid card

##### Class Name

`StatusEnum`

##### Fields

| Name |
|  --- |
| `QUEUED` |
| `LOSTSTOLENDAMAGED` |
| `ACTIVATED` |
| `PENDINGACTIVATION` |
| `SUSPENDED` |
| `COMPLIANCEHOLD` |
| `KYCHOLD` |
| `LOCKED` |

## Utility Classes Documentation

### ApiHelper Class

HttpRequest stores necessary information about the http request.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpMethod | The HTTP verb to use for this request. | `HttpMethod` |
| QueryUrl | The query url for the http request. | `string` |
| QueryParameters | Query parameters collection for the current http request. | `Dictionary<string, object>` |
| Headers | Headers collection for the current http request. | `Dictionary<string, string>` |
| FormParameters | Form parameters for the current http request. | `List<KeyValuePair<string, object>>` |
| Body | Optional raw string to send as request body. | `object` |
| Username | Optional username for Basic Auth. | `string` |
| Password | Optional password for Basic Auth. | `string` |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `DeepCloneObject<T>(T obj)` | Creates a deep clone of an object by serializing it into a json string and then deserializing back into an object. | `T` |
| `JsonSerialize(object obj, JsonConverter converter = null)` | JSON Serialization of a given object. | `string` |
| `JsonDeserialize<T>(string json, JsonConverter converter = null)` | JSON Deserialization of the given json string. | `T` |

### CustomDateTimeConverter Class

Extends from IsoDateTimeConverter to allow a custom DateTime format.

#### Constructors

| Name | Description |
|  --- | --- |
| `CustomDateTimeConverter(string format)` | Initializes a new instance of the <see cref="CustomDateTimeConverter"/> class. |

### ListDateTimeConverter Class

Extends from JsonConverter, allows the use of a custom converter.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| `Converter` | Gets or sets the JsonConverter. | `JsonConverter` |

#### Constructors

| Name | Description |
|  --- | --- |
| `ListDateTimeConverter()` | Initializes a new instance of the <see cref="ListDateTimeConverter"/> class. |
| `ListDateTimeConverter(Type converter)` | Initializes a new instance of the <see cref="ListDateTimeConverter"/> class. |
| `ListDateTimeConverter(Type converter, string format)` | Initializes a new instance of the <see cref="ListDateTimeConverter"/> class. |

### UnixDateTimeConverter Class

Extends from DateTimeConverterBase, uses unix DateTime format.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| DateTimeStyles | Gets or sets DateTimeStyles. | `DateTimeStyles` |

## Common Code Documentation

### HttpRequest Class

HttpResponse stores necessary information about the http response.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| StatusCode | Gets the HTTP Status code of the http response. | `int` |
| Headers | Gets the headers of the http response. | `Dictionary<string, string>` |
| RawBody | Gets the stream of the body. | `Stream` |

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpRequest(HttpMethod method, string queryUrl)` | Constructor to initialize the http request object. |
| `HttpRequest(HttpMethod method, string queryUrl, Dictionary<string, string> headers, string username, string password, Dictionary<string, object> queryParameters = null)` | Constructor to initialize the http request with headers and optional Basic auth params. |
| `HttpRequest(HttpMethod method, string queryUrl, Dictionary<string, string> headers, object body, string username, string password, Dictionary<string, object> queryParameters = null)` | Constructor to initialize the http request with headers, body and optional Basic auth params. |
| `HttpRequest(HttpMethod method, string queryUrl, Dictionary<string, string> headers, List<KeyValuePair<string, Object>> formParameters, string username, string password, Dictionary<string, object> queryParameters = null)` | Constructor to initialize the http request with headers, form parameters and optional Basic auth params. |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `AddHeaders(Dictionary<string, string> HeadersToAdd)` | Concatenate values from a Dictionary to this object. | `Dictionary<string, string>` |
| `AddQueryParameters(Dictionary<string, object> queryParamaters)` | Concatenate values from a Dictionary to query parameters dictionary. | `void` |

### HttpResponse Class

HttpResponse stores necessary information about the http response.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| StatusCode | Gets the HTTP Status code of the http response. | `int` |
| Headers | Gets the headers of the http response. | `Dictionary<string, string>` |
| RawBody | Gets the stream of the body. | `Stream` |

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpResponse(int statusCode, Dictionary<string, string> headers, Stream rawBody)` | Initializes a new instance of the <see cref="HttpResponse"/> class. |

### HttpStringResponse Class

HttpStringResponse inherits from HttpResponse and has additional property of string body.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| StatusCode | Gets the HTTP Status code of the http response. | `int` |
| Headers | Gets the headers of the http response. | `Dictionary<string, string>` |
| Body | Gets the raw string body of the http response. | `string` |

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpStringResponse(int statusCode, Dictionary<string, string> headers, Stream rawBody, string body) : base(statusCode, headers, rawBody)` | Initializes a new instance of the <see cref="HttpStringResponse"/> class. |

### HttpContext Class

Represents the contextual information of HTTP request and response.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| Request | Gets the http request in the current context. | `HttpRequest` |
| Response | Gets the http response in the current context. | `HttpResponse` |

#### Constructors

| Name | Description |
|  --- | --- |
| `HttpContext(HttpRequest request, HttpResponse response)` | Initializes a new instance of the <see cref="HttpContext"/> class. |

### HttpClientConfiguration Class

HttpClientConfiguration represents the current state of the Http Client.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| Timeout | Http client timeout. | `TimeSpan` |
| NumberOfRetries | Number of times the request is retried. | `int` |
| BackoffFactor | Exponential backoff factor for duration between retry calls. | `int` |
| RetryInterval | The time interval between the endpoint calls. | `double` |
| BackoffMax | The maximum back off time. | `TimeSpan` |
| StatusCodesToRetry | List of Http status codes to invoke retry. | `IList<int>` |
| RequestMethodsToRetry | List of Http request methods to invoke retry. | `IList<HttpMethod>` |

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `ToBuilder()` | Creates an object of the HttpClientConfiguration using the values provided for the builder. | `Builder` |

### HttpClientConfiguration Builder Class

Class to build instances of HttpClientConfiguration.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `NumberOfRetries(int numberOfRetries)` | Number of times the request is retried. | `Builder` |
| `BackoffFactor(int backoffFactor)` | Exponential backoff factor for duration between retry calls. | `Builder` |
| `RetryInterval(double retryInterval)` | The time interval between the endpoint calls. | `Builder` |
| `BackoffMax(TimeSpan backoffMax)` | The maximum back off time. | `Builder` |
| `StatusCodesToRetry(IList<int> statusCodesToRetry)` | List of Http status codes to invoke retry. | `Builder` |
| `RequestMethodsToRetry(IList<HttpMethod> requestMethodsToRetry)` | List of Http request methods to invoke retry. | `Builder` |
| `Build()` | Builds a new HttpClientConfiguration object using the set fields. | `HttpClientConfiguration` |

### IAuthManager Class

IAuthManager adds the authenticaion layer to the http calls.

#### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `Apply(HttpRequest httpRequest)` | Add authentication information to the HTTP Request. | `HttpRequest` |
| `ApplyAsync(HttpRequest httpRequest)` | Asynchronously add authentication information to the HTTP Request. | `Task<HttpRequest>` |

### ApiException Class

This is the base class for all exceptions that represent an error response from the server.

#### Properties

| Name | Description | Type |
|  --- | --- | --- |
| ResponseCode | Gets the HTTP response code from the API request. | `int` |
| HttpContext | Gets or sets the HttpContext for the request and response. | `HttpContext` |

#### Constructors

| Name | Description |
|  --- | --- |
| `ApiException(string reason, HttpContext context)` | Initializes a new instance of the <see cref="ApiException"/> class. |

