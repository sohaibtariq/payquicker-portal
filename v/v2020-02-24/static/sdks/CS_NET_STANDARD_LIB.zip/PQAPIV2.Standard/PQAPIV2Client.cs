// <copyright file="PQAPIV2Client.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text;
    using PQAPIV2.Standard.Authentication;
    using PQAPIV2.Standard.Controllers;
    using PQAPIV2.Standard.Http.Client;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class PQAPIV2Client : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Server, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Server, string>>
        {
            {
                Environment.Production, new Dictionary<Server, string>
                {
                    { Server.Default, "https://platform.mypayquicker.build/api/v2" },
                }
            },
        };

        private readonly IDictionary<string, IAuthManager> authManagers;
        private readonly IHttpClient httpClient;
        private readonly HttpCallBack httpCallBack;

        private readonly Lazy<PaymentsController> payments;
        private readonly Lazy<TransfersController> transfers;
        private readonly Lazy<SpendBackController> spendBack;
        private readonly Lazy<PrepaidCardsController> prepaidCards;
        private readonly Lazy<PaperChecksController> paperChecks;
        private readonly Lazy<BankAccountsController> bankAccounts;
        private readonly Lazy<BalancesController> balances;
        private readonly Lazy<ReceiptsController> receipts;
        private readonly Lazy<UsersController> users;
        private readonly Lazy<DocumentsController> documents;
        private readonly Lazy<WebhooksController> webhooks;
        private readonly Lazy<ProgramController> program;

        private PQAPIV2Client(
            Environment environment,
            IDictionary<string, IAuthManager> authManagers,
            IHttpClient httpClient,
            HttpCallBack httpCallBack,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.httpCallBack = httpCallBack;
            this.httpClient = httpClient;
            this.authManagers = (authManagers == null) ? new Dictionary<string, IAuthManager>() : new Dictionary<string, IAuthManager>(authManagers);
            this.HttpClientConfiguration = httpClientConfiguration;

            this.payments = new Lazy<PaymentsController>(
                () => new PaymentsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.transfers = new Lazy<TransfersController>(
                () => new TransfersController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.spendBack = new Lazy<SpendBackController>(
                () => new SpendBackController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.prepaidCards = new Lazy<PrepaidCardsController>(
                () => new PrepaidCardsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.paperChecks = new Lazy<PaperChecksController>(
                () => new PaperChecksController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.bankAccounts = new Lazy<BankAccountsController>(
                () => new BankAccountsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.balances = new Lazy<BalancesController>(
                () => new BalancesController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.receipts = new Lazy<ReceiptsController>(
                () => new ReceiptsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.users = new Lazy<UsersController>(
                () => new UsersController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.documents = new Lazy<DocumentsController>(
                () => new DocumentsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.webhooks = new Lazy<WebhooksController>(
                () => new WebhooksController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.program = new Lazy<ProgramController>(
                () => new ProgramController(this, this.httpClient, this.authManagers, this.httpCallBack));
        }

        /// <summary>
        /// Gets PaymentsController controller.
        /// </summary>
        public PaymentsController PaymentsController => this.payments.Value;

        /// <summary>
        /// Gets TransfersController controller.
        /// </summary>
        public TransfersController TransfersController => this.transfers.Value;

        /// <summary>
        /// Gets SpendBackController controller.
        /// </summary>
        public SpendBackController SpendBackController => this.spendBack.Value;

        /// <summary>
        /// Gets PrepaidCardsController controller.
        /// </summary>
        public PrepaidCardsController PrepaidCardsController => this.prepaidCards.Value;

        /// <summary>
        /// Gets PaperChecksController controller.
        /// </summary>
        public PaperChecksController PaperChecksController => this.paperChecks.Value;

        /// <summary>
        /// Gets BankAccountsController controller.
        /// </summary>
        public BankAccountsController BankAccountsController => this.bankAccounts.Value;

        /// <summary>
        /// Gets BalancesController controller.
        /// </summary>
        public BalancesController BalancesController => this.balances.Value;

        /// <summary>
        /// Gets ReceiptsController controller.
        /// </summary>
        public ReceiptsController ReceiptsController => this.receipts.Value;

        /// <summary>
        /// Gets UsersController controller.
        /// </summary>
        public UsersController UsersController => this.users.Value;

        /// <summary>
        /// Gets DocumentsController controller.
        /// </summary>
        public DocumentsController DocumentsController => this.documents.Value;

        /// <summary>
        /// Gets WebhooksController controller.
        /// </summary>
        public WebhooksController WebhooksController => this.webhooks.Value;

        /// <summary>
        /// Gets ProgramController controller.
        /// </summary>
        public ProgramController ProgramController => this.program.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets auth managers.
        /// </summary>
        internal IDictionary<string, IAuthManager> AuthManagers => this.authManagers;

        /// <summary>
        /// Gets http client.
        /// </summary>
        internal IHttpClient HttpClient => this.httpClient;

        /// <summary>
        /// Gets http callback.
        /// </summary>
        internal HttpCallBack HttpCallBack => this.httpCallBack;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            StringBuilder url = new StringBuilder(EnvironmentsMap[this.Environment][alias]);
            ApiHelper.AppendUrlWithTemplateParameters(url, this.GetBaseUriParameters());

            return url.ToString();
        }

        /// <summary>
        /// Creates an object of the PQAPIV2Client using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .HttpCallBack(this.httpCallBack)
                .HttpClient(this.httpClient)
                .AuthManagers(this.authManagers)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> PQAPIV2Client.</returns>
        internal static PQAPIV2Client CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("PQAPIV_2_STANDARD_ENVIRONMENT");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            return builder.Build();
        }

        /// <summary>
        /// Makes a list of the BaseURL parameters.
        /// </summary>
        /// <returns>Returns the parameters list.</returns>
        private List<KeyValuePair<string, object>> GetBaseUriParameters()
        {
            List<KeyValuePair<string, object>> kvpList = new List<KeyValuePair<string, object>>()
            {
            };
            return kvpList;
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = PQAPIV2.Standard.Environment.Production;
            private IDictionary<string, IAuthManager> authManagers = new Dictionary<string, IAuthManager>();
            private bool createCustomHttpClient = false;
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private IHttpClient httpClient;
            private HttpCallBack httpCallBack;

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                this.createCustomHttpClient = true;
                return this;
            }

            /// <summary>
            /// Sets the IHttpClient for the Builder.
            /// </summary>
            /// <param name="httpClient"> http client. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpClient(IHttpClient httpClient)
            {
                this.httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
                return this;
            }

            /// <summary>
            /// Sets the authentication managers for the Builder.
            /// </summary>
            /// <param name="authManagers"> auth managers. </param>
            /// <returns>Builder.</returns>
            internal Builder AuthManagers(IDictionary<string, IAuthManager> authManagers)
            {
                this.authManagers = authManagers ?? throw new ArgumentNullException(nameof(authManagers));
                return this;
            }

            /// <summary>
            /// Sets the HttpCallBack for the Builder.
            /// </summary>
            /// <param name="httpCallBack"> http callback. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpCallBack(HttpCallBack httpCallBack)
            {
                this.httpCallBack = httpCallBack;
                return this;
            }

            /// <summary>
            /// Creates an object of the PQAPIV2Client using the values provided for the builder.
            /// </summary>
            /// <returns>PQAPIV2Client.</returns>
            public PQAPIV2Client Build()
            {
                if (this.createCustomHttpClient)
                {
                    this.httpClient = new HttpClientWrapper(this.httpClientConfig.Build());
                }
                else
                {
                    this.httpClient = new HttpClientWrapper();
                }

                return new PQAPIV2Client(
                    this.environment,
                    this.authManagers,
                    this.httpClient,
                    this.httpCallBack,
                    this.httpClientConfig.Build());
            }
        }
    }
}
