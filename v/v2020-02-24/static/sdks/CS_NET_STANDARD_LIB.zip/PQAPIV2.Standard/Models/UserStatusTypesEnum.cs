// <copyright file="UserStatusTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// UserStatusTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum UserStatusTypesEnum
    {
        /// <summary>
        /// ACTIVATED.
        /// </summary>
        [EnumMember(Value = "ACTIVATED")]
        ACTIVATED,

        /// <summary>
        /// PREACTIVATED.
        /// </summary>
        [EnumMember(Value = "PRE_ACTIVATED")]
        PREACTIVATED,

        /// <summary>
        /// PENDINGEMAILVERIFICATION.
        /// </summary>
        [EnumMember(Value = "PENDING_EMAIL_VERIFICATION")]
        PENDINGEMAILVERIFICATION,

        /// <summary>
        /// PENDINGKYC.
        /// </summary>
        [EnumMember(Value = "PENDING_KYC")]
        PENDINGKYC,
    }
}