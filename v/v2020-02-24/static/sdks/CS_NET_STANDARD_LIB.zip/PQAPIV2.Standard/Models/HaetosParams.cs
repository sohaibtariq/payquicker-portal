// <copyright file="HaetosParams.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// HaetosParams.
    /// </summary>
    public class HaetosParams
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="HaetosParams"/> class.
        /// </summary>
        public HaetosParams()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="HaetosParams"/> class.
        /// </summary>
        /// <param name="mParams">params.</param>
        /// <param name="href">href.</param>
        public HaetosParams(
            Models.HaetosRelationship mParams,
            string href)
        {
            this.MParams = mParams;
            this.Href = href;
        }

        /// <summary>
        /// Indicates the HATEOS relationship between the target and current resources.
        /// </summary>
        [JsonProperty("params")]
        public Models.HaetosRelationship MParams { get; set; }

        /// <summary>
        /// URL for resource described by the relationship.
        /// </summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"HaetosParams : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is HaetosParams other &&
                ((this.MParams == null && other.MParams == null) || (this.MParams?.Equals(other.MParams) == true)) &&
                ((this.Href == null && other.Href == null) || (this.Href?.Equals(other.Href) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -54822713;

            if (this.MParams != null)
            {
               hashCode += this.MParams.GetHashCode();
            }

            if (this.Href != null)
            {
               hashCode += this.Href.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MParams = {(this.MParams == null ? "null" : this.MParams.ToString())}");
            toStringOutput.Add($"this.Href = {(this.Href == null ? "null" : this.Href == string.Empty ? "" : this.Href)}");
        }
    }
}