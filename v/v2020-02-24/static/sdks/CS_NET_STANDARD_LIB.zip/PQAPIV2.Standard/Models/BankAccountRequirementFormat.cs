// <copyright file="BankAccountRequirementFormat.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountRequirementFormat.
    /// </summary>
    public class BankAccountRequirementFormat
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirementFormat"/> class.
        /// </summary>
        public BankAccountRequirementFormat()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirementFormat"/> class.
        /// </summary>
        /// <param name="example">example.</param>
        /// <param name="legend">legend.</param>
        public BankAccountRequirementFormat(
            string example = null,
            List<Models.BankAccountRequirementFormatLegend> legend = null)
        {
            this.Example = example;
            this.Legend = legend;
        }

        /// <summary>
        /// Example of a requirement generated from the validator(s)
        /// </summary>
        [JsonProperty("example", NullValueHandling = NullValueHandling.Ignore)]
        public string Example { get; set; }

        /// <summary>
        /// Gets or sets Legend.
        /// </summary>
        [JsonProperty("legend", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.BankAccountRequirementFormatLegend> Legend { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccountRequirementFormat : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccountRequirementFormat other &&
                ((this.Example == null && other.Example == null) || (this.Example?.Equals(other.Example) == true)) &&
                ((this.Legend == null && other.Legend == null) || (this.Legend?.Equals(other.Legend) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1648446186;

            if (this.Example != null)
            {
               hashCode += this.Example.GetHashCode();
            }

            if (this.Legend != null)
            {
               hashCode += this.Legend.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Example = {(this.Example == null ? "null" : this.Example == string.Empty ? "" : this.Example)}");
            toStringOutput.Add($"this.Legend = {(this.Legend == null ? "null" : $"[{string.Join(", ", this.Legend)} ]")}");
        }
    }
}