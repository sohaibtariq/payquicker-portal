// <copyright file="IdentityVerificationSubResultType.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// IdentityVerificationSubResultType.
    /// </summary>
    public class IdentityVerificationSubResultType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityVerificationSubResultType"/> class.
        /// </summary>
        public IdentityVerificationSubResultType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityVerificationSubResultType"/> class.
        /// </summary>
        /// <param name="idvSubResult">idvSubResult.</param>
        public IdentityVerificationSubResultType(
            Models.IdentityVerificationResultSubTypesEnum? idvSubResult = null)
        {
            this.IdvSubResult = idvSubResult;
        }

        /// <summary>
        /// If used by a provider, sub-results that give additional insight into the results, including whether they result was <i>Soft</i> or <i>Hard</i>. <i>Soft</i> results may have additional recourse that can be leveraged to validate a user’s identity.
        /// </summary>
        [JsonProperty("idvSubResult", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.IdentityVerificationResultSubTypesEnum? IdvSubResult { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"IdentityVerificationSubResultType : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is IdentityVerificationSubResultType other &&
                ((this.IdvSubResult == null && other.IdvSubResult == null) || (this.IdvSubResult?.Equals(other.IdvSubResult) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1218640088;

            if (this.IdvSubResult != null)
            {
               hashCode += this.IdvSubResult.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IdvSubResult = {(this.IdvSubResult == null ? "null" : this.IdvSubResult.ToString())}");
        }
    }
}