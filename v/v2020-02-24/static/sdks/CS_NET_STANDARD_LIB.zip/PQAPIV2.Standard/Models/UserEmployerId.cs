// <copyright file="UserEmployerId.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// UserEmployerId.
    /// </summary>
    public class UserEmployerId
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserEmployerId"/> class.
        /// </summary>
        public UserEmployerId()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserEmployerId"/> class.
        /// </summary>
        /// <param name="employerId">employerId.</param>
        public UserEmployerId(
            string employerId = null)
        {
            this.EmployerId = employerId;
        }

        /// <summary>
        /// User's employer identifier
        /// </summary>
        [JsonProperty("employerId", NullValueHandling = NullValueHandling.Ignore)]
        public string EmployerId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UserEmployerId : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UserEmployerId other &&
                ((this.EmployerId == null && other.EmployerId == null) || (this.EmployerId?.Equals(other.EmployerId) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 945768083;

            if (this.EmployerId != null)
            {
               hashCode += this.EmployerId.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EmployerId = {(this.EmployerId == null ? "null" : this.EmployerId == string.Empty ? "" : this.EmployerId)}");
        }
    }
}