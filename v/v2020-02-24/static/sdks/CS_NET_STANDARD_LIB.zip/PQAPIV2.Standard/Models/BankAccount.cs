// <copyright file="BankAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccount.
    /// </summary>
    public class BankAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccount"/> class.
        /// </summary>
        public BankAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccount"/> class.
        /// </summary>
        /// <param name="token">token.</param>
        /// <param name="status">status.</param>
        /// <param name="createdOn">createdOn.</param>
        /// <param name="bankAccountOwnershipType">bankAccountOwnershipType.</param>
        /// <param name="type">type.</param>
        /// <param name="fields">fields.</param>
        /// <param name="bankCurrency">bankCurrency.</param>
        /// <param name="bankCountry">bankCountry.</param>
        /// <param name="description">description.</param>
        public BankAccount(
            string token = null,
            Models.BankAccountStatusTypesEnum? status = null,
            DateTime? createdOn = null,
            Models.BankAccountOwnershipTypesEnum? bankAccountOwnershipType = null,
            Models.BankAccountTypesEnum? type = null,
            List<Models.KeyValuePairBankFieldTypesString> fields = null,
            Models.CurrencyTypesEnum? bankCurrency = null,
            Models.CountryTypesEnum? bankCountry = null,
            string description = null)
        {
            this.Token = token;
            this.Status = status;
            this.CreatedOn = createdOn;
            this.BankAccountOwnershipType = bankAccountOwnershipType;
            this.Type = type;
            this.Fields = fields;
            this.BankCurrency = bankCurrency;
            this.BankCountry = bankCountry;
            this.Description = description;
        }

        /// <summary>
        /// Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// Current verification status type of the bank account
        /// </summary>
        [JsonProperty("status", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountStatusTypesEnum? Status { get; set; }

        /// <summary>
        /// Time at which the object was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("createdOn", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Account ownership types
        /// </summary>
        [JsonProperty("bankAccountOwnershipType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountOwnershipTypesEnum? BankAccountOwnershipType { get; set; }

        /// <summary>
        /// Financial purpose of the bank account (<i>Savings</i>, <i>Investment</i>)
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountTypesEnum? Type { get; set; }

        /// <summary>
        /// Gets or sets Fields.
        /// </summary>
        [JsonProperty("fields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.KeyValuePairBankFieldTypesString> Fields { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("bankCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? BankCurrency { get; set; }

        /// <summary>
        /// Two-digit country code types
        /// </summary>
        [JsonProperty("bankCountry", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CountryTypesEnum? BankCountry { get; set; }

        /// <summary>
        /// User-supplied description of the bank account for reference
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccount other &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.CreatedOn == null && other.CreatedOn == null) || (this.CreatedOn?.Equals(other.CreatedOn) == true)) &&
                ((this.BankAccountOwnershipType == null && other.BankAccountOwnershipType == null) || (this.BankAccountOwnershipType?.Equals(other.BankAccountOwnershipType) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Fields == null && other.Fields == null) || (this.Fields?.Equals(other.Fields) == true)) &&
                ((this.BankCurrency == null && other.BankCurrency == null) || (this.BankCurrency?.Equals(other.BankCurrency) == true)) &&
                ((this.BankCountry == null && other.BankCountry == null) || (this.BankCountry?.Equals(other.BankCountry) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 811499141;

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            if (this.Status != null)
            {
               hashCode += this.Status.GetHashCode();
            }

            if (this.CreatedOn != null)
            {
               hashCode += this.CreatedOn.GetHashCode();
            }

            if (this.BankAccountOwnershipType != null)
            {
               hashCode += this.BankAccountOwnershipType.GetHashCode();
            }

            if (this.Type != null)
            {
               hashCode += this.Type.GetHashCode();
            }

            if (this.Fields != null)
            {
               hashCode += this.Fields.GetHashCode();
            }

            if (this.BankCurrency != null)
            {
               hashCode += this.BankCurrency.GetHashCode();
            }

            if (this.BankCountry != null)
            {
               hashCode += this.BankCountry.GetHashCode();
            }

            if (this.Description != null)
            {
               hashCode += this.Description.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status.ToString())}");
            toStringOutput.Add($"this.CreatedOn = {(this.CreatedOn == null ? "null" : this.CreatedOn.ToString())}");
            toStringOutput.Add($"this.BankAccountOwnershipType = {(this.BankAccountOwnershipType == null ? "null" : this.BankAccountOwnershipType.ToString())}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type.ToString())}");
            toStringOutput.Add($"this.Fields = {(this.Fields == null ? "null" : $"[{string.Join(", ", this.Fields)} ]")}");
            toStringOutput.Add($"this.BankCurrency = {(this.BankCurrency == null ? "null" : this.BankCurrency.ToString())}");
            toStringOutput.Add($"this.BankCountry = {(this.BankCountry == null ? "null" : this.BankCountry.ToString())}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
        }
    }
}