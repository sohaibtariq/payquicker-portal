// <copyright file="TransferType.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// TransferType.
    /// </summary>
    public class TransferType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferType"/> class.
        /// </summary>
        public TransferType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TransferType"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        public TransferType(
            Models.TransferTypesEnum? type = null)
        {
            this.Type = type;
        }

        /// <summary>
        /// Transfer type
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TransferTypesEnum? Type { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TransferType : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is TransferType other &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -114356542;

            if (this.Type != null)
            {
               hashCode += this.Type.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type.ToString())}");
        }
    }
}