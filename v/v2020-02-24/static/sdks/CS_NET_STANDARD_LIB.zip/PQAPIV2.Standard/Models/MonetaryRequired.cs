// <copyright file="MonetaryRequired.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// MonetaryRequired.
    /// </summary>
    public class MonetaryRequired
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MonetaryRequired"/> class.
        /// </summary>
        public MonetaryRequired()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MonetaryRequired"/> class.
        /// </summary>
        /// <param name="amount">amount.</param>
        /// <param name="currency">currency.</param>
        public MonetaryRequired(
            double amount,
            Models.CurrencyTypesEnum currency)
        {
            this.Amount = amount;
            this.Currency = currency;
        }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("currency", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CurrencyTypesEnum Currency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MonetaryRequired : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MonetaryRequired other &&
                this.Amount.Equals(other.Amount) &&
                this.Currency.Equals(other.Currency);
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1631921436;
            hashCode += this.Amount.GetHashCode();
            hashCode += this.Currency.GetHashCode();

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Currency = {this.Currency}");
        }
    }
}