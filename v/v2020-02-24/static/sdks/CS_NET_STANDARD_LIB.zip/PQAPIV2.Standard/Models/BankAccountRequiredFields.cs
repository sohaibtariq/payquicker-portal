// <copyright file="BankAccountRequiredFields.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountRequiredFields.
    /// </summary>
    public class BankAccountRequiredFields
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequiredFields"/> class.
        /// </summary>
        public BankAccountRequiredFields()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequiredFields"/> class.
        /// </summary>
        /// <param name="format">format.</param>
        /// <param name="requirement">requirement.</param>
        /// <param name="description">description.</param>
        /// <param name="validators">validators.</param>
        public BankAccountRequiredFields(
            Models.BankAccountRequirementFormat format = null,
            Models.BankAccountFieldTypesEnum? requirement = null,
            List<Models.KeyValuePairLanguageTypeString> description = null,
            List<Models.BankAccountRequirementValidator> validators = null)
        {
            this.Format = format;
            this.Requirement = requirement;
            this.Description = description;
            this.Validators = validators;
        }

        /// <summary>
        /// Classifies the format of the required information for a bank account
        /// </summary>
        [JsonProperty("format", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountRequirementFormat Format { get; set; }

        /// <summary>
        /// Classifies account field types
        /// </summary>
        [JsonProperty("requirement", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccountFieldTypesEnum? Requirement { get; set; }

        /// <summary>
        /// Localized requirement description for display purposes
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.KeyValuePairLanguageTypeString> Description { get; set; }

        /// <summary>
        /// Gets or sets Validators.
        /// </summary>
        [JsonProperty("validators", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.BankAccountRequirementValidator> Validators { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccountRequiredFields : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccountRequiredFields other &&
                ((this.Format == null && other.Format == null) || (this.Format?.Equals(other.Format) == true)) &&
                ((this.Requirement == null && other.Requirement == null) || (this.Requirement?.Equals(other.Requirement) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Validators == null && other.Validators == null) || (this.Validators?.Equals(other.Validators) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 36109085;

            if (this.Format != null)
            {
               hashCode += this.Format.GetHashCode();
            }

            if (this.Requirement != null)
            {
               hashCode += this.Requirement.GetHashCode();
            }

            if (this.Description != null)
            {
               hashCode += this.Description.GetHashCode();
            }

            if (this.Validators != null)
            {
               hashCode += this.Validators.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Format = {(this.Format == null ? "null" : this.Format.ToString())}");
            toStringOutput.Add($"this.Requirement = {(this.Requirement == null ? "null" : this.Requirement.ToString())}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : $"[{string.Join(", ", this.Description)} ]")}");
            toStringOutput.Add($"this.Validators = {(this.Validators == null ? "null" : $"[{string.Join(", ", this.Validators)} ]")}");
        }
    }
}