// <copyright file="AddressTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// AddressTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressTypesEnum
    {
        /// <summary>
        /// RESIDENTIAL.
        /// </summary>
        [EnumMember(Value = "RESIDENTIAL")]
        RESIDENTIAL,

        /// <summary>
        /// BUSINESS.
        /// </summary>
        [EnumMember(Value = "BUSINESS")]
        BUSINESS,

        /// <summary>
        /// MAILING.
        /// </summary>
        [EnumMember(Value = "MAILING")]
        MAILING,
    }
}