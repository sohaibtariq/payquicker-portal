// <copyright file="BankAccountRequirementValidator.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// BankAccountRequirementValidator.
    /// </summary>
    public class BankAccountRequirementValidator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirementValidator"/> class.
        /// </summary>
        public BankAccountRequirementValidator()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankAccountRequirementValidator"/> class.
        /// </summary>
        /// <param name="expression">expression.</param>
        /// <param name="validatorType">validatorType.</param>
        public BankAccountRequirementValidator(
            string expression,
            Models.ValidatorTypesEnum? validatorType = null)
        {
            this.ValidatorType = validatorType;
            this.Expression = expression;
        }

        /// <summary>
        /// Gets or sets ValidatorType.
        /// </summary>
        [JsonProperty("validatorType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ValidatorTypesEnum? ValidatorType { get; set; }

        /// <summary>
        /// Validation regular expression
        /// </summary>
        [JsonProperty("expression")]
        public string Expression { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BankAccountRequirementValidator : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BankAccountRequirementValidator other &&
                ((this.ValidatorType == null && other.ValidatorType == null) || (this.ValidatorType?.Equals(other.ValidatorType) == true)) &&
                ((this.Expression == null && other.Expression == null) || (this.Expression?.Equals(other.Expression) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -66627589;

            if (this.ValidatorType != null)
            {
               hashCode += this.ValidatorType.GetHashCode();
            }

            if (this.Expression != null)
            {
               hashCode += this.Expression.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ValidatorType = {(this.ValidatorType == null ? "null" : this.ValidatorType.ToString())}");
            toStringOutput.Add($"this.Expression = {(this.Expression == null ? "null" : this.Expression == string.Empty ? "" : this.Expression)}");
        }
    }
}