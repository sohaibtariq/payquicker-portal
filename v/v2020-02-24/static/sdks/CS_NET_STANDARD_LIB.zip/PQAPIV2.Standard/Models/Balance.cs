// <copyright file="Balance.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// Balance.
    /// </summary>
    public class Balance
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Balance"/> class.
        /// </summary>
        public Balance()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Balance"/> class.
        /// </summary>
        /// <param name="amount">amount.</param>
        /// <param name="currency">currency.</param>
        /// <param name="formattedAmount">formattedAmount.</param>
        /// <param name="token">token.</param>
        public Balance(
            double amount,
            Models.CurrencyTypesEnum currency,
            string formattedAmount = null,
            string token = null)
        {
            this.FormattedAmount = formattedAmount;
            this.Amount = amount;
            this.Currency = currency;
            this.Token = token;
        }

        /// <summary>
        /// Formatted monetary amount
        /// </summary>
        [JsonProperty("formattedAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string FormattedAmount { get; set; }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("currency", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CurrencyTypesEnum Currency { get; set; }

        /// <summary>
        /// Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Balance : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Balance other &&
                ((this.FormattedAmount == null && other.FormattedAmount == null) || (this.FormattedAmount?.Equals(other.FormattedAmount) == true)) &&
                this.Amount.Equals(other.Amount) &&
                this.Currency.Equals(other.Currency) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 805232878;

            if (this.FormattedAmount != null)
            {
               hashCode += this.FormattedAmount.GetHashCode();
            }

            hashCode += this.Amount.GetHashCode();
            hashCode += this.Currency.GetHashCode();

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FormattedAmount = {(this.FormattedAmount == null ? "null" : this.FormattedAmount == string.Empty ? "" : this.FormattedAmount)}");
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Currency = {this.Currency}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
        }
    }
}