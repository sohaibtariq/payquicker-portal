// <copyright file="PaymentResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PaymentResponse.
    /// </summary>
    public class PaymentResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentResponse"/> class.
        /// </summary>
        public PaymentResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentResponse"/> class.
        /// </summary>
        /// <param name="amount">amount.</param>
        /// <param name="currency">currency.</param>
        /// <param name="sourceToken">sourceToken.</param>
        /// <param name="destinationToken">destinationToken.</param>
        /// <param name="notes">notes.</param>
        /// <param name="memo">memo.</param>
        /// <param name="purpose">purpose.</param>
        /// <param name="clientPaymentId">clientPaymentId.</param>
        /// <param name="autoAcceptQuote">autoAcceptQuote.</param>
        /// <param name="expires">expires.</param>
        /// <param name="notBefore">notBefore.</param>
        /// <param name="notAfter">notAfter.</param>
        /// <param name="status">status.</param>
        /// <param name="links">links.</param>
        public PaymentResponse(
            double amount,
            Models.CurrencyTypesEnum currency,
            string sourceToken = null,
            string destinationToken = null,
            string notes = null,
            string memo = null,
            Models.PaymentPurposeTypesEnum? purpose = null,
            string clientPaymentId = null,
            bool? autoAcceptQuote = null,
            DateTime? expires = null,
            DateTime? notBefore = null,
            DateTime? notAfter = null,
            Models.TransferStatusTypesEnum? status = null,
            List<Models.HaetosParams> links = null)
        {
            this.Amount = amount;
            this.Currency = currency;
            this.SourceToken = sourceToken;
            this.DestinationToken = destinationToken;
            this.Notes = notes;
            this.Memo = memo;
            this.Purpose = purpose;
            this.ClientPaymentId = clientPaymentId;
            this.AutoAcceptQuote = autoAcceptQuote;
            this.Expires = expires;
            this.NotBefore = notBefore;
            this.NotAfter = notAfter;
            this.Status = status;
            this.Links = links;
        }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("currency", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CurrencyTypesEnum Currency { get; set; }

        /// <summary>
        /// Unique identifier representing the source of funds.
        /// </summary>
        [JsonProperty("sourceToken", NullValueHandling = NullValueHandling.Ignore)]
        public string SourceToken { get; set; }

        /// <summary>
        /// Unique identifier representing the destination of funds.
        /// </summary>
        [JsonProperty("destinationToken", NullValueHandling = NullValueHandling.Ignore)]
        public string DestinationToken { get; set; }

        /// <summary>
        /// Optional comments visible to the user.
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Optional internal memo not visible to the user.
        /// </summary>
        [JsonProperty("memo", NullValueHandling = NullValueHandling.Ignore)]
        public string Memo { get; set; }

        /// <summary>
        /// Used to identify the purpose of a payment and impacts reporting and calculated taxable earnings (if utilizing tax services)
        /// </summary>
        [JsonProperty("purpose", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaymentPurposeTypesEnum? Purpose { get; set; }

        /// <summary>
        /// Unique value provided by the client for the payment.
        /// </summary>
        [JsonProperty("clientPaymentId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientPaymentId { get; set; }

        /// <summary>
        /// Determines whether the quote is automatically accepted or if a POST utilizing the token for the quote is required.
        /// </summary>
        [JsonProperty("autoAcceptQuote", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AutoAcceptQuote { get; set; }

        /// <summary>
        /// Quote expiration, ISO-8601 format, UTC by default unless overridden.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("expires", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? Expires { get; set; }

        /// <summary>
        /// Transfer is scheduled and will not process before this time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("notBefore", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? NotBefore { get; set; }

        /// <summary>
        /// Transfer expires if not completed prior to this time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("notAfter", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? NotAfter { get; set; }

        /// <summary>
        /// Current status of a transfer
        /// </summary>
        [JsonProperty("status", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TransferStatusTypesEnum? Status { get; set; }

        /// <summary>
        /// Gets or sets Links.
        /// </summary>
        [JsonProperty("links", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.HaetosParams> Links { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PaymentResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PaymentResponse other &&
                this.Amount.Equals(other.Amount) &&
                this.Currency.Equals(other.Currency) &&
                ((this.SourceToken == null && other.SourceToken == null) || (this.SourceToken?.Equals(other.SourceToken) == true)) &&
                ((this.DestinationToken == null && other.DestinationToken == null) || (this.DestinationToken?.Equals(other.DestinationToken) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.Memo == null && other.Memo == null) || (this.Memo?.Equals(other.Memo) == true)) &&
                ((this.Purpose == null && other.Purpose == null) || (this.Purpose?.Equals(other.Purpose) == true)) &&
                ((this.ClientPaymentId == null && other.ClientPaymentId == null) || (this.ClientPaymentId?.Equals(other.ClientPaymentId) == true)) &&
                ((this.AutoAcceptQuote == null && other.AutoAcceptQuote == null) || (this.AutoAcceptQuote?.Equals(other.AutoAcceptQuote) == true)) &&
                ((this.Expires == null && other.Expires == null) || (this.Expires?.Equals(other.Expires) == true)) &&
                ((this.NotBefore == null && other.NotBefore == null) || (this.NotBefore?.Equals(other.NotBefore) == true)) &&
                ((this.NotAfter == null && other.NotAfter == null) || (this.NotAfter?.Equals(other.NotAfter) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Links == null && other.Links == null) || (this.Links?.Equals(other.Links) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -2083647295;
            hashCode += this.Amount.GetHashCode();
            hashCode += this.Currency.GetHashCode();

            if (this.SourceToken != null)
            {
               hashCode += this.SourceToken.GetHashCode();
            }

            if (this.DestinationToken != null)
            {
               hashCode += this.DestinationToken.GetHashCode();
            }

            if (this.Notes != null)
            {
               hashCode += this.Notes.GetHashCode();
            }

            if (this.Memo != null)
            {
               hashCode += this.Memo.GetHashCode();
            }

            if (this.Purpose != null)
            {
               hashCode += this.Purpose.GetHashCode();
            }

            if (this.ClientPaymentId != null)
            {
               hashCode += this.ClientPaymentId.GetHashCode();
            }

            if (this.AutoAcceptQuote != null)
            {
               hashCode += this.AutoAcceptQuote.GetHashCode();
            }

            if (this.Expires != null)
            {
               hashCode += this.Expires.GetHashCode();
            }

            if (this.NotBefore != null)
            {
               hashCode += this.NotBefore.GetHashCode();
            }

            if (this.NotAfter != null)
            {
               hashCode += this.NotAfter.GetHashCode();
            }

            if (this.Status != null)
            {
               hashCode += this.Status.GetHashCode();
            }

            if (this.Links != null)
            {
               hashCode += this.Links.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Currency = {this.Currency}");
            toStringOutput.Add($"this.SourceToken = {(this.SourceToken == null ? "null" : this.SourceToken == string.Empty ? "" : this.SourceToken)}");
            toStringOutput.Add($"this.DestinationToken = {(this.DestinationToken == null ? "null" : this.DestinationToken == string.Empty ? "" : this.DestinationToken)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.Memo = {(this.Memo == null ? "null" : this.Memo == string.Empty ? "" : this.Memo)}");
            toStringOutput.Add($"this.Purpose = {(this.Purpose == null ? "null" : this.Purpose.ToString())}");
            toStringOutput.Add($"this.ClientPaymentId = {(this.ClientPaymentId == null ? "null" : this.ClientPaymentId == string.Empty ? "" : this.ClientPaymentId)}");
            toStringOutput.Add($"this.AutoAcceptQuote = {(this.AutoAcceptQuote == null ? "null" : this.AutoAcceptQuote.ToString())}");
            toStringOutput.Add($"this.Expires = {(this.Expires == null ? "null" : this.Expires.ToString())}");
            toStringOutput.Add($"this.NotBefore = {(this.NotBefore == null ? "null" : this.NotBefore.ToString())}");
            toStringOutput.Add($"this.NotAfter = {(this.NotAfter == null ? "null" : this.NotAfter.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status.ToString())}");
            toStringOutput.Add($"this.Links = {(this.Links == null ? "null" : $"[{string.Join(", ", this.Links)} ]")}");
        }
    }
}