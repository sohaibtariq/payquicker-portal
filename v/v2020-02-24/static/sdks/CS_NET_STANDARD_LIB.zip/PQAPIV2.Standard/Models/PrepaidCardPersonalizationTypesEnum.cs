// <copyright file="PrepaidCardPersonalizationTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// PrepaidCardPersonalizationTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PrepaidCardPersonalizationTypesEnum
    {
        /// <summary>
        /// PERSONALIZED.
        /// </summary>
        [EnumMember(Value = "PERSONALIZED")]
        PERSONALIZED,

        /// <summary>
        /// NONPERSONALIZED.
        /// </summary>
        [EnumMember(Value = "NON_PERSONALIZED")]
        NONPERSONALIZED,
    }
}