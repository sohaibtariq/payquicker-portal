// <copyright file="SourceMonetaryRequired.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// SourceMonetaryRequired.
    /// </summary>
    public class SourceMonetaryRequired
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SourceMonetaryRequired"/> class.
        /// </summary>
        public SourceMonetaryRequired()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SourceMonetaryRequired"/> class.
        /// </summary>
        /// <param name="sourceAmount">sourceAmount.</param>
        /// <param name="sourceCurrency">sourceCurrency.</param>
        public SourceMonetaryRequired(
            double? sourceAmount = null,
            Models.CurrencyTypesEnum? sourceCurrency = null)
        {
            this.SourceAmount = sourceAmount;
            this.SourceCurrency = sourceCurrency;
        }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("sourceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? SourceAmount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("sourceCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? SourceCurrency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SourceMonetaryRequired : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SourceMonetaryRequired other &&
                ((this.SourceAmount == null && other.SourceAmount == null) || (this.SourceAmount?.Equals(other.SourceAmount) == true)) &&
                ((this.SourceCurrency == null && other.SourceCurrency == null) || (this.SourceCurrency?.Equals(other.SourceCurrency) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1636294089;

            if (this.SourceAmount != null)
            {
               hashCode += this.SourceAmount.GetHashCode();
            }

            if (this.SourceCurrency != null)
            {
               hashCode += this.SourceCurrency.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SourceAmount = {(this.SourceAmount == null ? "null" : this.SourceAmount.ToString())}");
            toStringOutput.Add($"this.SourceCurrency = {(this.SourceCurrency == null ? "null" : this.SourceCurrency.ToString())}");
        }
    }
}