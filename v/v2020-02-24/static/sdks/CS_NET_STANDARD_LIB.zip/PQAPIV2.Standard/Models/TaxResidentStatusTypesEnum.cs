// <copyright file="TaxResidentStatusTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// TaxResidentStatusTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TaxResidentStatusTypesEnum
    {
        /// <summary>
        /// YES.
        /// </summary>
        [EnumMember(Value = "YES")]
        YES,

        /// <summary>
        /// NO.
        /// </summary>
        [EnumMember(Value = "NO")]
        NO,

        /// <summary>
        /// PREFERNOTTOANSWER.
        /// </summary>
        [EnumMember(Value = "PREFER_NOT_TO_ANSWER")]
        PREFERNOTTOANSWER,
    }
}