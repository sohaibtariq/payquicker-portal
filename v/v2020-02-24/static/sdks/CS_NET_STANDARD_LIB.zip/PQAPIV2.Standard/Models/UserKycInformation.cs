// <copyright file="UserKycInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// UserKycInformation.
    /// </summary>
    public class UserKycInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserKycInformation"/> class.
        /// </summary>
        public UserKycInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserKycInformation"/> class.
        /// </summary>
        /// <param name="driverLicenseId">driverLicenseId.</param>
        /// <param name="passportId">passportId.</param>
        /// <param name="governmentIdType">governmentIdType.</param>
        /// <param name="governmentId">governmentId.</param>
        public UserKycInformation(
            string driverLicenseId = null,
            string passportId = null,
            Models.GovernmentIdTypeEnum? governmentIdType = null,
            string governmentId = null)
        {
            this.DriverLicenseId = driverLicenseId;
            this.PassportId = passportId;
            this.GovernmentIdType = governmentIdType;
            this.GovernmentId = governmentId;
        }

        /// <summary>
        /// User's driver's license number
        /// </summary>
        [JsonProperty("driverLicenseId", NullValueHandling = NullValueHandling.Ignore)]
        public string DriverLicenseId { get; set; }

        /// <summary>
        /// User's passport number
        /// </summary>
        [JsonProperty("passportId", NullValueHandling = NullValueHandling.Ignore)]
        public string PassportId { get; set; }

        /// <summary>
        /// User's government ID type
        /// </summary>
        [JsonProperty("governmentIdType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.GovernmentIdTypeEnum? GovernmentIdType { get; set; }

        /// <summary>
        /// User's government ID number, such as a <i>SSN</i>, <i>EIN</i>, or <i>SIN</i>
        /// </summary>
        [JsonProperty("governmentId", NullValueHandling = NullValueHandling.Ignore)]
        public string GovernmentId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UserKycInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UserKycInformation other &&
                ((this.DriverLicenseId == null && other.DriverLicenseId == null) || (this.DriverLicenseId?.Equals(other.DriverLicenseId) == true)) &&
                ((this.PassportId == null && other.PassportId == null) || (this.PassportId?.Equals(other.PassportId) == true)) &&
                ((this.GovernmentIdType == null && other.GovernmentIdType == null) || (this.GovernmentIdType?.Equals(other.GovernmentIdType) == true)) &&
                ((this.GovernmentId == null && other.GovernmentId == null) || (this.GovernmentId?.Equals(other.GovernmentId) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1002773387;

            if (this.DriverLicenseId != null)
            {
               hashCode += this.DriverLicenseId.GetHashCode();
            }

            if (this.PassportId != null)
            {
               hashCode += this.PassportId.GetHashCode();
            }

            if (this.GovernmentIdType != null)
            {
               hashCode += this.GovernmentIdType.GetHashCode();
            }

            if (this.GovernmentId != null)
            {
               hashCode += this.GovernmentId.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DriverLicenseId = {(this.DriverLicenseId == null ? "null" : this.DriverLicenseId == string.Empty ? "" : this.DriverLicenseId)}");
            toStringOutput.Add($"this.PassportId = {(this.PassportId == null ? "null" : this.PassportId == string.Empty ? "" : this.PassportId)}");
            toStringOutput.Add($"this.GovernmentIdType = {(this.GovernmentIdType == null ? "null" : this.GovernmentIdType.ToString())}");
            toStringOutput.Add($"this.GovernmentId = {(this.GovernmentId == null ? "null" : this.GovernmentId == string.Empty ? "" : this.GovernmentId)}");
        }
    }
}