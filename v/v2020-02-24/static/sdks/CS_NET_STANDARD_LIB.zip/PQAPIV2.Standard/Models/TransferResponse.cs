// <copyright file="TransferResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// TransferResponse.
    /// </summary>
    public class TransferResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferResponse"/> class.
        /// </summary>
        public TransferResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TransferResponse"/> class.
        /// </summary>
        /// <param name="sourceToken">sourceToken.</param>
        /// <param name="destinationToken">destinationToken.</param>
        /// <param name="notes">notes.</param>
        /// <param name="memo">memo.</param>
        /// <param name="destinationAmount">destinationAmount.</param>
        /// <param name="destinationCurrency">destinationCurrency.</param>
        /// <param name="clientTransferId">clientTransferId.</param>
        /// <param name="token">token.</param>
        /// <param name="sourceAmount">sourceAmount.</param>
        /// <param name="sourceCurrency">sourceCurrency.</param>
        /// <param name="status">status.</param>
        /// <param name="fx">fx.</param>
        /// <param name="links">links.</param>
        public TransferResponse(
            string sourceToken = null,
            string destinationToken = null,
            string notes = null,
            string memo = null,
            double? destinationAmount = null,
            Models.CurrencyTypesEnum? destinationCurrency = null,
            string clientTransferId = null,
            string token = null,
            double? sourceAmount = null,
            Models.CurrencyTypesEnum? sourceCurrency = null,
            Models.TransferStatusTypesEnum? status = null,
            Models.FxObject fx = null,
            List<Models.HaetosParams> links = null)
        {
            this.SourceToken = sourceToken;
            this.DestinationToken = destinationToken;
            this.Notes = notes;
            this.Memo = memo;
            this.DestinationAmount = destinationAmount;
            this.DestinationCurrency = destinationCurrency;
            this.ClientTransferId = clientTransferId;
            this.Token = token;
            this.SourceAmount = sourceAmount;
            this.SourceCurrency = sourceCurrency;
            this.Status = status;
            this.Fx = fx;
            this.Links = links;
        }

        /// <summary>
        /// Unique identifier representing the source of funds.
        /// </summary>
        [JsonProperty("sourceToken", NullValueHandling = NullValueHandling.Ignore)]
        public string SourceToken { get; set; }

        /// <summary>
        /// Unique identifier representing the destination of funds.
        /// </summary>
        [JsonProperty("destinationToken", NullValueHandling = NullValueHandling.Ignore)]
        public string DestinationToken { get; set; }

        /// <summary>
        /// Optional comments visible to the user.
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Optional internal memo not visible to the user.
        /// </summary>
        [JsonProperty("memo", NullValueHandling = NullValueHandling.Ignore)]
        public string Memo { get; set; }

        /// <summary>
        /// Amount transferred to the destination
        /// </summary>
        [JsonProperty("destinationAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DestinationAmount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("destinationCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? DestinationCurrency { get; set; }

        /// <summary>
        /// Unique value provided by the client for the transfer.
        /// </summary>
        [JsonProperty("clientTransferId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientTransferId { get; set; }

        /// <summary>
        /// Token representing the resource, prefixed with <i>user-</i>, <i>dest-</i>, <i>xfer-</i>, <i>acct-</i>, <i>pmnt-</i>, or <i>docu-</i>.
        /// </summary>
        [JsonProperty("token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// Amount of the transfer in the specified currency.
        /// </summary>
        [JsonProperty("sourceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? SourceAmount { get; set; }

        /// <summary>
        /// Currency code type for the object
        /// </summary>
        [JsonProperty("sourceCurrency", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CurrencyTypesEnum? SourceCurrency { get; set; }

        /// <summary>
        /// Current status of a transfer
        /// </summary>
        [JsonProperty("status", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TransferStatusTypesEnum? Status { get; set; }

        /// <summary>
        /// Currency conversion object details
        /// </summary>
        [JsonProperty("fx", NullValueHandling = NullValueHandling.Ignore)]
        public Models.FxObject Fx { get; set; }

        /// <summary>
        /// Gets or sets Links.
        /// </summary>
        [JsonProperty("links", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.HaetosParams> Links { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TransferResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is TransferResponse other &&
                ((this.SourceToken == null && other.SourceToken == null) || (this.SourceToken?.Equals(other.SourceToken) == true)) &&
                ((this.DestinationToken == null && other.DestinationToken == null) || (this.DestinationToken?.Equals(other.DestinationToken) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.Memo == null && other.Memo == null) || (this.Memo?.Equals(other.Memo) == true)) &&
                ((this.DestinationAmount == null && other.DestinationAmount == null) || (this.DestinationAmount?.Equals(other.DestinationAmount) == true)) &&
                ((this.DestinationCurrency == null && other.DestinationCurrency == null) || (this.DestinationCurrency?.Equals(other.DestinationCurrency) == true)) &&
                ((this.ClientTransferId == null && other.ClientTransferId == null) || (this.ClientTransferId?.Equals(other.ClientTransferId) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.SourceAmount == null && other.SourceAmount == null) || (this.SourceAmount?.Equals(other.SourceAmount) == true)) &&
                ((this.SourceCurrency == null && other.SourceCurrency == null) || (this.SourceCurrency?.Equals(other.SourceCurrency) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Fx == null && other.Fx == null) || (this.Fx?.Equals(other.Fx) == true)) &&
                ((this.Links == null && other.Links == null) || (this.Links?.Equals(other.Links) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 184730691;

            if (this.SourceToken != null)
            {
               hashCode += this.SourceToken.GetHashCode();
            }

            if (this.DestinationToken != null)
            {
               hashCode += this.DestinationToken.GetHashCode();
            }

            if (this.Notes != null)
            {
               hashCode += this.Notes.GetHashCode();
            }

            if (this.Memo != null)
            {
               hashCode += this.Memo.GetHashCode();
            }

            if (this.DestinationAmount != null)
            {
               hashCode += this.DestinationAmount.GetHashCode();
            }

            if (this.DestinationCurrency != null)
            {
               hashCode += this.DestinationCurrency.GetHashCode();
            }

            if (this.ClientTransferId != null)
            {
               hashCode += this.ClientTransferId.GetHashCode();
            }

            if (this.Token != null)
            {
               hashCode += this.Token.GetHashCode();
            }

            if (this.SourceAmount != null)
            {
               hashCode += this.SourceAmount.GetHashCode();
            }

            if (this.SourceCurrency != null)
            {
               hashCode += this.SourceCurrency.GetHashCode();
            }

            if (this.Status != null)
            {
               hashCode += this.Status.GetHashCode();
            }

            if (this.Fx != null)
            {
               hashCode += this.Fx.GetHashCode();
            }

            if (this.Links != null)
            {
               hashCode += this.Links.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SourceToken = {(this.SourceToken == null ? "null" : this.SourceToken == string.Empty ? "" : this.SourceToken)}");
            toStringOutput.Add($"this.DestinationToken = {(this.DestinationToken == null ? "null" : this.DestinationToken == string.Empty ? "" : this.DestinationToken)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.Memo = {(this.Memo == null ? "null" : this.Memo == string.Empty ? "" : this.Memo)}");
            toStringOutput.Add($"this.DestinationAmount = {(this.DestinationAmount == null ? "null" : this.DestinationAmount.ToString())}");
            toStringOutput.Add($"this.DestinationCurrency = {(this.DestinationCurrency == null ? "null" : this.DestinationCurrency.ToString())}");
            toStringOutput.Add($"this.ClientTransferId = {(this.ClientTransferId == null ? "null" : this.ClientTransferId == string.Empty ? "" : this.ClientTransferId)}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.SourceAmount = {(this.SourceAmount == null ? "null" : this.SourceAmount.ToString())}");
            toStringOutput.Add($"this.SourceCurrency = {(this.SourceCurrency == null ? "null" : this.SourceCurrency.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status.ToString())}");
            toStringOutput.Add($"this.Fx = {(this.Fx == null ? "null" : this.Fx.ToString())}");
            toStringOutput.Add($"this.Links = {(this.Links == null ? "null" : $"[{string.Join(", ", this.Links)} ]")}");
        }
    }
}