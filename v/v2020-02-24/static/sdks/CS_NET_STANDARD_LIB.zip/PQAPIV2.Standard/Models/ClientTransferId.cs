// <copyright file="ClientTransferId.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace PQAPIV2.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using PQAPIV2.Standard;
    using PQAPIV2.Standard.Utilities;

    /// <summary>
    /// ClientTransferId.
    /// </summary>
    public class ClientTransferId
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientTransferId"/> class.
        /// </summary>
        public ClientTransferId()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientTransferId"/> class.
        /// </summary>
        /// <param name="clientTransferIdProp">clientTransferId.</param>
        public ClientTransferId(
            string clientTransferIdProp = null)
        {
            this.ClientTransferIdProp = clientTransferIdProp;
        }

        /// <summary>
        /// Unique value provided by the client for the transfer.
        /// </summary>
        [JsonProperty("clientTransferId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientTransferIdProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientTransferId : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ClientTransferId other &&
                ((this.ClientTransferIdProp == null && other.ClientTransferIdProp == null) || (this.ClientTransferIdProp?.Equals(other.ClientTransferIdProp) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1943905852;

            if (this.ClientTransferIdProp != null)
            {
               hashCode += this.ClientTransferIdProp.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientTransferIdProp = {(this.ClientTransferIdProp == null ? "null" : this.ClientTransferIdProp == string.Empty ? "" : this.ClientTransferIdProp)}");
        }
    }
}